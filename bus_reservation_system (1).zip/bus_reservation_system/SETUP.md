# Victory Liner Bus Reservation System - Quick Start Guide

## Installation Steps

### 1. Download & Extract Files
- Extract the `bus_reservation_system` folder to `C:\xampp\htdocs\`

### 2. Start XAMPP
- Open XAMPP Control Panel
- Click "Start" for Apache
- Click "Start" for MySQL
- Wait until both are running (green lights)

### 3. Create Database
**Method A: Using phpMyAdmin (Recommended)**
1. Open browser and go to: `http://localhost/phpmyadmin`
2. In left panel, click "New"
3. Type database name: `bus_reservation_db`
4. Click "Create"
5. Click on the new database name
6. Click "Import" tab
7. Click "Choose File" and select `database.sql` from the project
8. Click "Go/Import"

**Method B: Using Command Line**
```
cd C:\xampp\mysql\bin
mysql -u root -p
CREATE DATABASE bus_reservation_db;
USE bus_reservation_db;
source C:/xampp/htdocs/bus_reservation_system/database.sql;
```

### 4. Verify Database
- In phpMyAdmin, click `bus_reservation_db`
- You should see tables like: users, buses, schedules, bookings, etc.

### 4.1 Apply application schema updates
After importing the database, and after each application update that changes the schema, run this from the project folder in PowerShell:
```powershell
C:\xampp\php\php.exe scripts\prepare_system.php
```
This applies the current schema version, including passenger discount ID proof fields. Normal website requests do not run schema migrations.

### 4.2 Apply the Current Gonzaga Daily Schedule
After importing the database, run this from the project folder so the live Gonzaga trips are generated for the next 30 days:
```
php scripts\sync_gonzaga_daily_schedule.php

### 4.3 Keep Daily Recurring Schedules Running Automatically

New schedules can be marked **Automatically continue this schedule every day** in Admin → Schedule Management. The system immediately fills the booking window and refreshes it during normal site activity.

For guaranteed unattended refreshes, create a Windows Task Scheduler task that runs every 5 to 15 minutes:

```powershell
php C:\xampp\htdocs\bus_reservation_system\scripts\run_schedule_recurrences.php
```

The runner is safe to execute repeatedly: it only creates missing future departures, refuses a duplicate route/date/departure-time slot, and skips bus or driver conflicts.
```

### 5. Access the Application
- Customer Portal: `http://localhost/bus_reservation_system/`
- Admin Panel: `http://localhost/bus_reservation_system/admin/dashboard.php`

## Initial Accounts

No default credentials are included. Create the first administrator during deployment and create passenger test accounts through the registration page.

## What You Can Do

### As a Customer
1. Register a new account
2. Search for buses by date/route
3. Book a ticket
4. Add passenger details
5. Make payment
6. View your bookings
7. Cancel bookings (if allowed)
8. Update your profile

### As an Admin
1. Manage buses and bus classes
2. Create schedules and set prices
3. Manage terminals and routes
4. View all bookings
5. Manage customer accounts
6. Set fares for different routes
7. Add FAQ and content
8. View revenue and statistics

## Navigation

### Customer Menu
- **Home** - Landing page with features
- **Online Booking** - Search and book buses
- **Schedules** - View all available schedules
- **Bus Route** - View all routes
- **Terminals** - View terminal locations
- **Bus Fares** - View pricing
- **FAQ** - Frequently asked questions
- **Travel Guides** - Travel tips and guides
- **Blog** - News and updates
- **Login/Register** - User account management
- **Profile** - View and edit profile
- **My Bookings** - View your bookings
- **Logout** - Sign out

### Admin Menu
- **Dashboard** - Overview and statistics
- **Manage Buses** - Add/edit/delete buses
- **Manage Schedules** - Create bus schedules
- **Manage Routes** - View route information
- **Manage Terminals** - Add/edit terminals
- **Manage Fares** - View and manage fares
- **Manage Bookings** - View and update bookings
- **Manage Users** - View customer accounts
- **Manage FAQ** - Add/edit FAQ

## Booking Process

1. **Search**: Go to "Online Booking" → Select origin, destination, date, class
2. **Select**: Choose a schedule from the list
3. **Confirm**: Review booking details and click "Continue to Passenger Details"
4. **Add Passengers**: Enter details for each passenger
5. **Payment**: Choose payment method and click "Complete Payment"
6. **Confirmation**: Receive booking reference number

## Color Scheme
- **Primary Red**: #A72D2D (Accent color)
- **Dark Navy**: #1a1a2e (Headers/Sidebars)
- **Yellow**: #ffc107 (Buttons/Highlights)
- **Green**: #28a745 (Success messages)
- **Red**: #dc3545 (Error messages)

## File Locations
- Database config: `includes/config.php`
- Stylesheet: `assets/css/style.css`
- JavaScript: `assets/js/script.js`
- Database schema: `database.sql`

## Important Notes
1. Make sure both Apache and MySQL are running in XAMPP
2. Default database user is `root` with no password
3. Email notifications are not configured (can be added later)
4. Payment processing is simulated (connect to real gateway for production)
5. Always backup your database regularly

## Troubleshooting

**Problem**: "Connection failed" error
**Solution**: 
- Check MySQL is running (green in XAMPP)
- Verify config.php has correct credentials

**Problem**: Can't login as admin
**Solution**:
- Check database has admin user (email: admin@victoryliner.com)
- Clear browser cookies
- Try different browser

**Problem**: Images not showing
**Solution**:
- Create `assets/images/` folder if it doesn't exist
- Add placeholder images to folder

**Problem**: Bookings not saving
**Solution**:
- Check MySQL is running
- Verify database has bookings table
- Check file permissions on server

## Next Steps for Development

1. Add email notifications (PHPMailer)
2. Integrate real payment gateway (Stripe, Maya Checkout)
3. Add SMS notifications
4. Create mobile app
5. Add customer support chat
6. Implement loyalty points
7. Add online refund system
8. Create advanced reporting

## Support
For any issues:
1. Check the README.md for detailed information
2. Review database.sql for schema
3. Check includes/config.php for database settings
4. Test admin login first
5. Clear browser cache and try again

---

**Happy Booking! Welcome to Victory Liner Bus Reservation System!**

