# Context-Level Diagram

This context-level diagram is based on the current implemented system behavior in the codebase, especially the live app name in `includes/system_bootstrap.php`, the payment flow in `payment.php`, the staff scanner in `admin/pages/ticket-scanner.php`, and the schema in `database.sql`.

If your instructor wants a stricter DFD context diagram, you can remove the database node because data stores are often expanded in Level 1 instead of the context level.

```mermaid
flowchart TB
    P[Passengers / Customers]
    A[Admin / Management]
    S([Gonzaga Terminal Bus Reservation System])
    G[GCash / Payment Channel]
    O[Operations Staff / Terminal Counter]
    D[(Bus Reservation Database)]

    P -->|Registration, trip search, booking details, passenger info| S
    S -->|Schedules, fares, booking reference, e-ticket, notifications| P

    A -->|Manage buses, terminals, routes, schedules, fares, users| S
    S -->|Dashboard, reports, booking records, audit logs| A

    G -->|Payment proof / reference| S
    S -->|GCash number and payment instructions| G

    O -->|Payment approval, cash confirmation, QR scans, seat changes| S
    S -->|Pending payments, claim codes, ticket validation results| O

    S <--> |Users, schedules, bookings, payments, tickets| D

    style S fill:#ffffff,stroke:#444,stroke-width:2px,color:#111
    style P fill:#ffffff,stroke:#444,stroke-width:1.5px,color:#111
    style A fill:#ffffff,stroke:#444,stroke-width:1.5px,color:#111
    style G fill:#ffffff,stroke:#444,stroke-width:1.5px,color:#111
    style O fill:#ffffff,stroke:#444,stroke-width:1.5px,color:#111
    style D fill:#ffffff,stroke:#444,stroke-width:1.5px,color:#111
```
 