# Deployment and Defense Checklist

## Before publishing

1. Import `database.sql` into a new MySQL database.
2. Configure the `BUS_*` environment values from `.env.example`; use a restricted database user and a random `BUS_QR_SECRET` of at least 64 characters.
3. From the project directory, run `php scripts/prepare_system.php`.
4. Create the first administrator with `php scripts/create_initial_admin.php --email=admin@example.com --name="Terminal Administrator"` and use a unique password of at least 12 characters.
5. Ensure Apache serves the project over HTTPS. Confirm that `BUS_APP_ENV=production`, error display is disabled, and `BUS_RUN_SCHEMA_MIGRATIONS_ON_WEB=false`.
6. Schedule `php scripts/run_schedule_recurrences.php` every 5–15 minutes using Windows Task Scheduler or cron.
7. Back up the MySQL database and `storage/payment-proofs` before deployment and test a restore.

## What to demonstrate

- Passenger registration, secure sign-in, schedule search, seat selection, payment submission, and e-ticket viewing.
- Admin/staff role separation, payment review, QR ticket validation, audit logs, reports, and schedule management.
- Protections: CSRF validation, prepared database helpers, bcrypt password hashing with legacy upgrade, session renewal on login, rate-limited sign-in, protected payment proofs, upload MIME/size validation, and security response headers.
- Reliability: seats are enforced by a unique schedule-and-seat constraint; schema changes and recurring schedule jobs run outside visitor requests to keep page loads responsive.

## Quick smoke test

1. Register a passenger and sign in.
2. Search a valid route for today or the next three days.
3. Create a booking, add passengers, and submit a valid payment proof or select terminal cash.
4. Sign in as staff/admin, approve the payment or confirm cash, then open and scan the ticket.
5. Confirm the booking appears in the passenger dashboard, the payment queue, and the audit log.

Do not use real payment details or passenger personal data in a defense demonstration.
