<?php
$base_url = '';
$page_title = 'Booking Details';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$bookingId = (int) ($_REQUEST['booking_id'] ?? isset_get('booking_id'));
if ($bookingId < 1) {
    redirect('my-bookings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_post('action') === 'cancel_booking') {
    $result = cancel_booking_by_user($bookingId, (int) $_SESSION['user_id']);
    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('booking-view.php?booking_id=' . $bookingId);
}

$error = consume_flash('error');
$success = consume_flash('success');

$booking = db_select_one(
    "SELECT b.*, s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time, s.price,
            bus.bus_code, bus.bus_name, bus.bus_type,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN buses bus ON s.bus_id = bus.bus_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.booking_id = ?
     LIMIT 1",
    'i',
    [$bookingId]
);

if (!$booking) {
    redirect('my-bookings.php');
}

if (!can_access_admin_panel() && (int) $booking['user_id'] !== (int) $_SESSION['user_id']) {
    redirect('my-bookings.php');
}

$isOwnerView = (int) $booking['user_id'] === (int) ($_SESSION['user_id'] ?? 0);

// Repair tickets for completed legacy payments before loading the ticket
// list, so older paid bookings can still open a valid e-ticket.
if (($booking['payment_status'] ?? '') === 'paid'
    || db_select_one(
        'SELECT payment_id FROM payments WHERE booking_id = ? AND status = "paid" LIMIT 1',
        'i',
        [$bookingId]
    )) {
    ensure_paid_booking_tickets($bookingId);
    $booking = db_select_one(
        "SELECT b.*, s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time, s.price,
                bus.bus_code, bus.bus_name, bus.bus_type,
                origin.terminal_name AS origin_name,
                destination.terminal_name AS destination_name
         FROM bookings b
         JOIN schedules s ON b.schedule_id = s.schedule_id
         JOIN buses bus ON s.bus_id = bus.bus_id
         JOIN routes r ON s.route_id = r.route_id
         JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
         JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
         WHERE b.booking_id = ?
         LIMIT 1",
        'i',
        [$bookingId]
    ) ?: $booking;
}

$passengers = db_select_all(
    'SELECT * FROM passengers WHERE booking_id = ? ORDER BY passenger_id ASC',
    'i',
    [$bookingId]
);

$tickets = db_select_all(
    'SELECT t.*, s.seat_label, p.fullname AS passenger_name, p.email AS passenger_email
     FROM tickets t
     JOIN seats s ON t.seat_id = s.seat_id
     LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
     WHERE t.booking_id = ?
     ORDER BY s.seat_number ASC',
    'i',
    [$bookingId]
);

$usedTicketCount = count(array_filter($tickets, static fn($ticket) => ($ticket['ticket_status'] ?? '') === 'used'));
$missedPaidTrip = booking_is_missed_paid_trip($booking + ['used_ticket_count' => $usedTicketCount]);
$timeline = booking_live_countdown_context($booking + ['used_ticket_count' => $usedTicketCount]);
$cancellationState = booking_user_cancellation_state($booking + ['used_ticket_count' => $usedTicketCount]);
$canCancelBooking = $isOwnerView && (bool) ($cancellationState['can_cancel'] ?? false);
$needsStaffAssistance = (bool) ($cancellationState['needs_staff_assistance'] ?? false);
$effectiveTripStatus = (string) ($timeline['effective_trip_status'] ?? 'scheduled');
$effectiveScheduleStatus = (string) ($timeline['effective_schedule_status'] ?? ((string) ($booking['schedule_status'] ?? 'scheduled')));
$tripChipClass = match ($effectiveTripStatus) {
    'boarding' => 'warning',
    'departed' => 'soft',
    'arrived' => 'success',
    'cancelled' => 'danger',
    default => 'soft',
};
$statusLabel = $missedPaidTrip ? 'Missed' : ucwords(str_replace('_', ' ', (string) ($booking['status'] ?? '')));
$statusClass = $missedPaidTrip
    ? 'warning'
    : (in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true)
        ? 'success'
        : (((string) ($booking['status'] ?? '') === 'payment_review' || (string) ($booking['status'] ?? '') === 'pending') ? 'warning' : 'danger'));
$paymentClass = ((string) ($booking['payment_status'] ?? '') === 'paid')
    ? 'success'
    : (((string) ($booking['payment_status'] ?? '') === 'pending') ? 'warning' : 'danger');

$cashClaimActive = ($booking['payment_method'] ?? '') === 'cash'
    && ($booking['payment_status'] ?? '') !== 'paid'
    && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)
    && ((string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled');
$cashClaimBundle = $cashClaimActive ? build_cash_claim_payload($booking) : null;
$cashClaimCode = (string) (($cashClaimBundle['claim_code'] ?? '') ?: ($booking['claim_code'] ?? ''));
$preferredSeatLabels = decode_booking_seat_preferences($booking['seat_preferences'] ?? '');
$finalTicketReady = !$missedPaidTrip
    && (string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled'
    && ($booking['payment_status'] ?? '') === 'paid'
    && $tickets !== [];
$departureTimestamp = $timeline['departure_timestamp'];
$cashClaimGone = $cashClaimActive && $departureTimestamp !== null && $departureTimestamp <= time();
if ($cashClaimGone) {
    $cashClaimActive = false;
    $cashClaimBundle = null;
}
$canCompletePayment = $isOwnerView
    && in_array((string) ($booking['status'] ?? ''), ['pending', 'payment_review'], true)
    && (string) ($booking['payment_status'] ?? '') !== 'paid'
    && (string) ($booking['payment_method'] ?? '') !== 'cash';

$bookingHeading = $missedPaidTrip
    ? 'Missed Trip Details'
    : ($cashClaimGone
        ? 'Booking Details'
        : ($cashClaimActive ? 'Booking and Terminal Cash Ticket' : 'Booking and E-Ticket'));
$bookingLeadMessage = $missedPaidTrip
    ? 'This paid trip already departed and was not marked as used. You may remove it from your booking history.'
    : ($finalTicketReady
        ? 'Print this page or save it as PDF for boarding.'
        : ($cashClaimGone
            ? 'This trip already left. Manual staff or admin action is needed to close this unpaid cash ticket.'
            : ($cashClaimActive
                ? 'Show this terminal cash ticket to staff before the scheduled departure time.'
                : 'Review your booking details, countdown, and cancellation window here.')));
$claimDeadlineLabel = !empty($booking['expires_at'])
    ? date('M j, Y g:i A', strtotime((string) $booking['expires_at']))
    : (!empty($booking['departure_date']) && !empty($booking['departure_time'])
        ? date('M j, Y g:i A', strtotime((string) ($booking['departure_date'] . ' ' . $booking['departure_time'])))
        : 'Departure time unavailable');

include 'includes/header.php';
?>

<style>
.ticket-qr-shell {
    align-items: center;
    background: linear-gradient(180deg, #ffffff, #f8fafc);
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1.25rem;
    display: flex;
    justify-content: center;
    min-height: 210px;
    padding: 1rem;
}
.qr-canvas {
    align-items: center;
    background: #ffffff;
    border-radius: 1rem;
    box-shadow: 0 18px 35px rgba(15, 23, 42, 0.12);
    display: flex;
    height: 180px;
    justify-content: center;
    padding: 14px;
    width: 180px;
}
.qr-canvas canvas,
.qr-canvas img {
    display: block;
    height: 100% !important;
    image-rendering: pixelated;
    max-width: 100%;
    width: 100% !important;
}
.booking-detail-hero {
    background: linear-gradient(135deg, rgba(16, 32, 59, 0.98), rgba(180, 35, 24, 0.96));
    border: 0;
    color: #fff;
}
.countdown-shell {
    background: linear-gradient(180deg, #fff7ed, #fff);
    border: 1px solid rgba(251, 146, 60, 0.24);
    border-radius: 1.35rem;
}
.countdown-grid {
    display: grid;
    gap: 0.75rem;
    grid-template-columns: repeat(4, minmax(0, 1fr));
}
.countdown-unit {
    background: #ffffff;
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1rem;
    padding: 1rem 0.75rem;
    text-align: center;
}
.countdown-unit strong {
    color: #10203b;
    display: block;
    font-size: 1.55rem;
    line-height: 1;
}
.countdown-unit span {
    color: #64748b;
    display: block;
    font-size: 0.78rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    margin-top: 0.45rem;
    text-transform: uppercase;
}
@media (max-width: 767px) {
    .ticket-qr-shell {
        min-height: 180px;
    }
    .qr-canvas {
        height: 160px;
        width: 160px;
    }
    .countdown-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}
</style>

<section class="py-5">
    <div class="container">
        <div class="card booking-detail-hero rounded-4 shadow-lg overflow-hidden mb-4">
            <div class="card-body p-4 p-lg-5">
                <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
                    <div>
                        <span class="badge rounded-pill text-bg-light text-danger fw-semibold mb-3">Passenger Booking Center</span>
                        <h1 class="display-6 fw-bold mb-1"><?php echo e($bookingHeading); ?></h1>
                        <p class="mb-0 text-white-50"><?php echo e($bookingLeadMessage); ?></p>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <a class="btn btn-outline-light rounded-4 fw-semibold" href="my-bookings.php">
                            <i class="fa-solid fa-arrow-left me-2"></i>Back to My Bookings
                        </a>
                        <?php if ($canCompletePayment): ?>
                            <a class="btn btn-light text-danger rounded-4 fw-semibold" href="payment.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                <i class="fa-solid fa-wallet me-2"></i>Complete Payment
                            </a>
                        <?php endif; ?>
                        <?php if ($finalTicketReady || $cashClaimActive): ?>
                            <button class="btn btn-light text-danger rounded-4 fw-semibold" onclick="window.print()">
                                <i class="fa-solid fa-print me-2"></i>Print / Save PDF
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="d-flex flex-wrap gap-2">
                    <span class="chip <?php echo e($statusClass); ?>"><?php echo e($statusLabel); ?></span>
                    <span class="chip <?php echo e($paymentClass); ?>"><?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['payment_status'] ?? '')))); ?></span>
                    <span class="chip <?php echo e($tripChipClass); ?>"><?php echo e(ucfirst($effectiveTripStatus)); ?></span>
                </div>
            </div>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger rounded-4 mb-4"><?php echo e($error); ?></div>
        <?php endif; ?>
        <?php if ($success !== ''): ?>
            <div class="alert alert-success rounded-4 mb-4"><?php echo e($success); ?></div>
        <?php endif; ?>

        <?php if ((bool) ($timeline['is_live'] ?? false)): ?>
            <div class="countdown-shell p-3 p-lg-4 mb-4">
                <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
                    <div>
                        <div class="small text-uppercase text-muted fw-semibold mb-1"><?php echo e((string) ($timeline['label'] ?? 'Live countdown')); ?></div>
                        <div class="fw-semibold"><?php echo e((string) ($timeline['note'] ?? '')); ?></div>
                    </div>
                    <?php if ($canCancelBooking): ?>
                        <form method="post" onsubmit="return confirm('Cancel this booking?');">
                            <?php csrf_field(); ?>
                            <input type="hidden" name="action" value="cancel_booking">
                            <input type="hidden" name="booking_id" value="<?php echo (int) $booking['booking_id']; ?>">
                            <button class="btn btn-outline-danger rounded-4 fw-semibold" type="submit">
                                <i class="fa-solid fa-ban me-2"></i>Cancel Booking
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
                <div
                    class="countdown-grid live-countdown"
                    data-countdown-target="<?php echo (int) ($timeline['target_timestamp'] ?? 0); ?>"
                    data-expired-label="<?php echo e((string) ($timeline['expired_label'] ?? 'Closed')); ?>"
                >
                    <div class="countdown-unit"><strong data-unit="days">00</strong><span>Days</span></div>
                    <div class="countdown-unit"><strong data-unit="hours">00</strong><span>Hours</span></div>
                    <div class="countdown-unit"><strong data-unit="minutes">00</strong><span>Minutes</span></div>
                    <div class="countdown-unit"><strong data-unit="seconds">00</strong><span>Seconds</span></div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($cashClaimGone): ?>
            <div class="alert alert-warning rounded-4 mb-4">
                This trip already left. This unpaid cash ticket is no longer usable and must be cleared manually by staff or admin.
            </div>
        <?php elseif ($missedPaidTrip): ?>
            <div class="alert alert-warning rounded-4 mb-4">
                This paid trip already departed and was not marked as used. The e-ticket is no longer active for boarding. You may remove this record from My Bookings, and you should contact terminal staff for any manual assistance.
            </div>
        <?php elseif ($cashClaimActive): ?>
            <div class="alert alert-warning rounded-4 mb-4">
                This pay at terminal booking is still waiting for terminal payment. Show this terminal cash ticket to the staff before <strong><?php echo e($claimDeadlineLabel); ?></strong>. The final seat and e-ticket will only appear after payment is confirmed. If you want a different seat, request it directly from the staff before payment is confirmed.
            </div>
        <?php elseif ($needsStaffAssistance): ?>
            <div class="alert alert-secondary rounded-4 mb-4">
                <?php echo e((string) ($cancellationState['message'] ?? 'This trip already needs terminal staff assistance.')); ?>
            </div>
        <?php elseif ((string) ($timeline['note'] ?? '') !== '' && !(bool) ($timeline['is_live'] ?? false)): ?>
            <div class="alert alert-light border rounded-4 mb-4">
                <?php echo e((string) ($timeline['note'] ?? '')); ?>
            </div>
        <?php endif; ?>

        <div class="card border-0 shadow-lg rounded-4 overflow-hidden mb-4">
            <div class="card-header border-0 text-white p-4" style="background:linear-gradient(135deg,#10203b,#b42318);">
                <div class="d-flex flex-wrap justify-content-between gap-3">
                    <div>
                        <div class="small text-white-50"><?php echo $cashClaimActive ? 'Cash Ticket Code' : 'Booking Reference'; ?></div>
                        <div class="h3 fw-bold mb-0"><?php echo e($cashClaimActive ? $cashClaimCode : $booking['booking_reference']); ?></div>
                    </div>
                    <div class="text-end">
                        <div class="small text-white-50">Trip Route</div>
                        <div class="h5 fw-semibold mb-0"><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                    </div>
                </div>
            </div>
            <div class="card-body p-4">
                <div class="row g-4">
                    <div class="col-lg-7">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="small text-muted">Travel Date</div>
                                <div class="fw-semibold"><?php echo date('F j, Y', strtotime((string) $booking['departure_date'])); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Booking Status</div>
                                <div class="fw-semibold"><?php echo e($statusLabel); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Departure</div>
                                <div class="fw-semibold"><?php echo date('g:i A', strtotime((string) $booking['departure_time'])); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Arrival</div>
                                <div class="fw-semibold"><?php echo date('g:i A', strtotime((string) $booking['arrival_time'])); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Bus</div>
                                <div class="fw-semibold"><?php echo e($booking['bus_name'] ?: $booking['bus_code']); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Bus Type</div>
                                <div class="fw-semibold"><?php echo e($booking['bus_type']); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Payment</div>
                                <div class="fw-semibold text-uppercase"><?php echo e((string) ($booking['payment_method'] ?: 'pending')); ?> / <?php echo e((string) $booking['payment_status']); ?></div>
                            </div>
                            <div class="col-md-6">
                                <div class="small text-muted">Trip Progress</div>
                                <div class="fw-semibold"><?php echo e(ucfirst($effectiveTripStatus)); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="rounded-4 p-4 h-100" style="background:#f8fafc;">
                            <div class="small text-muted"><?php echo $cashClaimActive ? 'Claim Summary' : 'Ticket Summary'; ?></div>
                            <div class="display-6 fw-bold text-danger">PHP <?php echo number_format((float) $booking['total_amount'], 2); ?></div>
                            <?php if ($cashClaimActive): ?>
                                <div class="small text-muted mt-2"><?php echo (int) $booking['number_of_passengers']; ?> passenger(s) | terminal cash ticket</div>
                            <?php else: ?>
                                <div class="small text-muted mt-2"><?php echo (int) $booking['number_of_passengers']; ?> passenger(s) | <?php echo count($tickets); ?> ticket(s)</div>
                            <?php endif; ?>
                            <div class="small text-muted mt-3">Booked On</div>
                            <div class="fw-semibold"><?php echo date('M j, Y g:i A', strtotime((string) $booking['booking_date'])); ?></div>
                            <?php if ($canCancelBooking): ?>
                                <div class="small text-muted mt-3">Cancellation Policy</div>
                                <div class="fw-semibold"><?php echo e((string) ($cancellationState['message'] ?? '')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <h2 class="h5 fw-bold mb-3">Passenger List</h2>
                        <?php if ($passengers === []): ?>
                            <p class="text-muted mb-0">Passenger details are still being completed.</p>
                        <?php else: ?>
                            <div class="d-grid gap-3">
                                <?php foreach ($passengers as $passenger): ?>
                                    <div class="border rounded-4 p-3">
                                        <div class="fw-semibold"><?php echo e($passenger['fullname']); ?></div>
                                        <div class="text-muted small"><?php echo e($passenger['email']); ?></div>
                                        <div class="small mt-2"><?php echo $cashClaimActive ? 'Preferred Seat' : 'Seat'; ?>: <strong><?php echo e($passenger['seat_number']); ?></strong></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="card border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h2 class="h5 fw-bold mb-0"><?php echo $cashClaimActive ? 'Terminal Cash Ticket' : 'E-Tickets'; ?></h2>
                            <?php if ($finalTicketReady): ?>
                                <span class="chip success">Ready for QR scan</span>
                            <?php elseif ($cashClaimActive): ?>
                                <span class="chip warning">Pending Terminal Payment</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($cashClaimActive && $cashClaimBundle): ?>
                            <div class="border rounded-4 p-3">
                                <div class="row g-3 align-items-center">
                                    <div class="col-md-8">
                                        <div class="small text-muted">Cash Ticket Code</div>
                                        <div class="fw-semibold"><?php echo e($cashClaimCode !== '' ? $cashClaimCode : 'Pending code'); ?></div>
                                        <div class="mt-2 small text-muted">Preferred Seats</div>
                                        <div class="fw-semibold"><?php echo e($preferredSeatLabels !== [] ? implode(', ', $preferredSeatLabels) : 'Seat will be assigned at the terminal'); ?></div>
                                        <div class="mt-2 small text-muted">Ticket Status</div>
                                        <div class="fw-semibold text-uppercase">Pending Terminal Payment</div>
                                        <div class="mt-2 small text-muted">Valid Until Departure</div>
                                        <div class="fw-semibold"><?php echo e($claimDeadlineLabel); ?></div>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <div class="ticket-qr-shell">
                                            <div class="qr-canvas mx-auto" data-qr="<?php echo e($cashClaimBundle['qr_text']); ?>"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php elseif ($tickets === []): ?>
                            <p class="text-muted mb-0">No active tickets yet.</p>
                        <?php else: ?>
                            <div class="d-grid gap-3">
                                <?php foreach ($tickets as $ticket): ?>
                                    <?php
                                    $qrText = (string) ($ticket['ticket_code'] ?? '');
                                    if ($qrText === '' && !empty($ticket['qr_payload']) && !empty($ticket['qr_signature'])) {
                                        $qrText = json_encode(['payload' => $ticket['qr_payload'], 'sig' => $ticket['qr_signature']], JSON_UNESCAPED_SLASHES);
                                    }
                                    ?>
                                    <div class="border rounded-4 p-3">
                                        <div class="row g-3 align-items-center">
                                            <div class="col-md-8">
                                                <div class="small text-muted">Ticket Code</div>
                                                <div class="fw-semibold"><?php echo e($ticket['ticket_code'] ?: 'Pending issuance'); ?></div>
                                                <div class="mt-2 small text-muted">Passenger</div>
                                                <div class="fw-semibold"><?php echo e($ticket['passenger_name'] ?: 'Passenger pending'); ?></div>
                                                <div class="mt-2 small text-muted">Seat</div>
                                                <div class="fw-semibold"><?php echo e($ticket['seat_label']); ?></div>
                                                <div class="mt-2 small text-muted">Ticket Status</div>
                                                <div class="fw-semibold text-uppercase"><?php echo e((string) $ticket['ticket_status']); ?></div>
                                                <?php if ($qrText !== '' && ($ticket['ticket_code'] ?? '') !== ''): ?>
                                                    <div class="mt-2 small text-muted">QR content</div>
                                                    <div class="small fw-semibold"><?php echo e($ticket['ticket_code']); ?></div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-4 text-center">
                                                <?php if ($qrText !== '' && $finalTicketReady): ?>
                                                    <div class="ticket-qr-shell">
                                                        <div class="qr-canvas mx-auto" data-qr="<?php echo e($qrText); ?>"></div>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="small text-muted">QR will appear after confirmation.</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.qr-canvas').forEach(function (node) {
        const qrText = node.dataset.qr;
        if (!qrText) {
            return;
        }

        node.innerHTML = '';

        new QRCode(node, {
            text: qrText,
            width: 164,
            height: 164,
            colorDark: '#10203b',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
        });
    });

    const countdowns = Array.from(document.querySelectorAll('.live-countdown'));
    if (countdowns.length === 0) {
        return;
    }

    function updateCountdown(node) {
        const targetSeconds = Number(node.dataset.countdownTarget || '0');
        const targetMillis = targetSeconds * 1000;
        const remaining = Math.max(0, targetMillis - Date.now());
        const totalSeconds = Math.floor(remaining / 1000);
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const values = {
            days: String(days).padStart(2, '0'),
            hours: String(hours).padStart(2, '0'),
            minutes: String(minutes).padStart(2, '0'),
            seconds: String(seconds).padStart(2, '0')
        };

        Object.keys(values).forEach(function (key) {
            const target = node.querySelector('[data-unit="' + key + '"]');
            if (target) {
                target.textContent = values[key];
            }
        });
    }

    function tickAll() {
        countdowns.forEach(updateCountdown);
    }

    tickAll();
    window.setInterval(tickAll, 1000);
});
</script>

<?php include 'includes/footer.php'; ?>
