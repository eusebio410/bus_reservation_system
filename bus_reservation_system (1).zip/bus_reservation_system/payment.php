<?php
$base_url = '';
$page_title = 'Payment';
include 'includes/config.php';

$bookingId = (int) isset_get('booking_id');
$paymentReturnState = isset_get('payment_return');
$paymentRetryCount = max(0, min(12, (int) isset_get('payment_retry')));
$paymentReturnNeedsRetry = false;

// Older PayMongo sessions still return to payment.php with this query value.
// Send those legacy cancel/back returns to the homepage as well.
if (isset_get('payment_return') === 'cancelled') {
    redirect('index.php');
}

if ($bookingId < 1) {
    redirect('my-bookings.php');
}

// PayMongo can return the customer without the original site session (for
// example after a cross-site browser handoff). Reconcile the signed gateway
// result before requiring login so a paid checkout cannot remain pending just
// because the browser cookie was not sent back.
$paymentReturnMessage = '';
if ($paymentReturnState === 'success') {
    $pendingCheckout = db_select_one(
        'SELECT provider_checkout_id FROM payments
         WHERE booking_id = ? AND provider = "paymongo" AND payment_method = "qrph"
           AND status IN ("pending", "failed") AND provider_checkout_id IS NOT NULL
         ORDER BY payment_id DESC LIMIT 1',
        'i',
        [$bookingId]
    );
    if ($pendingCheckout && trim((string) ($pendingCheckout['provider_checkout_id'] ?? '')) !== '') {
        $confirmation = confirm_paymongo_checkout((string) $pendingCheckout['provider_checkout_id']);
        if (!$confirmation['ok']) {
            $paymentReturnMessage = (string) ($confirmation['message'] ?? 'PayMongo is still confirming this payment.');
            $paymentReturnNeedsRetry = true;
        }
    }
}

if (!is_logged_in()) {
    if ($paymentReturnMessage !== '') {
        set_flash('error', $paymentReturnMessage);
    }
    redirect('login.php');
}

$bookingSummarySql = "SELECT b.*, s.departure_date, s.departure_time,
        origin.terminal_name AS origin_name,
        destination.terminal_name AS destination_name
 FROM bookings b
 JOIN schedules s ON b.schedule_id = s.schedule_id
 JOIN routes r ON s.route_id = r.route_id
 JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
 JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
 WHERE b.booking_id = ?
 LIMIT 1";

$booking = db_select_one(
    $bookingSummarySql,
    'i',
    [$bookingId]
);

if (!$booking) {
    redirect('my-bookings.php');
}

if (!can_access_admin_panel() && (int) $booking['user_id'] !== (int) $_SESSION['user_id']) {
    redirect('my-bookings.php');
}

// Older completed payments may already be marked paid while their ticket
// rows were never created. Repair those records when the customer revisits
// this booking, and keep the normal payment flow idempotent.
$ticketRepairMessage = '';
if (($booking['payment_status'] ?? '') === 'paid'
    || db_select_one(
        'SELECT payment_id FROM payments WHERE booking_id = ? AND status = "paid" LIMIT 1',
        'i',
        [$bookingId]
    )) {
    if (!ensure_paid_booking_tickets($bookingId)) {
        $ticketRepairMessage = 'Your payment was recorded, but the e-ticket could not be issued automatically. Please contact terminal staff.';
    }
    $booking = db_select_one($bookingSummarySql, 'i', [$bookingId]) ?: $booking;
}

if (($booking['payment_method'] ?? '') === 'cash' && empty($booking['claim_code'])) {
    $booking['claim_code'] = ensure_booking_claim_code($bookingId, (string) ($booking['claim_code'] ?? ''));
}

$latestPayment = db_select_one(
    'SELECT * FROM payments WHERE booking_id = ? ORDER BY submitted_at DESC, payment_id DESC LIMIT 1',
    'i',
    [$bookingId]
);
$passengerRow = db_select_one(
    'SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ?',
    'i',
    [$bookingId]
);
$passengerDetailsComplete = (int) ($passengerRow['total'] ?? 0) === (int) ($booking['number_of_passengers'] ?? 0) && (int) ($booking['number_of_passengers'] ?? 0) > 0;

// A failed browser handoff can leave a valid PayMongo checkout pending. Reuse
// that checkout so the page shows one working continue action after reload.
$pendingQrCheckoutUrl = '';
if ($latestPayment
    && ($latestPayment['status'] ?? '') === 'pending'
    && ($latestPayment['payment_method'] ?? '') === 'qrph'
    && filter_var((string) ($latestPayment['provider_checkout_url'] ?? ''), FILTER_VALIDATE_URL)) {
    $pendingQrCheckoutUrl = (string) $latestPayment['provider_checkout_url'];
}

$error = $paymentReturnMessage;
$discountStatusColumnExists = column_exists('passengers', 'discount_status');
$discountPayoutSchemaReady = column_exists('passengers', 'discount_cash_amount')
    && column_exists('passengers', 'discount_cash_status');
$discountReviewPending = $discountStatusColumnExists && (bool) db_select_one(
    'SELECT passenger_id FROM passengers WHERE booking_id = ? AND discount_status = "pending" LIMIT 1',
    'i',
    [$bookingId]
);
$discountReviewNotice = $discountReviewPending
    ? ($discountPayoutSchemaReady
        ? 'Pay the full fare securely through PayMongo. Staff can review the ID after payment; if approved, the bus operator will give the configured discount amount in cash at departure.'
        : 'PayMongo checkout is available, but discount cash payout setup is incomplete. Please contact terminal staff before relying on a discount payout.')
    : '';
$discountCashSummary = ['cash_due' => 0, 'cash_paid' => 0];
if ($discountPayoutSchemaReady && $discountStatusColumnExists) {
    $discountCashSummary = db_select_one(
        'SELECT COALESCE(SUM(CASE WHEN discount_cash_status = "due" THEN discount_cash_amount ELSE 0 END), 0) AS cash_due,
                COALESCE(SUM(CASE WHEN discount_cash_status = "paid" THEN discount_cash_amount ELSE 0 END), 0) AS cash_paid
         FROM passengers WHERE booking_id = ? AND discount_status = "approved"',
        'i',
        [$bookingId]
    ) ?: $discountCashSummary;
}
$success = consume_flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentMethod = isset_post('payment_method');

    if ($paymentMethod === 'qrph') {
        $result = start_gcash_checkout($bookingId);
        if ($result['ok'] && !empty($result['checkout_url'])) {
            set_flash('success', 'Your secure QRPh checkout is ready. Press Continue Secure QRPh Checkout to open PayMongo.');
            redirect('payment.php?booking_id=' . $bookingId);
        }
        $error = (string) ($result['message'] ?? 'Unable to start the secure GCash checkout.');
    } else {
        $result = submit_payment_for_booking($bookingId, $paymentMethod, (float) $booking['total_amount']);
        if ($result['ok']) {
            set_flash('success', (string) ($result['message'] ?? 'Payment submitted successfully.'));
            redirect('payment.php?booking_id=' . $bookingId);
        }
        $error = (string) ($result['message'] ?? 'Unable to submit payment.');
    }
}

$isInactive = in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true);
$tripLabel = '';
if (!empty($booking['origin_name']) || !empty($booking['destination_name'])) {
    $tripLabel = trim((string) ($booking['origin_name'] ?? ''));
    if (!empty($booking['destination_name'])) {
        $tripLabel = $tripLabel !== ''
            ? $tripLabel . ' to ' . (string) $booking['destination_name']
            : (string) $booking['destination_name'];
    }
}
$departureLabel = '';
$departurePassed = false;
if (!empty($booking['departure_date']) && !empty($booking['departure_time'])) {
    $departureTimestamp = strtotime((string) $booking['departure_date'] . ' ' . (string) $booking['departure_time']);
    if ($departureTimestamp !== false) {
        $departureLabel = date('M j, Y g:i A', $departureTimestamp);
        $departurePassed = $departureTimestamp <= time();
    }
}
$cashClaimDeadlineLabel = '';
if (!empty($booking['expires_at'])) {
    $claimTimestamp = strtotime((string) $booking['expires_at']);
    if ($claimTimestamp !== false) {
        $cashClaimDeadlineLabel = date('M j, Y g:i A', $claimTimestamp);
    }
}
if ($cashClaimDeadlineLabel === '' && $departureLabel !== '') {
    $cashClaimDeadlineLabel = $departureLabel;
}
$cashClaimCode = (string) ($booking['claim_code'] ?? '');
$usedTicketRow = db_select_one(
    'SELECT COUNT(*) AS total FROM tickets WHERE booking_id = ? AND ticket_status = "used"',
    'i',
    [$bookingId]
);
$missedPaidTrip = booking_is_missed_paid_trip($booking + ['used_ticket_count' => (int) ($usedTicketRow['total'] ?? 0)]);
$amountDueFormatted = number_format((float) $booking['total_amount'], 2);
$gcashGatewayReady = paymongo_is_configured();
$demoGcashEnabled = false;
include 'includes/header.php';
?>

<style>
.payment-checkout-shell {
    margin: 0 auto;
    max-width: 760px;
}
.payment-summary-card {
    height: 100%;
    margin-right: auto;
    max-width: 240px;
}
.payment-summary-card .card-body {
    padding: 1rem !important;
}
.payment-summary-card h1 {
    font-size: 1rem;
    line-height: 1.3;
}
.payment-summary-card .display-6 {
    font-size: 1.65rem;
}
.payment-form-card .card-body {
    padding: 1rem !important;
}
.payment-form-card .card-header {
    padding: 1rem 1.1rem !important;
}
.payment-form-card {
    height: 100%;
    margin-left: auto;
    max-width: 520px;
}
.payment-form-card h2 {
    font-size: 1.15rem;
}
.gcash-scan-card {
    background: #ffffff;
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1rem;
    box-shadow: none;
    margin: 0 auto;
    max-width: 150px;
    padding: 0.45rem;
    text-align: center;
}
.gcash-scan-shell {
    background: #ffffff;
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 0.9rem;
    display: block;
    overflow: hidden;
}
.gcash-qr-wrapper {
    display: block;
    border-radius: 0.9rem;
    cursor: pointer;
    overflow: hidden;
    transition: transform 150ms ease, box-shadow 150ms ease;
}
.gcash-qr-wrapper:hover {
    transform: translateY(-1px);
    box-shadow: 0 10px 20px rgba(15, 23, 42, 0.12);
}
.gcash-qr-image {
    display: block;
    height: auto;
    max-width: 100%;
    width: 100%;
}
.gcash-qr-info {
    color: #475467;
    font-size: 0.82rem;
    margin-top: 0.55rem;
}
.payment-gcash-header {
    border-bottom: 1px solid rgba(15, 23, 42, 0.08);
    padding-bottom: 0.85rem;
    margin-bottom: 1rem;
}
.payment-gcash-header .gcash-badge {
    background: #e7f1ff;
    border-radius: 0.75rem;
    color: #0f3c78;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.04em;
    padding: 0.35rem 0.7rem;
    text-transform: uppercase;
}
.payment-gcash-header h3 {
    font-size: 1rem;
    margin-bottom: 0.25rem;
}
.gcash-account-copy,
.gcash-manual-number {
    color: #334155;
    font-size: 0.85rem;
    line-height: 1.4;
}
.gcash-manual-number {
    font-weight: 600;
    margin-top: 0.35rem;
}
.payment-action-form {
    gap: 0.45rem !important;
}
.payment-upload-panel {
    padding: 0.55rem !important;
}
.payment-gcash-layout {
    display: grid;
    gap: 0.75rem;
}
.payment-proof-stack {
    align-content: start;
    display: grid;
    gap: 0.45rem;
}
.payment-proof-input-wrapper {
    display: grid;
    gap: 0.4rem;
}
.payment-proof-fileinfo {
    color: #64748b;
    font-size: 0.82rem;
    line-height: 1.4;
    min-height: 1.2rem;
}
.payment-proof-hint {
    color: #475467;
    font-size: 0.82rem;
    line-height: 1.45;
}
.payment-manual-note {
    color: #64748b;
    font-size: 0.75rem;
    line-height: 1.35;
}
.payment-proof-row {
    align-items: center;
    display: flex;
    gap: 0.5rem;
    justify-content: space-between;
    margin-bottom: 0;
}
.payment-proof-label {
    font-size: 0.84rem;
    margin-bottom: 0 !important;
}
.payment-proof-input {
    font-size: 0.8rem;
    padding: 0.28rem 0.55rem;
}
.payment-submit-btn {
    align-items: center;
    display: inline-flex;
    font-size: 0.95rem;
    justify-content: center;
    line-height: 1.2;
    margin-top: 0.1rem;
    min-height: 44px;
    padding-bottom: 0.42rem;
    padding-top: 0.42rem;
    text-align: center;
    white-space: nowrap;
    width: 100%;
}
@media (min-width: 576px) {
    .payment-gcash-layout {
        align-items: start;
        grid-template-columns: 150px minmax(0, 1fr);
    }

    .gcash-scan-card {
        margin: 0;
        max-width: none;
    }
}
@media (max-width: 991.98px) {
    .payment-summary-card,
    .payment-form-card {
        margin-left: 0;
        margin-right: 0;
        max-width: none;
    }
}
@media (max-width: 767.98px) {
    .payment-checkout-shell {
        max-width: 100%;
    }

    .gcash-scan-card {
        max-width: 100%;
    }

    .payment-proof-row {
        align-items: flex-start;
        flex-direction: column;
    }
}

.page-payment {
    background: #f5f7fb;
}

.page-payment .site-main {
    padding: 0;
}

.payment-page {
    padding: 2rem 0 5rem;
}

.payment-page__back {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.9rem;
    font-weight: 800;
    gap: 0.55rem;
    margin-bottom: 1.25rem;
    text-decoration: none;
}

.payment-page__back:hover { color: #17257f; }

.payment-page__heading {
    align-items: end;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-bottom: 1.7rem;
}

.payment-page__eyebrow {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 800;
    gap: 0.45rem;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.payment-page__heading h1 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(1.8rem, 1.5rem + 1vw, 2.45rem);
    letter-spacing: -0.045em;
    margin: 0.35rem 0 0.45rem;
}

.payment-page__heading p { color: #667085; margin: 0; }

.payment-steps {
    align-items: center;
    display: inline-flex;
    gap: 0.45rem;
}

.payment-steps span {
    background: #344da4;
    border-radius: 999px;
    height: 0.42rem;
    width: 1.9rem;
}

.payment-steps span.is-current { background: #ef3e38; }

.payment-checkout-shell {
    margin: 0 auto;
    max-width: 1120px;
}

.payment-summary-card,
.payment-form-card {
    background: #fff;
    border: 1px solid #e4e7ec !important;
    border-radius: 1.5rem !important;
    box-shadow: 0 18px 42px rgba(16, 24, 40, 0.07) !important;
    margin: 0;
    max-width: none;
    overflow: hidden;
}

.payment-summary-card {
    position: sticky;
    top: 1.25rem;
}

.payment-summary-card__hero {
    background:
        radial-gradient(circle at 100% 0%, rgba(255, 207, 63, 0.25) 0, transparent 8rem),
        linear-gradient(135deg, #101f46 0%, #25398e 100%);
    color: #fff;
    padding: 1.4rem;
}

.payment-summary-card__hero span {
    color: #c7d7fe;
    display: block;
    font-size: 0.76rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.payment-summary-card__hero h2 {
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.25rem;
    margin: 0.5rem 0 0.35rem;
}

.payment-summary-card__hero p { color: #e9efff; font-size: 0.84rem; margin: 0; }

.payment-summary-card .card-body {
    padding: 1.25rem !important;
}

.payment-summary-list > div {
    border-bottom: 1px solid #eaecf0;
    padding: 0.75rem 0;
}

.payment-summary-list > div:first-child { padding-top: 0; }
.payment-summary-list > div:last-child { border-bottom: 0; padding-bottom: 0; }

.payment-summary-list dt {
    color: #667085 !important;
    font-size: 0.7rem !important;
    font-weight: 800;
    letter-spacing: 0.04em;
    margin-bottom: 0.28rem !important;
    text-transform: uppercase;
}

.payment-summary-list dd {
    color: #1d2939;
    font-size: 0.9rem;
    margin: 0;
    overflow-wrap: anywhere;
}

.payment-summary-list .payment-summary-list__amount {
    background: #fff5f3;
    border: 1px solid #fecdca;
    border-radius: 0.9rem;
    margin-top: 1rem;
    padding: 0.85rem;
}

.payment-summary-list .payment-summary-list__amount dt { color: #b42318 !important; }
.payment-summary-list .payment-summary-list__amount dd {
    color: #b42318;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.35rem !important;
    font-weight: 800;
}

.payment-form-card .card-header,
.payment-form-card__header {
    background: linear-gradient(135deg, #fff9f8 0%, #fff 85%) !important;
    border-bottom: 1px solid #eaecf0 !important;
    color: #101828 !important;
    padding: 1.3rem 1.5rem !important;
}

.payment-form-card__header h2 {
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.3rem;
    margin: 0 0 0.3rem;
}

.payment-form-card__header p { color: #667085; font-size: 0.88rem; margin: 0; }

.payment-form-card .card-body {
    padding: clamp(1.1rem, 2.5vw, 1.65rem) !important;
}

.payment-form-card .alert {
    border: 0;
    border-radius: 0.85rem;
    font-size: 0.88rem;
}

.payment-form-card .form-label { color: #344054; font-size: 0.82rem; font-weight: 800 !important; }
.payment-form-card .form-select,
.payment-form-card .form-control {
    border-color: #d0d5dd;
    border-radius: 0.75rem !important;
    min-height: 2.9rem;
}

.payment-form-card .form-select:focus,
.payment-form-card .form-control:focus {
    border-color: #344da4;
    box-shadow: 0 0 0 0.2rem rgba(52, 77, 164, 0.13);
}

.payment-upload-panel {
    background: #f8fafc;
    border-color: #e4e7ec !important;
    border-radius: 1rem !important;
    padding: 1rem !important;
}

.gcash-scan-card {
    background: #fff;
    border-color: #dbe3f8;
    border-radius: 0.9rem;
    max-width: 10.25rem;
    padding: 0.55rem;
}

.gcash-scan-amount {
    color: #17257f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 0.95rem;
    font-weight: 800;
    margin-top: 0.55rem;
}

.payment-submit-btn,
.payment-form-card .btn-danger {
    background: linear-gradient(180deg, #ef3e38 0%, #c82323 100%);
    border: 0;
    box-shadow: 0 10px 18px rgba(200, 35, 35, 0.2);
}

.payment-submit-btn:hover,
.payment-form-card .btn-danger:hover { filter: brightness(1.04); transform: translateY(-1px); }

@media (max-width: 991px) { .payment-summary-card { position: static; } }
@media (max-width: 767px) {
    .payment-page { padding: 1.25rem 0 3.5rem; }
    .payment-page__heading { align-items: flex-start; flex-direction: column; margin-bottom: 1.2rem; }
    .payment-summary-card, .payment-form-card { border-radius: 1.1rem !important; }
    .payment-summary-card__hero, .payment-form-card .card-header { padding: 1.1rem !important; }
}
</style>

<section class="payment-page">
    <div class="container">
        <a class="payment-page__back" href="passenger-details.php?booking_id=<?php echo $bookingId; ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Back to passenger details</a>

        <div class="payment-page__heading">
            <div>
                <span class="payment-page__eyebrow"><i class="fa-solid fa-credit-card" aria-hidden="true"></i> Secure checkout</span>
                <h1>Complete payment</h1>
                <p>Review your trip and choose how you would like to pay.</p>
            </div>
            <div class="payment-steps" aria-label="Booking step 3 of 3"><span></span><span></span><span class="is-current"></span></div>
        </div>

        <div class="row justify-content-center">
            <div class="col-xl-12 payment-checkout-shell">
                <div class="row g-4 align-items-start">
                    <div class="col-lg-4">
                        <aside class="card border-0 h-100 payment-summary-card" aria-label="Payment summary">
                            <div class="payment-summary-card__hero">
                                <span>Step 3 of 3 · Final review</span>
                                <h2>Trip payment</h2>
                                <p>Check the details before submitting payment.</p>
                            </div>
                            <div class="card-body p-4">
                                <dl class="payment-summary-list mb-0">
                                    <div>
                                        <dt class="small text-muted mb-1"><?php echo (($booking['payment_method'] ?? '') === 'cash' && ($latestPayment['payment_method'] ?? '') === 'cash') ? 'Cash Ticket Code' : 'Booking Reference'; ?></dt>
                                        <dd class="fw-semibold mb-0"><?php echo e((($booking['payment_method'] ?? '') === 'cash' && ($latestPayment['payment_method'] ?? '') === 'cash' && $cashClaimCode !== '') ? $cashClaimCode : $booking['booking_reference']); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="small text-muted mb-1">Trip</dt>
                                        <dd class="fw-semibold mb-0"><?php echo e($tripLabel !== '' ? $tripLabel : 'Trip details unavailable'); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="small text-muted mb-1">Departure</dt>
                                        <dd class="fw-semibold mb-0"><?php echo e($departureLabel !== '' ? $departureLabel : 'Schedule unavailable'); ?></dd>
                                    </div>
                                    <div>
                                        <dt class="small text-muted mb-1">Passengers</dt>
                                        <dd class="fw-semibold mb-0"><?php echo (int) $booking['number_of_passengers']; ?></dd>
                                    </div>
                                    <div class="payment-summary-list__amount">
                                        <dt class="small text-muted mb-1">Amount Due</dt>
                                        <dd class="display-6 text-danger fw-bold mb-0">PHP <?php echo number_format((float) $booking['total_amount'], 2); ?></dd>
                                    </div>
                                </dl>
                            </div>
                        </aside>
                    </div>

                    <div class="col-lg-8">
                        <div class="card border-0 payment-form-card">
                            <div class="card-header payment-form-card__header">
                                <h2 class="h4 mb-1 fw-bold">Finalize payment</h2>
                                <p>Submit your payment details to continue with your booking.</p>
                            </div>
                            <div class="card-body p-4">
                                <?php if ($error !== ''): ?>
                                    <div class="alert alert-danger"><?php echo e($error); ?></div>
                                <?php endif; ?>
                                <?php if ($success !== ''): ?>
                                    <div class="alert alert-success"><?php echo e($success); ?></div>
                                <?php endif; ?>
                                <?php if ($discountReviewNotice !== ''): ?>
                                    <div class="alert alert-info"><?php echo e($discountReviewNotice); ?></div>
                                <?php endif; ?>
                                <?php if ((float) ($discountCashSummary['cash_due'] ?? 0) > 0): ?>
                                    <div class="alert alert-success">Cash discount approved: PHP <?php echo number_format((float) $discountCashSummary['cash_due'], 2); ?> is due from the bus operator at departure.</div>
                                <?php endif; ?>
                                <?php if ((float) ($discountCashSummary['cash_paid'] ?? 0) > 0): ?>
                                    <div class="alert alert-secondary">Cash discount paid by the bus operator: PHP <?php echo number_format((float) $discountCashSummary['cash_paid'], 2); ?>.</div>
                                <?php endif; ?>

                                <?php if (!$passengerDetailsComplete): ?>
                                    <div class="alert alert-warning">
                                        Please complete the passenger details first before choosing or submitting a payment method.
                                    </div>
                                    <a class="btn btn-danger rounded-4 fw-semibold" href="passenger-details.php?booking_id=<?php echo $bookingId; ?>">
                                        <i class="fa-solid fa-id-card me-2"></i>Complete Passenger Details
                                    </a>
                                <?php elseif ($isInactive): ?>
                                    <div class="alert alert-warning">
                                        This booking is no longer active. You can remove it from My Bookings and create a new booking when ready.
                                    </div>
                                    <a class="btn btn-outline-secondary rounded-4 fw-semibold" href="my-bookings.php">
                                        Back to My Bookings
                                    </a>
                                <?php elseif (($booking['payment_status'] ?? '') !== 'paid' && $departurePassed): ?>
                                    <div class="alert alert-warning">
                                        This trip already left. This booking can no longer be paid or cancelled here and must be cleared manually by staff or admin.
                                    </div>
                                    <a class="btn btn-outline-secondary rounded-4 fw-semibold" href="my-bookings.php">
                                        Back to My Bookings
                                    </a>
                                <?php elseif ($missedPaidTrip): ?>
                                    <div class="alert alert-warning">
                                        This paid trip already departed and was not marked as used. The e-ticket is no longer valid for boarding. You may remove it from My Bookings and contact terminal staff if you need manual assistance.
                                    </div>
                                    <a class="btn btn-outline-secondary rounded-4 fw-semibold" href="my-bookings.php">
                                        Back to My Bookings
                                    </a>
                                <?php elseif (($booking['payment_status'] ?? '') === 'paid' || ($booking['status'] ?? '') === 'confirmed'): ?>
                                    <?php if ($ticketRepairMessage !== ''): ?>
                                        <div class="alert alert-warning">
                                            <?php echo e($ticketRepairMessage); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="alert alert-success">
                                        Your booking is confirmed. Your e-ticket is ready to view.
                                    </div>
                                    <a class="btn btn-danger rounded-4 fw-semibold" href="booking-view.php?booking_id=<?php echo $bookingId; ?>">
                                        <i class="fa-solid fa-ticket me-2"></i>Open E-Ticket
                                    </a>
                                    <a class="btn btn-outline-secondary rounded-4 fw-semibold ms-2" href="index.php">
                                        <i class="fa-solid fa-house me-2"></i>Back to Homepage
                                    </a>
                                <?php elseif ($latestPayment && ($latestPayment['status'] ?? '') === 'pending' && ($latestPayment['payment_method'] ?? '') === 'qrph'): ?>
                                    <div class="alert alert-warning">
                                        <?php if ($paymentReturnState === 'success'): ?>
                                            Your payment was submitted through QRPh. We are waiting for PayMongo's secure confirmation before issuing your QR ticket.
                                        <?php elseif ($paymentReturnState === 'cancelled'): ?>
                                            The QRPh checkout was not completed. You can try the secure checkout again when ready.
                                        <?php else: ?>
                                            Your secure QRPh checkout is still pending. Complete the payment through PayMongo; your booking and QR ticket will be confirmed automatically.
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($paymentReturnNeedsRetry): ?>
                                        <div id="payment-status-retry" class="small text-muted mt-2">
                                            <?php if ($paymentRetryCount < 12): ?>
                                                Checking PayMongo payment status automatically...
                                            <?php else: ?>
                                                Payment confirmation is taking longer than expected.
                                                <a href="payment.php?booking_id=<?php echo $bookingId; ?>&amp;payment_return=success&amp;payment_retry=12">Check payment status</a>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="small text-muted mb-2">
                                        <?php if ($demoGcashEnabled): ?>
                                            Development mode: scan the QR checkout on the next screen and complete the test payment. No money will be charged; the ticket will be issued automatically.
                                        <?php else: ?>
                                            Do not upload a receipt. The gateway verifies the payment directly and automatically issues the ticket after confirmation.
                                        <?php endif; ?>
                                    </div>
                                    <div class="small text-muted">
                                        Latest reference: <strong><?php echo e($latestPayment['payment_reference']); ?></strong>
                                    </div>
                                    <?php if ($pendingQrCheckoutUrl !== ''): ?>
                                        <a class="btn btn-danger rounded-4 fw-semibold mt-3 payment-checkout-link" href="<?php echo e($pendingQrCheckoutUrl); ?>">
                                            <i class="fa-solid fa-arrow-up-right-from-square me-2" aria-hidden="true"></i>Continue Secure QRPh Checkout
                                        </a>
                                    <?php endif; ?>
                                <?php elseif ($latestPayment && ($latestPayment['status'] ?? '') === 'pending' && ($latestPayment['payment_method'] ?? '') === 'cash'): ?>
                                    <div class="alert alert-info">
                                        Pay at terminal selected. Your terminal cash ticket is ready. Please pay at the terminal before departure so staff can reserve the final seat and issue the final ticket.
                                    </div>
                                    <div class="small text-muted mb-3">
                                        Preferred seats are not blocked yet and may change depending on availability at the time of payment. If you want a different seat, request it directly from the staff before payment is confirmed.
                                    </div>
                                    <?php if ($cashClaimCode !== ''): ?>
                                        <div class="small text-muted mb-2">
                                            Cash ticket code: <strong><?php echo e($cashClaimCode); ?></strong>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($cashClaimDeadlineLabel !== ''): ?>
                                        <div class="small text-muted mb-3">
                                            Valid until departure: <strong><?php echo e($cashClaimDeadlineLabel); ?></strong>
                                        </div>
                                    <?php endif; ?>
                                    <div class="d-flex flex-wrap gap-2">
                                        <a class="btn btn-danger rounded-4 fw-semibold" href="booking-view.php?booking_id=<?php echo $bookingId; ?>">
                                            <i class="fa-solid fa-qrcode me-2"></i>Open Terminal Cash Ticket
                                        </a>
                                        <a class="btn btn-outline-secondary rounded-4 fw-semibold" href="my-bookings.php">
                                            Back to My Bookings
                                        </a>
                                    </div>
                                <?php else: ?>
                                    <form method="post" action="payment.php?booking_id=<?php echo $bookingId; ?>" class="d-grid gap-3 payment-action-form" novalidate>
                                        <?php csrf_field(); ?>
                                        <div>
                                            <label class="form-label fw-semibold mb-1" for="payment_method">Method</label>
                                            <select class="form-select rounded-4" id="payment_method" name="payment_method">
                                                <option value="qrph" selected <?php echo !$gcashGatewayReady ? 'disabled' : ''; ?>>QRPh — automatic verification</option>
                                            </select>
                                        </div>

                                        <div id="gcash-panel" class="rounded-4 border p-4 payment-upload-panel">
                                            <div class="payment-gcash-header">
                                                <div class="gcash-badge"><?php echo $demoGcashEnabled ? 'Development QR checkout' : 'Secure GCash checkout'; ?></div>
                                                <h3 class="mb-1">Pay with QRPh</h3>
                                                <div class="gcash-account-copy">You will be redirected to PayMongo to complete your QRPh payment. No receipt upload is required.</div>
                                            </div>
                                            <?php if ($demoGcashEnabled || $gcashGatewayReady): ?>
                                                <div class="gcash-scan-amount">PHP <?php echo e($amountDueFormatted); ?></div>
                                                <div class="payment-proof-hint mt-2">After PayMongo verifies the completed QRPh transaction, the system automatically confirms your booking and issues the QR ticket.</div>
                                                <button class="btn btn-danger btn-lg rounded-4 fw-semibold payment-submit-btn mt-3" type="submit" name="payment_method" value="qrph">
                                                    <i class="fa-solid fa-arrow-up-right-from-square me-2" aria-hidden="true"></i>Continue Secure QRPh Checkout
                                                </button>
                                            <?php else: ?>
                                                <div class="alert alert-warning mb-0">QRPh is not configured yet. Ask the administrator to complete the PayMongo setup.</div>
                                            <?php endif; ?>
                                        </div>

                                        <div id="cash-panel" class="alert alert-info mb-0">
                                            PayMongo verifies the full fare automatically. Any approved discount is paid separately in cash by the bus operator at departure.
                                        </div>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const retryStatus = document.getElementById('payment-status-retry');
    if (retryStatus) {
        const retryCount = <?php echo (int) $paymentRetryCount; ?>;

        if (retryCount < 12) {
            let secondsRemaining = 3;
            const countdown = setInterval(function () {
                secondsRemaining -= 1;
                if (secondsRemaining > 0) {
                    retryStatus.textContent = 'Checking PayMongo payment status again in ' + secondsRemaining + '...';
                    return;
                }

                clearInterval(countdown);
                retryStatus.textContent = 'Checking PayMongo payment status...';
                const nextUrl = new URL(window.location.href);
                nextUrl.searchParams.set('payment_return', 'success');
                nextUrl.searchParams.set('payment_retry', String(retryCount + 1));
                window.location.replace(nextUrl.toString());
            }, 1000);
        }
    }

    const methodInput = document.getElementById('payment_method');
    const gcashPanel = document.getElementById('gcash-panel');
    const cashPanel = document.getElementById('cash-panel');

    if (!methodInput || !gcashPanel || !cashPanel) {
        return;
    }

    function syncMethod() {
        const usingQrph = methodInput.value === 'qrph';
        gcashPanel.style.display = usingQrph ? 'block' : 'none';
        cashPanel.style.display = usingQrph ? 'block' : 'none';
    }

    methodInput.addEventListener('change', syncMethod);
    syncMethod();

    document.querySelectorAll('.payment-action-form').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            const submitButton = event.submitter || form.querySelector('.payment-submit-btn');
            if (!submitButton) {
                return;
            }

            submitButton.disabled = true;
            submitButton.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-2" aria-hidden="true"></i>Opening secure checkout...';
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
