<?php
require_once 'includes/config.php';

$logoutScope = session_scope();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    exit('Logout requests must use the sign-out form.');
}

logout_user();

if ($logoutScope === SESSION_SCOPE_ADMIN) {
    redirect('admin/login.php');
}

redirect('index.php');
