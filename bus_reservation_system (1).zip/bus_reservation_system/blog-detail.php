<?php
$base_url = '';
include 'includes/config.php';

$post_id = isset_get('id');

if (!$post_id) {
    redirect('/blog.php');
}

// Fetch blog post
$post_query = "SELECT * FROM blog_posts WHERE post_id = " . intval($post_id) . " AND status = 'published'";
$post_result = $conn->query($post_query);

if ($post_result->num_rows == 0) {
    redirect('/blog.php');
}

$post = $post_result->fetch_assoc();
$page_title = $post['title'] . ' - Gonzaga Terminal';
include 'includes/header.php';
?>
        <section style="background-color: #f8f9fa; padding: 40px 20px;">
            <div class="container" style="max-width: 800px;">
                <?php if ($post['image_url']): ?>
                    <img src="<?php echo $post['image_url']; ?>" alt="Blog Post" style="width: 100%; height: 400px; object-fit: cover; border-radius: 8px; margin-bottom: 30px;">
                <?php endif; ?>

                <h1 style="color: #A72D2D; margin-bottom: 10px;"><?php echo $post['title']; ?></h1>
                <p style="color: #999; margin-bottom: 30px;">
                    Published: <?php echo date('M d, Y', strtotime($post['created_at'])); ?>
                </p>

                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); line-height: 1.8;">
                    <?php echo $post['content']; ?>
                </div>

                <div style="margin-top: 30px;">
                    <a href="blog.php" class="btn-submit">← Back to Blog</a>
                </div>
            </div>
        </section>
    <?php include 'includes/footer.php'; ?>
