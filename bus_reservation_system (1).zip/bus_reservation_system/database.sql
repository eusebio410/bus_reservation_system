-- Bus Reservation System Database Schema

CREATE DATABASE IF NOT EXISTS bus_reservation_db;
USE bus_reservation_db;

-- Users Table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password VARCHAR(255) NOT NULL,
    address VARCHAR(255),
    is_admin INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Terminals Table
CREATE TABLE terminals (
    terminal_id INT AUTO_INCREMENT PRIMARY KEY,
    terminal_name VARCHAR(100) NOT NULL UNIQUE,
    location VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(15),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Routes Table
CREATE TABLE routes (
    route_id INT AUTO_INCREMENT PRIMARY KEY,
    origin_terminal_id INT NOT NULL,
    destination_terminal_id INT NOT NULL,
    distance DECIMAL(10, 2),
    travel_time INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (origin_terminal_id) REFERENCES terminals(terminal_id),
    FOREIGN KEY (destination_terminal_id) REFERENCES terminals(terminal_id)
);

-- Bus Classes Table
CREATE TABLE bus_classes (
    class_id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(50) NOT NULL UNIQUE,
    capacity INT,
    description TEXT,
    amenities TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Buses Table
CREATE TABLE buses (
    bus_id INT AUTO_INCREMENT PRIMARY KEY,
    bus_code VARCHAR(20) UNIQUE NOT NULL,
    class_id INT NOT NULL,
    registration_number VARCHAR(20),
    model VARCHAR(100),
    year_manufactured INT,
    total_seats INT,
    status ENUM('active', 'maintenance', 'retired') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (class_id) REFERENCES bus_classes(class_id)
);

-- Schedules Table
CREATE TABLE schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,
    bus_id INT NOT NULL,
    route_id INT NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    departure_date DATE NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    available_seats INT NOT NULL,
    status ENUM('scheduled', 'cancelled', 'completed') DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bus_id) REFERENCES buses(bus_id),
    FOREIGN KEY (route_id) REFERENCES routes(route_id)
);

-- Bookings Table
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    schedule_id INT NOT NULL,
    booking_reference VARCHAR(20) UNIQUE NOT NULL,
    number_of_passengers INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_status ENUM('unpaid', 'paid', 'refunded') DEFAULT 'unpaid',
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id)
);

-- Passengers Table
CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(15),
    seat_number VARCHAR(10),
    age INT,
    gender ENUM('M', 'F') DEFAULT 'M',
    id_type VARCHAR(50),
    id_number VARCHAR(50),
    id_proof_path VARCHAR(255),
    discount_status VARCHAR(20) NOT NULL DEFAULT 'none',
    discount_percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
    discount_cash_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount_cash_status VARCHAR(20) NOT NULL DEFAULT 'not_due',
    discount_cash_paid_by INT NULL,
    discount_cash_paid_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- Fares Table
CREATE TABLE fares (
    fare_id INT AUTO_INCREMENT PRIMARY KEY,
    route_id INT NOT NULL,
    class_id INT NOT NULL,
    base_fare DECIMAL(10, 2) NOT NULL,
    discount_percentage DECIMAL(5, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(route_id),
    FOREIGN KEY (class_id) REFERENCES bus_classes(class_id)
);

-- FAQs Table
CREATE TABLE faqs (
    faq_id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100),
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Travel Guides Table
CREATE TABLE travel_guides (
    guide_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT NOT NULL,
    image_url VARCHAR(255),
    author_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(user_id)
);

-- Blog Posts Table
CREATE TABLE blog_posts (
    post_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content LONGTEXT NOT NULL,
    author_id INT,
    image_url VARCHAR(255),
    status ENUM('draft', 'published') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES users(user_id)
);

-- Insert Bus Classes
INSERT INTO bus_classes (class_name, capacity, description, amenities) VALUES
('Regular AC', 43, '43 seater bus configuration', 'Air-conditioned, On-board TV'),
('First Class / Deluxe', 43, '43 seater deluxe bus configuration', 'Spacious Legroom, Free Snacks, On-board Restroom, Electric Sockets, TV'),
('Premium - Victory Royal Sleeper', 43, '43 seat premium bus configuration', 'Lie-flat Seats, Premium Amenities, VIP Service, Priority Boarding');

-- Insert Sample Terminals
INSERT INTO terminals (terminal_name, location, address, phone, email) VALUES
('Cubao Terminal', 'Cubao, Quezon City', '123 EDSA, Cubao, Quezon City', '02-123-4567', 'cubao@victoryliner.com'),
('Pasay Terminal', 'Pasay City', '456 EDSA, Pasay City', '02-234-5678', 'pasay@victoryliner.com'),
('Kamias Terminal', 'Kamias, Quezon City', '789 Kamias Rd, Quezon City', '02-345-6789', 'kamias@victoryliner.com'),
('Baguio Terminal', 'Baguio City', '101 Upper Session Rd, Baguio City', '074-442-6111', 'baguio@victoryliner.com'),
('Dagupan Terminal', 'Dagupan City', '202 Peñafrancia Ave, Dagupan City', '075-516-5010', 'dagupan@victoryliner.com'),
('Tuguegarao Terminal', 'Tuguegarao City', '303 Florencio St, Tuguegarao', '078-844-1919', 'tuguegarao@victoryliner.com'),
('Olongapo Terminal', 'Olongapo City', '404 Magsaysay Ave, Olongapo', '047-222-2525', 'olongapo@victoryliner.com'),
('Zambales Terminal', 'Sta. Cruz, Zambales', '505 National Rd, Sta. Cruz', '047-631-1234', 'zambales@victoryliner.com');

-- Insert Sample Routes
INSERT INTO routes (origin_terminal_id, destination_terminal_id, distance, travel_time) VALUES
(1, 4, 250, 360),
(2, 4, 260, 380),
(3, 6, 550, 780),
(1, 7, 150, 180),
(1, 5, 200, 240),
(1, 8, 180, 210);

-- Insert Sample Fares
INSERT INTO fares (route_id, class_id, base_fare, discount_percentage) VALUES
(1, 1, 485, 0),
(1, 2, 800, 5),
(1, 3, 950, 10),
(2, 1, 496, 0),
(2, 2, 800, 5),
(3, 1, 950, 0),
(3, 2, 1800, 5),
(4, 1, 250, 0),
(5, 1, 350, 0),
(6, 1, 380, 0);

-- Insert Sample Buses
INSERT INTO buses (bus_code, class_id, registration_number, model, year_manufactured, total_seats, status) VALUES
('VL-001', 1, 'NQZ-001', 'Isuzu', 2021, 43, 'active'),
('VL-002', 1, 'NQZ-002', 'Isuzu', 2021, 43, 'active'),
('VL-003', 2, 'NQZ-003', 'Hino', 2022, 43, 'active'),
('VL-004', 3, 'NQZ-004', 'Volvo', 2023, 43, 'active'),
('VL-005', 1, 'NQZ-005', 'Isuzu', 2020, 43, 'active');

-- Insert Sample Schedules
INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, departure_date, price, available_seats, status) VALUES
(1, 1, '06:00:00', '12:00:00', CURDATE(), 485, 43, 'scheduled'),
(2, 1, '10:00:00', '16:00:00', CURDATE(), 485, 43, 'scheduled'),
(3, 1, '14:00:00', '20:00:00', CURDATE(), 800, 43, 'scheduled'),
(1, 2, '07:00:00', '13:00:00', CURDATE(), 496, 43, 'scheduled'),
(4, 3, '18:00:00', '04:00:00', CURDATE(), 950, 43, 'scheduled'),
(1, 4, '09:00:00', '11:00:00', CURDATE(), 250, 43, 'scheduled'),
(2, 5, '08:30:00', '12:30:00', CURDATE(), 350, 43, 'scheduled'),
(1, 6, '11:00:00', '12:50:00', CURDATE(), 380, 43, 'scheduled');

-- Insert Sample FAQs
INSERT INTO faqs (category, question, answer) VALUES
('Booking', 'How do I book a ticket?', 'You can book tickets through our website by selecting your route, date, and preferred bus class. Provide passenger details and proceed to payment.'),
('Booking', 'Can I cancel my booking?', 'Yes, you can cancel up to 24 hours before departure for a full refund. Cancellations within 24 hours will have a 25% cancellation fee.'),
('Baggage', 'What is the baggage allowance?', 'Passengers are allowed 1 piece of luggage (max 25kg) for free. Additional luggage costs ₱100 per piece.'),
('Baggage', 'Can I bring oversized baggage?', 'Oversized baggage can be accommodated for an additional charge. Please contact our office for details.'),
('Travel', 'What time should I arrive at the terminal?', 'Please arrive 30 minutes before departure for domestic trips.'),
('Travel', 'Are meals provided during the journey?', 'Yes, complimentary snacks and drinks are provided on all services. Full meals are served on longer routes.'),
('Refund', 'What is the refund policy?', 'Full refunds are available for cancellations 24 hours before departure. Partial refunds are applicable for cancellations within 24 hours.'),
('Accessibility', 'Is the bus wheelchair accessible?', 'Most of our buses have wheelchair accessibility features. Please inform us when booking if you require assistance.');

-- Create the first administrator through a secure deployment procedure.
-- Do not ship a publicly known administrator password in the database dump.

-- ------------------------------------------------------------------
-- Enterprise Upgrade Schema
-- ------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_key VARCHAR(30) NOT NULL UNIQUE,
    role_name VARCHAR(80) NOT NULL,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO roles (role_id, role_key, role_name, description) VALUES
(1, 'admin', 'Administrator', 'Full control of the platform'),
(2, 'staff', 'Staff', 'Operational access for payments, bookings, and QR validation'),
(3, 'passenger', 'Passenger', 'Standard passenger account');

ALTER TABLE users
    ADD COLUMN IF NOT EXISTS role_id INT NULL AFTER password,
    ADD COLUMN IF NOT EXISTS account_status VARCHAR(20) NOT NULL DEFAULT 'active' AFTER is_admin,
    ADD COLUMN IF NOT EXISTS last_login_at DATETIME NULL AFTER updated_at,
    ADD COLUMN IF NOT EXISTS last_activity_at DATETIME NULL AFTER last_login_at;

UPDATE users SET role_id = 1 WHERE is_admin = 1 AND (role_id IS NULL OR role_id = 0);
UPDATE users SET role_id = 3 WHERE is_admin = 0 AND (role_id IS NULL OR role_id = 0);

ALTER TABLE buses
    ADD COLUMN IF NOT EXISTS bus_name VARCHAR(120) NULL AFTER bus_code,
    ADD COLUMN IF NOT EXISTS bus_type VARCHAR(60) NULL AFTER bus_name,
    ADD COLUMN IF NOT EXISTS is_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER status,
    ADD COLUMN IF NOT EXISTS seat_map_columns INT NOT NULL DEFAULT 4 AFTER is_enabled;

ALTER TABLE schedules
    ADD COLUMN IF NOT EXISTS schedule_code VARCHAR(30) NULL AFTER schedule_id,
    ADD COLUMN IF NOT EXISTS operator_id INT NULL AFTER bus_id,
    ADD COLUMN IF NOT EXISTS bus_type VARCHAR(60) NULL AFTER route_id,
    ADD COLUMN IF NOT EXISTS is_auto_assigned TINYINT(1) NOT NULL DEFAULT 0 AFTER bus_type,
    ADD COLUMN IF NOT EXISTS recurrence_id INT NULL AFTER is_auto_assigned,
    ADD COLUMN IF NOT EXISTS is_recurring_generated TINYINT(1) NOT NULL DEFAULT 0 AFTER recurrence_id,
    ADD COLUMN IF NOT EXISTS trip_status VARCHAR(20) NOT NULL DEFAULT 'scheduled' AFTER status;

CREATE TABLE IF NOT EXISTS schedule_recurrences (
    recurrence_id INT AUTO_INCREMENT PRIMARY KEY,
    route_id INT NOT NULL,
    bus_id INT NOT NULL,
    operator_id INT NULL,
    bus_type VARCHAR(60) NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,
    start_date DATE NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_schedule_recurrences_active (is_active, start_date),
    INDEX idx_schedule_recurrences_route (route_id)
);

ALTER TABLE schedules
    ADD INDEX idx_schedules_operator (operator_id),
    ADD INDEX idx_schedules_trip_status (trip_status),
    ADD INDEX idx_schedules_recurrence (recurrence_id),
    ADD INDEX idx_schedules_status_departure (status, departure_date, departure_time),
    ADD INDEX idx_schedules_route_departure (route_id, departure_date, status, departure_time),
    ADD INDEX idx_schedules_bus_departure (bus_id, departure_date, status),
    ADD UNIQUE KEY uniq_schedules_route_departure (route_id, departure_date, departure_time);

ALTER TABLE bookings
    MODIFY COLUMN status VARCHAR(30) NOT NULL DEFAULT 'pending',
    MODIFY COLUMN payment_status VARCHAR(30) NOT NULL DEFAULT 'pending',
    MODIFY COLUMN payment_method VARCHAR(40) NULL,
    ADD COLUMN IF NOT EXISTS expires_at DATETIME NULL AFTER updated_at,
    ADD COLUMN IF NOT EXISTS confirmed_at DATETIME NULL AFTER expires_at,
    ADD COLUMN IF NOT EXISTS cancelled_at DATETIME NULL AFTER confirmed_at,
    ADD COLUMN IF NOT EXISTS seat_preferences TEXT NULL AFTER payment_status,
    ADD COLUMN IF NOT EXISTS claim_code VARCHAR(40) NULL AFTER booking_reference,
    ADD INDEX idx_bookings_user_date (user_id, booking_date),
    ADD INDEX idx_bookings_schedule_status (schedule_id, status),
    ADD INDEX idx_bookings_status_payment_date (status, payment_status, booking_date),
    ADD UNIQUE KEY uniq_bookings_claim_code (claim_code);

UPDATE bookings SET payment_status = 'pending' WHERE payment_status = 'unpaid';

ALTER TABLE passengers
    ADD COLUMN IF NOT EXISTS id_type VARCHAR(50) NULL AFTER gender,
    ADD COLUMN IF NOT EXISTS id_number VARCHAR(50) NULL AFTER id_type;

CREATE TABLE IF NOT EXISTS seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    bus_id INT NOT NULL,
    seat_number INT NOT NULL,
    seat_label VARCHAR(20) NOT NULL,
    seat_row INT NOT NULL,
    seat_column INT NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_bus_seat_number (bus_id, seat_number),
    UNIQUE KEY uniq_bus_seat_label (bus_id, seat_label),
    CONSTRAINT fk_seats_bus FOREIGN KEY (bus_id) REFERENCES buses(bus_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    payment_reference VARCHAR(40) NOT NULL UNIQUE,
    payment_method VARCHAR(30) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    proof_image VARCHAR(255) NULL,
    provider VARCHAR(30) NULL,
    provider_checkout_id VARCHAR(100) NULL,
    provider_checkout_url VARCHAR(2048) NULL,
    provider_payment_id VARCHAR(100) NULL,
    admin_notes TEXT NULL,
    submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    verified_at DATETIME NULL,
    verified_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_payments_booking (booking_id),
    INDEX idx_payments_status_submitted (status, submitted_at),
    INDEX idx_payments_status_verified (status, verified_at),
    UNIQUE KEY uniq_payments_provider_checkout (provider_checkout_id),
    UNIQUE KEY uniq_payments_provider_payment (provider_payment_id),
    CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tickets (
    ticket_id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    passenger_id INT NULL,
    schedule_id INT NOT NULL,
    seat_id INT NOT NULL,
    ticket_code VARCHAR(40) NULL UNIQUE,
    qr_payload LONGTEXT NULL,
    qr_signature VARCHAR(128) NULL,
    ticket_status VARCHAR(20) NOT NULL DEFAULT 'reserved',
    issued_at DATETIME NULL,
    used_at DATETIME NULL,
    scanned_by INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_schedule_seat (schedule_id, seat_id),
    INDEX idx_tickets_booking (booking_id),
    INDEX idx_tickets_booking_status (booking_id, ticket_status),
    CONSTRAINT fk_tickets_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    CONSTRAINT fk_tickets_passenger FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id) ON DELETE SET NULL,
    CONSTRAINT fk_tickets_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id) ON DELETE CASCADE,
    CONSTRAINT fk_tickets_seat FOREIGN KEY (seat_id) REFERENCES seats(seat_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS qr_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    scanned_by INT NULL,
    scan_status VARCHAR(20) NOT NULL,
    scan_message VARCHAR(255) NULL,
    scan_payload LONGTEXT NULL,
    scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_qr_logs_ticket (ticket_id),
    CONSTRAINT fk_qr_logs_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    booking_id INT NULL,
    notification_type VARCHAR(30) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notifications_user (user_id),
    INDEX idx_notifications_user_read_created (user_id, is_read, created_at),
    CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS login_attempts (
    throttle_key CHAR(64) NOT NULL PRIMARY KEY,
    failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
    locked_until DATETIME NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_login_attempts_locked_until (locked_until)
);

CREATE TABLE IF NOT EXISTS audit_logs (
    audit_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    role_key VARCHAR(30) NOT NULL DEFAULT '',
    action_key VARCHAR(80) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NOT NULL DEFAULT 0,
    description VARCHAR(255) NOT NULL,
    context_json LONGTEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_audit_logs_created_at (created_at),
    INDEX idx_audit_logs_user (user_id),
    INDEX idx_audit_logs_action (action_key),
    INDEX idx_audit_logs_entity (entity_type, entity_id),
    CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

ALTER TABLE routes
    ADD UNIQUE KEY uniq_route_pair (origin_terminal_id, destination_terminal_id);

ALTER TABLE fares
    ADD INDEX idx_fares_route_class (route_id, class_id);
