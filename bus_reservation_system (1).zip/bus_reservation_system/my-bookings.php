<?php
$base_url = '';
$page_title = 'My Bookings';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$userId = (int) $_SESSION['user_id'];
$error = consume_flash('error');
$success = consume_flash('success');
$selectedView = isset_get('view');
if (!in_array($selectedView, ['all', 'active', 'action', 'history'], true)) {
    $selectedView = 'all';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset_post('action');
    $returnView = isset_post('return_view');
    if (!in_array($returnView, ['all', 'active', 'action', 'history'], true)) {
        $returnView = 'all';
    }

    if ($action === 'cancel_booking') {
        $bookingId = (int) ($_POST['booking_id'] ?? 0);
        $result = cancel_booking_by_user($bookingId, $userId);
    } elseif ($action === 'clear_history') {
        $result = clear_user_booking_history($userId);
    } elseif ($action === 'clear_booking') {
        $bookingId = (int) ($_POST['booking_id'] ?? 0);
        $result = delete_booking_history($bookingId, $userId);
    } else {
        $result = ['ok' => false, 'message' => 'Unknown booking history action.'];
    }

    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('my-bookings.php?view=' . urlencode($returnView));
}

$notifications = get_notifications_for_user($userId, 5);
mark_notifications_read($userId);

$bookings = db_select_all(
    "SELECT b.*, s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name,
            COUNT(t.ticket_id) AS ticket_count,
            SUM(CASE WHEN t.ticket_status = 'used' THEN 1 ELSE 0 END) AS used_ticket_count
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     LEFT JOIN tickets t ON b.booking_id = t.booking_id
     WHERE b.user_id = ?
     GROUP BY b.booking_id
     ORDER BY b.booking_date DESC",
    'i',
    [$userId]
);

$viewCounts = [
    'all' => 0,
    'active' => 0,
    'action' => 0,
    'history' => 0,
];
$bookingCards = [];
$removableCount = 0;

foreach ($bookings as $booking) {
    $missedPaidTrip = booking_is_missed_paid_trip($booking);
    $statusClass = $missedPaidTrip
        ? 'warning'
        : (in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true)
            ? 'success'
            : (((string) ($booking['status'] ?? '') === 'payment_review' || (string) ($booking['status'] ?? '') === 'pending') ? 'warning' : 'danger'));
    $statusLabel = $missedPaidTrip ? 'Missed' : ucwords(str_replace('_', ' ', (string) ($booking['status'] ?? '')));
    $paymentClass = ((string) ($booking['payment_status'] ?? '') === 'paid')
        ? 'success'
        : (((string) ($booking['payment_status'] ?? '') === 'pending') ? 'warning' : 'danger');
    $canClearHistory = booking_history_is_clearable($booking);
    $timeline = booking_live_countdown_context($booking);
    $cancellationState = booking_user_cancellation_state($booking);
    $departureTimestamp = $timeline['departure_timestamp'];
    $departurePassed = $departureTimestamp !== null && $departureTimestamp <= time();
    $canCancelBooking = (bool) ($cancellationState['can_cancel'] ?? false);
    $needsManualStaffAssistance = (bool) ($cancellationState['needs_staff_assistance'] ?? false);
    $finalTicketReady = !$missedPaidTrip
        && (string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled'
        && (((string) ($booking['payment_status'] ?? '') === 'paid') || in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true));
    $requiresPayment = in_array((string) ($booking['status'] ?? ''), ['pending', 'payment_review'], true)
        && (string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled'
        && (string) ($booking['payment_status'] ?? '') !== 'paid';
    $cashTicketAvailable = ((string) ($booking['payment_method'] ?? '') === 'cash')
        && (string) ($booking['payment_status'] ?? '') !== 'paid'
        && (string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled'
        && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true);
    $effectiveTripStatus = (string) ($timeline['effective_trip_status'] ?? 'scheduled');
    $effectiveScheduleStatus = (string) ($timeline['effective_schedule_status'] ?? ((string) ($booking['schedule_status'] ?? 'scheduled')));
    $tripChipClass = match ($effectiveTripStatus) {
        'boarding' => 'warning',
        'departed' => 'soft',
        'arrived' => 'success',
        'cancelled' => 'danger',
        default => 'soft',
    };

    $isActiveView = !$canClearHistory
        && !$missedPaidTrip
        && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true);
    $needsActionView = $requiresPayment || $canCancelBooking || $needsManualStaffAssistance || ($cashTicketAvailable && !$departurePassed);
    $isHistoryView = $canClearHistory
        || $missedPaidTrip
        || in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
        || $effectiveScheduleStatus === 'completed';

    $viewCounts['all']++;
    if ($isActiveView) {
        $viewCounts['active']++;
    }
    if ($needsActionView) {
        $viewCounts['action']++;
    }
    if ($isHistoryView) {
        $viewCounts['history']++;
    }
    if ($canClearHistory) {
        $removableCount++;
    }

    $booking['status_class'] = $statusClass;
    $booking['status_label'] = $statusLabel;
    $booking['payment_class'] = $paymentClass;
    $booking['can_clear_history'] = $canClearHistory;
    $booking['timeline'] = $timeline;
    $booking['can_cancel_booking'] = $canCancelBooking;
    $booking['needs_manual_staff_assistance'] = $needsManualStaffAssistance;
    $booking['final_ticket_ready'] = $finalTicketReady;
    $booking['requires_payment'] = $requiresPayment;
    $booking['cash_ticket_available'] = $cashTicketAvailable;
    $booking['departure_passed'] = $departurePassed;
    $booking['effective_trip_status'] = $effectiveTripStatus;
    $booking['effective_schedule_status'] = $effectiveScheduleStatus;
    $booking['trip_chip_class'] = $tripChipClass;
    $booking['cancellation_message'] = (string) ($cancellationState['message'] ?? '');
    $booking['is_active_view'] = $isActiveView;
    $booking['needs_action_view'] = $needsActionView;
    $booking['is_history_view'] = $isHistoryView;

    $bookingCards[] = $booking;
}

$bookings = array_values(array_filter($bookingCards, static function (array $booking) use ($selectedView): bool {
    return match ($selectedView) {
        'active' => (bool) ($booking['is_active_view'] ?? false),
        'action' => (bool) ($booking['needs_action_view'] ?? false),
        'history' => (bool) ($booking['is_history_view'] ?? false),
        default => true,
    };
}));

$summaryCards = [
    ['label' => 'All Bookings', 'value' => $viewCounts['all'], 'icon' => 'fa-ticket'],
    ['label' => 'Active Trips', 'value' => $viewCounts['active'], 'icon' => 'fa-bus'],
    ['label' => 'Needs Action', 'value' => $viewCounts['action'], 'icon' => 'fa-bell'],
    ['label' => 'History Items', 'value' => $viewCounts['history'], 'icon' => 'fa-clock-rotate-left'],
];

include 'includes/header.php';
?>

<style>
.booking-hero-card {
    background: linear-gradient(135deg, rgba(16, 32, 59, 0.98), rgba(180, 35, 24, 0.96));
    border: 0;
    color: #fff;
}
.booking-summary-card {
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1.35rem;
    box-shadow: 0 18px 42px rgba(15, 23, 42, 0.06);
}
.booking-filter-pills {
    gap: 0.75rem;
}
.booking-filter-pills .nav-link {
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 999px;
    color: #334155;
    font-weight: 600;
    padding: 0.8rem 1.15rem;
}
.booking-filter-pills .nav-link.active {
    background: linear-gradient(135deg, #10203b, #b42318);
    border-color: transparent;
    color: #fff;
}
.booking-filter-pills .count {
    background: rgba(255, 255, 255, 0.18);
    border-radius: 999px;
    display: inline-flex;
    margin-left: 0.55rem;
    min-width: 2rem;
    justify-content: center;
    padding: 0.1rem 0.55rem;
}
.booking-filter-pills .nav-link:not(.active) .count {
    background: #eef2ff;
    color: #10203b;
}
.countdown-shell {
    background: linear-gradient(180deg, #fff7ed, #fff);
    border: 1px solid rgba(251, 146, 60, 0.25);
    border-radius: 1.25rem;
}
.countdown-grid {
    display: grid;
    gap: 0.75rem;
    grid-template-columns: repeat(4, minmax(0, 1fr));
}
.countdown-unit {
    background: #ffffff;
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1rem;
    padding: 0.85rem 0.65rem;
    text-align: center;
}
.countdown-unit strong {
    color: #10203b;
    display: block;
    font-size: 1.35rem;
    line-height: 1;
}
.countdown-unit span {
    color: #64748b;
    display: block;
    font-size: 0.76rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    margin-top: 0.4rem;
    text-transform: uppercase;
}
.booking-action-stack {
    align-items: stretch;
}
.booking-meta-panel {
    background: #f8fafc;
    border-radius: 1.2rem;
}

.page-my-bookings {
    background: #f5f7fb;
}

.page-my-bookings .site-main {
    padding: 0;
}

.my-bookings-page {
    padding: 2rem 0 5rem;
}

.booking-hero-card {
    background:
        radial-gradient(circle at 100% 0%, rgba(255, 207, 63, 0.24) 0, transparent 18rem),
        linear-gradient(135deg, #101f46 0%, #25398e 62%, #c82323 135%);
    border: 1px solid rgba(255, 255, 255, 0.13);
    border-radius: 1.5rem !important;
    box-shadow: 0 20px 44px rgba(16, 31, 70, 0.2) !important;
}

.booking-hero-card .card-body { padding: clamp(1.3rem, 3vw, 2rem) !important; }
.booking-hero-card h1 {
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(1.8rem, 1.5rem + 1vw, 2.45rem);
    letter-spacing: -0.045em;
}

.booking-summary-card {
    background: #fff;
    border-color: #e4e7ec;
    border-radius: 1.1rem;
    box-shadow: 0 12px 26px rgba(16, 24, 40, 0.05);
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.booking-summary-card:hover { box-shadow: 0 16px 30px rgba(16, 24, 40, 0.09); transform: translateY(-2px); }
.booking-summary-card .small { color: #667085 !important; font-size: 0.78rem; font-weight: 800; text-transform: uppercase; }
.booking-summary-card .display-6 { color: #17257f; font-family: 'Sora', 'Plus Jakarta Sans', sans-serif; font-size: 1.85rem; }
.booking-summary-card .chip.soft { background: #eef2ff; color: #344da4; }

.booking-filter-pills {
    background: #fff;
    border: 1px solid #e4e7ec;
    border-radius: 1.05rem;
    box-shadow: 0 10px 24px rgba(16, 24, 40, 0.04);
    gap: 0.45rem;
    padding: 0.5rem;
}

.booking-filter-pills .nav-link {
    border: 0;
    font-size: 0.86rem;
    padding: 0.65rem 0.85rem;
}

.booking-filter-pills .nav-link.active {
    background: #17257f;
    box-shadow: 0 5px 12px rgba(23, 37, 127, 0.18);
}

.booking-filter-pills .nav-link:not(.active):hover { background: #f2f4f7; color: #17257f; }

.booking-notifications-card,
.my-booking-card,
.booking-empty-state {
    background: #fff;
    border: 1px solid #e4e7ec !important;
    border-radius: 1.25rem !important;
    box-shadow: 0 12px 28px rgba(16, 24, 40, 0.05) !important;
}

.booking-notification-item {
    background: #f8fafc;
    border: 1px solid #eaecf0 !important;
    border-radius: 0.9rem !important;
}

.my-booking-card {
    overflow: hidden;
    transition: box-shadow 0.2s ease, transform 0.2s ease;
}

.my-booking-card:hover { box-shadow: 0 18px 34px rgba(16, 24, 40, 0.09) !important; transform: translateY(-2px); }
.my-booking-card__body { padding: clamp(1.1rem, 2.5vw, 1.5rem) !important; }

.my-booking-card__header {
    align-items: flex-start;
    border-bottom: 1px solid #eaecf0;
    margin: -0.15rem -0.15rem 1.2rem;
    padding: 0 0.15rem 1.1rem;
}

.my-booking-card__reference-label {
    color: #667085;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.05em;
    text-transform: uppercase;
}

.my-booking-card__reference {
    color: #17257f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.05rem;
    overflow-wrap: anywhere;
}

.my-booking-card__route {
    color: #344054;
    font-size: 0.92rem;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.my-booking-card .chip { font-size: 0.73rem; }

.countdown-shell {
    background: linear-gradient(110deg, #fff7ed 0%, #fffdf9 100%);
    border-color: #fed7aa;
    border-radius: 1rem;
}

.countdown-unit {
    border-color: #f1dfc6;
    border-radius: 0.8rem;
    padding: 0.75rem 0.5rem;
}

.booking-meta-panel {
    background: #f8fafc;
    border: 1px solid #eaecf0;
    border-radius: 1rem;
}

.booking-meta-panel .small {
    color: #667085 !important;
    font-size: 0.72rem;
    font-weight: 800;
    letter-spacing: 0.035em;
    text-transform: uppercase;
}

.booking-action-stack .btn,
.booking-action-stack form { margin: 0; }

.booking-action-stack .btn {
    align-items: center;
    display: inline-flex;
    font-size: 0.84rem;
    font-weight: 800;
    justify-content: center;
    min-height: 2.7rem;
}

.booking-action-stack .btn-danger {
    background: linear-gradient(180deg, #ef3e38 0%, #c82323 100%);
    border: 0;
    box-shadow: 0 8px 14px rgba(200, 35, 35, 0.18);
}

@media (max-width: 767px) {
    .my-bookings-page { padding: 1.25rem 0 3.5rem; }
    .booking-hero-card, .booking-notifications-card, .my-booking-card, .booking-empty-state { border-radius: 1.05rem !important; }
    .booking-filter-pills { overflow-x: auto; flex-wrap: nowrap !important; }
    .booking-filter-pills .nav-link { white-space: nowrap; }
    .my-booking-card__header { align-items: flex-start !important; flex-direction: column; }
    .my-booking-card__header > .text-end { text-align: left !important; }
    .my-booking-card__header .d-flex { justify-content: flex-start !important; }
}
@media (max-width: 767px) {
    .countdown-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}
</style>

<section class="my-bookings-page">
    <div class="container">
        <div class="card booking-hero-card rounded-4 shadow-lg overflow-hidden mb-4">
            <div class="card-body p-4 p-lg-5">
                <div class="d-flex flex-wrap justify-content-between align-items-end gap-3">
                    <div>
                        <span class="badge rounded-pill text-bg-light text-danger fw-semibold mb-3">Passenger Dashboard</span>
                        <h1 class="display-6 fw-bold mb-2">My Bookings</h1>
                        <p class="mb-0 text-white-50">Track booking status, countdowns, payment progress, and online cancellation from one place.</p>
                    </div>
                    <div class="d-flex flex-wrap gap-2">
                        <?php if ($removableCount > 0): ?>
                            <form method="post" onsubmit="return confirm('Clear old booking history from this list?');">
                                <?php csrf_field(); ?>
                                <input type="hidden" name="action" value="clear_history">
                                <input type="hidden" name="return_view" value="<?php echo e($selectedView); ?>">
                                <button class="btn btn-outline-light rounded-4 fw-semibold" type="submit">
                                    <i class="fa-solid fa-trash-can me-2"></i>Clear History
                                </button>
                            </form>
                        <?php endif; ?>
                        <a class="btn btn-light text-danger rounded-4 fw-semibold" href="booking.php">
                            <i class="fa-solid fa-ticket me-2"></i>Book Another Trip
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
        <?php endif; ?>
        <?php if ($success !== ''): ?>
            <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
        <?php endif; ?>

        <div class="row g-3 mb-4">
            <?php foreach ($summaryCards as $card): ?>
                <div class="col-6 col-lg-3">
                    <div class="card booking-summary-card h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-start gap-3">
                                <div>
                                    <div class="small text-muted"><?php echo e($card['label']); ?></div>
                                    <div class="display-6 fw-bold mb-0"><?php echo number_format((int) $card['value']); ?></div>
                                </div>
                                <div class="chip soft"><i class="fa-solid <?php echo e($card['icon']); ?>"></i></div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <ul class="nav booking-filter-pills flex-wrap mb-4">
            <li class="nav-item">
                <a class="nav-link<?php echo $selectedView === 'all' ? ' active' : ''; ?>" href="my-bookings.php?view=all">
                    All
                    <span class="count"><?php echo number_format($viewCounts['all']); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link<?php echo $selectedView === 'active' ? ' active' : ''; ?>" href="my-bookings.php?view=active">
                    Active Trips
                    <span class="count"><?php echo number_format($viewCounts['active']); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link<?php echo $selectedView === 'action' ? ' active' : ''; ?>" href="my-bookings.php?view=action">
                    Needs Action
                    <span class="count"><?php echo number_format($viewCounts['action']); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link<?php echo $selectedView === 'history' ? ' active' : ''; ?>" href="my-bookings.php?view=history">
                    History
                    <span class="count"><?php echo number_format($viewCounts['history']); ?></span>
                </a>
            </li>
        </ul>

        <?php if ($notifications !== []): ?>
            <div class="card border-0 shadow-sm rounded-4 mb-4 booking-notifications-card">
                <div class="card-body p-4">
                    <h2 class="h5 fw-bold mb-3">Recent Alerts</h2>
                    <div class="d-grid gap-3">
                        <?php foreach ($notifications as $notification): ?>
                            <div class="border rounded-4 p-3 booking-notification-item">
                                <div class="d-flex justify-content-between gap-3">
                                    <div>
                                        <div class="fw-semibold"><?php echo e($notification['title']); ?></div>
                                        <div class="text-muted small"><?php echo e($notification['message']); ?></div>
                                    </div>
                                    <div class="text-muted small text-nowrap"><?php echo date('M j, g:i A', strtotime($notification['created_at'])); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($bookings === []): ?>
            <div class="card border-0 shadow-sm rounded-4 booking-empty-state">
                <div class="card-body p-5 text-center">
                    <i class="fa-solid fa-ticket fs-1 text-danger mb-3"></i>
                    <h2 class="h4 fw-bold">
                        <?php echo $viewCounts['all'] === 0 ? 'No bookings yet' : 'No bookings in this tab'; ?>
                    </h2>
                    <p class="text-muted mb-4">
                        <?php echo $viewCounts['all'] === 0
                            ? 'Your trips, payments, and ticket history will appear here.'
                            : 'Try another booking tab to view your active trips, actions, or history.'; ?>
                    </p>
                    <a class="btn btn-danger rounded-4 fw-semibold" href="booking.php">Start booking</a>
                </div>
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($bookings as $booking): ?>
                    <div class="col-12">
                        <div class="card border-0 shadow-sm rounded-4 overflow-hidden my-booking-card">
                            <div class="card-body p-4 my-booking-card__body">
                                <div class="d-flex flex-wrap justify-content-between gap-3 mb-3 my-booking-card__header">
                                    <div>
                                        <div class="small text-muted my-booking-card__reference-label">Booking Reference</div>
                                        <div class="h5 fw-bold mb-1 my-booking-card__reference"><?php echo e($booking['booking_reference']); ?></div>
                                        <div class="text-muted my-booking-card__route"><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                                    </div>
                                    <div class="text-end">
                                        <div class="d-flex flex-wrap justify-content-end gap-2 mb-2">
                                            <span class="chip <?php echo e($booking['status_class']); ?>"><?php echo e($booking['status_label']); ?></span>
                                            <span class="chip <?php echo e($booking['payment_class']); ?>"><?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['payment_status'] ?? '')))); ?></span>
                                            <span class="chip <?php echo e($booking['trip_chip_class']); ?>"><?php echo e(ucfirst((string) ($booking['effective_trip_status'] ?? 'scheduled'))); ?></span>
                                        </div>
                                        <div class="text-muted small">Booked <?php echo date('M j, Y g:i A', strtotime((string) $booking['booking_date'])); ?></div>
                                    </div>
                                </div>

                                <?php if ((bool) ($booking['timeline']['is_live'] ?? false)): ?>
                                    <div class="countdown-shell p-3 p-lg-4 mb-4">
                                        <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
                                            <div>
                                                <div class="small text-uppercase text-muted fw-semibold mb-1"><?php echo e((string) ($booking['timeline']['label'] ?? 'Live countdown')); ?></div>
                                                <div class="fw-semibold"><?php echo e((string) ($booking['timeline']['note'] ?? '')); ?></div>
                                            </div>
                                            <?php if ((bool) ($booking['can_cancel_booking'] ?? false)): ?>
                                                <span class="chip warning">Cancelable Online</span>
                                            <?php endif; ?>
                                        </div>
                                        <div
                                            class="countdown-grid live-countdown"
                                            data-countdown-target="<?php echo (int) ($booking['timeline']['target_timestamp'] ?? 0); ?>"
                                            data-expired-label="<?php echo e((string) ($booking['timeline']['expired_label'] ?? 'Closed')); ?>"
                                        >
                                            <div class="countdown-unit"><strong data-unit="days">00</strong><span>Days</span></div>
                                            <div class="countdown-unit"><strong data-unit="hours">00</strong><span>Hours</span></div>
                                            <div class="countdown-unit"><strong data-unit="minutes">00</strong><span>Minutes</span></div>
                                            <div class="countdown-unit"><strong data-unit="seconds">00</strong><span>Seconds</span></div>
                                        </div>
                                    </div>
                                <?php elseif ((string) ($booking['timeline']['note'] ?? '') !== ''): ?>
                                    <div class="alert alert-light border rounded-4 mb-4">
                                        <?php echo e((string) ($booking['timeline']['note'] ?? '')); ?>
                                    </div>
                                <?php endif; ?>

                                <div class="booking-meta-panel p-3 p-lg-4 mb-4">
                                    <div class="row g-3">
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="small text-muted">Departure</div>
                                            <div class="fw-semibold"><?php echo date('M j, Y g:i A', strtotime((string) ($booking['departure_date'] . ' ' . $booking['departure_time']))); ?></div>
                                        </div>
                                        <div class="col-sm-6 col-lg-2">
                                            <div class="small text-muted">Passengers</div>
                                            <div class="fw-semibold"><?php echo (int) $booking['number_of_passengers']; ?></div>
                                        </div>
                                        <div class="col-sm-6 col-lg-2">
                                            <div class="small text-muted">Tickets</div>
                                            <div class="fw-semibold"><?php echo (int) $booking['ticket_count']; ?></div>
                                        </div>
                                        <div class="col-sm-6 col-lg-2">
                                            <div class="small text-muted">Payment</div>
                                            <div class="fw-semibold text-uppercase"><?php echo e((string) ($booking['payment_method'] ?: 'Pending')); ?></div>
                                        </div>
                                        <div class="col-sm-6 col-lg-3">
                                            <div class="small text-muted">Amount</div>
                                            <div class="fw-semibold text-danger">PHP <?php echo number_format((float) $booking['total_amount'], 2); ?></div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex flex-wrap gap-2 booking-action-stack">
                                    <a class="btn btn-outline-secondary rounded-4" href="booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                        <i class="fa-solid fa-eye me-1"></i>View Details
                                    </a>
                                    <?php if ((bool) ($booking['cash_ticket_available'] ?? false)): ?>
                                        <?php if ((bool) ($booking['departure_passed'] ?? false)): ?>
                                            <span class="btn btn-outline-secondary rounded-4 disabled">
                                                <i class="fa-solid fa-clock me-1"></i>Trip Already Gone
                                            </span>
                                        <?php else: ?>
                                            <a class="btn btn-danger rounded-4" href="booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                                <i class="fa-solid fa-qrcode me-1"></i>Open Cash Ticket
                                            </a>
                                        <?php endif; ?>
                                    <?php elseif ((bool) ($booking['requires_payment'] ?? false)): ?>
                                        <a class="btn btn-danger rounded-4" href="payment.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                            <i class="fa-solid fa-wallet me-1"></i>Complete Payment
                                        </a>
                                    <?php elseif ((bool) ($booking['final_ticket_ready'] ?? false)): ?>
                                        <a class="btn btn-danger rounded-4" href="booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                            <i class="fa-solid fa-qrcode me-1"></i>Open E-Ticket
                                        </a>
                                    <?php elseif ((string) ($booking['status_label'] ?? '') === 'Missed'): ?>
                                        <span class="btn btn-outline-secondary rounded-4 disabled">
                                            <i class="fa-solid fa-bus me-1"></i>Trip Departed
                                        </span>
                                    <?php endif; ?>

                                    <?php if ((bool) ($booking['can_cancel_booking'] ?? false)): ?>
                                        <form method="post" onsubmit="return confirm('Cancel this booking?');">
                                            <?php csrf_field(); ?>
                                            <input type="hidden" name="action" value="cancel_booking">
                                            <input type="hidden" name="return_view" value="<?php echo e($selectedView); ?>">
                                            <input type="hidden" name="booking_id" value="<?php echo (int) $booking['booking_id']; ?>">
                                            <button class="btn btn-outline-danger rounded-4" type="submit">
                                                <i class="fa-solid fa-ban me-1"></i>Cancel Booking
                                            </button>
                                        </form>
                                    <?php elseif ((bool) ($booking['needs_manual_staff_assistance'] ?? false)): ?>
                                        <span class="btn btn-outline-secondary rounded-4 disabled">
                                            <i class="fa-solid fa-user-gear me-1"></i>Staff Assistance Required
                                        </span>
                                    <?php endif; ?>

                                    <?php if ((bool) ($booking['can_clear_history'] ?? false)): ?>
                                        <form method="post" onsubmit="return confirm('Remove this booking from your history?');">
                                            <?php csrf_field(); ?>
                                            <input type="hidden" name="action" value="clear_booking">
                                            <input type="hidden" name="return_view" value="<?php echo e($selectedView); ?>">
                                            <input type="hidden" name="booking_id" value="<?php echo (int) $booking['booking_id']; ?>">
                                            <button class="btn btn-outline-danger rounded-4" type="submit">
                                                <i class="fa-solid fa-trash-can me-1"></i>Remove
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </div>

                                <?php if ((string) ($booking['cancellation_message'] ?? '') !== '' && ((bool) ($booking['can_cancel_booking'] ?? false) || (bool) ($booking['needs_manual_staff_assistance'] ?? false))): ?>
                                    <div class="small text-muted mt-3"><?php echo e((string) ($booking['cancellation_message'] ?? '')); ?></div>
                                <?php elseif ((string) ($booking['status_label'] ?? '') === 'Missed'): ?>
                                    <div class="small text-muted mt-3">
                                        This paid trip already departed and was not marked as used. You can now remove it from your history. If you need exception handling, please coordinate with terminal staff.
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const countdowns = Array.from(document.querySelectorAll('.live-countdown'));
    if (countdowns.length === 0) {
        return;
    }

    function updateCountdown(node) {
        const targetSeconds = Number(node.dataset.countdownTarget || '0');
        const targetMillis = targetSeconds * 1000;
        const expiredLabel = node.dataset.expiredLabel || 'Closed';
        const remaining = Math.max(0, targetMillis - Date.now());
        const totalSeconds = Math.floor(remaining / 1000);
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        const values = {
            days: String(days).padStart(2, '0'),
            hours: String(hours).padStart(2, '0'),
            minutes: String(minutes).padStart(2, '0'),
            seconds: String(seconds).padStart(2, '0')
        };

        Object.keys(values).forEach(function (key) {
            const target = node.querySelector('[data-unit="' + key + '"]');
            if (target) {
                target.textContent = values[key];
            }
        });

        if (remaining === 0) {
            node.setAttribute('title', expiredLabel);
        }
    }

    function tickAll() {
        countdowns.forEach(updateCountdown);
    }

    tickAll();
    window.setInterval(tickAll, 1000);
});
</script>

<?php include 'includes/footer.php'; ?>
