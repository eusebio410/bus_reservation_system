# Victory Liner Bus Reservation System

A comprehensive, fully functional bus reservation system built with PHP and MySQL, designed to replicate the Victory Liner bus booking platform.

## Features

### Customer Features
- **User Registration & Login**: Create accounts, manage profile, change password
- **Search & Book Buses**: Filter by origin, destination, date, and bus class
- **Multiple Payment Methods**: Credit card, debit card, online banking, GCash, PayPal
- **Booking Management**: View, modify, and cancel bookings
- **Passenger Details**: Add detailed passenger information during booking
- **Email Notifications**: Booking confirmations and updates
- **Travel History**: View all past and upcoming bookings

### Bus Operator Features
- **Terminals Management**: Add/edit/delete bus terminals
- **Bus Fleet Management**: Manage buses, classes, capacity, and status
- **Route Management**: Manage bus routes and schedules
- **Schedule Management**: Create and manage bus schedules with pricing
- **Booking Management**: View all bookings and update statuses
- **User Management**: Manage customer accounts
- **Fare Management**: Set and manage fares for different routes and classes
- **Analytics Dashboard**: View statistics on buses, schedules, bookings, revenue

### Bus Classes
1. **Regular AC** - 45-49 seater buses with 2×2 configuration
2. **First Class/Deluxe** - 29 seater buses with 2×1 configuration and premium amenities
3. **Victory Royal Sleeper** - 32 seater premium buses with lie-flat seats

### Routes & Coverage
- 25+ terminals across Luzon
- Routes to major cities: Baguio, Dagupan, Tuguegarao, Zambales, Olongapo, and more
- 620+ active buses
- 593+ daily trips

## Installation & Setup

### Prerequisites
- XAMPP (PHP 7.4+, MySQL 5.7+)
- Web browser
- Text editor

### Step 1: Extract Files
Extract the project to your XAMPP htdocs folder:
```
C:\xampp\htdocs\bus_reservation_system\
```

### Step 2: Create Database
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Create a new database named `bus_reservation_db`
3. Import the database schema:
   - Open the SQL file: `database.sql`
   - Copy and paste all contents into phpMyAdmin's SQL tab
   - Click "Go" to execute

### Step 3: Configure Database Connection
Set the following environment variables in Apache, PHP-FPM, or your hosting control panel. Use `.env.example` as the reference; do not commit a real `.env` file because this project intentionally does not load one directly.
```php
BUS_APP_ENV=production
BUS_DB_HOST=localhost
BUS_DB_USER=bus_application_user
BUS_DB_PASS=use-a-strong-password
BUS_DB_NAME=bus_reservation_db
BUS_QR_SECRET=use-a-random-64-character-secret
BUS_APP_URL=https://example.com/bus_reservation_system
BUS_MAYA_ENVIRONMENT=production
BUS_MAYA_PUBLIC_KEY=pk-your-maya-public-key
BUS_MAYA_SECRET_KEY=sk-your-maya-secret-key
```

### GCash automatic verification

GCash uses Maya Checkout; the system does not accept screenshots or static-QR transfers as proof of payment. Before enabling the feature, confirm with Maya that the merchant account has **Maya Checkout** and **GCash acceptance** enabled. Set the public and secret Maya Checkout API keys above, then register the public HTTPS endpoint `https://your-domain/bus_reservation_system/maya-webhook.php` in Maya Business Manager for `PAYMENT_SUCCESS`, `PAYMENT_FAILED`, `PAYMENT_EXPIRED`, and `PAYMENT_CANCELLED`.

Maya recommends restricting webhook traffic to its production IPs, `18.138.50.235` and `3.1.207.200`; those are the application defaults when `BUS_MAYA_ENVIRONMENT=production`. The webhook still retrieves the payment directly from Maya using the secret API key and only marks a booking as paid when the payment ID, merchant reference, PHP currency, and exact amount all match. A user return to the site or a payment screenshot never confirms a ticket. Sandbox can validate the integration and webhook behavior, but Maya documents GCash as production-only testing.

### Step 4: Prepare the Application
From the project directory, run the idempotent setup task once after importing the database and after each release:
```
php scripts/prepare_system.php
```
This applies schema upgrades and performance indexes outside normal web requests. Create the first administrator with `php scripts/create_initial_admin.php --email=admin@example.com --name="Terminal Administrator"`.

### Step 5: Start XAMPP
1. Open XAMPP Control Panel
2. Start Apache and MySQL services

### Step 6: Access the Application
- **Customer Portal**: http://localhost/bus_reservation_system/
- **Admin Panel**: http://localhost/bus_reservation_system/admin/dashboard.php

## Initial Accounts

No administrator, staff, or passenger password is shipped with the application. Create the first administrator during deployment, store its password in a password manager, and create test passenger accounts through registration.

## Project Structure

```
bus_reservation_system/
├── index.php                 # Home page
├── booking.php               # Booking search & list
├── booking-details.php       # Booking details & confirmation
├── booking-view.php          # View specific booking
├── passenger-details.php     # Add passenger information
├── payment.php               # Payment processing
├── schedules.php             # View all schedules
├── routes.php                # View all routes
├── terminals.php             # View terminals
├── fares.php                 # View fares
├── faq.php                   # FAQ page
├── travel-guides.php         # Travel guides
├── blog.php                  # Blog/News
├── login.php                 # User login
├── register.php              # User registration
├── profile.php               # User profile
├── my-bookings.php           # My bookings
├── logout.php                # Logout
│
├── admin/
│   ├── dashboard.php         # Admin dashboard
│   └── pages/
│       ├── manage-buses.php
│       ├── manage-schedules.php
│       ├── manage-routes.php
│       ├── manage-terminals.php
│       ├── manage-fares.php
│       ├── manage-bookings.php
│       ├── manage-users.php
│       └── manage-faq.php
│
├── includes/
│   ├── config.php            # Database configuration
│   ├── header.php            # Header/Navigation
│   └── footer.php            # Footer
│
├── assets/
│   ├── css/
│   │   └── style.css         # Main stylesheet
│   ├── js/
│   │   └── script.js         # JavaScript
│   └── images/               # Images folder
│
└── database.sql              # Database schema

```

## Database Schema

### Main Tables
- **users** - Customer and admin accounts
- **buses** - Bus fleet information
- **bus_classes** - Bus class types and amenities
- **terminals** - Bus terminals across Philippines
- **routes** - Bus routes between terminals
- **schedules** - Bus schedules with pricing
- **bookings** - Customer bookings
- **passengers** - Passenger details per booking
- **fares** - Fare pricing for routes and classes
- **faqs** - Frequently asked questions
- **blog_posts** - News and updates
- **travel_guides** - Travel guide articles

## Key Features Explained

### Booking System
1. Search for buses by origin, destination, date, and class
2. Select a schedule and continue to booking
3. Enter passenger information for each traveler
4. Choose payment method
5. Complete payment
6. Receive booking confirmation with reference number

### Admin Functions
- Complete CRUD operations for all entities
- Real-time statistics and analytics
- Booking status management
- Schedule and pricing management
- User account management
- FAQ management

### Security Features
- Bcrypt password hashing with automatic upgrade from legacy SHA-256 hashes
- CSRF validation, session ID renewal at login, strict session cookies, and sign-in rate limiting
- Prepared database helpers, role-based admin/staff access, and audit logging
- Maya Checkout webhook IP allow-listing plus direct API reconciliation, exact amount/reference validation, and automatic QR ticket issuance after GCash confirmation
- Security response headers, disabled directory listing, protected storage, and cached static assets

## Deployment and Defense

Use the [deployment and defense checklist](docs/DEPLOYMENT_AND_DEFENSE.md) before your final demonstration or publication. It includes the production configuration, scheduled job, backup, smoke-test, and feature-defense checklist.

## Customization

### Colors & Branding
Main colors are defined in `assets/css/style.css`:
```css
--primary-red: #A72D2D;
--dark-navy: #1a1a2e;
--warning-yellow: #ffc107;
```

### Adding Buses & Routes
1. Go to Admin > Manage Buses to add new buses
2. Go to Admin > Manage Terminals to add new terminals
3. Go to Admin > Manage Schedules to create bus schedules
4. Go to Admin > Manage Fares to set pricing

### Adding FAQ & Content
1. Go to Admin > Manage FAQ to add FAQs
2. Use the front-end pages (FAQ, Travel Guides, Blog) to display content

## Common Operations

### Add a New Bus
1. Admin Login → Dashboard → Manage Buses
2. Fill in bus details (code, class, capacity, etc.)
3. Click "Add Bus"

### Create a Schedule
1. Admin Login → Dashboard → Manage Schedules
2. Select bus, route, date, and time
3. Set price and available seats
4. Click "Add Schedule"

### View Bookings
1. Admin Login → Dashboard → Manage Bookings
2. View all customer bookings with status
3. Update booking status as needed

### Add FAQ
1. Admin Login → Dashboard → Manage FAQ
2. Enter category, question, and answer
3. Click "Add FAQ"

## Troubleshooting

### Database Connection Error
- Check if MySQL is running in XAMPP
- Verify database credentials in `includes/config.php`
- Ensure database `bus_reservation_db` exists

### Login Issues
- Clear browser cookies and try again
- Verify credentials are correct (email/password)
- Check if user account exists in database

### Session/Login Not Working
- Ensure `session_start()` is called in config.php
- Check browser's cookie settings
- Clear XAMPP temp files and restart

### Page Not Found (404)
- Verify all files are in correct directory
- Check that application is accessed from `localhost/bus_reservation_system/`
- Ensure htaccess or URL routing is configured properly

## Features To Add (Future Enhancements)

- SMS/Email notifications for bookings
- Additional payment providers beyond the integrated Maya Checkout flow
- Mobile app for booking
- Multiple language support
- Advanced reporting and analytics
- CRM System
- Fleet GPS tracking
- Seat selection UI
- Online customer support chat
- Loyalty points system
- Rating and reviews

## Performance Tips

- Use database indexing for frequently queried fields
- Cache popular schedules/routes
- Implement pagination for large datasets
- Optimize images before uploading
- Use CDN for static assets
- Enable GZIP compression

## Support & Documentation

For more information or issues:
1. Check the FAQ page for common questions
2. Review the code comments throughout
3. Check database structure in `database.sql`
4. Test functionality in admin panel first

## License

This project is created for educational purposes as a capstone project.

## Created By

GitHub Copilot - Educational Bus Reservation System

---

**Last Updated**: April 2, 2026
**Version**: 1.0.0 (Initial Release)

**Enjoy your fully functional Victory Liner Bus Reservation System!**

