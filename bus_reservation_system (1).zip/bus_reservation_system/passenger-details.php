<?php
$base_url = '';
$page_title = 'Passenger Details';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$bookingId = (int) isset_get('booking_id');
if ($bookingId < 1) {
    redirect('booking.php');
}

$booking = db_select_one(
    "SELECT b.*, s.departure_date, s.departure_time, s.arrival_time, s.price,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.booking_id = ?
     LIMIT 1",
    'i',
    [$bookingId]
);

if (!$booking) {
    redirect('booking.php');
}

if (!can_access_admin_panel() && (int) $booking['user_id'] !== (int) $_SESSION['user_id']) {
    redirect('my-bookings.php');
}

if (in_array($booking['status'], ['cancelled', 'expired'], true)) {
    redirect('my-bookings.php');
}

$seatManifest = get_booking_seat_manifest($bookingId);

if ($seatManifest === []) {
    redirect('booking-details.php?schedule_id=' . (int) $booking['schedule_id']);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passengers = [];
    $uploadedIdProofs = [];

    foreach ($seatManifest as $index => $seatSlot) {
        $slot = $index + 1;
        $fullname = isset_post('passenger_' . $slot . '_name');
        $email = normalize_email_address(isset_post('passenger_' . $slot . '_email'));
        $phoneInput = isset_post('passenger_' . $slot . '_phone');
        $phone = normalize_ph_phone($phoneInput);
        $age = isset_post('passenger_' . $slot . '_age');
        $gender = strtoupper(isset_post('passenger_' . $slot . '_gender')) ?: 'M';
        $idType = isset_post('passenger_' . $slot . '_id_type');
        $idProofPath = '';

        if ($fullname === '') {
            $error = 'Please enter the passenger name for every seat.';
            break;
        }

        if ($email !== '' && !is_valid_email_address($email)) {
            $error = 'Please enter a valid email address for each passenger or leave it blank.';
            break;
        }

        if ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
            $error = 'Please use a valid Philippine mobile number such as 09171234567 or +639171234567 for each passenger or leave it blank.';
            break;
        }

        if (!in_array($idType, ['', 'Senior Citizen', 'PWD', 'Student'], true)) {
            $error = 'Please choose a valid discount ID type.';
            break;
        }

        if ($idType !== '') {
            $proofFile = $_FILES['passenger_' . $slot . '_id_proof'] ?? [];
            if (($proofFile['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                $error = 'Upload a clear photo or PDF of the discount ID for each claim.';
                break;
            }
            $idProofPath = save_uploaded_file($proofFile, 'storage/discount-ids');
            if ($idProofPath === null) {
                $error = 'The ID file must be a valid JPG, PNG, WebP, or PDF smaller than 5 MB.';
                break;
            }
            $uploadedIdProofs[] = $idProofPath;
        } elseif (($_FILES['passenger_' . $slot . '_id_proof']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $error = 'Choose an ID type before entering or uploading a discount ID.';
            break;
        }

        $passengers[] = [
            'fullname' => $fullname,
            'email' => $email,
            'phone' => $phone,
            'age' => $age !== '' ? (int) $age : null,
            'gender' => in_array($gender, ['M', 'F'], true) ? $gender : 'M',
            'id_type' => $idType,
            'id_proof_path' => $idProofPath,
        ];
    }

    if ($error === '') {
        $hasDiscountClaim = count(array_filter($passengers, static fn($passenger) => $passenger['id_type'] !== '')) > 0;
        if ($hasDiscountClaim && isset_post('discount_id_consent') !== '1') {
            $error = 'Please confirm that staff may review the submitted ID for this booking.';
        }
    }

    if ($error === '') {
        $result = attach_passengers_to_booking($bookingId, $passengers);
        if ($result['ok']) {
            redirect('payment.php?booking_id=' . $bookingId);
        }

        $error = $result['message'];
    }

    if ($error !== '') {
        foreach ($uploadedIdProofs as $uploadedIdProof) {
            $absoluteProofPath = __DIR__ . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $uploadedIdProof);
            if (is_file($absoluteProofPath)) {
                unlink($absoluteProofPath);
            }
        }
    }
}

include 'includes/header.php';
?>

<style>
.page-passenger-details {
    background: #f5f7fb;
}

.page-passenger-details .site-main {
    padding: 0;
}

.passenger-page {
    padding: 2rem 0 5rem;
}

.passenger-page__back {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.9rem;
    font-weight: 800;
    gap: 0.55rem;
    margin-bottom: 1.25rem;
    text-decoration: none;
}

.passenger-page__back:hover { color: #17257f; }

.passenger-page__heading {
    align-items: end;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-bottom: 1.7rem;
}

.passenger-page__eyebrow {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 800;
    gap: 0.45rem;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.passenger-page__heading h1 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(1.8rem, 1.5rem + 1vw, 2.45rem);
    letter-spacing: -0.045em;
    margin: 0.35rem 0 0.45rem;
}

.passenger-page__heading p { color: #667085; margin: 0; }

.passenger-steps {
    align-items: center;
    display: inline-flex;
    gap: 0.45rem;
}

.passenger-steps span {
    background: #d0d5dd;
    border-radius: 999px;
    height: 0.42rem;
    width: 1.9rem;
}

.passenger-steps span.is-complete { background: #344da4; }
.passenger-steps span.is-current { background: #ef3e38; }

.passenger-journey-card,
.passenger-form-card {
    background: #fff;
    border: 1px solid #e4e7ec;
    border-radius: 1.5rem;
    box-shadow: 0 18px 42px rgba(16, 24, 40, 0.07);
    overflow: hidden;
}

.passenger-journey-card {
    position: sticky;
    top: 1.25rem;
}

.passenger-journey-card__hero {
    background:
        radial-gradient(circle at 100% 0%, rgba(255, 207, 63, 0.25) 0, transparent 8rem),
        linear-gradient(135deg, #101f46 0%, #25398e 100%);
    color: #fff;
    padding: 1.4rem;
}

.passenger-journey-card__step {
    color: #c7d7fe;
    display: block;
    font-size: 0.76rem;
    font-weight: 800;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.passenger-journey-card__route {
    align-items: center;
    display: grid;
    gap: 0.5rem;
    grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
    margin-top: 0.85rem;
}

.passenger-journey-card__route strong {
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1rem;
    overflow-wrap: anywhere;
}

.passenger-journey-card__route strong:last-child { text-align: right; }
.passenger-journey-card__route i { color: #ffcf3f; }

.passenger-journey-card__body { padding: 1.3rem; }

.passenger-trip-detail {
    border-bottom: 1px solid #eaecf0;
    padding: 0.75rem 0;
}

.passenger-trip-detail:first-child { padding-top: 0; }
.passenger-trip-detail:last-child { border-bottom: 0; padding-bottom: 0; }

.passenger-trip-detail span {
    color: #667085;
    display: block;
    font-size: 0.7rem;
    font-weight: 800;
    letter-spacing: 0.04em;
    margin-bottom: 0.28rem;
    text-transform: uppercase;
}

.passenger-trip-detail strong {
    color: #1d2939;
    display: block;
    font-size: 0.9rem;
    overflow-wrap: anywhere;
}

.passenger-seat-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 0.45rem;
}

.passenger-seat-tags b {
    background: #eef2ff;
    border: 1px solid #c7d7fe;
    border-radius: 999px;
    color: #25398e;
    font-size: 0.76rem;
    padding: 0.35rem 0.62rem;
}

.passenger-cash-note {
    background: #fffaeb;
    border: 1px solid #fedf89;
    border-radius: 0.85rem;
    color: #854a0e;
    font-size: 0.78rem;
    line-height: 1.5;
    margin-top: 1rem;
    padding: 0.75rem;
}

.passenger-form-card__header {
    background: linear-gradient(135deg, #fff9f8 0%, #fff 85%);
    border-bottom: 1px solid #eaecf0;
    padding: 1.3rem 1.5rem;
}

.passenger-form-card__header h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.3rem;
    margin: 0 0 0.3rem;
}

.passenger-form-card__header p { color: #667085; margin: 0; }
.passenger-form-card__body { padding: clamp(1.1rem, 2.5vw, 1.65rem); }

.passenger-form-card .alert {
    border: 0;
    border-radius: 0.85rem;
    font-size: 0.88rem;
}

.passenger-info-note {
    align-items: flex-start;
    background: #eff8ff;
    border: 1px solid #b2ddff;
    border-radius: 0.85rem;
    color: #175cd3;
    display: flex;
    font-size: 0.8rem;
    gap: 0.6rem;
    line-height: 1.5;
    margin-bottom: 1.1rem;
    padding: 0.78rem;
}

.passenger-info-note i { margin-top: 0.12rem; }
.passenger-info-note code { color: inherit; font-weight: 800; }

.passenger-entry {
    background: #fbfcfe;
    border: 1px solid #e4e7ec;
    border-radius: 1.05rem;
    padding: 1.05rem;
}

.passenger-entry__header {
    align-items: center;
    display: flex;
    justify-content: space-between;
    margin-bottom: 1rem;
}

.passenger-entry__header h3 {
    color: #1d2939;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1rem;
    margin: 0;
}

.passenger-entry__seat {
    background: #fff0ee;
    border: 1px solid #fecdca;
    border-radius: 999px;
    color: #b42318;
    font-size: 0.78rem;
    font-weight: 800;
    padding: 0.32rem 0.6rem;
}

.passenger-entry .form-label {
    color: #344054;
    font-size: 0.82rem;
    font-weight: 800;
    margin-bottom: 0.42rem;
}

.passenger-entry .form-control,
.passenger-entry .form-select {
    border-color: #d0d5dd;
    border-radius: 0.75rem;
    font-size: 0.9rem;
    min-height: 2.9rem;
}

.passenger-entry .form-control:focus,
.passenger-entry .form-select:focus {
    border-color: #344da4;
    box-shadow: 0 0 0 0.2rem rgba(52, 77, 164, 0.13);
}

.passenger-submit {
    align-items: center;
    background: linear-gradient(180deg, #ef3e38 0%, #c82323 100%);
    border: 0;
    border-radius: 0.85rem;
    box-shadow: 0 10px 18px rgba(200, 35, 35, 0.22);
    color: #fff;
    display: flex;
    font-weight: 800;
    gap: 0.6rem;
    justify-content: center;
    min-height: 3.25rem;
    transition: filter 0.2s ease, transform 0.2s ease;
}

.passenger-submit:hover { color: #fff; filter: brightness(1.04); transform: translateY(-1px); }

@media (max-width: 991px) { .passenger-journey-card { position: static; } }
@media (max-width: 767px) {
    .passenger-page { padding: 1.25rem 0 3.5rem; }
    .passenger-page__heading { align-items: flex-start; flex-direction: column; margin-bottom: 1.2rem; }
    .passenger-journey-card, .passenger-form-card { border-radius: 1.1rem; }
    .passenger-journey-card__hero, .passenger-journey-card__body, .passenger-form-card__header { padding: 1.1rem; }
}
</style>

<section class="passenger-page">
    <div class="container">
        <a class="passenger-page__back" href="booking-details.php?schedule_id=<?php echo (int) $booking['schedule_id']; ?>"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Back to seat selection</a>

        <div class="passenger-page__heading">
            <div>
                <span class="passenger-page__eyebrow"><i class="fa-solid fa-users" aria-hidden="true"></i> Traveller information</span>
                <h1>Passenger details</h1>
                <p>Add the details for every selected seat before continuing to payment.</p>
            </div>
            <div class="passenger-steps" aria-label="Booking step 2 of 3"><span class="is-complete"></span><span class="is-current"></span><span></span></div>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <aside class="passenger-journey-card" aria-label="Trip summary">
                    <div class="passenger-journey-card__hero">
                        <span class="passenger-journey-card__step">Step 2 of 3 · Passenger manifest</span>
                        <div class="passenger-journey-card__route">
                            <strong><?php echo e($booking['origin_name']); ?></strong>
                            <i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
                            <strong><?php echo e($booking['destination_name']); ?></strong>
                        </div>
                    </div>
                    <div class="passenger-journey-card__body">
                        <div class="passenger-trip-detail">
                            <span>Departure</span>
                            <strong><?php echo date('D, F j, Y · g:i A', strtotime($booking['departure_date'] . ' ' . $booking['departure_time'])); ?></strong>
                        </div>
                        <div class="passenger-trip-detail">
                            <span>Payment mode</span>
                            <strong><?php echo e(ucwords((string) $booking['payment_method'])); ?></strong>
                        </div>
                        <div class="passenger-trip-detail">
                            <span><?php echo ($booking['payment_method'] ?? '') === 'cash' ? 'Seat preference' : 'Seats locked'; ?></span>
                            <div class="passenger-seat-tags">
                                <?php foreach ($seatManifest as $seatSlot): ?><b><?php echo e($seatSlot['seat_label']); ?></b><?php endforeach; ?>
                            </div>
                        </div>
                        <?php if (($booking['payment_method'] ?? '') === 'cash'): ?>
                            <div class="passenger-cash-note">
                                Cash bookings do not block seats yet. Staff will confirm the final seat assignment once payment is received at the terminal.
                            </div>
                        <?php endif; ?>
                    </div>
                </aside>
            </div>

            <div class="col-lg-8">
                <div class="passenger-form-card">
                    <div class="passenger-form-card__header">
                        <h2>Who is travelling?</h2>
                        <p>Complete one form for each selected seat.</p>
                    </div>
                    <div class="passenger-form-card__body">
                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger"><i class="fa-solid fa-circle-exclamation me-2" aria-hidden="true"></i><?php echo e($error); ?></div>
                        <?php endif; ?>
                        <div class="passenger-info-note">
                            <i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>Passenger emails may use any valid email address. Phone numbers may use either 09XXXXXXXXX or +639XXXXXXXXX. PayMongo charges the full fare. If staff approves the uploaded ID, the bus operator pays the configured discount in cash at departure. Online government ID authentication is not available.</span>
                        </div>

                        <form method="post" enctype="multipart/form-data" class="d-grid gap-4">
                            <?php csrf_field(); ?>
                            <?php foreach ($seatManifest as $index => $seatSlot): ?>
                                <?php $slot = $index + 1; ?>
                                <div class="passenger-entry">
                                    <div class="passenger-entry__header">
                                        <h3>Passenger <?php echo $slot; ?></h3>
                                        <span class="passenger-entry__seat">Seat <?php echo e($seatSlot['seat_label']); ?></span>
                                    </div>
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_name">Full name</label>
                                            <input class="form-control" id="passenger_<?php echo $slot; ?>_name" type="text" name="passenger_<?php echo $slot; ?>_name" value="<?php echo e($_POST['passenger_' . $slot . '_name'] ?? ($slot === 1 ? ($_SESSION['user_name'] ?? '') : '')); ?>" required>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_email">Email <span class="text-muted small">(Optional)</span></label>
                                            <input class="form-control" id="passenger_<?php echo $slot; ?>_email" type="email" name="passenger_<?php echo $slot; ?>_email" value="<?php echo e($_POST['passenger_' . $slot . '_email'] ?? ($slot === 1 ? ($_SESSION['user_email'] ?? '') : '')); ?>" placeholder="name@example.com">
                                        </div>
                                        <div class="col-md-5">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_phone">Phone</label>
                                            <input class="form-control" id="passenger_<?php echo $slot; ?>_phone" type="tel" name="passenger_<?php echo $slot; ?>_phone" inputmode="tel" pattern="(?:09\d{9}|\+639\d{9})" maxlength="13" placeholder="09171234567" value="<?php echo e($_POST['passenger_' . $slot . '_phone'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-3">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_age">Age</label>
                                            <input class="form-control" id="passenger_<?php echo $slot; ?>_age" type="number" min="1" max="120" name="passenger_<?php echo $slot; ?>_age" value="<?php echo e($_POST['passenger_' . $slot . '_age'] ?? ''); ?>">
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_gender">Gender</label>
                                            <select class="form-select" id="passenger_<?php echo $slot; ?>_gender" name="passenger_<?php echo $slot; ?>_gender">
                                                <option value="M" <?php echo (($_POST['passenger_' . $slot . '_gender'] ?? 'M') === 'M') ? 'selected' : ''; ?>>Male</option>
                                                <option value="F" <?php echo (($_POST['passenger_' . $slot . '_gender'] ?? '') === 'F') ? 'selected' : ''; ?>>Female</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_id_type">Discount ID type <span class="text-muted small">(Optional)</span></label>
                                            <select class="form-select" id="passenger_<?php echo $slot; ?>_id_type" name="passenger_<?php echo $slot; ?>_id_type">
                                                <option value="">No discount claim</option>
                                                <?php foreach (['Senior Citizen', 'PWD', 'Student'] as $discountIdType): ?>
                                                    <option value="<?php echo e($discountIdType); ?>" <?php echo (($_POST['passenger_' . $slot . '_id_type'] ?? '') === $discountIdType) ? 'selected' : ''; ?>><?php echo e($discountIdType); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label" for="passenger_<?php echo $slot; ?>_id_proof">ID photo or PDF</label>
                                            <input class="form-control" id="passenger_<?php echo $slot; ?>_id_proof" type="file" name="passenger_<?php echo $slot; ?>_id_proof" accept="image/jpeg,image/png,image/webp,application/pdf">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                            <label class="passenger-info-note" for="discount_id_consent">
                                <input id="discount_id_consent" type="checkbox" name="discount_id_consent" value="1" <?php echo isset($_POST['discount_id_consent']) ? 'checked' : ''; ?>>
                                <span>I confirm each submitted ID belongs to the named passenger and consent to staff reviewing it for this booking. ID files are restricted to authorized staff.</span>
                            </label>

                            <button class="passenger-submit" type="submit">
                                Continue to payment <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
