<?php
$base_url = '';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

$user = db_select_one(
    'SELECT * FROM users WHERE user_id = ? LIMIT 1',
    'i',
    [$user_id]
);

if (!$user) {
    logout_user();
    redirect('login.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $fullname = isset_post('fullname');
    $phoneInput = isset_post('phone');
    $phone = normalize_ph_phone($phoneInput);
    $address = isset_post('address');

    if ($fullname === '') {
        $error = 'Full name is required.';
    } elseif ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
        $error = 'Please use a valid Philippine mobile number, such as 09171234567 or +639171234567.';
    } elseif (db_execute(
        'UPDATE users SET fullname = ?, phone = ?, address = ?, updated_at = NOW() WHERE user_id = ?',
        'sssi',
        [$fullname, $phone, $address, $user_id]
    )) {
        $_SESSION['user_name'] = $fullname;
        $success = "Profile updated successfully!";
        $_SESSION['user_phone'] = $phone;
        $user = db_select_one(
            'SELECT * FROM users WHERE user_id = ? LIMIT 1',
            'i',
            [$user_id]
        );
    } else {
        $error = "Error updating profile. Please try again.";
    }
}
ob_start();
?>
    <style>
        :root {
            --bs-body-bg: #f8f9fa;
            --vl-red: #A72D2D;
            --vl-navy: #1a1a2e;
            --vl-yellow: #ffc107;
        }
        body {
            background-color: #f8f9fa;
        }
        .profile-header {
            background: linear-gradient(135deg, var(--vl-navy) 0%, var(--vl-red) 100%);
            color: white;
            padding: 40px 20px;
            margin-bottom: 40px;
        }
        .profile-header h1 {
            font-size: 2.5rem;
            font-weight: bold;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .profile-header p {
            margin: 10px 0 0 0;
            opacity: 0.9;
        }
        .profile-avatar {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 120px;
            height: 120px;
            background-color: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            font-size: 3rem;
            margin-bottom: 20px;
        }
        .profile-card {
            background: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        .profile-card:hover {
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        .card-header-custom {
            background: linear-gradient(135deg, var(--vl-navy) 0%, var(--vl-red) 100%);
            color: white;
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .card-header-custom h2 {
            margin: 0;
            font-size: 1.5rem;
            font-weight: bold;
        }
        .card-header-custom i {
            font-size: 1.8rem;
        }
        .profile-card .card-body {
            padding: 30px;
        }
        .form-group-custom {
            margin-bottom: 25px;
        }
        .form-label-custom {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: bold;
            color: var(--vl-navy);
            margin-bottom: 10px;
            font-size: 1rem;
        }
        .form-label-custom i {
            color: var(--vl-red);
            font-size: 1.1rem;
        }
        .form-control:focus {
            border-color: var(--vl-red);
            box-shadow: 0 0 0 0.2rem rgba(167, 45, 45, 0.25);
        }
        .form-control {
            border-radius: 8px;
            padding: 12px 15px;
            border: 1px solid #ddd;
            font-size: 1rem;
        }
        .form-control:disabled,
        .form-control[readonly] {
            background-color: #f8f9fa;
            color: #6c757d;
        }
        .textarea-custom {
            resize: vertical;
            min-height: 120px;
        }
        .button-group {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        .btn-custom {
            padding: 12px 30px;
            font-weight: bold;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
            font-size: 1rem;
        }
        .btn-primary-custom {
            background-color: var(--vl-red);
            color: white;
        }
        .btn-primary-custom:hover {
            background-color: #8a2222;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(167, 45, 45, 0.3);
        }
        .btn-secondary-custom {
            background-color: #6c757d;
            color: white;
        }
        .btn-secondary-custom:hover {
            background-color: #5a6268;
            color: white;
            transform: translateY(-2px);
        }
        .btn-info-custom {
            background-color: #17a2b8;
            color: white;
        }
        .btn-info-custom:hover {
            background-color: #138496;
            color: white;
            transform: translateY(-2px);
        }
        .account-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .info-item {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--vl-red);
        }
        .info-label {
            color: #6c757d;
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: bold;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .info-value {
            color: var(--vl-navy);
            font-size: 1.1rem;
            font-weight: bold;
        }
        .alert-custom {
            border-radius: 8px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success-custom {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-danger-custom {
            background-color: #f8d7da;
            color: #721c24;
        }
        .alert-custom i {
            font-size: 1.3rem;
        }
        @media (max-width: 768px) {
            .profile-header h1 {
                font-size: 1.8rem;
            }
            .button-group {
                flex-direction: column;
            }
            .btn-custom {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
<?php
$page_head_extra = ob_get_clean();
$page_title = 'My Profile - Gonzaga Terminal';
include 'includes/header.php';
?>
    <section class="pb-5">
        <!-- Profile Header -->
        <div class="profile-header">
            <div class="container">
                <div class="profile-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h1>
                    <i class="fas fa-user-circle"></i> My Profile
                </h1>
                <p>Manage your account information and preferences</p>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container py-4">
            <!-- Alerts -->
            <?php if ($error): ?>
                <div class="alert-custom alert-danger-custom">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert-custom alert-success-custom">
                    <i class="fas fa-check-circle"></i>
                    <span><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Edit Profile Card -->
                <div class="col-lg-8">
                    <div class="profile-card">
                        <div class="card-header-custom">
                            <i class="fas fa-edit"></i>
                            <h2>Edit Profile Information</h2>
                        </div>

                        <div class="card-body">
                            <form method="POST">
                                <?php csrf_field(); ?>
                                <!-- Full Name -->
                                <div class="form-group-custom">
                                    <label for="fullname" class="form-label-custom">
                                        <i class="fas fa-user"></i> Full Name
                                    </label>
                                    <input 
                                        type="text" 
                                        name="fullname" 
                                        id="fullname" 
                                        class="form-control" 
                                        value="<?php echo htmlspecialchars($user['fullname']); ?>" 
                                        required>
                                </div>

                                <!-- Email Address -->
                                <div class="form-group-custom">
                                    <label for="email" class="form-label-custom">
                                        <i class="fas fa-envelope"></i> Email Address
                                    </label>
                                    <input 
                                        type="email" 
                                        id="email" 
                                        class="form-control" 
                                        value="<?php echo htmlspecialchars($user['email']); ?>" 
                                        disabled>
                                    <small class="text-muted d-block mt-2">
                                        <i class="fas fa-info-circle"></i> Email address cannot be changed
                                    </small>
                                </div>

                                <!-- Phone Number -->
                                <div class="form-group-custom">
                                    <label for="phone" class="form-label-custom">
                                        <i class="fas fa-phone"></i> Phone Number
                                    </label>
                                    <input 
                                        type="tel" 
                                        name="phone" 
                                        id="phone" 
                                        class="form-control" 
                                        inputmode="tel"
                                        pattern="(?:09\d{9}|\+639\d{9})"
                                        maxlength="13"
                                        placeholder="09171234567"
                                        value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                                    <small class="text-muted d-block mt-2">
                                        <i class="fas fa-info-circle"></i> Use Philippine mobile format like +639171234567
                                    </small>
                                </div>

                                <!-- Address -->
                                <div class="form-group-custom">
                                    <label for="address" class="form-label-custom">
                                        <i class="fas fa-map-marker-alt"></i> Address
                                    </label>
                                    <textarea 
                                        name="address" 
                                        id="address" 
                                        class="form-control textarea-custom"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                                </div>

                                <!-- Button Group -->
                                <div class="button-group">
                                    <button type="submit" class="btn-custom btn-primary-custom">
                                        <i class="fas fa-save"></i> Save Changes
                                    </button>
                                    <a href="my-bookings.php" class="btn-custom btn-info-custom">
                                        <i class="fas fa-history"></i> My Bookings
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Account Info Sidebar -->
                <div class="col-lg-4">
                    <div class="profile-card">
                        <div class="card-header-custom">
                            <i class="fas fa-info-circle"></i>
                            <h2>Account Info</h2>
                        </div>

                        <div class="card-body">
                            <div class="account-info-grid">
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-calendar"></i> Member Since
                                    </div>
                                    <div class="info-value">
                                        <?php echo date('M d, Y', strtotime($user['created_at'])); ?>
                                    </div>
                                </div>

                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-sync"></i> Last Updated
                                    </div>
                                    <div class="info-value">
                                        <?php echo date('M d, Y', strtotime($user['updated_at'])); ?>
                                    </div>
                                </div>

                                <div class="info-item" style="grid-column: 1 / -1;">
                                    <div class="info-label">
                                        <i class="fas fa-user-tag"></i> Account Status
                                    </div>
                                    <div class="info-value" style="color: #28a745;">
                                        <i class="fas fa-check-circle"></i> Active
                                    </div>
                                </div>
                            </div>

                            <!-- Additional Info -->
                            <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid #e9ecef;">
                                <div class="info-label">
                                    <i class="fas fa-link"></i> Quick Links
                                </div>
                                <ul style="list-style: none; padding: 0; margin: 15px 0 0 0;">
                                    <li style="margin-bottom: 10px;">
                                        <a href="my-bookings.php" style="color: var(--vl-red); text-decoration: none; font-weight: bold;">
                                            <i class="fas fa-ticket-alt"></i> View My Bookings
                                        </a>
                                    </li>
                                    <li style="margin-bottom: 10px;">
                                        <a href="booking.php" style="color: var(--vl-red); text-decoration: none; font-weight: bold;">
                                            <i class="fas fa-plus-circle"></i> Book a Ticket
                                        </a>
                                    </li>
                                    <li>
                                        <form method="post" action="logout.php?scope=site" style="display: inline;">
                                            <?php csrf_field(); ?>
                                            <button type="submit" style="background: transparent; border: 0; color: #dc3545; cursor: pointer; font-weight: bold; padding: 0;">
                                                <i class="fas fa-sign-out-alt"></i> Logout
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>
