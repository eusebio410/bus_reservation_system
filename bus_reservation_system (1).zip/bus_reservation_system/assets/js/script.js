/*
 * Victory Liner Bus Reservation System
 * Main JavaScript File
 */

document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Initialize Application
function initializeApp() {
    setupDatePickers();
    setupFormValidation();
    setupAlertDismissal();
    setupSmoothScroll();
    setupDropdownAnimation();
    setupAuthInteractions();
    setupResponsiveNavigation();
}

// ================================
// DATE PICKER SETUP
// ================================

function setupDatePickers() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        // Use the visitor's local calendar date. toISOString() uses UTC and can
        // incorrectly make Philippine users wait until the next day near midnight.
        const today = getLocalDateValue();
        input.setAttribute('min', today);
        
        // Add change event listener
        input.addEventListener('change', function() {
            validateDateInput(this);
        });
    });
}

function getLocalDateValue(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
}

function validateDateInput(input) {
    if (!input.value) {
        return;
    }

    if (input.value < getLocalDateValue()) {
        showAlert('Please select a date today or in the future', 'warning');
        input.value = '';
    }
}

// ================================
// FORM VALIDATION
// ================================

function setupFormValidation() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!validateForm(this)) {
                e.preventDefault();
                showAlert('Please fill in all required fields correctly', 'danger');
            }
        });
    });
}

function validateForm(form) {
    const inputs = form.querySelectorAll('input[required]:not(:disabled), select[required]:not(:disabled), textarea[required]:not(:disabled)');
    let isValid = true;

    inputs.forEach(input => {
        if (!input.checkValidity()) {
            isValid = false;
            highlightInvalidInput(input);
        } else {
            removeInputHighlight(input);
        }
    });

    return isValid;
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function highlightInvalidInput(input) {
    input.classList.add('is-invalid');
    input.classList.remove('is-valid');
}

function removeInputHighlight(input) {
    input.classList.remove('is-invalid');
    input.classList.add('is-valid');
}

// ================================
// ALERT HANDLING
// ================================

function setupAlertDismissal() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert.classList.contains('alert-success') || alert.classList.contains('alert-info')) {
                alert.style.transition = 'opacity 0.5s ease';
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 500);
            }
        }, 5000);
    });
}

function showAlert(message, type = 'info') {
    const safeTypes = ['danger', 'success', 'warning', 'info'];
    const alertType = safeTypes.includes(type) ? type : 'info';
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${alertType} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');

    const icon = document.createElement('i');
    icon.className = `fas fa-${getAlertIcon(alertType)}`;
    icon.setAttribute('aria-hidden', 'true');
    alertDiv.appendChild(icon);
    alertDiv.append(' ', String(message));

    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.className = 'btn-close';
    closeButton.setAttribute('data-bs-dismiss', 'alert');
    closeButton.setAttribute('aria-label', 'Close');
    alertDiv.appendChild(closeButton);
    
    const container = document.querySelector('main') || document.body;
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto dismiss success/info alerts
    if (alertType === 'success' || alertType === 'info') {
        setTimeout(() => {
            alertDiv.style.transition = 'opacity 0.5s ease';
            alertDiv.style.opacity = '0';
            setTimeout(() => alertDiv.remove(), 500);
        }, 5000);
    }
}

function getAlertIcon(type) {
    const icons = {
        'danger': 'exclamation-circle',
        'success': 'check-circle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// ================================
// CURRENCY FORMATTING
// ================================

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PH', {
        style: 'currency',
        currency: 'PHP'
    }).format(amount);
}

function formatCurrencyInPage() {
    const currencyElements = document.querySelectorAll('[data-currency]');
    currencyElements.forEach(element => {
        const amount = parseFloat(element.dataset.currency);
        if (!isNaN(amount)) {
            element.textContent = formatCurrency(amount);
        }
    });
}

// ================================
// PASSENGER COUNT CALCULATION
// ================================

function updatePassengerTotal(event) {
    const passengerCount = parseInt(event.target.value);
    const basePrice =  parseFloat(document.getElementById('basePrice')?.value || 0);
    
    if (!isNaN(passengerCount) && !isNaN(basePrice)) {
        const totalPrice = passengerCount * basePrice;
        const totalDiv = document.getElementById('totalPrice');
        if (totalDiv) {
            totalDiv.textContent = formatCurrency(totalPrice);
            totalDiv.setAttribute('data-total', totalPrice);
        }
    }
    
    // Update passenger form rows
    updatePassengerForms(passengerCount);
}

function updatePassengerForms(count) {
    const formsContainer = document.getElementById('passengerFormsContainer');
    if (!formsContainer) return;
    
    formsContainer.innerHTML = '';
    for (let i = 1; i <= count; i++) {
        const formHTML = `
            <div class="card mb-3">
                <div class="card-header bg-danger text-white">
                    <h5 class="mb-0"><i class="fas fa-user"></i> Passenger ${i}</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name *</label>
                            <input type="text" class="form-control" name="passenger_name_${i}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email *</label>
                            <input type="email" class="form-control" name="passenger_email_${i}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Phone Number *</label>
                            <input type="tel" class="form-control" name="passenger_phone_${i}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Age *</label>
                            <input type="number" class="form-control" name="passenger_age_${i}" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Gender *</label>
                            <select class="form-select" name="passenger_gender_${i}" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        `;
        formsContainer.insertAdjacentHTML('beforeend', formHTML);
    }
}

// ================================
// SMOOTH SCROLLING
// ================================

function setupSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            }
        });
    });
}

// ================================
// DROPDOWN ANIMATION
// ================================

function setupDropdownAnimation() {
    // Get all dropdown toggles
    const dropdownToggles = document.querySelectorAll('[data-bs-toggle="dropdown"]');
    
    dropdownToggles.forEach(toggle => {
        // Prevent default anchor behavior
        toggle.addEventListener('click', function(e) {
            // Let Bootstrap handle the toggle
            e.preventDefault();
        });
        
        // Listen for Bootstrap dropdown events
        toggle.addEventListener('show.bs.dropdown', function() {
            this.setAttribute('aria-expanded', 'true');
        });
        
        toggle.addEventListener('hide.bs.dropdown', function() {
            this.setAttribute('aria-expanded', 'false');
        });
    });
}

// ================================
// RESPONSIVE NAVIGATION
// ================================

function setupResponsiveNavigation() {
    const navCollapse = document.getElementById('navbarNav');
    if (!navCollapse) {
        return;
    }

    const toggler = document.querySelector('.site-navbar-toggler');
    const closeButton = navCollapse.querySelector('.site-mobile-menu-close');
    const isDrawerViewport = () => window.matchMedia('(max-width: 991.98px)').matches;
    const updateDrawerState = (isOpen) => {
        if (!isDrawerViewport()) {
            document.body.classList.remove('site-menu-open');
            return;
        }

        document.body.classList.toggle('site-menu-open', isOpen);
        toggler?.setAttribute('aria-expanded', String(isOpen));
    };
    const closeNavigation = () => {
        if (window.bootstrap && typeof window.bootstrap.Collapse === 'function') {
            window.bootstrap.Collapse.getOrCreateInstance(navCollapse).hide();
        } else {
            navCollapse.classList.remove('show');
            updateDrawerState(false);
        }
    };

    navCollapse.addEventListener('show.bs.collapse', () => updateDrawerState(true));
    navCollapse.addEventListener('hidden.bs.collapse', () => updateDrawerState(false));

    // Keep the navigation usable if the Bootstrap bundle is temporarily
    // unavailable (for example, during a slow or interrupted CDN request).
    if (!(window.bootstrap && typeof window.bootstrap.Collapse === 'function')) {
        toggler?.addEventListener('click', function () {
            const isOpen = !navCollapse.classList.contains('show');
            navCollapse.classList.toggle('show', isOpen);
            updateDrawerState(isOpen);
        });

        closeButton?.addEventListener('click', closeNavigation);
    }

    // Close the mobile menu after a destination is chosen. This prevents the
    // expanded menu from covering the next page on smaller screens.
    navCollapse.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function () {
            if (window.innerWidth >= 1400 || !navCollapse.classList.contains('show')) {
                return;
            }

            closeNavigation();
        });
    });

    document.addEventListener('click', function (event) {
        if (!isDrawerViewport() || !navCollapse.classList.contains('show')) {
            return;
        }

        if (navCollapse.contains(event.target) || toggler?.contains(event.target)) {
            return;
        }

        closeNavigation();
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape' || !navCollapse.classList.contains('show')) {
            return;
        }

        closeNavigation();

        toggler?.focus();
    });

    window.addEventListener('resize', function () {
        if (!isDrawerViewport()) {
            document.body.classList.remove('site-menu-open');
        }
    });
}

// ================================
// AUTHENTICATION INTERACTIONS
// ================================

function setupAuthInteractions() {
    const passwordToggles = document.querySelectorAll('[data-password-toggle]');

    passwordToggles.forEach(toggle => {
        const targetId = toggle.getAttribute('data-password-target');
        const input = targetId ? document.getElementById(targetId) : null;

        if (!input) {
            return;
        }

        toggle.addEventListener('click', function () {
            const revealPassword = input.type === 'password';
            input.type = revealPassword ? 'text' : 'password';
            toggle.setAttribute('aria-pressed', String(revealPassword));
            toggle.setAttribute('aria-label', revealPassword ? 'Hide password' : 'Show password');

            const icon = toggle.querySelector('i');
            if (icon) {
                icon.className = revealPassword ? 'fa-regular fa-eye-slash' : 'fa-regular fa-eye';
            }
        });
    });

    const passwordInput = document.querySelector('[data-password-strength-input]');
    const strengthMeter = document.querySelector('[data-password-strength]');

    if (!passwordInput || !strengthMeter) {
        return;
    }

    const strengthLabel = strengthMeter.querySelector('[data-password-strength-label]');
    const updatePasswordStrength = function () {
        const value = passwordInput.value;
        let strength = 0;
        let label = 'Use at least 8 characters.';

        if (value.length > 0) {
            strength = 1;
            label = 'Add more characters for a stronger password.';
        }

        if (value.length >= 8) {
            strength = 2;
            label = 'Good start — add a number or symbol.';
        }

        if (value.length >= 8 && /[A-Z]/.test(value) && /\d/.test(value)) {
            strength = 3;
            label = 'Strong password.';
        }

        if (value.length >= 12 && /[A-Z]/.test(value) && /[a-z]/.test(value) && /\d/.test(value) && /[^A-Za-z0-9]/.test(value)) {
            strength = 4;
            label = 'Excellent password strength.';
        }

        strengthMeter.setAttribute('data-strength', String(strength));
        if (strengthLabel) {
            strengthLabel.textContent = label;
        }
    };

    passwordInput.addEventListener('input', updatePasswordStrength);
    updatePasswordStrength();
}

// ================================
// UTILITY FUNCTIONS
// ================================

function confirmDelete(message = 'Are you sure you want to delete this item?') {
    return confirm(message);
}

function toggleElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.toggle('d-none');
    }
}

function toggleMobileMenu() {
    const menu = document.querySelector('.navbar-collapse');
    if (menu) {
        menu.classList.toggle('show');
    }
}

// ================================
// TABLE SORTING
// ================================

function sortTable(columnIndex, tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    
    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();
        
        // Try to convert to numbers
        const aNum = parseFloat(aValue);
        const bNum = parseFloat(bValue);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            return aNum - bNum;
        }
        return aValue.localeCompare(bValue);
    });
    
    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));
}

// ================================
// STATUS BADGE STYLING
// ================================

function updateStatusBadge(status) {
    const statusMap = {
        'pending': 'badge-warning',
        'confirmed': 'badge-info',
        'completed': 'badge-success',
        'cancelled': 'badge-danger'
    };
    
    return statusMap[status.toLowerCase()] || 'badge-secondary';
}

// ================================
// LOCAL STORAGE HELPERS
// ================================

function saveToLocalStorage(key, value) {
    try {
        localStorage.setItem(key, JSON.stringify(value));
        return true;
    } catch (e) {
        console.error('localStorage error:', e);
        return false;
    }
}

function getFromLocalStorage(key) {
    try {
        const item = localStorage.getItem(key);
        return item ? JSON.parse(item) : null;
    } catch (e) {
        console.error('localStorage error:', e);
        return null;
    }
}

function removeFromLocalStorage(key) {
    try {
        localStorage.removeItem(key);
        return true;
    } catch (e) {
        console.error('localStorage error:', e);
        return false;
    }
}

// ================================
// INITIALIZE ON LOAD
// ================================

window.addEventListener('load', function() {
    formatCurrencyInPage();
});
