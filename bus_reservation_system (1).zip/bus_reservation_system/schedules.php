<?php
$base_url = '';
$page_title = 'Bus Schedules - Gonzaga Terminal';

include 'includes/config.php';

$page = isset_get('page') ? max(1, (int) isset_get('page')) : 1;
$limit = 6;
$offset = ($page - 1) * $limit;

$format_place_label = static function ($location, $terminal_name) {
    $location = trim((string) $location);

    if ($location !== '') {
        $parts = explode(',', $location);
        $label = trim($parts[0]);
    } else {
        $label = preg_replace('/\s+Terminal$/i', '', (string) $terminal_name);
    }

    $label = preg_replace('/\s+City$/i', '', $label);

    return $label !== '' ? $label : (string) $terminal_name;
};

$format_duration = static function ($minutes) {
    $minutes = max(0, (int) $minutes);

    if ($minutes === 0) {
        return 'Schedule varies';
    }

    $hours = $minutes / 60;
    $low = max(1, (int) floor($hours));
    $high = max($low, (int) ceil($hours));

    if ($low === $high) {
        return $high . ' hour' . ($high === 1 ? '' : 's');
    }

    return $low . '-' . $high . ' hours';
};

$normalize_class_labels = static function ($raw_labels) {
    if (!$raw_labels) {
        return 'Schedule Available';
    }

    $label_map = [
        'Regular AC' => 'Regular AC',
        'First Class / Deluxe' => 'Deluxe',
        'Premium - Victory Royal Sleeper' => 'Sleeper',
    ];

    $labels = [];
    foreach (explode('|', (string) $raw_labels) as $label) {
        $label = trim($label);

        if ($label === '') {
            continue;
        }

        $labels[] = $label_map[$label] ?? $label;
    }

    $labels = array_values(array_unique($labels));

    return !empty($labels) ? implode(' / ', $labels) : 'Schedule Available';
};

$route_base_query = "
    SELECT s.route_id, MIN(s.departure_date) AS next_departure_date
    FROM schedules s
    JOIN routes r ON s.route_id = r.route_id
    JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
    WHERE s.status = 'scheduled'
      AND (s.departure_date > CURDATE() OR (s.departure_date = CURDATE() AND s.departure_time > CURTIME()))
    GROUP BY s.route_id
";

$schedule_cards_query = "
    SELECT
        r.route_id,
        t1.terminal_name AS origin_terminal_name,
        t1.location AS origin_location,
        t2.terminal_name AS destination_terminal_name,
        t2.location AS destination_location,
        r.distance,
        r.travel_time,
        base.next_departure_date,
        COUNT(s.schedule_id) AS trip_count,
        GROUP_CONCAT(DATE_FORMAT(s.departure_time, '%l:%i%p') ORDER BY s.departure_time SEPARATOR '|') AS departure_times_raw,
        GROUP_CONCAT(
            DISTINCT bc.class_name
            ORDER BY FIELD(bc.class_name, 'Regular AC', 'First Class / Deluxe', 'Premium - Victory Royal Sleeper'), bc.class_name
            SEPARATOR '|'
        ) AS class_names_raw
    FROM (" . $route_base_query . ") base
    JOIN routes r ON base.route_id = r.route_id
    JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
    JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
    JOIN schedules s
        ON s.route_id = base.route_id
        AND s.departure_date = base.next_departure_date
        AND s.status = 'scheduled'
        AND (s.departure_date > CURDATE() OR (s.departure_date = CURDATE() AND s.departure_time > CURTIME()))
    JOIN buses b ON s.bus_id = b.bus_id
    JOIN bus_classes bc ON b.class_id = bc.class_id
    GROUP BY
        r.route_id,
        t1.terminal_name,
        t1.location,
        t2.terminal_name,
        t2.location,
        r.distance,
        r.travel_time,
        base.next_departure_date
    ORDER BY base.next_departure_date ASC, t1.terminal_name ASC, t2.terminal_name ASC
    LIMIT $limit OFFSET $offset
";

$schedule_cards_result = $conn->query($schedule_cards_query);

$count_query = "SELECT COUNT(*) AS total FROM (" . $route_base_query . ") route_summary";
$count_result = $conn->query($count_query);
$total_routes = 0;
$total_pages = 1;

if ($count_result && $count_row = $count_result->fetch_assoc()) {
    $total_routes = (int) ($count_row['total'] ?? 0);
    $total_pages = max(1, (int) ceil($total_routes / $limit));
}

include 'includes/header.php';
?>

<style>
.page-schedules {
    background: #eef1f5;
}

.page-schedules .site-main {
    padding: 0;
}

.page-schedules footer {
    margin-top: 0 !important;
}

.page-schedules .schedules-hero {
    background:
        linear-gradient(90deg, rgba(10, 16, 29, 0.88) 0%, rgba(10, 16, 29, 0.78) 28%, rgba(10, 16, 29, 0.44) 100%),
        url('assets/images/bus-terminal-hero.jpg') center center / cover no-repeat;
    min-height: 34.5rem;
    overflow: hidden;
    position: relative;
}

.page-schedules .schedules-hero::before {
    background:
        linear-gradient(180deg, rgba(6, 10, 22, 0.12) 0%, rgba(6, 10, 22, 0.24) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-schedules .schedules-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 34.5rem;
    padding: 5.2rem 0 4rem;
    position: relative;
    z-index: 1;
}

.page-schedules .schedules-hero__copy {
    max-width: 60rem;
}

.page-schedules .schedules-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(3rem, 5vw, 4.5rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.45rem;
}

.page-schedules .schedules-hero__copy p {
    color: rgba(255, 255, 255, 0.88);
    font-size: clamp(1.12rem, 0.98rem + 0.45vw, 1.5rem);
    line-height: 1.45;
    margin: 0 0 2rem;
    max-width: 54rem;
}

.page-schedules .schedules-hero__notice {
    align-items: center;
    background: rgba(85, 68, 17, 0.84);
    border: 1px solid rgba(248, 201, 72, 0.28);
    border-radius: 1.2rem;
    box-shadow: 0 14px 30px rgba(8, 12, 24, 0.22);
    color: #fff4c7;
    display: inline-flex;
    font-size: 0.95rem;
    font-weight: 700;
    gap: 0.9rem;
    max-width: 60rem;
    padding: 1rem 1.25rem;
}

.page-schedules .schedules-hero__notice i {
    color: #ffcf3f;
    font-size: 1.1rem;
}

.page-schedules .schedules-section {
    padding: 4.2rem 0 5.2rem;
}

.page-schedules .schedules-grid {
    display: grid;
    gap: 1.9rem;
    grid-template-columns: repeat(2, minmax(0, 1fr));
}

.page-schedules .schedule-card {
    background: rgba(255, 255, 255, 0.96);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.75rem;
    box-shadow: 0 18px 42px rgba(15, 23, 42, 0.08);
    overflow: hidden;
    padding: 1.9rem 1.9rem 2rem;
}

.page-schedules .schedule-card__top {
    align-items: flex-start;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-bottom: 0.55rem;
}

.page-schedules .schedule-card__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(1.55rem, 1.25rem + 0.8vw, 2rem);
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1.08;
    margin: 0 0 0.6rem;
}

.page-schedules .schedule-card__terminal {
    align-items: center;
    color: #344054;
    display: inline-flex;
    font-size: 1rem;
    gap: 0.7rem;
}

.page-schedules .schedule-card__terminal i {
    color: #1f2a44;
}

.page-schedules .schedule-card__class-pill {
    background: #fdeceb;
    border-radius: 999px;
    color: #d92d20;
    display: inline-flex;
    font-size: 0.95rem;
    font-weight: 500;
    padding: 0.5rem 1rem;
    text-align: center;
    white-space: nowrap;
}

.page-schedules .schedule-card__meta {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 1rem 1.7rem;
    margin-top: 1.55rem;
}

.page-schedules .schedule-card__meta span {
    align-items: center;
    color: #08152f;
    display: inline-flex;
    font-size: 0.98rem;
    gap: 0.7rem;
}

.page-schedules .schedule-card__meta i {
    color: #ef1d17;
}

.page-schedules .schedule-card__divider {
    background: #e4e7ec;
    height: 1px;
    margin: 1.6rem 0 1.25rem;
    width: 100%;
}

.page-schedules .schedule-card__label {
    color: #08152f;
    font-size: 0.98rem;
    font-weight: 500;
    margin-bottom: 1rem;
}

.page-schedules .schedule-card__times {
    display: flex;
    flex-wrap: wrap;
    gap: 0.7rem;
}

.page-schedules .schedule-card__time-pill,
.page-schedules .schedule-card__more-pill {
    background: #f2f4f7;
    border-radius: 999px;
    color: #08152f;
    display: inline-flex;
    font-size: 0.92rem;
    min-width: 5.2rem;
    padding: 0.42rem 0.95rem;
    text-align: center;
    text-decoration: none;
}

.page-schedules .schedule-card__time-pill {
    justify-content: center;
}

.page-schedules .schedule-card__time-pill:hover {
    background: #e9eef7;
    color: #08152f;
}

.page-schedules .schedule-card__more-pill {
    background: #fdeceb;
    color: #d92d20;
    justify-content: center;
}

.page-schedules .schedule-card__date {
    color: #667085;
    font-size: 0.88rem;
    margin-top: 1.1rem;
}

.page-schedules .schedules-pagination {
    margin-top: 2.5rem;
}

.page-schedules .schedules-pagination .pagination {
    gap: 0.45rem;
}

.page-schedules .schedules-pagination .page-link {
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 0.9rem;
    color: #101828;
    font-weight: 700;
    min-width: 3rem;
    padding: 0.75rem 0.95rem;
    text-align: center;
}

.page-schedules .schedules-pagination .page-item.active .page-link,
.page-schedules .schedules-pagination .page-link:hover {
    background: #a72d2d;
    border-color: #a72d2d;
    color: #fff;
}

.page-schedules .schedules-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.95);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.75rem;
    box-shadow: 0 18px 42px rgba(15, 23, 42, 0.08);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-schedules .schedules-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.3rem;
    width: 4.6rem;
}

.page-schedules .schedules-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.7rem;
}

.page-schedules .schedules-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-schedules .schedules-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-schedules .schedules-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 991px) {
    .page-schedules .schedules-hero {
        min-height: auto;
    }

    .page-schedules .schedules-hero__inner {
        min-height: auto;
        padding: 4.2rem 0 3.8rem;
    }

    .page-schedules .schedules-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 767px) {
    .page-schedules .schedules-hero__inner {
        padding: 3.3rem 0 3.4rem;
    }

    .page-schedules .schedules-hero__notice {
        font-size: 0.88rem;
    }

    .page-schedules .schedule-card {
        border-radius: 1.35rem;
        padding: 1.35rem;
    }

    .page-schedules .schedule-card__top {
        flex-direction: column;
    }

    .page-schedules .schedule-card__class-pill {
        white-space: normal;
    }

    .page-schedules .schedules-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="schedules-hero">
    <div class="container schedules-hero__inner">
        <div class="schedules-hero__copy">
            <h1 class="schedules-hero__title">Bus Schedules</h1>
            <p>View Gonzaga Terminal departure schedules for the routes currently loaded in the system. Schedules may vary, so please confirm terminal details before travel.</p>

            <div class="schedules-hero__notice">
                <i class="fas fa-exclamation-circle"></i>
                <span>TRIP SCHEDULE MAY CHANGE WITHOUT PRIOR NOTICE. Please visit the terminal or official page for updated departure details.</span>
            </div>
        </div>
    </div>
</section>

<section class="schedules-section">
    <div class="container">
        <?php if ($schedule_cards_result && $schedule_cards_result->num_rows > 0): ?>
            <div class="schedules-grid">
                <?php while ($schedule_card = $schedule_cards_result->fetch_assoc()): ?>
                    <?php
                    $origin_title = $format_place_label($schedule_card['origin_location'] ?? '', $schedule_card['origin_terminal_name'] ?? '');
                    $destination_title = $format_place_label($schedule_card['destination_location'] ?? '', $schedule_card['destination_terminal_name'] ?? '');
                    $class_label = $normalize_class_labels($schedule_card['class_names_raw'] ?? '');
                    $duration_label = $format_duration($schedule_card['travel_time'] ?? 0);
                    $departure_times = array_values(array_filter(explode('|', (string) ($schedule_card['departure_times_raw'] ?? ''))));
                    $visible_times = array_slice($departure_times, 0, 8);
                    $remaining_count = max(0, count($departure_times) - count($visible_times));
                    $next_departure_date_value = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($schedule_card['next_departure_date'] ?? ''))
                        ? (string) $schedule_card['next_departure_date']
                        : '';
                    $next_departure_date = $next_departure_date_value !== ''
                        ? date('F j, Y', strtotime($next_departure_date_value))
                        : '';
                    ?>
                    <article class="schedule-card">
                        <div class="schedule-card__top">
                            <div>
                                <h2 class="schedule-card__title"><?php echo htmlspecialchars($origin_title); ?> to <?php echo htmlspecialchars($destination_title); ?></h2>
                                <div class="schedule-card__terminal">
                                    <i class="fas fa-location-dot"></i>
                                    <span><?php echo htmlspecialchars($schedule_card['origin_terminal_name']); ?></span>
                                </div>
                            </div>

                            <span class="schedule-card__class-pill"><?php echo htmlspecialchars($class_label); ?></span>
                        </div>

                        <div class="schedule-card__meta">
                            <span>
                                <i class="fas fa-clock"></i>
                                <?php echo htmlspecialchars($duration_label); ?>
                            </span>
                            <span>
                                <i class="fas fa-bus-simple"></i>
                                <?php echo number_format((int) $schedule_card['trip_count']); ?> trip<?php echo (int) $schedule_card['trip_count'] === 1 ? '' : 's'; ?> scheduled
                            </span>
                        </div>

                        <div class="schedule-card__divider"></div>

                        <div class="schedule-card__label">Departure Times:</div>
                        <div class="schedule-card__times">
                            <?php foreach ($visible_times as $time_label): ?>
                                <a class="schedule-card__time-pill" href="booking.php?route_id=<?php echo (int) $schedule_card['route_id']; ?>&amp;departure_date=<?php echo rawurlencode($next_departure_date_value); ?>">
                                    <?php echo htmlspecialchars($time_label); ?>
                                </a>
                            <?php endforeach; ?>

                            <?php if ($remaining_count > 0): ?>
                                <span class="schedule-card__more-pill">+<?php echo $remaining_count; ?> more</span>
                            <?php endif; ?>
                        </div>

                        <?php if ($next_departure_date !== ''): ?>
                            <div class="schedule-card__date">Next departures for <?php echo htmlspecialchars($next_departure_date); ?></div>
                        <?php endif; ?>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php if ($total_pages > 1): ?>
                <nav aria-label="Schedules pagination" class="schedules-pagination">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link" href="schedules.php?page=<?php echo $page - 1; ?>">Previous</a>
                            </li>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i === $page): ?>
                                <li class="page-item active"><span class="page-link"><?php echo $i; ?></span></li>
                            <?php else: ?>
                                <li class="page-item"><a class="page-link" href="schedules.php?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($page < $total_pages): ?>
                            <li class="page-item">
                                <a class="page-link" href="schedules.php?page=<?php echo $page + 1; ?>">Next</a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php else: ?>
            <div class="schedules-empty-state">
                <span class="schedules-empty-state__icon"><i class="fas fa-calendar-xmark"></i></span>
                <h2>No schedules available</h2>
                <p>There are no upcoming departures listed right now. Please check again later or contact the terminal for the latest trip availability.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="schedules-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
