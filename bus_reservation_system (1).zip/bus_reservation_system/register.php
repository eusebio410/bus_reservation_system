<?php
$base_url = '';
$page_title = 'Create Account';
include 'includes/config.php';

if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';
$passengerRole = db_select_one('SELECT role_id FROM roles WHERE role_key = "passenger" LIMIT 1');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = isset_post('fullname');
    $email = normalize_email_address(isset_post('email'));
    $phoneInput = isset_post('phone');
    $phone = normalize_ph_phone($phoneInput);
    $address = isset_post('address');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($fullname === '' || $email === '' || $password === '' || $confirmPassword === '') {
        $error = 'Please complete all required fields.';
    } elseif (!is_valid_person_name($fullname)) {
        $error = 'Please enter your full name with at least 2 letters, such as Juan Dela Cruz.';
    } elseif (!is_valid_registration_email($email)) {
        $error = 'Please use a valid personal email address. Random or disposable email accounts are not accepted.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters long.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } elseif ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
        $error = 'Please use a valid Philippine mobile number, such as 09171234567 or +639171234567.';
    } elseif (!$passengerRole) {
        $error = 'Role setup is incomplete. Please contact the administrator.';
    } else {
        $existing = db_select_one('SELECT user_id FROM users WHERE email = ? LIMIT 1', 's', [$email]);

        if ($existing) {
            $error = 'That email address is already registered.';
        } else {
            $ok = db_execute(
                'INSERT INTO users (fullname, email, phone, address, password, is_admin, role_id, account_status, created_at, updated_at)
                 VALUES (?, ?, ?, ?, ?, 0, ?, "active", NOW(), NOW())',
                'sssssi',
                [$fullname, $email, $phone, $address, password_hash($password, PASSWORD_BCRYPT), (int) $passengerRole['role_id']]
            );

            if ($ok) {
                set_flash('success', 'Account created successfully. You can now sign in.');
                redirect('login.php');
            }

            $error = 'Unable to create your account right now.';
        }
    }
}

include 'includes/header.php';
$brand_logo = $asset_base . 'assets/images/bus-terminal-logo.svg';
?>

<section class="auth-shell auth-shell--register">
    <div class="container auth-shell__container">
        <div class="row g-4 align-items-stretch justify-content-center auth-layout">
            <div class="col-xl-5 col-lg-5 d-none d-lg-block">
                <aside class="auth-promo">
                    <img class="auth-promo__logo" src="<?php echo e($brand_logo); ?>" alt="Bus Terminal logo">
                    <span class="auth-promo__kicker">Create Passenger Access</span>
                    <h1>Register once and make every future booking easier.</h1>
                    <p>The refreshed register page now shares the same terminal background and branding as the rest of the passenger experience.</p>

                    <div class="auth-promo__points">
                        <span><i class="fa-solid fa-id-card"></i>Store passenger details for faster checkout</span>
                        <span><i class="fa-solid fa-bus"></i>Manage upcoming trips from one account</span>
                        <span><i class="fa-solid fa-shield-check"></i>Automatic GCash verification and online tickets</span>
                    </div>
                </aside>
            </div>

            <div class="col-xl-6 col-lg-7">
                <div class="auth-card auth-card--passenger auth-card--register">
                    <div class="auth-card__header">
                        <img class="auth-card__logo" src="<?php echo e($brand_logo); ?>" alt="Bus Terminal logo">
                        <div class="auth-card__header-copy">
                            <span class="auth-card__eyebrow">Passenger Registration</span>
                            <h1 class="auth-card__title">Create Your Passenger Account</h1>
                            <p class="auth-card__subtitle">Book seats, pay securely with automatic verification, and manage e-tickets online.</p>
                        </div>
                    </div>
                    <div class="auth-card__body">
                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endif; ?>

                        <form method="post" class="auth-form row g-3" autocomplete="on">
                            <?php csrf_field(); ?>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="fullname">Full name <span>Required</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-user" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="text" id="fullname" name="fullname" value="<?php echo e($_POST['fullname'] ?? ''); ?>" autocomplete="name" required>
                                </div>
                            </div>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="email">Email address <span>Required</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="email" id="email" name="email" value="<?php echo e($_POST['email'] ?? ''); ?>" placeholder="name@example.com" autocomplete="email" required>
                                </div>
                                <div class="form-text">Use an email address you can access.</div>
                            </div>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="phone">Phone number <span>Optional</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-mobile-screen-button" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="tel" id="phone" name="phone" inputmode="tel" pattern="(?:09\d{9}|\+639\d{9})" maxlength="13" placeholder="09171234567" autocomplete="tel" value="<?php echo e($_POST['phone'] ?? ''); ?>">
                                </div>
                                <div class="form-text">Use a Philippine mobile number like <code>09171234567</code> or <code>+639171234567</code>.</div>
                            </div>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="address">Address <span>Optional</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-location-dot" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="text" id="address" name="address" value="<?php echo e($_POST['address'] ?? ''); ?>" autocomplete="street-address">
                                </div>
                            </div>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="password">Create a password <span>Required</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-lock" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="password" id="password" name="password" autocomplete="new-password" data-password-strength-input required>
                                    <button class="auth-password-toggle" type="button" data-password-toggle data-password-target="password" aria-label="Show password" aria-pressed="false">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                                <div class="auth-password-strength" data-password-strength aria-live="polite">
                                    <span class="auth-password-strength__bars" aria-hidden="true"><i></i><i></i><i></i><i></i></span>
                                    <small data-password-strength-label>Use at least 8 characters.</small>
                                </div>
                            </div>
                            <div class="col-md-6 auth-field">
                                <label class="form-label auth-field__label" for="confirm_password">Confirm password <span>Required</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-shield-halved" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
                                    <button class="auth-password-toggle" type="button" data-password-toggle data-password-target="confirm_password" aria-label="Show password" aria-pressed="false">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-12">
                                <button class="btn btn-danger btn-lg auth-submit" type="submit">
                                    <i class="fa-solid fa-user-plus me-2"></i>Create Account
                                    <i class="fa-solid fa-arrow-right auth-submit__arrow" aria-hidden="true"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                    <div class="auth-card__footer auth-card__footer--compact">
                        <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                        <span>Already registered? <a href="login.php">Sign in to your account</a>.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
