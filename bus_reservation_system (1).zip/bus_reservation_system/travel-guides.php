<?php
$base_url = '';
$page_title = 'Travel Guides - Victory Liner';

include 'includes/config.php';

$guides_query = "SELECT * FROM travel_guides ORDER BY created_at DESC";
$guides_result = $conn->query($guides_query);

$guides = [];

if ($guides_result && $guides_result->num_rows > 0) {
    while ($guide = $guides_result->fetch_assoc()) {
        $guides[] = $guide;
    }
}

$guide_count = count($guides);

$build_excerpt = static function ($content, $length = 170) {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags((string) $content)));

    if (strlen($text) <= $length) {
        return $text;
    }

    return rtrim(substr($text, 0, $length - 3)) . '...';
};

include 'includes/header.php';
?>

<style>
.page-travel-guides {
    background: #eef1f5;
}

.page-travel-guides .site-main {
    padding: 0;
}

.page-travel-guides footer {
    margin-top: 0 !important;
}

.page-travel-guides .guides-hero {
    background:
        linear-gradient(90deg, rgba(10, 18, 34, 0.88) 0%, rgba(10, 18, 34, 0.72) 32%, rgba(10, 18, 34, 0.44) 100%),
        url('assets/images/bus-terminal-hero-v3.jpg') center center / cover no-repeat;
    min-height: 28rem;
    overflow: hidden;
    position: relative;
}

.page-travel-guides .guides-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.16) 0%, rgba(7, 12, 24, 0.28) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-travel-guides .guides-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 28rem;
    padding: 4.8rem 0 3.5rem;
    position: relative;
    z-index: 1;
}

.page-travel-guides .guides-hero__copy {
    max-width: 56rem;
}

.page-travel-guides .guides-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.8rem, 4.8vw, 4.4rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.2rem;
}

.page-travel-guides .guides-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.06rem, 0.97rem + 0.36vw, 1.34rem);
    line-height: 1.52;
    margin: 0 0 1.7rem;
    max-width: 48rem;
}

.page-travel-guides .guides-hero__stats {
    display: flex;
    flex-wrap: wrap;
    gap: 0.8rem;
}

.page-travel-guides .guides-hero__stats span {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 0.92rem;
    font-weight: 700;
    gap: 0.5rem;
    padding: 0.65rem 0.95rem;
}

.page-travel-guides .guides-section {
    padding: 3.8rem 0 5.2rem;
}

.page-travel-guides .guides-section__heading {
    margin-bottom: 2.2rem;
    text-align: center;
}

.page-travel-guides .guides-section__heading h2 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.2rem, 2vw + 1rem, 3.3rem);
    font-weight: 800;
    letter-spacing: -0.05em;
    margin: 0 0 0.8rem;
}

.page-travel-guides .guides-section__heading p {
    color: #475467;
    font-size: 1.05rem;
    margin: 0;
}

.page-travel-guides .guides-grid {
    display: grid;
    gap: 1.35rem;
    grid-template-columns: repeat(3, minmax(0, 1fr));
}

.page-travel-guides .guide-card {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.25rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.page-travel-guides .guide-card__media,
.page-travel-guides .guide-card__placeholder {
    height: 14rem;
    width: 100%;
}

.page-travel-guides .guide-card__media {
    object-fit: cover;
}

.page-travel-guides .guide-card__placeholder {
    align-items: center;
    background:
        linear-gradient(180deg, rgba(20, 27, 45, 0.12) 0%, rgba(20, 27, 45, 0.2) 100%),
        linear-gradient(135deg, #d5e4f4 0%, #f6ead8 100%);
    color: #a72d2d;
    display: flex;
    font-size: 2rem;
    justify-content: center;
}

.page-travel-guides .guide-card__body {
    display: flex;
    flex: 1;
    flex-direction: column;
    padding: 1.35rem;
}

.page-travel-guides .guide-card__date {
    color: #667085;
    font-size: 0.85rem;
    font-weight: 700;
    letter-spacing: 0.05em;
    margin-bottom: 0.75rem;
    text-transform: uppercase;
}

.page-travel-guides .guide-card__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.35rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1.15;
    margin: 0 0 0.75rem;
}

.page-travel-guides .guide-card__body p {
    color: #475467;
    line-height: 1.65;
    margin: 0 0 1rem;
}

.page-travel-guides .guide-card__link {
    align-items: center;
    color: #a72d2d;
    display: inline-flex;
    font-weight: 800;
    gap: 0.6rem;
    margin-top: auto;
    text-decoration: none;
}

.page-travel-guides .guide-card__link:hover {
    color: #8f2323;
}

.page-travel-guides .guides-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-travel-guides .guides-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.6rem;
}

.page-travel-guides .guides-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-travel-guides .guides-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-travel-guides .guides-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-travel-guides .guides-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 1199px) {
    .page-travel-guides .guides-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 767px) {
    .page-travel-guides .guides-grid {
        grid-template-columns: 1fr;
    }

    .page-travel-guides .guides-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="guides-hero">
    <div class="container guides-hero__inner">
        <div class="guides-hero__copy">
            <h1 class="guides-hero__title">Travel Guides</h1>
            <p>Browse destination tips, trip-planning notes, and practical travel information to make your next Victory Liner ride smoother from departure to arrival.</p>
            <div class="guides-hero__stats">
                <span><i class="fas fa-map"></i> Destination planning content</span>
                <span><i class="fas fa-book-open"></i> <?php echo number_format($guide_count); ?> guides published</span>
                <span><i class="fas fa-route"></i> Luzon travel inspiration</span>
            </div>
        </div>
    </div>
</section>

<section class="guides-section">
    <div class="container">
        <div class="guides-section__heading">
            <h2>Featured Guides</h2>
            <p>Helpful reads for passengers exploring destinations, routes, and travel ideas across the Victory Liner network.</p>
        </div>

        <?php if (!empty($guides)): ?>
            <div class="guides-grid">
                <?php foreach ($guides as $guide): ?>
                    <article class="guide-card">
                        <?php if (!empty($guide['image_url'])): ?>
                            <img class="guide-card__media" src="<?php echo htmlspecialchars($guide['image_url']); ?>" alt="<?php echo htmlspecialchars($guide['title']); ?>">
                        <?php else: ?>
                            <div class="guide-card__placeholder">
                                <i class="fas fa-compass"></i>
                            </div>
                        <?php endif; ?>

                        <div class="guide-card__body">
                            <div class="guide-card__date"><?php echo date('F j, Y', strtotime($guide['created_at'])); ?></div>
                            <h3 class="guide-card__title"><?php echo htmlspecialchars($guide['title']); ?></h3>
                            <p><?php echo htmlspecialchars($build_excerpt($guide['content'] ?? '')); ?></p>
                            <a class="guide-card__link" href="travel-guide-detail.php?id=<?php echo (int) $guide['guide_id']; ?>">
                                <span>Read guide</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="guides-empty-state">
                <span class="guides-empty-state__icon"><i class="fas fa-compass"></i></span>
                <h2>No travel guides yet</h2>
                <p>Travel guide entries have not been published yet. When new destination articles are added, they will appear here as featured cards.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="guides-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
