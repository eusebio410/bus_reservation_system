<?php
if (!defined('BUS_SYSTEM_CONFIG_LOADED')) {
    require_once __DIR__ . '/config.php';
}

if (!function_exists('admin_menu_catalog')) {
    function admin_menu_catalog(): array
    {
        $inPagesDirectory = basename(dirname($_SERVER['PHP_SELF'] ?? '')) === 'pages';
        $dashboardHref = $inPagesDirectory ? '../dashboard.php' : 'dashboard.php';
        $pagePrefix = $inPagesDirectory ? '' : 'pages/';

        return [
            'dashboard' => ['label' => 'Dashboard', 'href' => $dashboardHref, 'icon' => 'fa-chart-pie'],
            'routes' => ['label' => 'Routes', 'href' => $pagePrefix . 'manage-routes.php', 'icon' => 'fa-road'],
            'schedules' => ['label' => 'Schedules', 'href' => $pagePrefix . 'manage-schedules.php', 'icon' => 'fa-calendar-days'],
            'buses' => ['label' => 'Buses', 'href' => $pagePrefix . 'manage-buses.php', 'icon' => 'fa-bus'],
            'operators' => ['label' => 'Bus Operators', 'href' => $pagePrefix . 'manage-operators.php', 'icon' => 'fa-id-card-clip'],
            'seats' => ['label' => 'Seats', 'href' => $pagePrefix . 'manage-seats.php', 'icon' => 'fa-chair'],
            'bookings' => ['label' => 'Bookings', 'href' => $pagePrefix . 'manage-bookings.php', 'icon' => 'fa-ticket'],
            'discounts' => ['label' => 'Discount Reviews', 'href' => $pagePrefix . 'manage-discounts.php', 'icon' => 'fa-id-card'],
            'payments' => ['label' => 'Payments', 'href' => $pagePrefix . 'manage-payments.php', 'icon' => 'fa-wallet'],
            'users' => ['label' => 'Users', 'href' => $pagePrefix . 'manage-users.php', 'icon' => 'fa-users'],
            'audit' => ['label' => 'Audit Logs', 'href' => $pagePrefix . 'audit-logs.php', 'icon' => 'fa-clipboard-list'],
            'reports' => ['label' => 'Reports', 'href' => $pagePrefix . 'reports.php', 'icon' => 'fa-chart-line'],
            'scanner' => ['label' => 'QR Scanner', 'href' => $pagePrefix . 'ticket-scanner.php', 'icon' => 'fa-qrcode'],
            'terminals' => ['label' => 'Terminals', 'href' => $pagePrefix . 'manage-terminals.php', 'icon' => 'fa-map-location-dot'],
            'fares' => ['label' => 'Fares', 'href' => $pagePrefix . 'manage-fares.php', 'icon' => 'fa-money-bill-wave'],
            'faq' => ['label' => 'FAQ', 'href' => $pagePrefix . 'manage-faq.php', 'icon' => 'fa-circle-question'],
        ];
    }
}

if (!function_exists('admin_allowed_menu_keys')) {
    function admin_allowed_menu_keys(?string $roleKey = null): array
    {
        $roleKey = $roleKey ?: current_role_key();

        if ($roleKey === 'staff') {
            return ['dashboard', 'schedules', 'seats', 'bookings', 'discounts', 'payments', 'scanner'];
        }

        return array_keys(admin_menu_catalog());
    }
}

if (!function_exists('admin_page_permitted')) {
    function admin_page_permitted(string $key, ?string $roleKey = null): bool
    {
        return in_array($key, admin_allowed_menu_keys($roleKey), true);
    }
}

if (!function_exists('admin_menu_items')) {
    function admin_menu_items(): array
    {
        $catalog = admin_menu_catalog();

        return array_filter(
            $catalog,
            static fn($key) => admin_page_permitted($key),
            ARRAY_FILTER_USE_KEY
        );
    }
}

if (!function_exists('admin_render_menu_links')) {
    function admin_render_menu_links(array $menuItems, string $activeKey, bool $dismissDrawer = false): void
    {
        foreach ($menuItems as $key => $item) {
            $isActive = $activeKey === $key;
            ?>
            <a
                class="admin-nav-link<?php echo $isActive ? ' is-active' : ''; ?>"
                href="<?php echo e($item['href']); ?>"
                <?php echo $isActive ? 'aria-current="page"' : ''; ?>
                <?php echo $dismissDrawer ? 'data-bs-dismiss="offcanvas"' : ''; ?>
            >
                <span class="icon-wrap"><i class="fa-solid <?php echo e($item['icon']); ?>"></i></span>
                <span><?php echo e($item['label']); ?></span>
            </a>
            <?php
        }
    }
}

if (!function_exists('admin_render_header')) {
    function admin_render_header(string $title, string $activeKey): void
    {
        $menuItems = admin_menu_items();
        $currentUser = current_user_record();
        $displayName = $currentUser['fullname'] ?? ($_SESSION['user_name'] ?? 'Admin');
        $roleName = $currentUser['role_name'] ?? ucfirst(current_role_key());
        $roleKey = current_role_key();
        $inPagesDirectory = basename(dirname($_SERVER['PHP_SELF'] ?? '')) === 'pages';
        $sitePrefix = $inPagesDirectory ? '../../' : '../';
        $assetPrefix = $sitePrefix;
        $brandLogo = $assetPrefix . 'assets/images/bus-terminal-logo.svg';
        $brandKicker = 'Gonzaga Terminal';
        $portalLabel = $roleKey === 'staff' ? 'Operations Console' : 'Admin Control Center';
        $menuLabel = $roleKey === 'staff' ? 'Operations' : 'Management';
        $dashboardHref = $menuItems['dashboard']['href'] ?? '#';
        $drawerId = 'adminMenuDrawer';
        $nameParts = preg_split('/\s+/', trim($displayName)) ?: [];
        $initials = '';

        foreach ($nameParts as $part) {
            if ($part === '') {
                continue;
            }

            $initials .= strtoupper(substr($part, 0, 1));

            if (strlen($initials) >= 2) {
                break;
            }
        }

        if ($initials === '') {
            $initials = $roleKey === 'staff' ? 'ST' : 'AD';
        }
        $rolePillClass = $roleKey === 'staff' ? 'topbar-pill-warning' : 'topbar-pill-accent';
        $rolePillIcon = $roleKey === 'staff' ? 'fa-user-gear' : 'fa-shield-halved';
        $sidebarFootnote = $roleKey === 'staff'
            ? 'Keep the payment queue moving, validate tickets quickly, and stay ahead of departures.'
            : 'Monitor dispatch, revenue, passenger activity, and team access from one polished control center.';
        $sidebarBrandSummary = $roleKey === 'staff'
            ? 'Payment review, ticket validation, and shift operations in one branded workspace.'
            : 'Dispatch, fleet coordination, user management, and reporting in one branded workspace.';
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?> - <?php echo e($portalLabel); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e($assetPrefix . 'assets/css/style.css'); ?>">
    <style>
        :root {
            --admin-topbar-height: 56px;
            --admin-bg: #eef4fb;
            --admin-card: #ffffff;
            --admin-border: rgba(8, 26, 51, 0.09);
            --admin-text: #0c1f3d;
            --admin-muted: #5e6f88;
            --admin-accent: #1352a3;
            --admin-accent-soft: #edf5ff;
            --admin-accent-strong: #0b2d5f;
            --admin-ink: #081a33;
            --admin-gold: #f28a1d;
            --admin-gold-soft: #fff4e2;
            --admin-danger: #b83224;
            --admin-danger-soft: #fef1ef;
            --admin-success: #067647;
            --admin-warning: #b86b10;
            --admin-info: #2b7eea;
            --admin-shadow-soft: 0 20px 52px rgba(8, 26, 51, 0.08);
            --admin-shadow-strong: 0 30px 74px rgba(8, 26, 51, 0.14);
        }
        body.admin-shell {
            background:
                radial-gradient(circle at 12% 10%, rgba(242, 138, 29, 0.12) 0, transparent 18rem),
                radial-gradient(circle at 88% 18%, rgba(43, 126, 234, 0.12) 0, transparent 20rem),
                linear-gradient(180deg, #f8fbff 0%, #eef4fb 48%, #edf2f8 100%);
            color: var(--admin-text);
            font-family: 'Outfit', sans-serif;
            margin: 0;
            min-height: 100vh;
            overflow-x: hidden;
            padding: 0;
        }
        .admin-skip-link {
            background: #fff;
            border-radius: 999px;
            box-shadow: var(--admin-shadow-soft);
            color: var(--admin-ink);
            left: 1rem;
            padding: 0.7rem 1rem;
            position: fixed;
            text-decoration: none;
            top: 0.75rem;
            transform: translateY(-160%);
            transition: transform 0.2s ease;
            z-index: 1100;
        }
        .admin-skip-link:focus {
            transform: translateY(0);
        }
        .admin-topbar {
            background:
                linear-gradient(90deg, rgba(8, 26, 51, 0.98) 0%, rgba(11, 45, 95, 0.97) 58%, rgba(21, 82, 163, 0.93) 100%);
            backdrop-filter: blur(18px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 12px 28px rgba(8, 26, 51, 0.18);
            min-height: var(--admin-topbar-height);
            padding: 0;
            z-index: 1040;
        }
        .admin-topbar .container-fluid {
            align-items: center;
            display: flex;
            gap: 0.75rem;
            min-height: var(--admin-topbar-height);
        }
        .admin-topbar-start {
            align-items: center;
            display: flex;
            gap: 0.75rem;
            min-width: 0;
        }
        .admin-menu-trigger {
            align-items: center;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 0.9rem;
            color: #fff;
            display: inline-flex;
            height: 2.45rem;
            justify-content: center;
            padding: 0;
            width: 2.45rem;
        }
        .admin-menu-trigger:hover,
        .admin-menu-trigger:focus {
            background: rgba(255, 255, 255, 0.14);
            color: #fff;
        }
        .admin-brand {
            color: #fff;
            display: inline-flex;
            align-items: center;
            gap: 0.85rem;
            font-family: 'Space Grotesk', sans-serif;
            min-width: 0;
            text-decoration: none;
        }
        .admin-brand:hover {
            color: #fff;
        }
        .admin-brand-mark {
            align-items: center;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.14), rgba(242, 138, 29, 0.12));
            border: 1px solid rgba(255, 255, 255, 0.18);
            border-radius: 1rem;
            display: inline-flex;
            flex-shrink: 0;
            height: 3.25rem;
            justify-content: center;
            min-width: 3.25rem;
            padding: 0.2rem;
        }
        .admin-brand-logo {
            display: block;
            filter: drop-shadow(0 14px 24px rgba(4, 10, 19, 0.22));
            height: 2.85rem;
            width: auto;
        }
        .admin-brand .brand-text,
        .admin-brand-copy {
            display: grid;
            gap: 0.08rem;
            min-width: 0;
        }
        .admin-brand-kicker {
            color: rgba(255, 225, 178, 0.86);
            font-size: 0.62rem;
            font-weight: 800;
            letter-spacing: 0.18em;
            overflow: hidden;
            text-overflow: ellipsis;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .admin-brand-title {
            color: #fff;
            font-size: clamp(1rem, 1.15vw + 0.78rem, 1.5rem);
            font-weight: 700;
            letter-spacing: -0.04em;
            line-height: 1.02;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .admin-topbar-meta {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.55rem;
            margin-left: auto;
        }
        .topbar-pill {
            align-items: center;
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 999px;
            color: #fff;
            display: inline-flex;
            font-size: 0.8rem;
            font-weight: 700;
            gap: 0.45rem;
            min-height: 2.35rem;
            padding: 0.45rem 0.85rem;
        }
        .topbar-pill-accent {
            background: linear-gradient(135deg, rgba(21, 82, 163, 0.78), rgba(242, 138, 29, 0.56));
            border-color: rgba(255, 212, 133, 0.2);
        }
        .topbar-pill-warning {
            background: linear-gradient(135deg, rgba(184, 107, 16, 0.7), rgba(242, 138, 29, 0.46));
            border-color: rgba(255, 211, 132, 0.22);
        }
        .topbar-pill-muted {
            background: rgba(255, 255, 255, 0.06);
            color: rgba(255, 255, 255, 0.82);
        }
        .admin-top-actions {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.6rem;
            justify-content: flex-end;
        }
        .admin-top-actions .btn {
            align-items: center;
            border-radius: 999px;
            display: inline-flex;
            gap: 0.45rem;
            min-height: 2.45rem;
            padding-inline: 1rem;
            transition: transform 0.2s ease, background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
        }
        .admin-topbar .btn-outline-light {
            background: rgba(255, 255, 255, 0.04);
            border-color: rgba(255, 255, 255, 0.74);
            color: #fff;
        }
        .admin-topbar .btn-outline-light:hover {
            background: rgba(255, 255, 255, 0.12);
            border-color: rgba(255, 255, 255, 0.92);
            color: #fff;
            transform: translateY(-1px);
        }
        .admin-topbar .btn-outline-danger {
            background: rgba(184, 50, 36, 0.12);
            border-color: rgba(255, 163, 150, 0.48);
            color: #ffe5df;
        }
        .admin-topbar .btn-outline-danger:hover {
            background: rgba(184, 50, 36, 0.22);
            border-color: rgba(255, 180, 169, 0.62);
            color: #fff8f6;
            transform: translateY(-1px);
        }
        .admin-wrap {
            display: block;
            min-height: calc(100vh - var(--admin-topbar-height));
            margin-top: 0 !important;
            padding-top: 0 !important;
        }
        .admin-sidebar {
            background:
                linear-gradient(180deg, rgba(8, 26, 51, 0.99) 0%, rgba(11, 45, 95, 0.97) 34%, rgba(7, 18, 37, 0.98) 100%);
            color: #fff;
        }
        .admin-sidebar--desktop {
            bottom: 0;
            left: 0;
            overflow-x: hidden;
            overflow-y: auto;
            overscroll-behavior: contain;
            padding: 1.4rem;
            position: fixed;
            top: var(--admin-topbar-height);
            width: 270px;
            z-index: 1020;
        }
        .admin-sidebar-drawer {
            background:
                linear-gradient(180deg, rgba(8, 26, 51, 0.99) 0%, rgba(11, 45, 95, 0.98) 36%, rgba(7, 18, 37, 0.99) 100%);
            color: #fff;
            width: min(84vw, 320px);
        }
        .admin-sidebar-drawer .offcanvas-header {
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding: 1rem 1rem 0.9rem;
        }
        .admin-sidebar-drawer .offcanvas-body {
            padding: 1rem;
        }
        .admin-sidebar-drawer .btn-close {
            filter: brightness(0) invert(1);
        }
        .admin-sidebar-brand {
            background:
                linear-gradient(145deg, rgba(21, 82, 163, 0.24), rgba(242, 138, 29, 0.16) 68%, rgba(255, 255, 255, 0.04));
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 1.35rem;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06);
            margin-bottom: 1rem;
            padding: 1rem;
        }
        .admin-sidebar-brand__head {
            align-items: center;
            display: flex;
            gap: 0.85rem;
            margin-bottom: 0.7rem;
        }
        .admin-sidebar-brand__logo {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.16);
            border-radius: 1rem;
            display: block;
            flex-shrink: 0;
            padding: 0.3rem;
            width: 4.2rem;
        }
        .admin-sidebar-brand__copy {
            display: grid;
            gap: 0.18rem;
            min-width: 0;
        }
        .admin-sidebar-brand__copy span {
            color: rgba(255, 225, 178, 0.84);
            font-size: 0.68rem;
            font-weight: 800;
            letter-spacing: 0.16em;
            text-transform: uppercase;
        }
        .admin-sidebar-brand__copy strong {
            color: #fff;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.05rem;
            font-weight: 700;
            letter-spacing: -0.03em;
            line-height: 1.05;
        }
        .admin-sidebar-brand p {
            color: rgba(255, 255, 255, 0.78);
            font-size: 0.88rem;
            line-height: 1.55;
            margin: 0;
        }
        .admin-sidebar .profile-card,
        .admin-sidebar-drawer .profile-card {
            background: linear-gradient(145deg, rgba(21, 82, 163, 0.22), rgba(255, 255, 255, 0.04) 52%, rgba(242, 138, 29, 0.14));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1.25rem;
            margin-bottom: 1rem;
            padding: 1rem;
        }
        .admin-profile-head {
            align-items: center;
            display: flex;
            gap: 0.9rem;
        }
        .admin-profile-avatar {
            align-items: center;
            background: linear-gradient(135deg, var(--admin-accent), var(--admin-gold));
            border-radius: 999px;
            color: #fff;
            display: inline-flex;
            font-size: 0.85rem;
            font-weight: 800;
            height: 2.75rem;
            justify-content: center;
            min-width: 2.75rem;
        }
        .profile-name {
            color: #fff;
            font-weight: 700;
            margin-bottom: 0.1rem;
        }
        .profile-role {
            color: rgba(255, 255, 255, 0.68);
            font-size: 0.92rem;
        }
        .admin-sidebar-footer {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.07), rgba(21, 82, 163, 0.12), rgba(242, 138, 29, 0.14));
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 1rem;
            margin-top: 1rem;
            padding: 0.95rem 1rem;
        }
        .sidebar-footer-title {
            color: #fff;
            font-size: 0.82rem;
            font-weight: 700;
            margin-bottom: 0.35rem;
        }
        .sidebar-footer-copy {
            color: rgba(255, 255, 255, 0.72);
            font-size: 0.86rem;
            line-height: 1.55;
        }
        .admin-menu-label {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.72rem;
            font-weight: 700;
            letter-spacing: 0.12em;
            margin: 1.2rem 0 0.75rem;
            text-transform: uppercase;
        }
        .admin-nav-link {
            align-items: center;
            border-radius: 0.95rem;
            color: rgba(255, 255, 255, 0.75);
            display: flex;
            gap: 0.9rem;
            overflow: hidden;
            padding: 0.85rem 0.95rem;
            position: relative;
            text-decoration: none;
            transition: background 0.2s ease, color 0.2s ease, transform 0.2s ease;
        }
        .admin-nav-link::after {
            background: linear-gradient(180deg, rgba(43, 126, 234, 1), rgba(242, 138, 29, 0.92));
            border-radius: 999px;
            content: '';
            height: calc(100% - 1rem);
            left: 0.38rem;
            opacity: 0;
            position: absolute;
            top: 0.5rem;
            transform: scaleY(0.35);
            transform-origin: center;
            transition: opacity 0.2s ease, transform 0.2s ease;
            width: 0.24rem;
        }
        .admin-nav-link:hover,
        .admin-nav-link.is-active {
            background: rgba(255, 255, 255, 0.08);
            color: #fff;
            transform: translateX(2px);
        }
        .admin-nav-link:hover::after,
        .admin-nav-link.is-active::after {
            opacity: 1;
            transform: scaleY(1);
        }
        .admin-nav-link .icon-wrap {
            align-items: center;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 0.8rem;
            display: inline-flex;
            height: 2.2rem;
            justify-content: center;
            transition: background 0.2s ease, transform 0.2s ease;
            width: 2.2rem;
        }
        .admin-nav-link:hover .icon-wrap,
        .admin-nav-link.is-active .icon-wrap {
            background: rgba(255, 255, 255, 0.16);
            transform: translateY(-1px);
        }
        .admin-content {
            margin-left: 270px;
            min-height: calc(100vh - var(--admin-topbar-height));
            min-width: 0;
            padding: 1.35rem 2rem 2.2rem;
            position: relative;
        }
        .admin-content > * {
            position: relative;
            z-index: 1;
        }
        .admin-content::before,
        .admin-content::after {
            border-radius: 999px;
            content: '';
            filter: blur(60px);
            pointer-events: none;
            position: absolute;
            z-index: 0;
        }
        .admin-content::before {
            background: rgba(242, 138, 29, 0.14);
            height: 220px;
            right: -80px;
            top: -10px;
            width: 220px;
        }
        .admin-content::after {
            background: rgba(21, 88, 188, 0.08);
            bottom: 40px;
            height: 260px;
            left: -110px;
            width: 260px;
        }
        .admin-page-header {
            align-items: end;
            background:
                linear-gradient(135deg, rgba(255, 255, 255, 0.98), rgba(237, 245, 255, 0.98)),
                radial-gradient(circle at top right, rgba(21, 82, 163, 0.12), transparent 44%);
            border: 1px solid rgba(15, 23, 42, 0.08);
            border-radius: 1.6rem;
            box-shadow: var(--admin-shadow-soft);
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: space-between;
            margin-bottom: 1.6rem;
            overflow: hidden;
            padding: 1.4rem 1.45rem;
            position: relative;
            z-index: 1;
        }
        .admin-page-header::before {
            background: linear-gradient(90deg, rgba(21, 82, 163, 0.95), rgba(242, 138, 29, 0.88), rgba(8, 26, 51, 0.94));
            border-radius: 999px;
            content: '';
            height: 4px;
            left: 1.45rem;
            position: absolute;
            top: 0.95rem;
            width: 12rem;
        }
        .admin-page-header > * {
            position: relative;
            z-index: 1;
        }
        .admin-page-copy {
            max-width: min(58rem, 100%);
        }
        .admin-page-kicker {
            align-items: center;
            color: var(--admin-accent);
            display: inline-flex;
            font-size: 0.76rem;
            font-weight: 800;
            gap: 0.45rem;
            letter-spacing: 0.1em;
            margin-bottom: 0.75rem;
            text-transform: uppercase;
        }
        .admin-page-kicker::before {
            background: linear-gradient(135deg, var(--admin-accent), var(--admin-gold));
            border-radius: 999px;
            content: '';
            display: inline-block;
            height: 0.55rem;
            width: 0.55rem;
        }
        .admin-page-header h1 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(2rem, 3vw, 2.8rem);
            font-weight: 700;
            letter-spacing: -0.05em;
            margin: 0;
        }
        .admin-page-header p {
            color: var(--admin-muted);
            margin: 0.5rem 0 0;
            max-width: 48rem;
        }
        .admin-page-actions {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            justify-content: flex-end;
        }
        .admin-page-header,
        .admin-card,
        .stat-tile {
            opacity: 0;
            transform: translateY(16px);
            transition: opacity 0.42s ease, transform 0.42s ease;
        }
        body.admin-shell.is-ready .admin-page-header,
        body.admin-shell.is-ready .admin-card,
        body.admin-shell.is-ready .stat-tile {
            opacity: 1;
            transform: translateY(0);
        }
        .admin-card {
            background: var(--admin-card);
            border: 1px solid var(--admin-border);
            border-radius: 1.4rem;
            box-shadow: var(--admin-shadow-soft);
            overflow: hidden;
            position: relative;
            transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
            z-index: 1;
        }
        .admin-card::before {
            background: linear-gradient(90deg, rgba(21, 82, 163, 0.98), rgba(242, 138, 29, 0.86), rgba(8, 26, 51, 0.96));
            content: '';
            height: 4px;
            left: 0;
            position: absolute;
            right: 0;
            top: 0;
        }
        .admin-card:hover {
            border-color: rgba(21, 82, 163, 0.16);
            box-shadow: var(--admin-shadow-strong);
            transform: translateY(-2px);
        }
        .admin-card-header {
            align-items: center;
            background:
                linear-gradient(180deg, rgba(255, 255, 255, 0.94), rgba(248, 250, 252, 0.98));
            border-bottom: 1px solid rgba(15, 23, 42, 0.06);
            display: flex;
            justify-content: space-between;
            gap: 1rem;
            padding: 1.25rem 1.35rem 1rem;
        }
        .admin-card-header h2,
        .admin-card-header h3 {
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.08rem;
            margin: 0;
        }
        .admin-card-body {
            padding: 1.35rem;
        }
        .admin-card-body > form.row.g-3 {
            background: linear-gradient(180deg, rgba(248, 250, 252, 0.88), rgba(255, 255, 255, 0.98));
            border: 1px solid rgba(15, 23, 42, 0.06);
            border-radius: 1.25rem;
            padding: 0.45rem;
        }
        .admin-toolbar-card {
            background:
                linear-gradient(135deg, rgba(8, 26, 51, 0.98), rgba(11, 45, 95, 0.96) 58%, rgba(21, 82, 163, 0.92) 82%, rgba(242, 138, 29, 0.82));
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 1.5rem;
            box-shadow: 0 22px 54px rgba(15, 23, 42, 0.18);
            color: #fff;
            margin-bottom: 1.4rem;
            overflow: hidden;
            padding: 1.25rem 1.35rem;
            position: relative;
            z-index: 1;
        }
        .admin-toolbar-card::after {
            background: radial-gradient(circle at top right, rgba(255, 255, 255, 0.14), transparent 34%);
            content: '';
            inset: 0;
            pointer-events: none;
            position: absolute;
        }
        .admin-toolbar-grid {
            align-items: center;
            display: grid;
            gap: 1rem;
            grid-template-columns: minmax(0, 1fr) auto;
            position: relative;
            z-index: 1;
        }
        .admin-toolbar-copy {
            min-width: 0;
        }
        .admin-toolbar-eyebrow {
            color: rgba(255, 255, 255, 0.68);
            display: inline-flex;
            font-size: 0.76rem;
            font-weight: 800;
            letter-spacing: 0.1em;
            margin-bottom: 0.65rem;
            text-transform: uppercase;
        }
        .admin-toolbar-card h2 {
            color: #fff;
            font-family: 'Space Grotesk', sans-serif;
            font-size: clamp(1.4rem, 2vw, 2rem);
            letter-spacing: -0.04em;
            margin: 0;
        }
        .admin-toolbar-card p {
            color: rgba(255, 255, 255, 0.78);
            margin: 0.55rem 0 0;
            max-width: 46rem;
        }
        .admin-toolbar-actions {
            align-items: center;
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            justify-content: flex-end;
        }
        .admin-toolbar-actions > * {
            margin: 0;
        }
        .admin-metric-grid {
            display: grid;
            gap: 1rem;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            margin-bottom: 1.4rem;
        }
        .admin-metric-card {
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.96), rgba(248, 250, 252, 0.98));
            border: 1px solid rgba(15, 23, 42, 0.08);
            border-radius: 1.25rem;
            overflow: hidden;
            padding: 1rem 1.05rem;
            position: relative;
        }
        .admin-metric-card::after {
            background: radial-gradient(circle at top right, rgba(242, 138, 29, 0.16), transparent 50%);
            content: '';
            inset: 0;
            pointer-events: none;
            position: absolute;
        }
        .admin-metric-card > * {
            position: relative;
            z-index: 1;
        }
        .admin-metric-label {
            color: var(--admin-muted);
            display: block;
            font-size: 0.84rem;
            margin-bottom: 0.45rem;
        }
        .admin-metric-value {
            color: var(--admin-ink);
            display: block;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 1.55rem;
            font-weight: 700;
            line-height: 1.08;
        }
        .admin-metric-copy {
            color: var(--admin-muted);
            display: block;
            font-size: 0.82rem;
            margin-top: 0.45rem;
        }
        .admin-list-stack {
            display: grid;
            gap: 0.85rem;
        }
        .admin-list-card {
            align-items: center;
            background: linear-gradient(180deg, rgba(255, 255, 255, 0.96), rgba(248, 250, 252, 0.98));
            border: 1px solid rgba(15, 23, 42, 0.08);
            border-radius: 1.15rem;
            color: inherit;
            display: grid;
            gap: 0.85rem;
            grid-template-columns: minmax(0, 1fr) auto;
            padding: 1rem;
            text-decoration: none;
        }
        .admin-list-main {
            min-width: 0;
        }
        .admin-list-title {
            font-weight: 700;
            margin-bottom: 0.2rem;
        }
        .admin-list-meta,
        .admin-list-copy,
        .admin-section-note {
            color: var(--admin-muted);
        }
        .admin-list-meta,
        .admin-list-copy {
            font-size: 0.88rem;
        }
        .admin-list-side {
            align-items: flex-end;
            display: grid;
            gap: 0.4rem;
            justify-items: end;
            text-align: right;
        }
        .admin-inline-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 0.55rem;
        }
        .admin-split-grid {
            display: grid;
            gap: 1.4rem;
            grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        .admin-progress {
            background: rgba(15, 23, 42, 0.08);
            border-radius: 999px;
            height: 0.55rem;
            margin-top: 0.7rem;
            overflow: hidden;
        }
        .admin-progress > span {
            background: linear-gradient(90deg, rgba(21, 82, 163, 0.98), rgba(242, 138, 29, 0.88));
            border-radius: inherit;
            display: block;
            height: 100%;
        }
        .admin-empty-state {
            border: 1px dashed rgba(15, 23, 42, 0.14);
            border-radius: 1.15rem;
            color: var(--admin-muted);
            padding: 1rem 1.1rem;
            text-align: center;
        }
        .stats-grid {
            display: grid;
            gap: 1rem;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            margin-bottom: 1.4rem;
        }
        .stat-tile {
            background: linear-gradient(180deg, #fff, #fbfdff);
            border: 1px solid var(--admin-border);
            border-radius: 1.25rem;
            overflow: hidden;
            padding: 1.1rem 1.15rem;
            position: relative;
        }
        .stat-tile::after {
            background: radial-gradient(circle at top right, rgba(242, 138, 29, 0.18), transparent 50%);
            content: '';
            inset: 0;
            pointer-events: none;
            position: absolute;
        }
        .stat-tile .label {
            color: var(--admin-muted);
            display: block;
            font-size: 0.88rem;
            margin-bottom: 0.4rem;
        }
        .stat-tile .value {
            color: var(--admin-ink);
            display: block;
            font-family: 'Space Grotesk', sans-serif;
            font-size: 2rem;
            font-weight: 700;
            line-height: 1;
        }
        .stat-tile .hint {
            color: var(--admin-muted);
            display: block;
            font-size: 0.82rem;
            margin-top: 0.45rem;
        }
        .chip {
            align-items: center;
            border-radius: 999px;
            display: inline-flex;
            font-size: 0.76rem;
            font-weight: 700;
            gap: 0.35rem;
            line-height: 1;
            padding: 0.36rem 0.68rem;
        }
        .chip.soft {
            background: var(--admin-accent-soft);
            color: var(--admin-accent);
        }
        .chip.success {
            background: #ecfdf3;
            color: var(--admin-success);
        }
        .chip.warning {
            background: var(--admin-gold-soft);
            color: var(--admin-warning);
        }
        .chip.danger {
            background: var(--admin-danger-soft);
            color: var(--admin-danger);
        }
        .table-responsive {
            border-radius: 1.15rem;
            overflow: auto;
        }
        .admin-table {
            border-collapse: separate;
            border-spacing: 0 0.8rem;
            margin-top: -0.35rem;
        }
        .admin-table th {
            background: transparent;
            color: var(--admin-muted);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
        }
        .admin-table th,
        .admin-table td {
            padding: 0.95rem 0.85rem;
            vertical-align: middle;
        }
        .admin-table tbody td {
            background: linear-gradient(180deg, #ffffff, #fbfdff);
            border-bottom: 1px solid rgba(15, 23, 42, 0.08);
            border-top: 1px solid rgba(15, 23, 42, 0.08);
        }
        .admin-table tbody td:first-child {
            border-bottom-left-radius: 1rem;
            border-left: 1px solid rgba(15, 23, 42, 0.08);
            border-top-left-radius: 1rem;
        }
        .admin-table tbody td:last-child {
            border-bottom-right-radius: 1rem;
            border-right: 1px solid rgba(15, 23, 42, 0.08);
            border-top-right-radius: 1rem;
        }
        .admin-table tbody tr:hover td {
            background: linear-gradient(180deg, #fff, #f5faff);
            border-color: rgba(21, 82, 163, 0.14);
        }
        .form-label {
            color: var(--admin-text);
            font-size: 0.92rem;
            font-weight: 600;
        }
        .form-control,
        .form-select {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(15, 23, 42, 0.1);
            box-shadow: inset 0 1px 2px rgba(15, 23, 42, 0.02);
            border-radius: 0.9rem;
            min-height: 3rem;
            transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
        }
        .form-control:hover,
        .form-select:hover {
            border-color: rgba(16, 32, 59, 0.18);
        }
        .form-control:focus,
        .form-select:focus {
            background: #fff;
            border-color: rgba(21, 82, 163, 0.42);
            box-shadow: 0 0 0 0.28rem rgba(21, 82, 163, 0.12);
            transform: translateY(-1px);
        }
        .form-text {
            color: var(--admin-muted);
            font-size: 0.8rem;
        }
        .btn {
            border-radius: 0.95rem;
            font-weight: 600;
            padding-inline: 1rem;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease;
        }
        .btn:hover {
            transform: translateY(-1px);
        }
        .btn-accent {
            background: linear-gradient(135deg, var(--admin-accent), var(--admin-accent-strong));
            border: none;
            box-shadow: 0 14px 30px rgba(21, 82, 163, 0.2);
            color: #fff;
        }
        .btn-accent:hover {
            color: #fff;
            filter: brightness(0.96);
        }
        .btn-outline-secondary,
        .btn-outline-primary,
        .btn-outline-danger {
            background: rgba(255, 255, 255, 0.92);
            backdrop-filter: blur(8px);
        }
        .btn-outline-secondary {
            border-color: rgba(15, 23, 42, 0.14);
            color: var(--admin-ink);
        }
        .btn-outline-secondary:hover {
            background: rgba(16, 32, 59, 0.06);
            border-color: rgba(16, 32, 59, 0.22);
            color: var(--admin-ink);
        }
        .btn-outline-primary {
            border-color: rgba(21, 88, 188, 0.28);
            color: var(--admin-info);
        }
        .btn-outline-primary:hover {
            background: rgba(21, 88, 188, 0.08);
            border-color: rgba(21, 88, 188, 0.42);
            color: #0f4fa7;
        }
        .btn-outline-danger {
            border-color: rgba(184, 50, 36, 0.28);
            color: var(--admin-danger);
        }
        .btn-outline-danger:hover {
            background: rgba(184, 50, 36, 0.08);
            border-color: rgba(184, 50, 36, 0.42);
            color: var(--admin-danger);
        }
        .admin-grid-2 {
            display: grid;
            gap: 1.4rem;
            grid-template-columns: 1.15fr 1fr;
        }
        @media (max-width: 1199px) {
            .admin-grid-2 {
                grid-template-columns: 1fr;
            }
            .admin-split-grid {
                grid-template-columns: 1fr;
            }
            .topbar-pill-muted {
                display: none;
            }
        }
        @media (max-width: 991.98px) {
            .admin-sidebar--desktop {
                display: none;
            }
            body.admin-drawer-fallback-open {
                overflow: hidden;
            }
            body.admin-drawer-fallback-open::before {
                background: rgba(3, 10, 24, 0.58);
                content: '';
                inset: 0;
                position: fixed;
                z-index: 1045;
            }
            .admin-sidebar-drawer.admin-sidebar-drawer--fallback-open {
                display: block;
                transform: none;
                visibility: visible;
                z-index: 1050;
            }
            .admin-wrap {
                display: block;
                min-height: auto;
            }
            .admin-content {
                margin-left: 0;
                padding: 1rem;
            }
            .admin-page-header {
                padding: 1.2rem;
            }
            .admin-toolbar-grid {
                grid-template-columns: 1fr;
            }
            .admin-toolbar-actions {
                justify-content: flex-start;
            }
            .admin-topbar-meta {
                display: none;
            }
        }
        @media (min-width: 992px) {
            .admin-sidebar-drawer {
                display: none;
            }
        }
        @media (max-width: 575.98px) {
            :root {
                --admin-topbar-height: 54px;
            }
            .admin-topbar .container-fluid {
                gap: 0.55rem;
                padding-left: 0.75rem !important;
                padding-right: 0.75rem !important;
            }
            .admin-brand .brand-text {
                max-width: 10.5rem;
            }
            .admin-brand-mark {
                border-radius: 0.85rem;
                height: 2.7rem;
                min-width: 2.7rem;
            }
            .admin-brand-logo {
                height: 2.35rem;
            }
            .admin-top-actions .btn {
                padding-inline: 0.75rem;
            }
            .admin-action-label {
                display: none;
            }
            .admin-sidebar-footer {
                padding: 0.85rem 0.9rem;
            }
            .admin-page-header h1 {
                font-size: 1.7rem;
            }
            .admin-page-header::before {
                left: 1rem;
                top: 0.8rem;
                width: 8rem;
            }
            .admin-card-header,
            .admin-card-body {
                padding: 1rem;
            }
            .admin-toolbar-card {
                padding: 1rem;
            }
            .admin-card-body > form.row.g-3 {
                padding: 0.25rem;
            }
            .admin-list-card {
                grid-template-columns: 1fr;
            }
            .admin-list-side {
                justify-items: start;
                text-align: left;
            }
            .admin-table {
                border-spacing: 0 0.55rem;
            }
            .admin-table th,
            .admin-table td {
                padding: 0.85rem 0.75rem;
            }
        }
        @media (prefers-reduced-motion: reduce) {
            .admin-page-header,
            .admin-card,
            .stat-tile,
            .admin-nav-link,
            .admin-nav-link .icon-wrap,
            .admin-top-actions .btn,
            .btn {
                opacity: 1 !important;
                transform: none !important;
                transition: none !important;
            }
        }
    </style>
</head>
<body class="admin-shell">
    <a class="admin-skip-link" href="#adminMainContent">Skip to content</a>
    <nav class="navbar admin-topbar sticky-top">
        <div class="container-fluid px-3 px-lg-4">
            <div class="admin-topbar-start">
                <button
                    class="btn admin-menu-trigger d-lg-none"
                    type="button"
                    data-bs-toggle="offcanvas"
                    data-bs-target="#<?php echo e($drawerId); ?>"
                    aria-controls="<?php echo e($drawerId); ?>"
                    aria-expanded="false"
                    aria-label="Open admin menu"
                    data-admin-menu-trigger
                >
                    <i class="fa-solid fa-bars"></i>
                </button>
                <a class="admin-brand" href="<?php echo e($dashboardHref); ?>">
                    <span class="admin-brand-mark">
                        <img class="admin-brand-logo" src="<?php echo e($brandLogo); ?>" alt="Bus Terminal logo">
                    </span>
                    <span class="brand-text admin-brand-copy">
                        <span class="admin-brand-kicker"><?php echo e($brandKicker); ?></span>
                        <span class="admin-brand-title">Control Portal</span>
                    </span>
                </a>
            </div>

            <div class="admin-topbar-meta">
                <span class="topbar-pill <?php echo e($rolePillClass); ?>">
                    <i class="fa-solid <?php echo e($rolePillIcon); ?>"></i>
                    <?php echo e($roleName); ?>
                </span>
                <span class="topbar-pill topbar-pill-muted">
                    <i class="fa-regular fa-clock"></i>
                    <span data-admin-live-time><?php echo e(date('D, M j, Y g:i A')); ?></span>
                </span>
            </div>
            <div class="admin-top-actions">
                <a class="btn btn-sm btn-outline-light" href="<?php echo e($sitePrefix . 'index.php'); ?>">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                    <span class="admin-action-label">Website</span>
                </a>
                <form method="post" action="<?php echo e($sitePrefix . 'logout.php?scope=admin'); ?>">
                    <?php csrf_field(); ?>
                    <button class="btn btn-sm btn-outline-danger" type="submit">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span class="admin-action-label">Logout</span>
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <div class="offcanvas offcanvas-start admin-sidebar-drawer" tabindex="-1" id="<?php echo e($drawerId); ?>" aria-labelledby="<?php echo e($drawerId); ?>Label">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title fw-bold" id="<?php echo e($drawerId); ?>Label"><?php echo e($portalLabel); ?></h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <div class="admin-sidebar-brand">
                <div class="admin-sidebar-brand__head">
                    <img class="admin-sidebar-brand__logo" src="<?php echo e($brandLogo); ?>" alt="Bus Terminal logo">
                    <div class="admin-sidebar-brand__copy">
                        <span><?php echo e($brandKicker); ?></span>
                        <strong><?php echo e($portalLabel); ?></strong>
                    </div>
                </div>
                <p><?php echo e($sidebarBrandSummary); ?></p>
            </div>
            <div class="profile-card">
                <div class="admin-profile-head">
                    <span class="admin-profile-avatar"><?php echo e($initials); ?></span>
                    <div>
                        <div class="profile-name"><?php echo e($displayName); ?></div>
                        <div class="profile-role"><?php echo e($roleName); ?> control access</div>
                    </div>
                </div>
            </div>
            <div class="admin-menu-label"><?php echo e($menuLabel); ?></div>
            <nav class="d-grid gap-1">
                <?php admin_render_menu_links($menuItems, $activeKey, true); ?>
            </nav>
            <div class="admin-sidebar-footer">
                <div class="sidebar-footer-title">Today In Focus</div>
                <div class="sidebar-footer-copy"><?php echo e($sidebarFootnote); ?></div>
            </div>
        </div>
    </div>

    <div class="admin-wrap">
        <aside class="admin-sidebar admin-sidebar--desktop">
            <div class="admin-sidebar-brand">
                <div class="admin-sidebar-brand__head">
                    <img class="admin-sidebar-brand__logo" src="<?php echo e($brandLogo); ?>" alt="Bus Terminal logo">
                    <div class="admin-sidebar-brand__copy">
                        <span><?php echo e($brandKicker); ?></span>
                        <strong><?php echo e($portalLabel); ?></strong>
                    </div>
                </div>
                <p><?php echo e($sidebarBrandSummary); ?></p>
            </div>
            <div class="profile-card">
                <div class="admin-profile-head">
                    <span class="admin-profile-avatar"><?php echo e($initials); ?></span>
                    <div>
                        <div class="profile-name"><?php echo e($displayName); ?></div>
                        <div class="profile-role"><?php echo e($roleName); ?> control access</div>
                    </div>
                </div>
            </div>
            <div class="admin-menu-label"><?php echo e($menuLabel); ?></div>
            <nav class="d-grid gap-1">
                <?php admin_render_menu_links($menuItems, $activeKey); ?>
            </nav>
            <div class="admin-sidebar-footer">
                <div class="sidebar-footer-title">Today In Focus</div>
                <div class="sidebar-footer-copy"><?php echo e($sidebarFootnote); ?></div>
            </div>
        </aside>

        <main id="adminMainContent" class="admin-content">
<?php
    }
}

if (!function_exists('admin_page_header')) {
    function admin_page_header(string $title, string $subtitle = '', array $actions = []): void
    {
        $workspaceLabel = current_role_key() === 'staff' ? 'Operations Workspace' : 'Management Workspace';
        ?>
            <div class="admin-page-header">
                <div class="admin-page-copy">
                    <span class="admin-page-kicker"><?php echo e($workspaceLabel); ?></span>
                    <h1><?php echo e($title); ?></h1>
                    <?php if ($subtitle !== ''): ?>
                        <p><?php echo e($subtitle); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ($actions !== []): ?>
                    <div class="admin-page-actions">
                        <?php foreach ($actions as $action): ?>
                            <a class="btn <?php echo e($action['class'] ?? 'btn-outline-secondary'); ?>" href="<?php echo e($action['href']); ?>">
                                <?php if (!empty($action['icon'])): ?>
                                    <i class="fa-solid <?php echo e($action['icon']); ?> me-1"></i>
                                <?php endif; ?>
                                <?php echo e($action['label'] ?? 'Action'); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php
    }
}

if (!function_exists('admin_render_footer')) {
    function admin_render_footer(string $extraScripts = ''): void
    {
        ?>
        </main>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function () {
        document.body.classList.add('is-ready');

        const adminDrawer = document.getElementById('adminMenuDrawer');
        const adminDrawerTrigger = document.querySelector('[data-admin-menu-trigger]');
        const isCompactAdminViewport = function () {
            return window.matchMedia('(max-width: 991.98px)').matches;
        };

        if (adminDrawer && adminDrawerTrigger) {
            const setFallbackDrawerState = function (isOpen) {
                adminDrawer.classList.toggle('admin-sidebar-drawer--fallback-open', isOpen);
                document.body.classList.toggle('admin-drawer-fallback-open', isOpen);
                adminDrawerTrigger.setAttribute('aria-expanded', String(isOpen));
            };

            if (window.bootstrap && typeof window.bootstrap.Offcanvas === 'function') {
                adminDrawer.addEventListener('shown.bs.offcanvas', function () {
                    adminDrawerTrigger.setAttribute('aria-expanded', 'true');
                });
                adminDrawer.addEventListener('hidden.bs.offcanvas', function () {
                    adminDrawerTrigger.setAttribute('aria-expanded', 'false');
                });
            } else {
                const closeFallbackDrawer = function () {
                    setFallbackDrawerState(false);
                    adminDrawerTrigger.focus();
                };

                adminDrawerTrigger.addEventListener('click', function (event) {
                    event.preventDefault();
                    setFallbackDrawerState(!adminDrawer.classList.contains('admin-sidebar-drawer--fallback-open'));
                });

                adminDrawer.querySelectorAll('[data-bs-dismiss="offcanvas"], .admin-nav-link').forEach(function (control) {
                    control.addEventListener('click', closeFallbackDrawer);
                });

                document.addEventListener('keydown', function (event) {
                    if (event.key === 'Escape' && adminDrawer.classList.contains('admin-sidebar-drawer--fallback-open')) {
                        closeFallbackDrawer();
                    }
                });

                document.addEventListener('click', function (event) {
                    if (!isCompactAdminViewport() || !adminDrawer.classList.contains('admin-sidebar-drawer--fallback-open')) {
                        return;
                    }

                    if (!adminDrawer.contains(event.target) && !adminDrawerTrigger.contains(event.target)) {
                        closeFallbackDrawer();
                    }
                });
            }

            window.addEventListener('resize', function () {
                if (!isCompactAdminViewport()) {
                    setFallbackDrawerState(false);
                }
            });

            adminDrawer.querySelectorAll('.admin-nav-link').forEach(function (control) {
                control.addEventListener('click', function () {
                    if (!isCompactAdminViewport()) {
                        return;
                    }

                    const destination = control.href;
                    if (destination) {
                        window.setTimeout(function () {
                            window.location.assign(destination);
                        }, 0);
                    }
                });
            });
        }

        const timeNodes = document.querySelectorAll('[data-admin-live-time]');
        if (!timeNodes.length) {
            return;
        }

        const formatter = new Intl.DateTimeFormat('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            year: 'numeric',
            hour: 'numeric',
            minute: '2-digit'
        });

        const updateClock = function () {
            const label = formatter.format(new Date());
            timeNodes.forEach(function (node) {
                node.textContent = label;
            });
        };

        updateClock();
        window.setInterval(updateClock, 60000);
    });
    </script>
    <?php echo $extraScripts; ?>
</body>
</html>
<?php
    }
}
