<?php
if (!defined('BUS_SYSTEM_HEADER_INCLUDED')) {
    define('BUS_SYSTEM_HEADER_INCLUDED', true);

    if (!defined('BUS_SYSTEM_CONFIG_LOADED')) {
        include __DIR__ . '/config.php';
    }

    $page_title = $page_title ?? 'Gonzaga Terminal - Bus Reservation System';
    $current_page = basename($_SERVER['PHP_SELF'] ?? 'index.php');
    $current_view = $_GET['view'] ?? ($current_page === 'fares.php' ? 'bus-fares' : null);
    $page_slug = pathinfo($current_page, PATHINFO_FILENAME);
    $body_class = 'site-page page-' . preg_replace('/[^a-z0-9-]+/i', '-', strtolower($page_slug));
    $main_class = 'site-main';
    $style_asset_path = dirname(__DIR__) . '/assets/css/style.css';
    $style_asset_version = file_exists($style_asset_path) ? (string) filemtime($style_asset_path) : (string) time();
    $base_url = isset($base_url) ? trim((string) $base_url) : '';
    $asset_base = $base_url !== '' ? rtrim(str_replace('\\', '/', $base_url), '/') . '/' : '';
    $brand_logo = $asset_base . 'assets/images/bus-terminal-logo.svg';

    if ($current_page === 'index.php') {
        $body_class .= ' site-page-home';
        $main_class .= ' site-main-home';
    }

    $navigation_items = [
        [
            'label' => 'Home',
            'href' => 'index.php',
            'matches' => ['index.php'],
        ],
    ];

    if (is_logged_in()) {
        $navigation_items[] = [
            'label' => 'Dashboard',
            'href' => 'dashboard.php',
            'matches' => ['dashboard.php'],
        ];
    }

    $navigation_items = array_merge($navigation_items, [
        [
            'label' => 'Online Booking',
            'href' => 'booking.php',
            'matches' => ['booking.php', 'booking-details.php', 'booking-view.php', 'passenger-details.php', 'payment.php', 'my-bookings.php'],
        ],
        [
            'label' => 'Schedules',
            'href' => 'schedules.php',
            'matches' => ['schedules.php'],
        ],
        [
            'label' => 'Rates',
            'href' => 'fares.php?view=rates',
            'matches' => ['fares.php'],
            'view' => 'rates',
        ],
        [
            'label' => 'Bus Route',
            'href' => 'routes.php',
            'matches' => ['routes.php'],
        ],
        [
            'label' => 'Terminals',
            'href' => 'terminals.php',
            'matches' => ['terminals.php'],
        ],
        [
            'label' => 'Bus Fares',
            'href' => 'fares.php?view=bus-fares',
            'matches' => ['fares.php'],
            'view' => 'bus-fares',
        ],
        [
            'label' => 'FAQ',
            'href' => 'faq.php',
            'matches' => ['faq.php'],
        ],
        [
            'label' => 'Travel Guides',
            'href' => 'travel-guides.php',
            'matches' => ['travel-guides.php', 'travel-guide-detail.php'],
        ],
        [
            'label' => 'Blog',
            'href' => 'blog.php',
            'matches' => ['blog.php', 'blog-detail.php'],
        ],
    ]);

    // Keep the header compact while retaining quick access to every page.
    $visible_navigation_items = array_values(array_filter(
        $navigation_items,
        static fn (array $item): bool => ($item['href'] ?? '') !== 'dashboard.php'
    ));
    $primary_navigation_items = array_slice($visible_navigation_items, 0, 5);
    $secondary_navigation_items = array_slice($visible_navigation_items, 5);
    $is_navigation_item_active = static function (array $item) use ($current_page, $current_view): bool {
        $is_active = in_array($current_page, $item['matches'], true);

        return $is_active && (!isset($item['view']) || $current_view === $item['view']);
    };

    $account_name = (string) ($_SESSION['user_name'] ?? 'Account');
    $account_parts = preg_split('/\s+/', trim($account_name)) ?: [];
    $account_initials = '';

    foreach ($account_parts as $part) {
        if ($part === '') {
            continue;
        }

        $account_initials .= strtoupper(substr($part, 0, 1));

        if (strlen($account_initials) >= 2) {
            break;
        }
    }

    if ($account_initials === '') {
        $account_initials = 'GT';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Sora:wght@600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?php echo htmlspecialchars($asset_base . 'assets/css/style.css'); ?>?v=<?php echo htmlspecialchars($style_asset_version); ?>">
    <?php echo isset($page_head_extra) ? $page_head_extra : ''; ?>
    <style>
        .chip {
            align-items: center;
            border-radius: 999px;
            display: inline-flex;
            font-size: .78rem;
            font-weight: 700;
            gap: .35rem;
            padding: .36rem .72rem;
        }
        .chip.soft {
            background: #fff1ef;
            color: #b42318;
        }
        .chip.success {
            background: #ecfdf3;
            color: #067647;
        }
        .chip.warning {
            background: #fffaeb;
            color: #b54708;
        }
        .chip.danger {
            background: #fef3f2;
            color: #b42318;
        }
    </style>
</head>
<body class="<?php echo htmlspecialchars($body_class); ?>">
    <a class="skip-link" href="#main-content">Skip to main content</a>
    <header class="site-header">
        <nav class="navbar navbar-expand-xxl navbar-light site-navbar">
            <div class="container-fluid header-shell">
                <a class="site-brand" href="<?php echo htmlspecialchars($asset_base . 'index.php'); ?>">
                    <span class="site-brand-logo-wrap">
                        <img class="site-brand-logo" src="<?php echo htmlspecialchars($brand_logo); ?>" alt="Bus Terminal logo">
                    </span>
                    <span class="site-brand-copy">
                        <span class="site-brand-kicker">Bus Reservation System</span>
                        <span class="site-brand-title">Gonzaga Terminal</span>
                    </span>
                </a>

                <button class="navbar-toggler site-navbar-toggler site-navbar-toggler--responsive-left" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="site-mobile-menu-header">
                        <span>Navigation</span>
                        <button class="site-mobile-menu-close" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                                aria-controls="navbarNav" aria-label="Close navigation menu">
                            <i class="fa-solid fa-xmark" aria-hidden="true"></i>
                        </button>
                    </div>
                    <ul class="navbar-nav site-nav-list me-auto ms-lg-4">
                        <?php foreach ($primary_navigation_items as $item): ?>
                            <?php $is_active = $is_navigation_item_active($item); ?>
                            <li class="nav-item">
                                <a
                                    class="nav-link site-nav-link<?php echo $is_active ? ' is-active' : ''; ?>"
                                    href="<?php echo htmlspecialchars($asset_base . $item['href']); ?>"
                                    <?php echo $is_active ? 'aria-current="page"' : ''; ?>
                                >
                                    <?php echo htmlspecialchars($item['label']); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>

                        <?php if ($secondary_navigation_items): ?>
                            <?php
                            $has_active_secondary_item = false;
                            foreach ($secondary_navigation_items as $item) {
                                if ($is_navigation_item_active($item)) {
                                    $has_active_secondary_item = true;
                                    break;
                                }
                            }
                            ?>
                            <li class="nav-item dropdown">
                                <button class="nav-link site-nav-link site-nav-more-toggle dropdown-toggle<?php echo $has_active_secondary_item ? ' is-active' : ''; ?>" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    More <i class="fa-solid fa-chevron-down ms-1" aria-hidden="true"></i>
                                </button>
                                <ul class="dropdown-menu site-nav-more-menu">
                                    <?php foreach ($secondary_navigation_items as $item): ?>
                                        <?php $is_active = $is_navigation_item_active($item); ?>
                                        <li>
                                            <a class="dropdown-item<?php echo $is_active ? ' active' : ''; ?>" href="<?php echo htmlspecialchars($asset_base . $item['href']); ?>"<?php echo $is_active ? ' aria-current="page"' : ''; ?>>
                                                <?php echo htmlspecialchars($item['label']); ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>

                    <div class="site-header-actions">
                        <?php if (is_logged_in()): ?>
                            <a class="site-book-btn btn btn-danger rounded-pill px-4 py-2 text-white" href="<?php echo htmlspecialchars($asset_base . 'booking.php'); ?>">Book Now</a>
                            <div class="dropdown">
                                <button class="btn site-account-toggle dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <span class="site-account-avatar"><?php echo htmlspecialchars($account_initials); ?></span>
                                    <span class="site-account-toggle-label">
                                        <strong><?php echo htmlspecialchars($account_name); ?></strong>
                                        <small>My Account</small>
                                    </span>
                                    <i class="fa-solid fa-chevron-down site-account-toggle-arrow" aria-hidden="true"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="<?php echo htmlspecialchars($asset_base . 'dashboard.php'); ?>">
                                            <i class="fas fa-table-columns"></i> Dashboard
                                        </a>
                                    </li>
                                    <?php if (can_access_admin_panel()): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo htmlspecialchars($asset_base . 'admin/dashboard.php'); ?>">
                                                <i class="fas fa-shield-halved"></i> Control Panel
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <!-- Profile moved to user dashboard quick actions per UX request -->
                                    <li>
                                        <a class="dropdown-item" href="<?php echo htmlspecialchars($asset_base . 'my-bookings.php'); ?>">
                                            <i class="fas fa-ticket"></i> My Bookings
                                        </a>
                                    </li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li>
                                        <form method="post" action="<?php echo htmlspecialchars($asset_base . 'logout.php?scope=site'); ?>">
                                            <?php csrf_field(); ?>
                                            <button class="dropdown-item text-danger" type="submit">
                                                <i class="fas fa-sign-out-alt"></i> Logout
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <a class="site-book-btn btn btn-danger rounded-pill px-4 py-2 text-white" href="<?php echo htmlspecialchars($asset_base . 'booking.php'); ?>">Book Now</a>
                            <a class="site-account-link btn btn-outline-secondary rounded-pill px-3 py-1" href="<?php echo htmlspecialchars($asset_base . 'login.php'); ?>">
                                <span>Sign In</span>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <main id="main-content" class="<?php echo htmlspecialchars($main_class); ?>" tabindex="-1">
<?php
}
?>
