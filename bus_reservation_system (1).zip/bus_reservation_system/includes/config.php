<?php
if (defined('BUS_SYSTEM_CONFIG_LOADED')) {
    return;
}
define('BUS_SYSTEM_CONFIG_LOADED', true);

require_once __DIR__ . '/system_bootstrap.php';
