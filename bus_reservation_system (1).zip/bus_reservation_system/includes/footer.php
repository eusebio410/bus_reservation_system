    </main>

    <?php
    $base_url = isset($base_url) ? trim((string) $base_url) : '';
    $asset_base = $base_url !== '' ? rtrim(str_replace('\\', '/', $base_url), '/') . '/' : '';
    ?>

    <footer class="bg-dark text-white mt-5 py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="mb-3"><i class="fas fa-building"></i> Terminal</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'index.php'); ?>" class="text-white-50 text-decoration-none">About Gonzaga Terminal</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'terminals.php'); ?>" class="text-white-50 text-decoration-none">Terminal Information</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'blog.php'); ?>" class="text-white-50 text-decoration-none">Announcements</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'faq.php'); ?>" class="text-white-50 text-decoration-none">Passenger Help</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="mb-3"><i class="fas fa-concierge-bell"></i> Services</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'booking.php'); ?>" class="text-white-50 text-decoration-none">Online Booking</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'schedules.php'); ?>" class="text-white-50 text-decoration-none">Bus Schedules</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'routes.php'); ?>" class="text-white-50 text-decoration-none">Route List</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'fares.php?view=bus-fares'); ?>" class="text-white-50 text-decoration-none">Fare Reference</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="mb-3"><i class="fas fa-headset"></i> Support</h5>
                    <ul class="list-unstyled">
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'faq.php'); ?>" class="text-white-50 text-decoration-none">FAQ</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'travel-guides.php'); ?>" class="text-white-50 text-decoration-none">Travel Guides</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'booking.php'); ?>" class="text-white-50 text-decoration-none">Reservation Help</a></li>
                        <li><a href="<?php echo htmlspecialchars($asset_base . 'my-bookings.php'); ?>" class="text-white-50 text-decoration-none">My Bookings</a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 mb-4">
                    <h5 class="mb-3"><i class="fas fa-share-alt"></i> Follow Us</h5>
                    <div class="d-flex gap-3">
                        <a href="#" class="text-white-50 text-decoration-none"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-white-50 text-decoration-none"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-white-50 text-decoration-none"><i class="fab fa-youtube"></i></a>
                    </div>
                </div>
            </div>
            <hr class="bg-white-50">
            <div class="text-center text-white-50 small">
                <p>&copy; <?php echo date('Y'); ?> Gonzaga Terminal Bus Reservation System. All rights reserved.</p>
                <p>Capstone project for Gonzaga, Cagayan | Terminal-based reservations | Local schedule support</p>
            </div>
        </div>
    </footer>

    <?php
    $script_asset_path = dirname(__DIR__) . '/assets/js/script.js';
    $script_asset_version = file_exists($script_asset_path) ? (string) filemtime($script_asset_path) : (string) time();
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo htmlspecialchars($asset_base . 'assets/js/script.js'); ?>?v=<?php echo htmlspecialchars($script_asset_version); ?>"></script>
</body>
</html>
