<?php
if (!function_exists('app_env')) {
    function app_env(string $key, string $default = ''): string
    {
        $value = getenv($key);

        return $value === false ? $default : trim((string) $value);
    }
}

if (!function_exists('app_env_bool')) {
    /**
     * Read a conventional environment boolean without treating arbitrary text
     * such as "false" as truthy.
     */
    function app_env_bool(string $key, bool $default = false): bool
    {
        $value = getenv($key);

        if ($value === false || trim((string) $value) === '') {
            return $default;
        }

        return filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? $default;
    }
}

define('APP_ENV', strtolower(app_env('BUS_APP_ENV', 'development')));
define('DB_HOST', app_env('BUS_DB_HOST', 'sql301.infinityfree.com'));
define('DB_USER', app_env('BUS_DB_USER', 'if0_43150141'));
define('DB_PASS', app_env('BUS_DB_PASS', '8Pvbqs6inE'));
define('DB_NAME', app_env('BUS_DB_NAME', 'if0_43150141_bus_reservation_db'));

define('APP_NAME', app_env('BUS_APP_NAME', 'Gonzaga Terminal Bus Reservation System'));
$configuredQrSecret = app_env('BUS_QR_SECRET');
if (APP_ENV === 'production' && $configuredQrSecret === '') {
    throw new RuntimeException('BUS_QR_SECRET must be configured in production.');
}
// The fallback is only for a local devesql301.infinityfree.comlopment install. Production always requires BUS_QR_SECRET.
define('APP_QR_SECRET', $configuredQrSecret !== '' ? $configuredQrSecret : hash('sha256', __DIR__ . '|development-only'));
define('APP_TIMEZONE', app_env('BUS_TIMEZONE', 'Asia/Manila'));
define('APP_DB_TIMEZONE_OFFSET', app_env('BUS_DB_TIMEZONE_OFFSET', '+08:00'));
define('GCASH_ACCOUNT_NUMBER', app_env('BUS_GCASH_ACCOUNT_NUMBER'));
define('GCASH_ACCOUNT_DISPLAY', app_env('BUS_GCASH_ACCOUNT_DISPLAY'));
// GCash is collected through Maya Checkout. A personal GCash QR or account
// number cannot provide a trustworthy server-side payment confirmation.
define('APP_PUBLIC_URL', rtrim(app_env('BUS_APP_URL', 'https://busreservation.wuaze.com/bus_reservation_system'), '/'));
define('MAYA_ENVIRONMENT', strtolower(app_env('BUS_MAYA_ENVIRONMENT', 'sandbox')) === 'production' ? 'production' : 'sandbox');
define('MAYA_PUBLIC_KEY', app_env('BUS_MAYA_PUBLIC_KEY'));
define('MAYA_SECRET_KEY', app_env('BUS_MAYA_SECRET_KEY'));
define('MAYA_API_BASE_URL', rtrim(app_env(
    'BUS_MAYA_API_BASE_URL',
    MAYA_ENVIRONMENT === 'production' ? 'https://pg.maya.ph' : 'https://pg-sandbox.paymaya.com'
), '/'));
// Maya documents IP allow-listing as the webhook authentication control. Keep
// this override for deployments behind a proxy that exposes a known source IP.
define('MAYA_WEBHOOK_ALLOWED_IPS', app_env(
    'BUS_MAYA_WEBHOOK_ALLOWED_IPS',
    MAYA_ENVIRONMENT === 'production' ? '18.138.50.235,3.1.207.200' : '13.229.160.234,3.1.199.75'
));
define('PAYMONGO_PUBLIC_KEY', app_env('BUS_PAYMONGO_PUBLIC_KEY', 'pk_live_rC2Caqpmt5vUY4yoWXRrug3C'));
define('PAYMONGO_SECRET_KEY', app_env('BUS_PAYMONGO_SECRET_KEY', 'sk_live_yhY19mcjCTWgs5PfCzeCrrJ3'));
define('PAYMONGO_WEBHOOK_SECRET', app_env('BUS_PAYMONGO_WEBHOOK_SECRET', 'whsk_hudxNuTtMWvf8EaJfn6AiFDo'));
define('PAYMONGO_API_BASE_URL', rtrim(app_env('BUS_PAYMONGO_API_BASE_URL', 'https://api.paymongo.com'), '/'));
// Demo payments are permanently disabled; GCash uses PayMongo only.
define('DEMO_GCASH_ENABLED', false);
define('MAX_ADVANCE_BOOKING_DAYS', 3);
define('SESSION_TIMEOUT_SECONDS', 1800);
define('MAX_LOGIN_FAILURES', 5);
define('LOGIN_LOCKOUT_SECONDS', 15 * 60);
define('BOOKING_HOLD_MINUTES', 10);
define('MAX_PAYMENT_PROOF_UPLOAD_BYTES', 5 * 1024 * 1024);
define('FIXED_BUS_SEAT_CAPACITY', 43);
define('SESSION_SCOPE_SITE', 'site');
define('SESSION_SCOPE_ADMIN', 'admin');
define('APP_BOOTSTRAP_VERSION', '2026-09-17-7');
define('APP_BOOTSTRAP_LOCK_NAME', 'bus_system_bootstrap');
define('APP_HOUSEKEEPING_LOCK_NAME', 'bus_system_housekeeping');
define('APP_HOUSEKEEPING_INTERVAL_SECONDS', 60);
// Schema changes and recurrence generation belong to an explicit deployment or
// scheduler task. Running them on normal page requests causes avoidable reload
// delays and can lock tables while passengers are booking.
define('RUN_SCHEMA_MIGRATIONS_ON_WEB', app_env_bool('BUS_RUN_SCHEMA_MIGRATIONS_ON_WEB'));
define('RUN_HOUSEKEEPING_ON_WEB', app_env_bool('BUS_RUN_HOUSEKEEPING_ON_WEB'));

date_default_timezone_set(APP_TIMEZONE);

if (APP_ENV === 'production') {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}

if (!function_exists('app_timezone')) {
    function app_timezone(): DateTimeZone
    {
        static $timezone = null;

        if ($timezone === null) {
            $timezone = new DateTimeZone(APP_TIMEZONE);
        }

        return $timezone;
    }
}

if (!function_exists('fixed_bus_seat_capacity')) {
    function fixed_bus_seat_capacity(): int
    {
        return max(1, (int) FIXED_BUS_SEAT_CAPACITY);
    }
}

if (!function_exists('script_name_normalized')) {
    function script_name_normalized(): string
    {
        return str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    }
}

if (!function_exists('app_base_web_path')) {
    function app_base_web_path(): string
    {
        static $basePath = null;

        if ($basePath !== null) {
            return $basePath;
        }

        $scriptName = script_name_normalized();
        if ($scriptName === '') {
            $basePath = '/';
            return $basePath;
        }

        $adminMarker = '/admin/';
        $adminPosition = strpos($scriptName, $adminMarker);
        if ($adminPosition !== false) {
            $basePath = substr($scriptName, 0, $adminPosition);
        } else {
            $basePath = rtrim(str_replace('\\', '/', dirname($scriptName)), '/');
        }

        if ($basePath === '' || $basePath === '.') {
            $basePath = '/';
        }

        return $basePath;
    }
}

if (!function_exists('session_scope_cookie_name')) {
    function session_scope_cookie_name(string $scope): string
    {
        return $scope === SESSION_SCOPE_ADMIN ? 'BUS_ADMIN_SESSION' : 'BUS_SITE_SESSION';
    }
}

if (!function_exists('session_scope_cookie_path')) {
    function session_scope_cookie_path(string $scope): string
    {
        $basePath = rtrim(app_base_web_path(), '/');
        if ($basePath === '') {
            $basePath = '';
        }

        if ($scope === SESSION_SCOPE_ADMIN) {
            return ($basePath !== '' ? $basePath : '') . '/admin';
        }

        return $basePath !== '' ? $basePath : '/';
    }
}

if (!function_exists('detect_session_scope')) {
    function detect_session_scope(): string
    {
        // The logout endpoint is shared by the two intentionally isolated sessions.
        // Do not let arbitrary pages choose their session scope through a query parameter.
        $scope = strtolower(trim((string) ($_GET['scope'] ?? '')));
        if (basename(script_name_normalized()) === 'logout.php'
            && in_array($scope, [SESSION_SCOPE_SITE, SESSION_SCOPE_ADMIN], true)) {
            return $scope;
        }

        return strpos(script_name_normalized(), '/admin/') !== false
            ? SESSION_SCOPE_ADMIN
            : SESSION_SCOPE_SITE;
    }
}

if (!function_exists('session_scope')) {
    function session_scope(): string
    {
        return (string) ($GLOBALS['bus_session_scope'] ?? detect_session_scope());
    }
}

if (!function_exists('apply_session_scope')) {
    function apply_session_scope(string $scope): void
    {
        $GLOBALS['bus_session_scope'] = $scope;

        if (PHP_SAPI === 'cli') {
            return;
        }

        session_name(session_scope_cookie_name($scope));
        session_set_cookie_params([
            'httponly' => true,
            'path' => session_scope_cookie_path($scope),
            'samesite' => 'Lax',
            'secure' => request_uses_https(),
        ]);
    }
}

if (!function_exists('request_uses_https')) {
    function request_uses_https(): bool
    {
        return (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
            || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
    }
}

if (!function_exists('configure_application_session_storage')) {
    /**
     * Keep PHP sessions in the application's protected storage directory.
     * This avoids relying on a machine-wide XAMPP temp folder that may not be
     * writable by Apache/PHP on a new deployment.
     */
    function configure_application_session_storage(): void
    {
        static $configured = false;
        if ($configured || session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $configured = true;
        $sessionDirectory = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'storage' . DIRECTORY_SEPARATOR . 'sessions';

        if (!is_dir($sessionDirectory) && !mkdir($sessionDirectory, 0775, true) && !is_dir($sessionDirectory)) {
            error_log('Bus reservation session directory could not be created.');
            return;
        }

        if (is_writable($sessionDirectory)) {
            session_save_path($sessionDirectory);
        } else {
            error_log('Bus reservation session directory is not writable.');
        }
    }
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    error_log('Bus reservation database connection failed: ' . $conn->connect_error);
    http_response_code(500);
    exit('The system is temporarily unavailable. Please try again later.');
}

$conn->set_charset('utf8mb4');
$conn->query("SET time_zone = '" . APP_DB_TIMEZONE_OFFSET . "'");

if (PHP_SAPI !== 'cli') {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.use_strict_mode', '1');
        configure_application_session_storage();
        apply_session_scope(detect_session_scope());
        session_start();
    }

    if (!empty($_SESSION['user_id'])) {
        $lastActivity = (int) ($_SESSION['last_activity'] ?? time());
        if ((time() - $lastActivity) > SESSION_TIMEOUT_SECONDS) {
            $_SESSION = [];
            session_destroy();
            session_start();
            $_SESSION['flash_error'] = 'Your session expired. Please sign in again.';
        } else {
            $_SESSION['last_activity'] = time();
        }
    }

    if (!function_exists('send_security_headers')) {
        function send_security_headers(): void
        {
            if (PHP_SAPI === 'cli') {
                return;
            }

            if (request_uses_https()) {
                header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
            }

            header_remove('X-Powered-By');
            header('X-Content-Type-Options: nosniff');
            header('X-Frame-Options: SAMEORIGIN');
            header('X-Permitted-Cross-Domain-Policies: none');
            header('Referrer-Policy: strict-origin-when-cross-origin');
            header('Permissions-Policy: camera=(), geolocation=(), microphone=(), interest-cohort=()');
            header('Cross-Origin-Opener-Policy: same-origin');
            header('Cross-Origin-Resource-Policy: same-origin');
            header(
                "Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; "
                . "frame-ancestors 'self'; object-src 'none'; connect-src 'self'; "
                . "img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdn.jsdelivr.net https://cdnjs.cloudflare.com; "
                . "font-src 'self' data: https://fonts.gstatic.com https://cdnjs.cloudflare.com; "
                . "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com https://unpkg.com"
            );
        }
    }

    send_security_headers();
}

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        if (PHP_SAPI === 'cli' || session_status() !== PHP_SESSION_ACTIVE) {
            return '';
        }

        if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): void
    {
        echo '<input type="hidden" name="_csrf_token" value="' . e(csrf_token()) . '">';
    }
}

if (!function_exists('csrf_request_is_valid')) {
    function csrf_request_is_valid(): bool
    {
        if (PHP_SAPI === 'cli') {
            return true;
        }

        $submittedToken = $_POST['_csrf_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

        return is_string($submittedToken)
            && $submittedToken !== ''
            && hash_equals(csrf_token(), $submittedToken);
    }
}

$isMayaWebhookRequest = defined('BUS_MAYA_WEBHOOK_REQUEST')
    && BUS_MAYA_WEBHOOK_REQUEST === true
    && basename(script_name_normalized()) === 'maya-webhook.php';
$isPayMongoWebhookRequest = defined('BUS_PAYMONGO_WEBHOOK_REQUEST')
    && BUS_PAYMONGO_WEBHOOK_REQUEST === true
    && basename(script_name_normalized()) === 'paymongo-webhook.php';
$isDemoGcashRequest = defined('BUS_DEMO_GCASH_REQUEST')
    && BUS_DEMO_GCASH_REQUEST === true
    && basename(script_name_normalized()) === 'demo-gcash-checkout.php';

if (PHP_SAPI !== 'cli' && ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && basename(script_name_normalized()) !== 'logout.php' && !$isMayaWebhookRequest && !$isPayMongoWebhookRequest && !$isDemoGcashRequest && !csrf_request_is_valid()) {
    $expectsJson = strpos((string) ($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false
        || isset($_GET['ajax']);
    http_response_code(403);
    if ($expectsJson) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'forbidden', 'message' => 'Your form session expired. Refresh the page and try again.']);
    } else {
        echo 'Your form session expired. Refresh the page and try again.';
    }
    exit();
}

if (!function_exists('sanitize')) {
    function sanitize($value): string
    {
        if (is_array($value)) {
            return '';
        }

        return trim((string) $value);
    }
}

if (!function_exists('normalize_ph_phone')) {
    function normalize_ph_phone(string $phone): string
    {
        $phone = trim($phone);
        if ($phone === '') {
            return '';
        }

        $digits = preg_replace('/\D+/', '', $phone);
        if ($digits === null || $digits === '') {
            return '';
        }

        if (strlen($digits) === 12 && strncmp($digits, '63', 2) === 0) {
            return '+'.$digits;
        }

        if (strlen($digits) === 11 && $digits[0] === '0') {
            return '+63' . substr($digits, 1);
        }

        if (strlen($digits) === 10 && $digits[0] === '9') {
            return '+63' . $digits;
        }

        return '';
    }
}

if (!function_exists('normalize_email_address')) {
    function normalize_email_address(string $email): string
    {
        $normalized = strtolower(trim($email));

        return preg_replace('/\s+/', '', $normalized) ?? $normalized;
    }
}

if (!function_exists('is_valid_email_address')) {
    function is_valid_email_address(string $email): bool
    {
        $email = normalize_email_address($email);

        if ($email === '' || strlen($email) > 254 || strpos($email, '@') === false) {
            return false;
        }

        [$localPart, $domain] = array_pad(explode('@', $email, 2), 2, '');

        if ($localPart === '' || $domain === '') {
            return false;
        }

        if (!preg_match("/^[A-Za-z0-9.!#$%&'*+\\/?^_{}|~-]+$/", $localPart)) {
            return false;
        }

        if (!preg_match('/^(?:[A-Za-z0-9-]+\\.)+[A-Za-z]{2,63}$/', $domain) && !preg_match('/^[A-Za-z0-9-]{1,63}$/', $domain)) {
            return false;
        }

        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
}

if (!function_exists('is_valid_person_name')) {
    function is_valid_person_name(string $name): bool
    {
        $name = trim($name);

        if ($name === '' || strlen($name) < 2 || strlen($name) > 120) {
            return false;
        }

        if (preg_match('/\d/', $name) === 1) {
            return false;
        }

        if (preg_match('/^[A-Za-z][A-Za-z .\'-]*[A-Za-z]$/', $name) !== 1 && preg_match('/^[A-Za-z]{2,}$/', $name) !== 1) {
            return false;
        }

        if (preg_match('/\s{2,}/', $name) === 1 || preg_match('/[._-]{2,}/', $name) === 1) {
            return false;
        }

        $letters = preg_match_all('/[A-Za-z]/', $name);

        return $letters >= 2;
    }
}

if (!function_exists('is_valid_registration_email')) {
    function is_valid_registration_email(string $email): bool
    {
        $email = normalize_email_address($email);

        if (!is_valid_email_address($email)) {
            return false;
        }

        [$localPart, $domain] = array_pad(explode('@', $email, 2), 2, '');
        $localPart = strtolower($localPart);
        $domain = strtolower($domain);

        if (strlen($localPart) < 3 || preg_match('/^(.)\1{3,}$/', $localPart) === 1) {
            return false;
        }

        $blockedLocalParts = ['hahaha', 'haha', 'test', 'demo', 'sample', 'guest', 'user', 'admin', 'random', 'asdf', 'qwerty'];
        $blockedDomains = [
            'mailinator.com',
            '10minutemail.com',
            'tempmail.com',
            'yopmail.com',
            'guerrillamail.com',
            'trashmail.com',
            'dispostable.com',
            'temp-mail.org',
            'throwawaymail.com',
            'fakeinbox.com',
        ];

        if (in_array($localPart, $blockedLocalParts, true) || in_array($domain, $blockedDomains, true)) {
            return false;
        }

        return true;
    }
}

if (!function_exists('normalize_gmail_email')) {
    function normalize_gmail_email(string $email): string
    {
        return normalize_email_address($email);
    }
}

if (!function_exists('is_valid_gmail_email')) {
    function is_valid_gmail_email(string $email): bool
    {
        return is_valid_email_address($email);
    }
}

if (!function_exists('is_valid_ph_phone')) {
    function is_valid_ph_phone(string $phone): bool
    {
        $normalizedPhone = normalize_ph_phone($phone);

        return $normalizedPhone !== '' && preg_match('/^\+639\d{9}$/', $normalizedPhone) === 1;
    }
}

if (!function_exists('e')) {
    function e($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('redirect')) {
    function redirect(string $location): void
    {
        header('Location: ' . $location);
        exit();
    }
}

if (!function_exists('isset_post')) {
    function isset_post(string $name): string
    {
        return isset($_POST[$name]) ? sanitize($_POST[$name]) : '';
    }
}

if (!function_exists('isset_get')) {
    function isset_get(string $name): string
    {
        return isset($_GET[$name]) ? sanitize($_GET[$name]) : '';
    }
}

if (!function_exists('set_flash')) {
    function set_flash(string $key, string $message): void
    {
        if (PHP_SAPI === 'cli') {
            return;
        }

        $_SESSION['flash_' . $key] = $message;
    }
}

if (!function_exists('consume_flash')) {
    function consume_flash(string $key): string
    {
        if (PHP_SAPI === 'cli') {
            return '';
        }

        $sessionKey = 'flash_' . $key;
        $message = $_SESSION[$sessionKey] ?? '';
        unset($_SESSION[$sessionKey]);

        return (string) $message;
    }
}

if (!function_exists('table_exists')) {
    function table_exists(string $table): bool
    {
        global $conn;

        static $cache = [];

        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($table === '') {
            return false;
        }

        if (array_key_exists($table, $cache)) {
            return $cache[$table];
        }

        $result = $conn->query("SHOW TABLES LIKE '" . $conn->real_escape_string($table) . "'");

        return $cache[$table] = $result instanceof mysqli_result && $result->num_rows > 0;
    }
}

if (!function_exists('column_exists')) {
    function column_exists(string $table, string $column): bool
    {
        global $conn;

        static $cache = [];

        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        $column = preg_replace('/[^a-zA-Z0-9_]/', '', $column);

        $cacheKey = $table . '.' . $column;
        if (array_key_exists($cacheKey, $cache)) {
            return $cache[$cacheKey];
        }

        if ($table === '' || $column === '' || !table_exists($table)) {
            return $cache[$cacheKey] = false;
        }

        $result = $conn->query("SHOW COLUMNS FROM `$table` LIKE '" . $conn->real_escape_string($column) . "'");

        return $cache[$cacheKey] = $result instanceof mysqli_result && $result->num_rows > 0;
    }
}

if (!function_exists('index_exists')) {
    function index_exists(string $table, string $index): bool
    {
        global $conn;

        static $cache = [];

        $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        $index = preg_replace('/[^a-zA-Z0-9_]/', '', $index);

        $cacheKey = $table . '.' . $index;
        if (array_key_exists($cacheKey, $cache)) {
            return $cache[$cacheKey];
        }

        if ($table === '' || $index === '' || !table_exists($table)) {
            return $cache[$cacheKey] = false;
        }

        $result = $conn->query("SHOW INDEX FROM `$table` WHERE Key_name = '" . $conn->real_escape_string($index) . "'");

        return $cache[$cacheKey] = $result instanceof mysqli_result && $result->num_rows > 0;
    }
}

if (!function_exists('db_select_one')) {
    function db_select_one(string $sql, string $types = '', array $params = []): ?array
    {
        global $conn;

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return null;
        }

        if ($types !== '' && $params !== []) {
            $stmt->bind_param($types, ...$params);
        }

        if (!$stmt->execute()) {
            $stmt->close();
            return null;
        }

        $result = $stmt->get_result();
        $row = $result ? $result->fetch_assoc() : null;
        $stmt->close();

        return $row ?: null;
    }
}

if (!function_exists('db_select_all')) {
    function db_select_all(string $sql, string $types = '', array $params = []): array
    {
        global $conn;

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return [];
        }

        if ($types !== '' && $params !== []) {
            $stmt->bind_param($types, ...$params);
        }

        if (!$stmt->execute()) {
            $stmt->close();
            return [];
        }

        $result = $stmt->get_result();
        $rows = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
        $stmt->close();

        return $rows;
    }
}

if (!function_exists('db_execute')) {
    function db_execute(string $sql, string $types = '', array $params = []): bool
    {
        global $conn;

        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return false;
        }

        if ($types !== '' && $params !== []) {
            $stmt->bind_param($types, ...$params);
        }

        $ok = $stmt->execute();
        $stmt->close();

        return $ok;
    }
}

if (!function_exists('db_last_insert_id')) {
    function db_last_insert_id(): int
    {
        global $conn;
        return (int) $conn->insert_id;
    }
}

if (!function_exists('login_throttle_key')) {
    function login_throttle_key(string $email): string
    {
        $ipAddress = trim((string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));

        return hash('sha256', normalize_email_address($email) . '|' . $ipAddress);
    }
}

if (!function_exists('login_rate_limit_status')) {
    function login_rate_limit_status(string $email): array
    {
        if (!table_exists('login_attempts')) {
            return ['blocked' => false, 'retry_after' => 0];
        }

        $key = login_throttle_key($email);
        $row = db_select_one(
            'SELECT failed_attempts, locked_until FROM login_attempts WHERE throttle_key = ? LIMIT 1',
            's',
            [$key]
        );

        if (!$row || empty($row['locked_until'])) {
            return ['blocked' => false, 'retry_after' => 0];
        }

        $lockedUntil = strtotime((string) $row['locked_until']);
        if ($lockedUntil === false || $lockedUntil <= time()) {
            db_execute(
                'UPDATE login_attempts SET failed_attempts = 0, locked_until = NULL WHERE throttle_key = ?',
                's',
                [$key]
            );

            return ['blocked' => false, 'retry_after' => 0];
        }

        return ['blocked' => true, 'retry_after' => $lockedUntil - time()];
    }
}

if (!function_exists('record_failed_login')) {
    function record_failed_login(string $email): array
    {
        if (!table_exists('login_attempts')) {
            return ['blocked' => false, 'retry_after' => 0];
        }

        $key = login_throttle_key($email);
        $row = db_select_one(
            'SELECT failed_attempts, locked_until FROM login_attempts WHERE throttle_key = ? LIMIT 1',
            's',
            [$key]
        );
        $lockedUntil = $row['locked_until'] ?? null;
        $isExistingLock = $lockedUntil !== null && strtotime((string) $lockedUntil) > time();

        if ($isExistingLock) {
            return login_rate_limit_status($email);
        }

        $attempts = (int) ($row['failed_attempts'] ?? 0) + 1;
        $newLockedUntil = $attempts >= MAX_LOGIN_FAILURES
            ? date('Y-m-d H:i:s', time() + LOGIN_LOCKOUT_SECONDS)
            : null;

        if ($row) {
            db_execute(
                'UPDATE login_attempts SET failed_attempts = ?, locked_until = ? WHERE throttle_key = ?',
                'iss',
                [$attempts, $newLockedUntil, $key]
            );
        } else {
            db_execute(
                'INSERT INTO login_attempts (throttle_key, failed_attempts, locked_until) VALUES (?, ?, ?)',
                'sis',
                [$key, $attempts, $newLockedUntil]
            );
        }

        return [
            'blocked' => $newLockedUntil !== null,
            'retry_after' => $newLockedUntil !== null ? LOGIN_LOCKOUT_SECONDS : 0,
        ];
    }
}

if (!function_exists('clear_failed_logins')) {
    function clear_failed_logins(string $email): void
    {
        if (table_exists('login_attempts')) {
            db_execute('DELETE FROM login_attempts WHERE throttle_key = ?', 's', [login_throttle_key($email)]);
        }
    }
}

if (!function_exists('ensure_app_runtime_meta_table')) {
    function ensure_app_runtime_meta_table(): void
    {
        global $conn;

        static $ready = false;
        if ($ready) {
            return;
        }

        $conn->query(
            "CREATE TABLE IF NOT EXISTS app_runtime_meta (
                meta_key VARCHAR(80) NOT NULL PRIMARY KEY,
                meta_value LONGTEXT NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
        );

        $ready = true;
    }
}

if (!function_exists('app_runtime_meta_get')) {
    function app_runtime_meta_get(string $key, ?string $default = null): ?string
    {
        ensure_app_runtime_meta_table();

        $row = db_select_one(
            'SELECT meta_value FROM app_runtime_meta WHERE meta_key = ? LIMIT 1',
            's',
            [$key]
        );

        if ($row === null || !array_key_exists('meta_value', $row) || $row['meta_value'] === null) {
            return $default;
        }

        return (string) $row['meta_value'];
    }
}

if (!function_exists('app_runtime_meta_set')) {
    function app_runtime_meta_set(string $key, string $value): void
    {
        ensure_app_runtime_meta_table();

        db_execute(
            'INSERT INTO app_runtime_meta (meta_key, meta_value)
             VALUES (?, ?)
             ON DUPLICATE KEY UPDATE meta_value = VALUES(meta_value), updated_at = CURRENT_TIMESTAMP',
            'ss',
            [$key, $value]
        );
    }
}

if (!function_exists('acquire_database_lock')) {
    function acquire_database_lock(string $lockName, int $timeoutSeconds = 15): bool
    {
        $lock = db_select_one(
            'SELECT GET_LOCK(?, ?) AS lock_status',
            'si',
            [$lockName, max(0, $timeoutSeconds)]
        );

        return (int) ($lock['lock_status'] ?? 0) === 1;
    }
}

if (!function_exists('release_database_lock')) {
    function release_database_lock(string $lockName): bool
    {
        $lock = db_select_one(
            'SELECT RELEASE_LOCK(?) AS lock_status',
            's',
            [$lockName]
        );

        return (int) ($lock['lock_status'] ?? 0) === 1;
    }
}

if (!function_exists('showError')) {
    function showError(string $message): void
    {
        echo '<div class="alert alert-danger">' . e($message) . '</div>';
    }
}

if (!function_exists('showSuccess')) {
    function showSuccess(string $message): void
    {
        echo '<div class="alert alert-success">' . e($message) . '</div>';
    }
}

if (!function_exists('generate_reference')) {
    function generate_reference(string $prefix, int $length = 6): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $suffix = '';

        for ($i = 0; $i < $length; $i++) {
            $suffix .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        }

        return strtoupper($prefix) . date('ymd') . $suffix;
    }
}

if (!function_exists('password_uses_native_hash')) {
    function password_uses_native_hash(string $hash): bool
    {
        if ($hash === '') {
            return false;
        }

        $info = password_get_info($hash);
        $algoName = (string) ($info['algoName'] ?? 'unknown');

        return $algoName !== '' && $algoName !== 'unknown';
    }
}

if (!function_exists('password_needs_bcrypt_upgrade')) {
    function password_needs_bcrypt_upgrade(string $hash): bool
    {
        if ($hash === '') {
            return false;
        }

        if (!password_uses_native_hash($hash)) {
            return true;
        }

        return password_needs_rehash($hash, PASSWORD_BCRYPT);
    }
}

if (!function_exists('verify_password_compat')) {
    function verify_password_compat(string $password, string $storedHash, int $userId = 0): bool
    {
        global $conn;

        $valid = false;
        $shouldUpgrade = false;

        if (password_uses_native_hash($storedHash)) {
            $valid = password_verify($password, $storedHash);
            $shouldUpgrade = $valid && password_needs_rehash($storedHash, PASSWORD_BCRYPT);
        } else {
            $legacyHash = hash('sha256', $password);
            $valid = $storedHash !== '' && hash_equals($storedHash, $legacyHash);
            $shouldUpgrade = $valid;
        }

        if ($valid && $shouldUpgrade && $userId > 0) {
            $newHash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare('UPDATE users SET password = ? WHERE user_id = ?');
            if ($stmt) {
                $stmt->bind_param('si', $newHash, $userId);
                $stmt->execute();
                $stmt->close();
            }
        }

        return $valid;
    }
}

if (!function_exists('current_user_record')) {
    function current_user_record(): ?array
    {
        static $cachedUserId = null;
        static $cachedUserRecord = false;

        $userId = (int) ($_SESSION['user_id'] ?? 0);
        if ($userId < 1) {
            return null;
        }

        if ($cachedUserId === $userId) {
            return is_array($cachedUserRecord) ? $cachedUserRecord : null;
        }

        $cachedUserId = $userId;
        $cachedUserRecord = db_select_one(
            "SELECT u.*, r.role_key, r.role_name
             FROM users u
             LEFT JOIN roles r ON u.role_id = r.role_id
             WHERE u.user_id = ?
             LIMIT 1",
            'i',
            [$userId]
        );

        return is_array($cachedUserRecord) ? $cachedUserRecord : null;
    }
}

if (!function_exists('login_user')) {
    function login_user(array $user): void
    {
        if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        $_SESSION['user_id'] = (int) $user['user_id'];
        $_SESSION['user_name'] = $user['fullname'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['role_key'] = $user['role_key'] ?? ((int) ($user['is_admin'] ?? 0) === 1 ? 'admin' : 'passenger');
        $_SESSION['is_admin'] = ($_SESSION['role_key'] === 'admin') ? 1 : 0;
        $_SESSION['last_activity'] = time();

        db_execute(
            'UPDATE users SET last_login_at = NOW(), last_activity_at = NOW() WHERE user_id = ?',
            'i',
            [(int) $user['user_id']]
        );

        if (in_array((string) ($_SESSION['role_key'] ?? ''), ['admin', 'staff'], true)) {
            create_audit_log(
                (int) $user['user_id'],
                'auth.login',
                'user',
                (int) $user['user_id'],
                'Portal sign-in completed.',
                ['role_key' => (string) ($_SESSION['role_key'] ?? '')]
            );
        }
    }
}

if (!function_exists('logout_user')) {
    function logout_user(): void
    {
        $_SESSION = [];
        if (session_status() === PHP_SESSION_ACTIVE) {
            $cookieParams = session_get_cookie_params();
            setcookie(
                session_name(),
                '',
                time() - 3600,
                $cookieParams['path'] ?? '/',
                $cookieParams['domain'] ?? '',
                (bool) ($cookieParams['secure'] ?? false),
                (bool) ($cookieParams['httponly'] ?? true)
            );
            session_destroy();
        }
    }
}

if (!function_exists('current_role_key')) {
    function current_role_key(): string
    {
        if (!empty($_SESSION['role_key'])) {
            return (string) $_SESSION['role_key'];
        }

        $user = current_user_record();

        return (string) ($user['role_key'] ?? (((int) ($user['is_admin'] ?? 0) === 1) ? 'admin' : 'passenger'));
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool
    {
        return current_role_key() === 'admin';
    }
}

if (!function_exists('is_staff')) {
    function is_staff(): bool
    {
        return current_role_key() === 'staff';
    }
}

if (!function_exists('can_access_admin_panel')) {
    function can_access_admin_panel(): bool
    {
        return in_array(current_role_key(), ['admin', 'staff'], true);
    }
}

if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool
    {
        if (empty($_SESSION['user_id'])) {
            return false;
        }

        $user = current_user_record();

        if (!$user || ($user['account_status'] ?? 'active') !== 'active') {
            logout_user();
            return false;
        }

        return true;
    }
}

if (!function_exists('create_notification')) {
    function create_notification(int $userId, string $type, string $title, string $message, ?int $bookingId = null): void
    {
        if (!table_exists('notifications')) {
            return;
        }

        db_execute(
            'INSERT INTO notifications (user_id, booking_id, notification_type, title, message) VALUES (?, ?, ?, ?, ?)',
            'iisss',
            [$userId, $bookingId, $type, $title, $message]
        );
    }
}

if (!function_exists('get_notifications_for_user')) {
    function get_notifications_for_user(int $userId, int $limit = 6): array
    {
        if (!table_exists('notifications')) {
            return [];
        }

        return db_select_all(
            'SELECT notification_id, notification_type, title, message, is_read, created_at
             FROM notifications
             WHERE user_id = ?
             ORDER BY created_at DESC
             LIMIT ' . max(1, (int) $limit),
            'i',
            [$userId]
        );
    }
}

if (!function_exists('mark_notifications_read')) {
    function mark_notifications_read(int $userId): void
    {
        if (!table_exists('notifications')) {
            return;
        }

        db_execute('UPDATE notifications SET is_read = 1 WHERE user_id = ?', 'i', [$userId]);
    }
}

if (!function_exists('role_key_for_user')) {
    function role_key_for_user(int $userId): string
    {
        if ($userId < 1) {
            return '';
        }

        $user = db_select_one(
            "SELECT COALESCE(r.role_key, CASE WHEN u.is_admin = 1 THEN 'admin' ELSE 'passenger' END) AS role_key
             FROM users u
             LEFT JOIN roles r ON u.role_id = r.role_id
             WHERE u.user_id = ?
             LIMIT 1",
            'i',
            [$userId]
        );

        return (string) ($user['role_key'] ?? '');
    }
}

if (!function_exists('create_audit_log')) {
    function create_audit_log(?int $userId, string $actionKey, string $entityType, int $entityId = 0, string $description = '', array $context = []): void
    {
        if (!table_exists('audit_logs')) {
            return;
        }

        $userId = $userId !== null && $userId > 0 ? $userId : 0;
        $roleKey = $userId > 0 ? role_key_for_user($userId) : '';
        if ($roleKey === '' && !empty($_SESSION['role_key'])) {
            $roleKey = (string) $_SESSION['role_key'];
        }

        $actionKey = strtolower(trim($actionKey));
        $actionKey = preg_replace('/[^a-z0-9._-]+/', '_', $actionKey) ?: 'action';
        $entityType = strtolower(trim($entityType));
        $entityType = preg_replace('/[^a-z0-9._-]+/', '_', $entityType) ?: 'system';
        $description = trim($description);
        $contextJson = $context !== []
            ? json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
            : null;

        db_execute(
            'INSERT INTO audit_logs (user_id, role_key, action_key, entity_type, entity_id, description, context_json, created_at)
             VALUES (NULLIF(?, 0), ?, ?, ?, ?, ?, ?, NOW())',
            'isssiss',
            [$userId, $roleKey, $actionKey, $entityType, $entityId, $description, $contextJson]
        );
    }
}

if (!function_exists('get_audit_logs')) {
    function get_audit_logs(array $filters = [], int $limit = 100): array
    {
        if (!table_exists('audit_logs')) {
            return [];
        }

        $limit = max(1, min(500, $limit));
        $sql = "SELECT a.*, u.fullname AS actor_name, u.email AS actor_email
                FROM audit_logs a
                LEFT JOIN users u ON a.user_id = u.user_id
                WHERE 1 = 1";
        $types = '';
        $params = [];

        $actionKey = trim((string) ($filters['action_key'] ?? ''));
        if ($actionKey !== '') {
            $sql .= ' AND a.action_key = ?';
            $types .= 's';
            $params[] = $actionKey;
        }

        $entityType = trim((string) ($filters['entity_type'] ?? ''));
        if ($entityType !== '') {
            $sql .= ' AND a.entity_type = ?';
            $types .= 's';
            $params[] = $entityType;
        }

        $roleKey = trim((string) ($filters['role_key'] ?? ''));
        if ($roleKey !== '') {
            $sql .= ' AND a.role_key = ?';
            $types .= 's';
            $params[] = $roleKey;
        }

        $actorId = (int) ($filters['user_id'] ?? 0);
        if ($actorId > 0) {
            $sql .= ' AND a.user_id = ?';
            $types .= 'i';
            $params[] = $actorId;
        }

        $dateFrom = trim((string) ($filters['date_from'] ?? ''));
        if ($dateFrom !== '') {
            $sql .= ' AND DATE(a.created_at) >= ?';
            $types .= 's';
            $params[] = $dateFrom;
        }

        $dateTo = trim((string) ($filters['date_to'] ?? ''));
        if ($dateTo !== '') {
            $sql .= ' AND DATE(a.created_at) <= ?';
            $types .= 's';
            $params[] = $dateTo;
        }

        $sql .= ' ORDER BY a.created_at DESC, a.audit_id DESC LIMIT ' . $limit;

        return db_select_all($sql, $types, $params);
    }
}

if (!function_exists('allowed_trip_statuses')) {
    function allowed_trip_statuses(): array
    {
        return ['scheduled', 'boarding', 'departed', 'arrived', 'delayed', 'cancelled'];
    }
}

if (!function_exists('normalize_schedule_trip_status')) {
    function normalize_schedule_trip_status(string $tripStatus, string $scheduleStatus = 'scheduled'): string
    {
        $scheduleStatus = strtolower(trim($scheduleStatus));
        $tripStatus = strtolower(trim($tripStatus));

        if ($scheduleStatus === 'cancelled') {
            return 'cancelled';
        }

        if ($scheduleStatus === 'completed') {
            return 'arrived';
        }

        return in_array($tripStatus, allowed_trip_statuses(), true)
            ? $tripStatus
            : 'scheduled';
    }
}

if (!function_exists('effective_schedule_trip_status')) {
    function effective_schedule_trip_status(array $schedule, ?DateTimeInterface $referenceTime = null): string
    {
        $scheduleStatus = strtolower(trim((string) ($schedule['status'] ?? 'scheduled')));
        if ($scheduleStatus === 'cancelled') {
            return 'cancelled';
        }

        $departureDate = trim((string) ($schedule['departure_date'] ?? ''));
        $departureTime = trim((string) ($schedule['departure_time'] ?? ''));
        $arrivalTime = trim((string) ($schedule['arrival_time'] ?? ''));

        if ($departureDate === '' || $departureTime === '' || $arrivalTime === '') {
            return normalize_schedule_trip_status((string) ($schedule['trip_status'] ?? 'scheduled'), $scheduleStatus);
        }

        try {
            [$departureWindowStart, $departureWindowEnd] = schedule_window($departureDate, $departureTime, $arrivalTime);
        } catch (Throwable $exception) {
            return normalize_schedule_trip_status((string) ($schedule['trip_status'] ?? 'scheduled'), $scheduleStatus);
        }

        $departureWindowStart = DateTimeImmutable::createFromMutable($departureWindowStart);
        $departureWindowEnd = DateTimeImmutable::createFromMutable($departureWindowEnd);

        $currentTime = $referenceTime
            ? DateTimeImmutable::createFromInterface($referenceTime)
            : new DateTimeImmutable('now');
        $boardingWindowStart = $departureWindowStart->modify('-30 minutes');

        if ($currentTime >= $departureWindowEnd) {
            return 'arrived';
        }

        if ($currentTime >= $departureWindowStart) {
            return 'departed';
        }

        if ($currentTime >= $boardingWindowStart) {
            return 'boarding';
        }

        return 'scheduled';
    }
}

if (!function_exists('effective_schedule_status')) {
    function effective_schedule_status(array $schedule, ?DateTimeInterface $referenceTime = null): string
    {
        $scheduleStatus = strtolower(trim((string) ($schedule['status'] ?? 'scheduled')));
        if ($scheduleStatus === 'cancelled') {
            return 'cancelled';
        }

        return effective_schedule_trip_status($schedule, $referenceTime) === 'arrived'
            ? 'completed'
            : 'scheduled';
    }
}

if (!function_exists('ensure_upload_directory')) {
    function ensure_upload_directory(string $relativePath): string
    {
        $relativePath = trim(str_replace('\\', '/', $relativePath), '/');
        if ($relativePath === '' || strpos($relativePath, '..') !== false) {
            throw new InvalidArgumentException('Invalid upload directory.');
        }

        $absolutePath = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $relativePath);

        if (!is_dir($absolutePath)) {
            mkdir($absolutePath, 0775, true);
        }

        return $absolutePath;
    }
}

if (!function_exists('save_uploaded_file')) {
    function save_uploaded_file(array $file, string $directory, array $allowedExtensions = ['jpg', 'jpeg', 'png', 'webp', 'pdf']): ?string
    {
        if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
            return null;
        }

        $tmpName = (string) ($file['tmp_name'] ?? '');
        $fileSize = (int) ($file['size'] ?? 0);
        if ($tmpName === '' || $fileSize < 1 || $fileSize > MAX_PAYMENT_PROOF_UPLOAD_BYTES) {
            return null;
        }

        if (!is_uploaded_file($tmpName)) {
            return null;
        }

        $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
        if (!in_array($extension, $allowedExtensions, true)) {
            return null;
        }

        $allowedMimeTypes = [
            'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png' => ['image/png'],
            'webp' => ['image/webp'],
            'pdf' => ['application/pdf'],
        ];

        $detectedMimeType = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo !== false) {
                $detectedMimeType = (string) finfo_file($finfo, $tmpName);
                finfo_close($finfo);
            }
        }

        if ($detectedMimeType === '' || !in_array($detectedMimeType, $allowedMimeTypes[$extension] ?? [], true)) {
            return null;
        }

        $targetDirectory = ensure_upload_directory($directory);
        $filename = generate_reference('PAY', 8) . '.' . $extension;
        $targetPath = $targetDirectory . DIRECTORY_SEPARATOR . $filename;

        if (!move_uploaded_file($tmpName, $targetPath)) {
            return null;
        }

        return trim(str_replace('\\', '/', $directory), '/') . '/' . $filename;
    }
}

if (!function_exists('schedule_window')) {
    function schedule_window(string $departureDate, string $departureTime, string $arrivalTime): array
    {
        $start = new DateTime($departureDate . ' ' . $departureTime, app_timezone());
        $end = new DateTime($departureDate . ' ' . $arrivalTime, app_timezone());

        if ($end <= $start) {
            $end->modify('+1 day');
        }

        return [$start, $end];
    }
}

if (!function_exists('bus_has_schedule_conflict')) {
    function bus_has_schedule_conflict(int $busId, string $departureDate, string $departureTime, string $arrivalTime, int $excludeScheduleId = 0): bool
    {
        [$newStart, $newEnd] = schedule_window($departureDate, $departureTime, $arrivalTime);
        $windowStart = $newStart->modify('-1 day')->format('Y-m-d');
        $windowEnd = $newEnd->modify('+1 day')->format('Y-m-d');

        [$compareStart, $compareEnd] = schedule_window($departureDate, $departureTime, $arrivalTime);

        $rows = db_select_all(
            'SELECT schedule_id, departure_date, departure_time, arrival_time
             FROM schedules
             WHERE bus_id = ?
             AND status <> "cancelled"
             AND schedule_id <> ?
             AND departure_date BETWEEN ? AND ?',
            'iiss',
            [$busId, $excludeScheduleId, $windowStart, $windowEnd]
        );

        foreach ($rows as $row) {
            [$existingStart, $existingEnd] = schedule_window(
                $row['departure_date'],
                $row['departure_time'],
                $row['arrival_time']
            );

            if ($compareStart < $existingEnd && $compareEnd > $existingStart) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('operator_has_schedule_conflict')) {
    function operator_has_schedule_conflict(int $operatorId, string $departureDate, string $departureTime, string $arrivalTime, int $excludeScheduleId = 0): bool
    {
        if ($operatorId < 1) {
            return false;
        }

        [$newStart, $newEnd] = schedule_window($departureDate, $departureTime, $arrivalTime);
        $windowStart = $newStart->modify('-1 day')->format('Y-m-d');
        $windowEnd = $newEnd->modify('+1 day')->format('Y-m-d');
        [$compareStart, $compareEnd] = schedule_window($departureDate, $departureTime, $arrivalTime);

        $rows = db_select_all(
            'SELECT schedule_id, departure_date, departure_time, arrival_time
             FROM schedules
             WHERE operator_id = ?
             AND status <> "cancelled"
             AND schedule_id <> ?
             AND departure_date BETWEEN ? AND ?',
            'iiss',
            [$operatorId, $excludeScheduleId, $windowStart, $windowEnd]
        );

        foreach ($rows as $row) {
            [$existingStart, $existingEnd] = schedule_window(
                $row['departure_date'],
                $row['departure_time'],
                $row['arrival_time']
            );

            if ($compareStart < $existingEnd && $compareEnd > $existingStart) {
                return true;
            }
        }

        return false;
    }
}

if (!function_exists('find_available_bus_for_schedule')) {
    function find_available_bus_for_schedule(string $busType, string $departureDate, string $departureTime, string $arrivalTime, int $excludeScheduleId = 0): ?array
    {
        $sql = 'SELECT bus_id, bus_code, bus_name, bus_type, total_seats
                FROM buses
                WHERE status = "active"
                AND is_enabled = 1';
        $types = '';
        $params = [];

        if ($busType !== '') {
            $sql .= ' AND bus_type = ?';
            $types .= 's';
            $params[] = $busType;
        }

        $sql .= ' ORDER BY total_seats ASC, bus_code ASC';
        $buses = db_select_all($sql, $types, $params);

        foreach ($buses as $bus) {
            if (!bus_has_schedule_conflict((int) $bus['bus_id'], $departureDate, $departureTime, $arrivalTime, $excludeScheduleId)) {
                return $bus;
            }
        }

        return null;
    }
}

if (!function_exists('sync_bus_seats')) {
    function sync_bus_seats(int $busId, int $capacity, int $columns = 4): void
    {
        if ($busId < 1 || !table_exists('seats')) {
            return;
        }

        $capacity = max(1, $capacity);
        $columns = max(2, min(4, $columns));
        $existing = db_select_all(
            'SELECT seat_id, seat_number FROM seats WHERE bus_id = ? ORDER BY seat_number ASC',
            'i',
            [$busId]
        );

        $existingByNumber = [];
        foreach ($existing as $seat) {
            $existingByNumber[(int) $seat['seat_number']] = (int) $seat['seat_id'];
        }

        for ($seatNumber = 1; $seatNumber <= $capacity; $seatNumber++) {
            $seatRow = (int) ceil($seatNumber / $columns);
            $seatColumn = (($seatNumber - 1) % $columns) + 1;
            $seatLabel = 'S' . str_pad((string) $seatNumber, 2, '0', STR_PAD_LEFT);

            if (isset($existingByNumber[$seatNumber])) {
                db_execute(
                    'UPDATE seats SET seat_label = ?, seat_row = ?, seat_column = ?, is_active = 1 WHERE seat_id = ?',
                    'siii',
                    [$seatLabel, $seatRow, $seatColumn, $existingByNumber[$seatNumber]]
                );
            } else {
                db_execute(
                    'INSERT INTO seats (bus_id, seat_number, seat_label, seat_row, seat_column, is_active) VALUES (?, ?, ?, ?, ?, 1)',
                    'iisii',
                    [$busId, $seatNumber, $seatLabel, $seatRow, $seatColumn]
                );
            }
        }

        db_execute(
            'UPDATE seats SET is_active = 0 WHERE bus_id = ? AND seat_number > ?',
            'ii',
            [$busId, $capacity]
        );
    }
}

if (!function_exists('sync_all_bus_seats')) {
    function sync_all_bus_seats(): void
    {
        if (!table_exists('buses')) {
            return;
        }

        $buses = db_select_all('SELECT bus_id, total_seats, seat_map_columns FROM buses');

        foreach ($buses as $bus) {
            sync_bus_seats(
                (int) $bus['bus_id'],
                max(1, (int) ($bus['total_seats'] ?? 1)),
                (int) ($bus['seat_map_columns'] ?? 4)
            );
        }
    }
}

if (!function_exists('enforce_fixed_bus_capacity')) {
    function enforce_fixed_bus_capacity(): void
    {
        if (!table_exists('buses')) {
            return;
        }

        $capacity = fixed_bus_seat_capacity();
        db_execute(
            'UPDATE buses SET total_seats = ? WHERE total_seats <> ?',
            'ii',
            [$capacity, $capacity]
        );

        if (table_exists('bus_classes') && column_exists('bus_classes', 'capacity')) {
            db_execute(
                'UPDATE bus_classes SET capacity = ? WHERE capacity IS NULL OR capacity <> ?',
                'ii',
                [$capacity, $capacity]
            );
        }
    }
}

if (!function_exists('get_schedule_details')) {
    function get_schedule_details(int $scheduleId): ?array
    {
        return db_select_one(
            "SELECT s.*, b.bus_code, b.bus_name, b.bus_type, b.total_seats, b.seat_map_columns, bc.class_name,
                    bo.full_name AS operator_name,
                    t1.terminal_name AS origin_name, t2.terminal_name AS destination_name
             FROM schedules s
             JOIN buses b ON s.bus_id = b.bus_id
             LEFT JOIN bus_classes bc ON b.class_id = bc.class_id
             LEFT JOIN bus_operators bo ON s.operator_id = bo.operator_id
             JOIN routes r ON s.route_id = r.route_id
             JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
             JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
             WHERE s.schedule_id = ?
             LIMIT 1",
            'i',
            [$scheduleId]
        );
    }
}

if (!function_exists('count_schedule_bookings')) {
    function count_schedule_bookings(int $scheduleId): int
    {
        $row = db_select_one('SELECT COUNT(*) AS total FROM bookings WHERE schedule_id = ?', 'i', [$scheduleId]);
        return (int) ($row['total'] ?? 0);
    }
}

if (!function_exists('schedule_has_bookings')) {
    function schedule_has_bookings(int $scheduleId): bool
    {
        return count_schedule_bookings($scheduleId) > 0;
    }
}

if (!function_exists('schedule_duplicate_exists')) {
    /**
     * A route may have more than one departure per day, but it must not have
     * two departures at the exact same time. This also prevents a manual
     * schedule from duplicating an occurrence created by a recurring rule.
     */
    function schedule_duplicate_exists(int $routeId, string $departureDate, string $departureTime, int $excludeScheduleId = 0): bool
    {
        if ($routeId < 1 || trim($departureDate) === '' || trim($departureTime) === '') {
            return false;
        }

        return db_select_one(
            'SELECT schedule_id
             FROM schedules
             WHERE route_id = ?
               AND departure_date = ?
               AND departure_time = ?
               AND schedule_id <> ?
             LIMIT 1',
            'issi',
            [$routeId, $departureDate, $departureTime, $excludeScheduleId]
        ) !== null;
    }
}

if (!function_exists('create_schedule_recurrence')) {
    function create_schedule_recurrence(
        int $routeId,
        int $busId,
        int $operatorId,
        string $busType,
        string $departureDate,
        string $departureTime,
        string $arrivalTime,
        float $price,
        int $createdBy = 0
    ): int {
        $created = db_execute(
            'INSERT INTO schedule_recurrences
                (route_id, bus_id, operator_id, bus_type, departure_time, arrival_time, start_date, price, is_active, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
            'iiissssdi',
            [
                $routeId,
                $busId,
                $operatorId,
                $busType,
                $departureTime,
                $arrivalTime,
                $departureDate,
                $price,
                $createdBy > 0 ? $createdBy : null,
            ]
        );

        return $created ? db_last_insert_id() : 0;
    }
}

if (!function_exists('materialize_schedule_recurrence')) {
    /**
     * Keep an active daily recurrence populated through the last bookable
     * date. A skipped date is retried on the next housekeeping run, so a bus
     * released from a conflicting trip becomes available automatically.
     *
     * @return array{created:int, skipped_duplicate:int, skipped_conflict:int}
     */
    function materialize_schedule_recurrence(int $recurrenceId): array
    {
        $summary = ['created' => 0, 'skipped_duplicate' => 0, 'skipped_conflict' => 0];
        if ($recurrenceId < 1 || !table_exists('schedule_recurrences')) {
            return $summary;
        }

        $rule = db_select_one(
            'SELECT sr.*, b.status AS bus_status, b.is_enabled AS bus_enabled,
                    bo.status AS operator_status, r.route_id AS valid_route_id
             FROM schedule_recurrences sr
             LEFT JOIN buses b ON sr.bus_id = b.bus_id
             LEFT JOIN bus_operators bo ON sr.operator_id = bo.operator_id
             LEFT JOIN routes r ON sr.route_id = r.route_id
             WHERE sr.recurrence_id = ? AND sr.is_active = 1
             LIMIT 1',
            'i',
            [$recurrenceId]
        );

        if (
            !$rule
            || (int) ($rule['valid_route_id'] ?? 0) < 1
            || ($rule['bus_status'] ?? '') !== 'active'
            || (int) ($rule['bus_enabled'] ?? 0) !== 1
            || ((int) ($rule['operator_id'] ?? 0) > 0 && ($rule['operator_status'] ?? '') !== 'active')
        ) {
            return $summary;
        }

        try {
            $today = new DateTimeImmutable('today', app_timezone());
            $startDate = new DateTimeImmutable((string) $rule['start_date'], app_timezone());
            $horizon = new DateTimeImmutable(max_advance_booking_date(), app_timezone());
        } catch (Throwable $exception) {
            return $summary;
        }

        $candidate = $startDate > $today ? $startDate : $today;
        $now = time();

        while ($candidate <= $horizon) {
            $departureDate = $candidate->format('Y-m-d');
            $departureTime = (string) $rule['departure_time'];
            $arrivalTime = (string) $rule['arrival_time'];

            // Do not create a trip that has already departed earlier today.
            $departureAt = departure_timestamp($departureDate, $departureTime);
            if ($departureAt !== null && $departureAt > $now) {
                if (schedule_duplicate_exists((int) $rule['route_id'], $departureDate, $departureTime)) {
                    $summary['skipped_duplicate']++;
                } elseif (
                    bus_has_schedule_conflict((int) $rule['bus_id'], $departureDate, $departureTime, $arrivalTime)
                    || operator_has_schedule_conflict((int) $rule['operator_id'], $departureDate, $departureTime, $arrivalTime)
                ) {
                    $summary['skipped_conflict']++;
                } else {
                    $created = db_execute(
                        'INSERT INTO schedules
                            (schedule_code, bus_id, route_id, operator_id, bus_type, is_auto_assigned, recurrence_id, is_recurring_generated,
                             departure_time, arrival_time, departure_date, price, available_seats, status, trip_status)
                         VALUES (?, ?, ?, ?, ?, 0, ?, 1, ?, ?, ?, ?, ?, "scheduled", "scheduled")',
                        'siiisisssdi',
                        [
                            generate_reference('SCH', 6),
                            (int) $rule['bus_id'],
                            (int) $rule['route_id'],
                            (int) $rule['operator_id'],
                            (string) $rule['bus_type'],
                            $recurrenceId,
                            $departureTime,
                            $arrivalTime,
                            $departureDate,
                            (float) $rule['price'],
                            fixed_bus_seat_capacity(),
                        ]
                    );

                    if ($created) {
                        sync_schedule_available_seats(db_last_insert_id());
                        $summary['created']++;
                    }
                }
            }

            $candidate = $candidate->modify('+1 day');
        }

        return $summary;
    }
}

if (!function_exists('materialize_active_schedule_recurrences')) {
    function materialize_active_schedule_recurrences(): array
    {
        $summary = ['created' => 0, 'skipped_duplicate' => 0, 'skipped_conflict' => 0];
        if (!table_exists('schedule_recurrences')) {
            return $summary;
        }

        $rules = db_select_all('SELECT recurrence_id FROM schedule_recurrences WHERE is_active = 1');
        foreach ($rules as $rule) {
            $result = materialize_schedule_recurrence((int) ($rule['recurrence_id'] ?? 0));
            foreach ($summary as $key => $value) {
                $summary[$key] += (int) ($result[$key] ?? 0);
            }
        }

        return $summary;
    }
}

if (!function_exists('departure_timestamp')) {
    function departure_timestamp(?string $departureDate, ?string $departureTime): ?int
    {
        $departureDate = trim((string) $departureDate);
        $departureTime = trim((string) $departureTime);

        if ($departureDate === '' || $departureTime === '') {
            return null;
        }

        try {
            $timestamp = (new DateTimeImmutable($departureDate . ' ' . $departureTime, app_timezone()))->getTimestamp();
        } catch (Throwable $exception) {
            return null;
        }

        return $timestamp;
    }
}

if (!function_exists('arrival_timestamp')) {
    function arrival_timestamp(?string $departureDate, ?string $departureTime, ?string $arrivalTime): ?int
    {
        $departureDate = trim((string) $departureDate);
        $departureTime = trim((string) $departureTime);
        $arrivalTime = trim((string) $arrivalTime);

        if ($departureDate === '' || $departureTime === '' || $arrivalTime === '') {
            return null;
        }

        try {
            [, $end] = schedule_window($departureDate, $departureTime, $arrivalTime);
        } catch (Throwable $exception) {
            return null;
        }

        return $end->getTimestamp();
    }
}

if (!function_exists('max_advance_booking_date')) {
    function max_advance_booking_date(): string
    {
        return date('Y-m-d', strtotime('+' . MAX_ADVANCE_BOOKING_DAYS . ' days'));
    }
}

if (!function_exists('booking_date_within_allowed_window')) {
    function booking_date_within_allowed_window(?string $travelDate): bool
    {
        $travelDate = trim((string) $travelDate);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $travelDate)) {
            return false;
        }

        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $travelDate, app_timezone());
        $errors = DateTimeImmutable::getLastErrors();
        if ($date === false || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
            return false;
        }

        $today = date('Y-m-d');
        $maxDate = max_advance_booking_date();

        return $travelDate >= $today && $travelDate <= $maxDate;
    }
}

if (!function_exists('booking_is_missed_paid_trip')) {
    function booking_is_missed_paid_trip(array $booking): bool
    {
        if (($booking['payment_status'] ?? '') !== 'paid') {
            return false;
        }

        if ((string) ($booking['status'] ?? '') === 'used') {
            return false;
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );

        if ($departureTimestamp === null || $departureTimestamp > time()) {
            return false;
        }

        if (array_key_exists('used_ticket_count', $booking)) {
            return (int) $booking['used_ticket_count'] === 0;
        }

        if (!empty($booking['booking_id']) && table_exists('tickets')) {
            $usedRow = db_select_one(
                'SELECT COUNT(*) AS total FROM tickets WHERE booking_id = ? AND ticket_status = "used"',
                'i',
                [(int) $booking['booking_id']]
            );

            return (int) ($usedRow['total'] ?? 0) === 0;
        }

        return true;
    }
}

if (!function_exists('booking_history_is_clearable')) {
    function booking_history_is_clearable(array $booking): bool
    {
        $status = (string) ($booking['status'] ?? '');
        if (in_array($status, ['cancelled', 'expired', 'used'], true)) {
            return true;
        }

        if (booking_is_missed_paid_trip($booking)) {
            return true;
        }

        if (($booking['payment_status'] ?? '') === 'paid' || $status === 'confirmed') {
            return false;
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );

        return $departureTimestamp !== null && $departureTimestamp <= time();
    }
}

if (!function_exists('booking_user_cancellation_state')) {
    function booking_user_cancellation_state(array $booking, ?int $referenceTimestamp = null): array
    {
        $referenceTimestamp = $referenceTimestamp ?? time();
        $status = strtolower(trim((string) ($booking['status'] ?? '')));
        $scheduleStatus = strtolower(trim((string) ($booking['schedule_status'] ?? 'scheduled')));
        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        $missedPaidTrip = booking_is_missed_paid_trip($booking);
        $activeBooking = in_array($status, ['pending', 'payment_review', 'confirmed'], true);

        if ($missedPaidTrip) {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => false,
                'message' => 'This trip already departed and can no longer be cancelled online.',
                'deadline_timestamp' => $departureTimestamp,
            ];
        }

        if (in_array($status, ['cancelled', 'expired', 'used'], true)) {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => false,
                'message' => 'This booking can no longer be cancelled.',
                'deadline_timestamp' => $departureTimestamp,
            ];
        }

        if ($scheduleStatus === 'cancelled') {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => false,
                'message' => 'This trip is already marked cancelled.',
                'deadline_timestamp' => $departureTimestamp,
            ];
        }

        if (!$activeBooking) {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => false,
                'message' => 'This booking is not in a cancellable status.',
                'deadline_timestamp' => $departureTimestamp,
            ];
        }

        if ($departureTimestamp === null) {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => true,
                'message' => 'Trip timing is unavailable. Please contact terminal staff for assistance.',
                'deadline_timestamp' => null,
            ];
        }

        if ($departureTimestamp <= $referenceTimestamp) {
            return [
                'can_cancel' => false,
                'needs_staff_assistance' => true,
                'message' => 'This trip has already started and can no longer be cancelled online. Please coordinate with terminal staff for manual assistance or a seat change request.',
                'deadline_timestamp' => $departureTimestamp,
            ];
        }

        return [
            'can_cancel' => true,
            'needs_staff_assistance' => false,
            'message' => 'Online cancellation stays available until departure time.',
            'deadline_timestamp' => $departureTimestamp,
        ];
    }
}

if (!function_exists('booking_live_countdown_context')) {
    function booking_live_countdown_context(array $booking, ?int $referenceTimestamp = null): array
    {
        $referenceTimestamp = $referenceTimestamp ?? time();
        $status = strtolower(trim((string) ($booking['status'] ?? '')));
        $scheduleStatus = strtolower(trim((string) ($booking['schedule_status'] ?? 'scheduled')));
        $paymentMethod = strtolower(trim((string) ($booking['payment_method'] ?? '')));
        $paymentStatus = strtolower(trim((string) ($booking['payment_status'] ?? '')));
        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        $arrivalTimestamp = arrival_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? ''),
            (string) ($booking['arrival_time'] ?? '')
        );
        $missedPaidTrip = booking_is_missed_paid_trip($booking);
        $effectiveTripStatus = effective_schedule_trip_status([
            'status' => $scheduleStatus,
            'departure_date' => (string) ($booking['departure_date'] ?? ''),
            'departure_time' => (string) ($booking['departure_time'] ?? ''),
            'arrival_time' => (string) ($booking['arrival_time'] ?? ''),
        ]);
        $effectiveScheduleStatus = effective_schedule_status([
            'status' => $scheduleStatus,
            'departure_date' => (string) ($booking['departure_date'] ?? ''),
            'departure_time' => (string) ($booking['departure_time'] ?? ''),
            'arrival_time' => (string) ($booking['arrival_time'] ?? ''),
        ]);

        $context = [
            'is_live' => false,
            'target_timestamp' => null,
            'label' => '',
            'note' => '',
            'expired_label' => '',
            'departure_timestamp' => $departureTimestamp,
            'arrival_timestamp' => $arrivalTimestamp,
            'effective_trip_status' => $effectiveTripStatus,
            'effective_schedule_status' => $effectiveScheduleStatus,
        ];

        if ($scheduleStatus === 'cancelled' || $status === 'cancelled') {
            $context['note'] = 'This booking is cancelled.';
            $context['expired_label'] = 'Cancelled';
            return $context;
        }

        if ($status === 'expired') {
            $context['note'] = 'This booking expired before payment was completed.';
            $context['expired_label'] = 'Expired';
            return $context;
        }

        if ($status === 'used') {
            $context['note'] = 'This trip was already used for boarding.';
            $context['expired_label'] = 'Boarded';
            return $context;
        }

        if ($missedPaidTrip) {
            $context['note'] = 'This paid trip already departed and now requires staff assistance for any exception handling.';
            $context['expired_label'] = 'Departed';
            return $context;
        }

        if ($departureTimestamp !== null && $referenceTimestamp < $departureTimestamp) {
            $context['is_live'] = true;
            $context['target_timestamp'] = $departureTimestamp;
            $context['label'] = ($paymentMethod === 'cash' && $paymentStatus !== 'paid')
                ? 'Terminal payment closes in'
                : 'Trip departs in';
            $context['note'] = ($paymentMethod === 'cash' && $paymentStatus !== 'paid')
                ? 'Present your booking to terminal staff before departure to finish payment and issue the final ticket.'
                : 'Online cancellation stays available until departure time.';
            $context['expired_label'] = 'Departing now';
            return $context;
        }

        if ($arrivalTimestamp !== null && $referenceTimestamp < $arrivalTimestamp) {
            $context['is_live'] = true;
            $context['target_timestamp'] = $arrivalTimestamp;
            $context['label'] = 'Estimated arrival in';
            $context['note'] = 'This trip is already in progress.';
            $context['expired_label'] = 'Arriving now';
            return $context;
        }

        $context['note'] = $effectiveTripStatus === 'arrived'
            ? 'This trip has reached its scheduled arrival time.'
            : 'No live countdown is available for this booking right now.';
        $context['expired_label'] = $effectiveTripStatus === 'arrived' ? 'Arrived' : 'Closed';

        return $context;
    }
}

if (!function_exists('calculate_cash_claim_window_minutes')) {
    function calculate_cash_claim_window_minutes(?string $departureDate, ?string $departureTime): int
    {
        $departureTimestamp = departure_timestamp($departureDate, $departureTime);
        if ($departureTimestamp === null) {
            return 0;
        }

        $minutesUntilDeparture = (int) floor(($departureTimestamp - time()) / 60);
        if ($minutesUntilDeparture <= 0) {
            return 0;
        }

        return $minutesUntilDeparture > 240 ? 60 : 30;
    }
}

if (!function_exists('calculate_cash_claim_deadline')) {
    function calculate_cash_claim_deadline(?string $departureDate, ?string $departureTime): ?string
    {
        $departureTimestamp = departure_timestamp($departureDate, $departureTime);
        if ($departureTimestamp === null || $departureTimestamp <= time()) {
            return null;
        }

        $windowMinutes = calculate_cash_claim_window_minutes($departureDate, $departureTime);
        if ($windowMinutes < 1) {
            return null;
        }

        $deadlineTimestamp = min(time() + ($windowMinutes * 60), $departureTimestamp);

        return date('Y-m-d H:i:s', $deadlineTimestamp);
    }
}

if (!function_exists('get_schedule_seat_map')) {
    function get_schedule_seat_map(int $scheduleId): array
    {
        $schedule = get_schedule_details($scheduleId);
        if (!$schedule) {
            return [];
        }

        sync_bus_seats(
            (int) $schedule['bus_id'],
            max(1, (int) $schedule['total_seats']),
            (int) ($schedule['seat_map_columns'] ?? 4)
        );

        $seats = db_select_all(
            'SELECT seat_id, seat_number, seat_label, seat_row, seat_column
             FROM seats
             WHERE bus_id = ? AND is_active = 1
             ORDER BY seat_number ASC',
            'i',
            [(int) $schedule['bus_id']]
        );

        $tickets = db_select_all(
            "SELECT t.ticket_id, t.seat_id, t.booking_id, t.ticket_status, t.ticket_code,
                    b.booking_reference, b.status AS booking_status, b.payment_status,
                    p.fullname AS passenger_name
             FROM tickets t
             JOIN bookings b ON t.booking_id = b.booking_id
             LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
             WHERE t.schedule_id = ?",
            'i',
            [$scheduleId]
        );

        $ticketBySeat = [];
        foreach ($tickets as $ticket) {
            $ticketBySeat[(int) $ticket['seat_id']] = $ticket;
        }

        $seatMap = [];
        foreach ($seats as $seat) {
            $seatId = (int) $seat['seat_id'];
            $status = 'available';
            $meta = [
                'booking_reference' => '',
                'passenger_name' => '',
                'ticket_code' => '',
            ];

            if (isset($ticketBySeat[$seatId])) {
                $ticket = $ticketBySeat[$seatId];
                $ticketStatus = $ticket['ticket_status'] ?? 'reserved';
                $bookingStatus = $ticket['booking_status'] ?? 'pending';

                if ($ticketStatus === 'used') {
                    $status = 'used';
                } elseif (in_array($bookingStatus, ['confirmed', 'used'], true) || $ticketStatus === 'issued') {
                    $status = 'booked';
                } else {
                    $status = 'reserved';
                }

                $meta = [
                    'booking_reference' => $ticket['booking_reference'] ?? '',
                    'passenger_name' => $ticket['passenger_name'] ?? '',
                    'ticket_code' => $ticket['ticket_code'] ?? '',
                ];
            }

            $seatMap[] = [
                'seat_id' => $seatId,
                'seat_number' => (int) $seat['seat_number'],
                'seat_label' => $seat['seat_label'],
                'seat_row' => (int) $seat['seat_row'],
                'seat_column' => (int) $seat['seat_column'],
                'status' => $status,
                'meta' => $meta,
            ];
        }

        return $seatMap;
    }
}

if (!function_exists('count_available_schedule_seats')) {
    function count_available_schedule_seats(int $scheduleId): int
    {
        $available = 0;
        foreach (get_schedule_seat_map($scheduleId) as $seat) {
            if (($seat['status'] ?? '') === 'available') {
                $available++;
            }
        }

        return $available;
    }
}

if (!function_exists('sync_schedule_available_seats')) {
    function sync_schedule_available_seats(int $scheduleId): void
    {
        db_execute(
            'UPDATE schedules SET available_seats = ? WHERE schedule_id = ?',
            'ii',
            [count_available_schedule_seats($scheduleId), $scheduleId]
        );
    }
}

if (!function_exists('sync_all_schedule_available_seats')) {
    function sync_all_schedule_available_seats(): void
    {
        if (!table_exists('schedules')) {
            return;
        }

        $schedules = db_select_all('SELECT schedule_id FROM schedules');

        foreach ($schedules as $schedule) {
            sync_schedule_available_seats((int) ($schedule['schedule_id'] ?? 0));
        }
    }
}

if (!function_exists('build_in_clause')) {
    function build_in_clause(array $values): array
    {
        return [
            implode(', ', array_fill(0, count($values), '?')),
            str_repeat('i', count($values)),
        ];
    }
}

if (!function_exists('encode_booking_seat_preferences')) {
    function encode_booking_seat_preferences(array $seatLabels): string
    {
        $cleaned = [];

        foreach ($seatLabels as $seatLabel) {
            $seatLabel = trim((string) $seatLabel);
            if ($seatLabel === '') {
                continue;
            }

            $cleaned[] = $seatLabel;
        }

        return json_encode(array_values($cleaned), JSON_UNESCAPED_SLASHES) ?: '[]';
    }
}

if (!function_exists('decode_booking_seat_preferences')) {
    function decode_booking_seat_preferences($rawSeatPreferences): array
    {
        if (is_array($rawSeatPreferences)) {
            $decoded = $rawSeatPreferences;
        } else {
            $rawSeatPreferences = trim((string) $rawSeatPreferences);
            if ($rawSeatPreferences === '') {
                return [];
            }

            $decoded = json_decode($rawSeatPreferences, true);
            if (!is_array($decoded)) {
                $decoded = preg_split('/\s*,\s*/', $rawSeatPreferences) ?: [];
            }
        }

        $seatLabels = [];
        foreach ($decoded as $seatPreference) {
            if (is_array($seatPreference)) {
                $seatPreference = $seatPreference['seat_label'] ?? $seatPreference['label'] ?? '';
            }

            $seatLabel = trim((string) $seatPreference);
            if ($seatLabel === '') {
                continue;
            }

            $seatLabels[] = $seatLabel;
        }

        return array_values($seatLabels);
    }
}

if (!function_exists('get_booking_seat_manifest')) {
    function get_booking_seat_manifest(int $bookingId): array
    {
        $tickets = db_select_all(
            'SELECT t.ticket_id, t.seat_id, s.seat_label
             FROM tickets t
             JOIN seats s ON t.seat_id = s.seat_id
             WHERE t.booking_id = ?
             ORDER BY s.seat_number ASC',
            'i',
            [$bookingId]
        );

        if ($tickets !== []) {
            return $tickets;
        }

        $passengerSeats = db_select_all(
            'SELECT seat_number
             FROM passengers
             WHERE booking_id = ?
             AND seat_number IS NOT NULL
             AND seat_number <> ""
             ORDER BY passenger_id ASC',
            'i',
            [$bookingId]
        );

        if ($passengerSeats !== []) {
            return array_map(
                static fn($row) => [
                    'ticket_id' => null,
                    'seat_id' => null,
                    'seat_label' => (string) $row['seat_number'],
                ],
                $passengerSeats
            );
        }

        $booking = db_select_one(
            'SELECT seat_preferences FROM bookings WHERE booking_id = ? LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return [];
        }

        return array_map(
            static fn($seatLabel) => [
                'ticket_id' => null,
                'seat_id' => null,
                'seat_label' => $seatLabel,
            ],
            decode_booking_seat_preferences($booking['seat_preferences'] ?? '')
        );
    }
}

if (!function_exists('lock_booking_seats')) {
    function lock_booking_seats(int $bookingId, int $scheduleId, array $seatIds): array
    {
        global $conn;

        $seatIds = array_values(array_unique(array_map('intval', $seatIds)));
        if ($bookingId < 1 || $scheduleId < 1 || $seatIds === []) {
            return ['ok' => false, 'message' => 'Please select at least one seat.'];
        }

        $schedule = get_schedule_details($scheduleId);
        if (!$schedule) {
            return ['ok' => false, 'message' => 'The selected trip is no longer available.'];
        }

        sync_bus_seats(
            (int) $schedule['bus_id'],
            max(1, (int) $schedule['total_seats']),
            (int) ($schedule['seat_map_columns'] ?? 4)
        );

        [$placeholders, $types] = build_in_clause($seatIds);
        $seatRows = db_select_all(
            "SELECT seat_id, seat_label
             FROM seats
             WHERE bus_id = ?
             AND is_active = 1
             AND seat_id IN ($placeholders)
             ORDER BY seat_number ASC",
            'i' . $types,
            array_merge([(int) $schedule['bus_id']], $seatIds)
        );

        if (count($seatRows) !== count($seatIds)) {
            return ['ok' => false, 'message' => 'One or more selected seats are invalid.'];
        }

        $conn->begin_transaction();

        try {
            $conflicts = db_select_all(
                "SELECT ticket_id, seat_id
                 FROM tickets
                 WHERE schedule_id = ?
                 AND booking_id <> ?
                 AND seat_id IN ($placeholders)
                 FOR UPDATE",
                'ii' . $types,
                array_merge([$scheduleId, $bookingId], $seatIds)
            );

            if ($conflicts !== []) {
                throw new RuntimeException('One or more seats were just reserved by another passenger. Please choose again.');
            }

            db_execute('DELETE FROM tickets WHERE booking_id = ?', 'i', [$bookingId]);

            foreach ($seatRows as $seatRow) {
                if (!db_execute(
                    'INSERT INTO tickets (booking_id, schedule_id, seat_id, ticket_status) VALUES (?, ?, ?, "reserved")',
                    'iii',
                    [$bookingId, $scheduleId, (int) $seatRow['seat_id']]
                )) {
                    throw new RuntimeException('Unable to lock the selected seats.');
                }
            }

            sync_schedule_available_seats($scheduleId);
            $conn->commit();

            return ['ok' => true, 'message' => 'Seats locked successfully.'];
        } catch (Throwable $exception) {
            $conn->rollback();

            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('attach_passengers_to_booking')) {
    function attach_passengers_to_booking(int $bookingId, array $passengers): array
    {
        global $conn;

        $booking = db_select_one(
            'SELECT booking_id, user_id, payment_method, schedule_id, seat_preferences
             FROM bookings
             WHERE booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }

        $seatManifest = get_booking_seat_manifest($bookingId);

        if ($seatManifest === [] || count($seatManifest) !== count($passengers)) {
            return ['ok' => false, 'message' => 'Selected seats do not match the passenger count.'];
        }

        $conn->begin_transaction();

        try {
            db_execute('DELETE FROM passengers WHERE booking_id = ?', 'i', [$bookingId]);

            foreach ($passengers as $index => $passenger) {
                $seatSlot = $seatManifest[$index];
                $fullname = trim((string) ($passenger['fullname'] ?? ''));
                $email = normalize_gmail_email((string) ($passenger['email'] ?? ''));
                $phone = normalize_ph_phone((string) ($passenger['phone'] ?? ''));

                if ($fullname === '') {
                    throw new RuntimeException('Please enter the passenger name for every seat.');
                }

                if ($email !== '' && !is_valid_gmail_email($email)) {
                    throw new RuntimeException('Please enter a valid email address for each passenger or leave it blank.');
                }

                if ($phone !== '' && !is_valid_ph_phone($phone)) {
                    throw new RuntimeException('Please use a valid Philippine mobile number such as 09171234567 or +639171234567 for each passenger or leave it blank.');
                }

                $stmt = $conn->prepare(
                    'INSERT INTO passengers (booking_id, fullname, email, phone, seat_number, age, gender)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );

                if (!$stmt) {
                    throw new RuntimeException('Unable to save passenger details.');
                }

                $age = array_key_exists('age', $passenger) && $passenger['age'] !== null ? (int) $passenger['age'] : null;
                $email = $email !== '' ? $email : null;
                $phone = $phone !== '' ? $phone : null;
                $seatLabel = (string) $seatSlot['seat_label'];
                $gender = in_array((string) ($passenger['gender'] ?? 'M'), ['M', 'F'], true) ? (string) $passenger['gender'] : 'M';

                $stmt->bind_param(
                    'issssis',
                    $bookingId,
                    $fullname,
                    $email,
                    $phone,
                    $seatLabel,
                    $age,
                    $gender
                );

                if (!$stmt->execute()) {
                    $stmt->close();
                    throw new RuntimeException('Unable to save passenger details.');
                }

                $passengerId = (int) $stmt->insert_id;
                $stmt->close();

                if (!empty($seatSlot['ticket_id']) && !db_execute(
                    'UPDATE tickets SET passenger_id = ? WHERE ticket_id = ?',
                    'ii',
                    [$passengerId, (int) $seatSlot['ticket_id']]
                )) {
                    throw new RuntimeException('Unable to link passengers to seats.');
                }
            }

            db_execute(
                'UPDATE bookings SET status = "pending", updated_at = NOW() WHERE booking_id = ?',
                'i',
                [$bookingId]
            );

            create_notification(
                (int) $booking['user_id'],
                'booking',
                'Passenger details saved',
                $booking['payment_method'] === 'cash'
                    ? 'Passenger details were saved. Final seat assignment and ticket issuance will happen after terminal payment is confirmed.'
                    : 'Passenger details were saved. Your GCash seat preference will only be locked after payment approval.',
                $bookingId
            );

            $conn->commit();

            return ['ok' => true, 'message' => 'Passenger details saved successfully.'];
        } catch (Throwable $exception) {
            $conn->rollback();

            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('create_booking_tickets_from_preferences')) {
    function create_booking_tickets_from_preferences(int $bookingId): bool
    {
        $booking = db_select_one(
            'SELECT b.booking_id, b.schedule_id, b.seat_preferences,
                    s.bus_id, bus.total_seats, bus.seat_map_columns
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             JOIN buses bus ON s.bus_id = bus.bus_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return false;
        }

        $existingTickets = db_select_one(
            'SELECT COUNT(*) AS total FROM tickets WHERE booking_id = ?',
            'i',
            [$bookingId]
        );

        if ((int) ($existingTickets['total'] ?? 0) > 0) {
            return true;
        }

        $passengers = db_select_all(
            'SELECT passenger_id, seat_number
             FROM passengers
             WHERE booking_id = ?
             ORDER BY passenger_id ASC',
            'i',
            [$bookingId]
        );

        if ($passengers === []) {
            return false;
        }

        sync_bus_seats(
            (int) $booking['bus_id'],
            max(1, (int) $booking['total_seats']),
            (int) ($booking['seat_map_columns'] ?? 4)
        );

        $allSeats = db_select_all(
            'SELECT seat_id, seat_label, seat_number
             FROM seats
             WHERE bus_id = ?
             AND is_active = 1
             ORDER BY seat_number ASC',
            'i',
            [(int) $booking['bus_id']]
        );

        if ($allSeats === []) {
            return false;
        }

        $occupiedRows = db_select_all(
            'SELECT seat_id
             FROM tickets
             WHERE schedule_id = ?
             AND booking_id <> ?',
            'ii',
            [(int) $booking['schedule_id'], $bookingId]
        );

        $occupiedSeatIds = [];
        foreach ($occupiedRows as $occupiedRow) {
            $occupiedSeatIds[(int) $occupiedRow['seat_id']] = true;
        }

        $availableSeats = [];
        $availableByLabel = [];
        foreach ($allSeats as $seatRow) {
            $seatId = (int) $seatRow['seat_id'];
            if (isset($occupiedSeatIds[$seatId])) {
                continue;
            }

            $availableSeats[] = $seatRow;
            $availableByLabel[(string) $seatRow['seat_label']] = $seatRow;
        }

        if (count($availableSeats) < count($passengers)) {
            return false;
        }

        $assignedSeatIds = [];
        $finalSeatLabels = [];

        foreach ($passengers as $passenger) {
            $preferredSeatLabel = trim((string) ($passenger['seat_number'] ?? ''));
            $chosenSeat = null;

            if ($preferredSeatLabel !== '' && isset($availableByLabel[$preferredSeatLabel])) {
                $candidateSeat = $availableByLabel[$preferredSeatLabel];
                if (!isset($assignedSeatIds[(int) $candidateSeat['seat_id']])) {
                    $chosenSeat = $candidateSeat;
                }
            }

            if ($chosenSeat === null) {
                foreach ($availableSeats as $candidateSeat) {
                    if (!isset($assignedSeatIds[(int) $candidateSeat['seat_id']])) {
                        $chosenSeat = $candidateSeat;
                        break;
                    }
                }
            }

            if ($chosenSeat === null) {
                return false;
            }

            if (!db_execute(
                'INSERT INTO tickets (booking_id, passenger_id, schedule_id, seat_id, ticket_status)
                 VALUES (?, ?, ?, ?, "reserved")',
                'iiii',
                [$bookingId, (int) $passenger['passenger_id'], (int) $booking['schedule_id'], (int) $chosenSeat['seat_id']]
            )) {
                return false;
            }

            $assignedSeatIds[(int) $chosenSeat['seat_id']] = true;
            $finalSeatLabels[] = (string) $chosenSeat['seat_label'];

            if ($preferredSeatLabel !== (string) $chosenSeat['seat_label']) {
                db_execute(
                    'UPDATE passengers SET seat_number = ? WHERE passenger_id = ?',
                    'si',
                    [(string) $chosenSeat['seat_label'], (int) $passenger['passenger_id']]
                );
            }
        }

        db_execute(
            'UPDATE bookings SET seat_preferences = ?, updated_at = NOW() WHERE booking_id = ?',
            'si',
            [encode_booking_seat_preferences($finalSeatLabels), $bookingId]
        );

        sync_schedule_available_seats((int) $booking['schedule_id']);

        return true;
    }
}

if (!function_exists('change_booking_seats')) {
    function change_booking_seats(int $bookingId, array $seatAssignments, int $actorUserId = 0): array
    {
        global $conn;

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.schedule_id, b.payment_method, b.payment_status, b.status,
                    s.departure_date, s.departure_time,
                    bus.bus_id, bus.total_seats, bus.seat_map_columns
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             JOIN buses bus ON s.bus_id = bus.bus_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }

        if (in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)) {
            return ['ok' => false, 'message' => 'Seats can only be changed on active bookings.'];
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        if ($departureTimestamp !== null && $departureTimestamp <= time()) {
            return ['ok' => false, 'message' => 'This trip already left. Seat changes are no longer allowed.'];
        }

        $passengers = db_select_all(
            'SELECT passenger_id, fullname, seat_number
             FROM passengers
             WHERE booking_id = ?
             ORDER BY passenger_id ASC',
            'i',
            [$bookingId]
        );

        if ($passengers === []) {
            return ['ok' => false, 'message' => 'Passenger details must be completed before seats can be changed.'];
        }

        sync_bus_seats(
            (int) $booking['bus_id'],
            max(1, (int) $booking['total_seats']),
            (int) ($booking['seat_map_columns'] ?? 4)
        );

        $seatRows = db_select_all(
            'SELECT seat_id, seat_label, seat_number
             FROM seats
             WHERE bus_id = ?
             AND is_active = 1
             ORDER BY seat_number ASC',
            'i',
            [(int) $booking['bus_id']]
        );

        if ($seatRows === []) {
            return ['ok' => false, 'message' => 'Seat records are not available for this bus.'];
        }

        $seatByLabel = [];
        foreach ($seatRows as $seatRow) {
            $label = strtoupper(trim((string) ($seatRow['seat_label'] ?? '')));
            if ($label === '') {
                continue;
            }

            $seatByLabel[$label] = [
                'seat_id' => (int) $seatRow['seat_id'],
                'seat_label' => (string) $seatRow['seat_label'],
            ];
        }

        $normalizedAssignments = [];
        $selectedSeatIds = [];

        foreach ($passengers as $passenger) {
            $passengerId = (int) $passenger['passenger_id'];
            $requestedLabel = strtoupper(trim((string) ($seatAssignments[$passengerId] ?? '')));

            if ($requestedLabel === '') {
                return ['ok' => false, 'message' => 'Please choose a seat for every passenger.'];
            }

            if (!isset($seatByLabel[$requestedLabel])) {
                return ['ok' => false, 'message' => 'One of the selected seats is no longer valid.'];
            }

            if (in_array($requestedLabel, $normalizedAssignments, true)) {
                return ['ok' => false, 'message' => 'Each passenger must have a different seat.'];
            }

            $normalizedAssignments[$passengerId] = $seatByLabel[$requestedLabel]['seat_label'];
            $selectedSeatIds[] = (int) $seatByLabel[$requestedLabel]['seat_id'];
        }

        $ticketRows = db_select_all(
            'SELECT ticket_id, passenger_id, seat_id
             FROM tickets
             WHERE booking_id = ?
             ORDER BY ticket_id ASC',
            'i',
            [$bookingId]
        );

        if ($ticketRows !== [] && count($ticketRows) !== count($passengers)) {
            return ['ok' => false, 'message' => 'This booking has incomplete ticket records. Please review it before changing seats.'];
        }

        $conn->begin_transaction();

        try {
            [$placeholders, $types] = build_in_clause($selectedSeatIds);
            $conflicts = db_select_all(
                "SELECT s.seat_label
                 FROM tickets t
                 JOIN seats s ON t.seat_id = s.seat_id
                 WHERE t.schedule_id = ?
                 AND t.booking_id <> ?
                 AND t.seat_id IN ($placeholders)
                 FOR UPDATE",
                'ii' . $types,
                array_merge([(int) $booking['schedule_id'], $bookingId], $selectedSeatIds)
            );

            if ($conflicts !== []) {
                throw new RuntimeException('Seat ' . (string) ($conflicts[0]['seat_label'] ?? 'selection') . ' is already occupied by another booking.');
            }

            $ticketByPassengerId = [];
            $remainingTickets = [];
            foreach ($ticketRows as $ticketRow) {
                $ticketPassengerId = (int) ($ticketRow['passenger_id'] ?? 0);
                if ($ticketPassengerId > 0) {
                    $ticketByPassengerId[$ticketPassengerId] = $ticketRow;
                } else {
                    $remainingTickets[] = $ticketRow;
                }
            }

            $finalSeatLabels = [];
            foreach ($passengers as $passenger) {
                $passengerId = (int) $passenger['passenger_id'];
                $seatLabel = (string) ($normalizedAssignments[$passengerId] ?? '');
                $seatKey = strtoupper($seatLabel);
                $seatId = (int) ($seatByLabel[$seatKey]['seat_id'] ?? 0);

                if ($seatId < 1) {
                    throw new RuntimeException('One of the selected seats is no longer available.');
                }

                if (!db_execute(
                    'UPDATE passengers SET seat_number = ? WHERE passenger_id = ?',
                    'si',
                    [$seatLabel, $passengerId]
                )) {
                    throw new RuntimeException('Unable to update the passenger seat assignment.');
                }

                if ($ticketRows !== []) {
                    $ticketRow = $ticketByPassengerId[$passengerId] ?? array_shift($remainingTickets);
                    if (!$ticketRow || !db_execute(
                        'UPDATE tickets SET passenger_id = ?, seat_id = ? WHERE ticket_id = ?',
                        'iii',
                        [$passengerId, $seatId, (int) $ticketRow['ticket_id']]
                    )) {
                        throw new RuntimeException('Unable to update the ticket seat assignment.');
                    }
                }

                $finalSeatLabels[] = $seatLabel;
            }

            if (!db_execute(
                'UPDATE bookings SET seat_preferences = ?, updated_at = NOW() WHERE booking_id = ?',
                'si',
                [encode_booking_seat_preferences($finalSeatLabels), $bookingId]
            )) {
                throw new RuntimeException('Unable to save the updated seat selection.');
            }

            sync_schedule_available_seats((int) $booking['schedule_id']);

            $actorName = '';
            if ($actorUserId > 0) {
                $actor = db_select_one(
                    'SELECT fullname FROM users WHERE user_id = ? LIMIT 1',
                    'i',
                    [$actorUserId]
                );
                $actorName = trim((string) ($actor['fullname'] ?? ''));
            }

            create_notification(
                (int) $booking['user_id'],
                'booking',
                'Seat assignment updated',
                ($actorName !== '' ? $actorName : 'Staff') . (
                    (($booking['payment_method'] ?? '') === 'cash' && ($booking['payment_status'] ?? '') !== 'paid')
                        ? ' updated your preferred seats. The final seat will still be locked once terminal payment is confirmed.'
                        : ' updated your seat assignment. Please review your latest booking details before travel.'
                ),
                $bookingId
            );

            $conn->commit();

            return [
                'ok' => true,
                'message' => (($booking['payment_method'] ?? '') === 'cash' && ($booking['payment_status'] ?? '') !== 'paid')
                    ? 'Preferred seats updated successfully. The booking will still wait for terminal payment before the final seat is locked.'
                    : 'Seat assignment updated successfully.',
            ];
        } catch (Throwable $exception) {
            $conn->rollback();

            return ['ok' => false, 'message' => $exception->getMessage() ?: 'Unable to change the seats right now.'];
        }
    }
}

if (!function_exists('build_ticket_payload')) {
    function build_ticket_payload(array $ticket): array
    {
        $payloadData = [
            'ticket_code' => $ticket['ticket_code'],
            'booking_reference' => $ticket['booking_reference'],
            'passenger_name' => $ticket['passenger_name'],
            'seat' => $ticket['seat_label'],
            'route' => $ticket['origin_name'] . ' to ' . $ticket['destination_name'],
            'departure_date' => $ticket['departure_date'],
            'departure_time' => $ticket['departure_time'],
        ];

        $payload = base64_encode(json_encode($payloadData, JSON_UNESCAPED_SLASHES));
        $signature = hash_hmac('sha256', $payload, APP_QR_SECRET);

        return [
            'payload' => $payload,
            'signature' => $signature,
            'qr_text' => json_encode([
                'payload' => $payload,
                'sig' => $signature,
            ], JSON_UNESCAPED_SLASHES),
        ];
    }
}

if (!function_exists('ensure_booking_claim_code')) {
    function ensure_booking_claim_code(int $bookingId, string $currentCode = ''): string
    {
        $currentCode = strtoupper(trim($currentCode));
        if ($bookingId < 1) {
            return '';
        }

        if ($currentCode !== '') {
            return $currentCode;
        }

        for ($attempt = 0; $attempt < 5; $attempt++) {
            $claimCode = generate_reference('CTK', 8);
            $existing = db_select_one(
                'SELECT booking_id FROM bookings WHERE claim_code = ? LIMIT 1',
                's',
                [$claimCode]
            );

            if ($existing) {
                continue;
            }

            if (!db_execute(
                'UPDATE bookings
                 SET claim_code = COALESCE(NULLIF(claim_code, ""), ?),
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'si',
                [$claimCode, $bookingId]
            )) {
                continue;
            }

            $booking = db_select_one(
                'SELECT claim_code FROM bookings WHERE booking_id = ? LIMIT 1',
                'i',
                [$bookingId]
            );

            $persistedCode = strtoupper(trim((string) ($booking['claim_code'] ?? '')));
            if ($persistedCode !== '') {
                return $persistedCode;
            }
        }

        return '';
    }
}

if (!function_exists('build_cash_claim_payload')) {
    function build_cash_claim_payload(array $booking): array
    {
        $claimCode = ensure_booking_claim_code(
            (int) ($booking['booking_id'] ?? 0),
            (string) ($booking['claim_code'] ?? '')
        );

        return [
            'claim_code' => $claimCode,
            'qr_text' => $claimCode,
        ];
    }
}

if (!function_exists('get_cash_claim_summary')) {
    function get_cash_claim_summary(int $bookingId): ?array
    {
        $booking = db_select_one(
            "SELECT b.booking_id, b.booking_reference, b.claim_code, b.status, b.payment_status, b.payment_method,
                    b.number_of_passengers, b.total_amount, b.seat_preferences, b.expires_at,
                    u.fullname AS account_name,
                    sch.departure_date, sch.departure_time,
                    origin.terminal_name AS origin_name,
                    destination.terminal_name AS destination_name
             FROM bookings b
             JOIN users u ON b.user_id = u.user_id
             JOIN schedules sch ON b.schedule_id = sch.schedule_id
             JOIN routes r ON sch.route_id = r.route_id
             JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
             JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
             WHERE b.booking_id = ?
             LIMIT 1",
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return null;
        }

        $booking['claim_code'] = ensure_booking_claim_code(
            (int) ($booking['booking_id'] ?? 0),
            (string) ($booking['claim_code'] ?? '')
        );
        $preferredSeats = decode_booking_seat_preferences($booking['seat_preferences'] ?? '');
        $booking['preferred_seats'] = implode(', ', $preferredSeats);
        $booking['preferred_seat_list'] = $preferredSeats;
        $booking['departure_label'] = !empty($booking['departure_date']) && !empty($booking['departure_time'])
            ? date('M j, Y g:i A', strtotime($booking['departure_date'] . ' ' . $booking['departure_time']))
            : '';
        $booking['expires_at_label'] = !empty($booking['expires_at'])
            ? date('M j, Y g:i A', strtotime($booking['expires_at']))
            : $booking['departure_label'];

        return $booking;
    }
}

if (!function_exists('get_cash_claim_summary_by_code')) {
    function get_cash_claim_summary_by_code(string $claimCode): ?array
    {
        $claimCode = strtoupper(trim($claimCode));
        if ($claimCode === '') {
            return null;
        }

        $booking = db_select_one(
            'SELECT booking_id FROM bookings WHERE claim_code = ? LIMIT 1',
            's',
            [$claimCode]
        );

        if (!$booking) {
            return null;
        }

        return get_cash_claim_summary((int) $booking['booking_id']);
    }
}

if (!function_exists('evaluate_cash_claim_summary')) {
    function evaluate_cash_claim_summary(array $booking): array
    {
        $bookingId = (int) ($booking['booking_id'] ?? 0);

        $departureTs = departure_timestamp((string) ($booking['departure_date'] ?? ''), (string) ($booking['departure_time'] ?? ''));
        if ($departureTs !== null && $departureTs <= time()) {
            return [
                'status' => 'claim_expired',
                'message' => 'This trip already left. Manual staff/admin action is required to close this cash ticket.',
                'booking_claim' => $booking,
            ];
        }

        if (($booking['payment_status'] ?? '') === 'paid') {
            if (!in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true)) {
                db_execute(
                    'UPDATE bookings
                     SET status = "confirmed",
                         expires_at = NULL,
                         confirmed_at = COALESCE(confirmed_at, NOW()),
                         updated_at = NOW()
                     WHERE booking_id = ?',
                    'i',
                    [$bookingId]
                );
                $booking = get_cash_claim_summary($bookingId) ?? $booking;
            }

            return [
                'status' => 'cash_claim_paid',
                'message' => 'Cash payment was already confirmed. Use the final boarding ticket QR instead.',
                'booking_claim' => $booking,
            ];
        }

        if (in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)) {
            return [
                'status' => 'claim_expired',
                'message' => 'This cash ticket is no longer active.',
                'booking_claim' => $booking,
            ];
        }

        return [
            'status' => 'cash_claim_pending',
            'message' => 'Terminal cash ticket found. Collect payment and confirm to reserve the seat and issue the final ticket.',
            'booking_claim' => $booking,
        ];
    }
}

if (!function_exists('issue_booking_tickets')) {
    function issue_booking_tickets(int $bookingId): bool
    {
        $rows = db_select_all(
            "SELECT t.ticket_id, t.ticket_code,
                    b.booking_reference, b.user_id,
                    p.fullname AS passenger_name,
                    s2.seat_label,
                    sch.departure_date, sch.departure_time,
                    origin.terminal_name AS origin_name,
                    destination.terminal_name AS destination_name
             FROM tickets t
             JOIN bookings b ON t.booking_id = b.booking_id
             LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
             JOIN seats s2 ON t.seat_id = s2.seat_id
             JOIN schedules sch ON b.schedule_id = sch.schedule_id
             JOIN routes r ON sch.route_id = r.route_id
             JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
             JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
             WHERE t.booking_id = ?",
            'i',
            [$bookingId]
        );

        if ($rows === [] && !create_booking_tickets_from_preferences($bookingId)) {
            return false;
        }

        if ($rows === []) {
            $rows = db_select_all(
                "SELECT t.ticket_id, t.ticket_code,
                        b.booking_reference, b.user_id,
                        p.fullname AS passenger_name,
                        s2.seat_label,
                        sch.departure_date, sch.departure_time,
                        origin.terminal_name AS origin_name,
                        destination.terminal_name AS destination_name
                 FROM tickets t
                 JOIN bookings b ON t.booking_id = b.booking_id
                 LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
                 JOIN seats s2 ON t.seat_id = s2.seat_id
                 JOIN schedules sch ON b.schedule_id = sch.schedule_id
                 JOIN routes r ON sch.route_id = r.route_id
                 JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
                 JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
                 WHERE t.booking_id = ?",
                'i',
                [$bookingId]
            );
        }

        if ($rows === []) {
            return false;
        }

        foreach ($rows as $row) {
            $ticketCode = $row['ticket_code'] ?: generate_reference('TKT', 8);
            $payloadBundle = build_ticket_payload([
                'ticket_code' => $ticketCode,
                'booking_reference' => $row['booking_reference'],
                'passenger_name' => $row['passenger_name'] ?: 'Passenger',
                'seat_label' => $row['seat_label'],
                'origin_name' => $row['origin_name'],
                'destination_name' => $row['destination_name'],
                'departure_date' => $row['departure_date'],
                'departure_time' => $row['departure_time'],
            ]);

            if (!db_execute(
                'UPDATE tickets
                 SET ticket_code = ?, qr_payload = ?, qr_signature = ?,
                     ticket_status = CASE WHEN ticket_status = "used" THEN "used" ELSE "issued" END,
                     issued_at = COALESCE(issued_at, NOW())
                 WHERE ticket_id = ?',
                'sssi',
                [$ticketCode, $payloadBundle['payload'], $payloadBundle['signature'], (int) $row['ticket_id']]
            )) {
                return false;
            }
        }

        if (!db_execute(
            'UPDATE bookings
             SET status = CASE WHEN status = "used" THEN "used" ELSE "confirmed" END,
                 confirmed_at = COALESCE(confirmed_at, NOW()),
                 updated_at = NOW()
             WHERE booking_id = ?',
            'i',
            [$bookingId]
        )) {
            return false;
        }

        return true;
    }
}

if (!function_exists('ensure_paid_booking_tickets')) {
    /**
     * Repair ticket issuance for completed bookings, including bookings that
     * were paid before the current PayMongo confirmation flow was deployed.
     * A locally recorded paid payment is authoritative for legacy records.
     */
    function ensure_paid_booking_tickets(int $bookingId): bool
    {
        $booking = db_select_one(
            'SELECT b.booking_id, b.status, b.payment_status, b.number_of_passengers,
                    s.status AS schedule_status, s.departure_date, s.departure_time,
                    EXISTS(
                        SELECT 1
                        FROM payments p
                        WHERE p.booking_id = b.booking_id
                          AND p.status = "paid"
                    ) AS has_paid_payment
             FROM bookings b
             JOIN schedules s ON s.schedule_id = b.schedule_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return true;
        }

        $hasPaidPayment = (int) ($booking['has_paid_payment'] ?? 0) > 0;
        $isPaid = (string) ($booking['payment_status'] ?? '') === 'paid' || $hasPaidPayment;
        if (!$isPaid) {
            return true;
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        if (($booking['schedule_status'] ?? '') === 'cancelled'
            || $departureTimestamp === null
            || $departureTimestamp <= time()) {
            return true;
        }

        $needsBookingRepair = (string) ($booking['payment_status'] ?? '') !== 'paid'
            || in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true);

        $expectedPassengers = (int) ($booking['number_of_passengers'] ?? 0);
        if ($expectedPassengers < 1) {
            return false;
        }

        $tickets = db_select_all(
            'SELECT ticket_code, qr_payload, qr_signature, ticket_status
             FROM tickets
             WHERE booking_id = ?',
            'i',
            [$bookingId]
        );

        $ticketsComplete = count($tickets) === $expectedPassengers;
        if ($ticketsComplete) {
            foreach ($tickets as $ticket) {
                if (trim((string) ($ticket['ticket_code'] ?? '')) === ''
                    || trim((string) ($ticket['qr_payload'] ?? '')) === ''
                    || trim((string) ($ticket['qr_signature'] ?? '')) === ''
                    || !in_array((string) ($ticket['ticket_status'] ?? ''), ['issued', 'used'], true)) {
                    $ticketsComplete = false;
                    break;
                }
            }
        }

        if ($ticketsComplete) {
            return !$needsBookingRepair || db_execute(
                'UPDATE bookings
                 SET status = "confirmed",
                     payment_status = "paid",
                     expires_at = NULL,
                     cancelled_at = NULL,
                     confirmed_at = COALESCE(confirmed_at, NOW()),
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [$bookingId]
            );
        }

        if (!issue_booking_tickets($bookingId)) {
            return false;
        }

        return !$needsBookingRepair || db_execute(
            'UPDATE bookings
             SET status = "confirmed",
                 payment_status = "paid",
                 expires_at = NULL,
                 cancelled_at = NULL,
                 confirmed_at = COALESCE(confirmed_at, NOW()),
                 updated_at = NOW()
             WHERE booking_id = ?',
            'i',
            [$bookingId]
        );
    }
}

if (!function_exists('release_booking_hold')) {
    function release_booking_hold(int $bookingId, string $status = 'cancelled', bool $markPaymentFailed = false): bool
    {
        global $conn;

        $booking = db_select_one(
            'SELECT booking_id, user_id, schedule_id, payment_status, payment_method FROM bookings WHERE booking_id = ? LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return false;
        }

        $conn->begin_transaction();

        try {
            db_execute('DELETE FROM tickets WHERE booking_id = ?', 'i', [$bookingId]);

            $paymentStatus = $booking['payment_status'];
            if ($markPaymentFailed && $paymentStatus !== 'paid') {
                $paymentStatus = 'failed';
                db_execute(
                    'UPDATE payments SET status = "failed", admin_notes = COALESCE(admin_notes, "Booking expired before payment completion.") WHERE booking_id = ? AND status IN ("pending", "rejected")',
                    'i',
                    [$bookingId]
                );
            }

            db_execute(
                'UPDATE bookings SET status = ?, payment_status = ?, cancelled_at = NOW(), updated_at = NOW() WHERE booking_id = ?',
                'ssi',
                [$status, $paymentStatus, $bookingId]
            );

            sync_schedule_available_seats((int) $booking['schedule_id']);
            create_notification(
                (int) $booking['user_id'],
                'booking',
                ucfirst($status) . ' booking',
                $status === 'expired'
                    ? (($booking['payment_method'] ?? '') === 'cash'
                        ? 'Your terminal cash claim expired before staff received payment. Please create a new booking if you still plan to travel.'
                        : 'Your booking expired because payment was not completed in time.')
                    : 'Your booking status was updated to ' . $status . '.',
                $bookingId
            );

            create_audit_log(
                (int) ($_SESSION['user_id'] ?? $booking['user_id']),
                'booking.' . $status,
                'booking',
                $bookingId,
                'Booking status changed to ' . $status . '.',
                [
                    'payment_status' => (string) $paymentStatus,
                    'payment_method' => (string) ($booking['payment_method'] ?? ''),
                    'schedule_id' => (int) ($booking['schedule_id'] ?? 0),
                ]
            );

            $conn->commit();
            return true;
        } catch (Throwable $exception) {
            $conn->rollback();
            return false;
        }
    }
}

if (!function_exists('expire_pending_bookings')) {
    function expire_pending_bookings(): void
    {
        // Manual mode: pay-at-terminal bookings are not auto-expired here.
    }
}

if (!function_exists('delete_booking_history')) {
    function delete_booking_history(int $bookingId, int $userId): array
    {
        global $conn;

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.schedule_id, b.status, b.payment_status,
                    s.departure_date, s.departure_time
             FROM bookings b
             LEFT JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking || (int) $booking['user_id'] !== $userId) {
            return ['ok' => false, 'message' => 'Booking history item not found.'];
        }

        if (!booking_history_is_clearable($booking)) {
            return ['ok' => false, 'message' => 'Only finished, cancelled, expired, used, missed, or already departed bookings can be cleared from history.'];
        }

        $conn->begin_transaction();

        try {
            $ticketIds = [];
            if (table_exists('tickets')) {
                $ticketIds = array_map(
                    'intval',
                    array_column(
                        db_select_all('SELECT ticket_id FROM tickets WHERE booking_id = ?', 'i', [$bookingId]),
                        'ticket_id'
                    )
                );
            }

            if ($ticketIds !== [] && table_exists('qr_logs')) {
                [$placeholders, $types] = build_in_clause($ticketIds);
                db_execute(
                    "DELETE FROM qr_logs WHERE ticket_id IN ($placeholders)",
                    $types,
                    $ticketIds
                );
            }

            if (table_exists('notifications')) {
                db_execute('DELETE FROM notifications WHERE booking_id = ?', 'i', [$bookingId]);
            }
            if (table_exists('payments')) {
                db_execute('DELETE FROM payments WHERE booking_id = ?', 'i', [$bookingId]);
            }
            if (table_exists('tickets')) {
                db_execute('DELETE FROM tickets WHERE booking_id = ?', 'i', [$bookingId]);
            }
            if (table_exists('passengers')) {
                db_execute('DELETE FROM passengers WHERE booking_id = ?', 'i', [$bookingId]);
            }
            db_execute('DELETE FROM bookings WHERE booking_id = ? AND user_id = ?', 'ii', [$bookingId, $userId]);

            sync_schedule_available_seats((int) $booking['schedule_id']);

            $conn->commit();
            return ['ok' => true, 'message' => 'Booking history cleared successfully.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'Unable to clear the booking history item.'];
        }
    }
}

if (!function_exists('clear_user_booking_history')) {
    function clear_user_booking_history(int $userId): array
    {
        $rows = db_select_all(
            'SELECT b.booking_id, b.status, b.payment_status,
                    s.departure_date, s.departure_time
             FROM bookings b
             LEFT JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.user_id = ?
             ORDER BY b.booking_id ASC',
            'i',
            [$userId]
        );

        $clearableRows = array_values(array_filter($rows, 'booking_history_is_clearable'));

        if ($clearableRows === []) {
            return ['ok' => false, 'message' => 'There are no removable booking history items yet.'];
        }

        foreach ($clearableRows as $row) {
            $result = delete_booking_history((int) $row['booking_id'], $userId);
            if (!$result['ok']) {
                return $result;
            }
        }

        return ['ok' => true, 'message' => 'Booking history cleared successfully.'];
    }
}

if (!function_exists('clear_admin_booking_history')) {
    function clear_admin_booking_history(): array
    {
        global $conn;

        $rows = db_select_all(
            'SELECT b.booking_id, b.schedule_id, b.status, b.payment_status,
                    s.departure_date, s.departure_time
             FROM bookings b
             LEFT JOIN schedules s ON b.schedule_id = s.schedule_id
             ORDER BY b.booking_id ASC'
        );

        $clearableRows = array_values(array_filter($rows, 'booking_history_is_clearable'));

        if ($clearableRows === []) {
            return ['ok' => false, 'message' => 'There are no removable history records right now.'];
        }

        $conn->begin_transaction();

        try {
            foreach ($clearableRows as $row) {
                $bookingId = (int) ($row['booking_id'] ?? 0);
                $scheduleId = (int) ($row['schedule_id'] ?? 0);
                $ticketIds = [];

                if (table_exists('tickets')) {
                    $ticketIds = array_map(
                        'intval',
                        array_column(
                            db_select_all('SELECT ticket_id FROM tickets WHERE booking_id = ?', 'i', [$bookingId]),
                            'ticket_id'
                        )
                    );
                }

                if ($ticketIds !== [] && table_exists('qr_logs')) {
                    [$placeholders, $types] = build_in_clause($ticketIds);
                    db_execute(
                        "DELETE FROM qr_logs WHERE ticket_id IN ($placeholders)",
                        $types,
                        $ticketIds
                    );
                }

                if (table_exists('notifications')) {
                    db_execute('DELETE FROM notifications WHERE booking_id = ?', 'i', [$bookingId]);
                }
                if (table_exists('payments')) {
                    db_execute('DELETE FROM payments WHERE booking_id = ?', 'i', [$bookingId]);
                }
                if (table_exists('tickets')) {
                    db_execute('DELETE FROM tickets WHERE booking_id = ?', 'i', [$bookingId]);
                }
                if (table_exists('passengers')) {
                    db_execute('DELETE FROM passengers WHERE booking_id = ?', 'i', [$bookingId]);
                }
                db_execute('DELETE FROM bookings WHERE booking_id = ?', 'i', [$bookingId]);

                if ($scheduleId > 0) {
                    sync_schedule_available_seats($scheduleId);
                }
            }

            $conn->commit();

            return ['ok' => true, 'message' => 'Old booking history cleared successfully.'];
        } catch (Throwable $exception) {
            $conn->rollback();

            return ['ok' => false, 'message' => 'Unable to clear the old booking history right now.'];
        }
    }
}

if (!function_exists('clear_qr_scan_history')) {
    function clear_qr_scan_history(): array
    {
        if (!table_exists('qr_logs')) {
            return ['ok' => false, 'message' => 'QR scan log table is not available.'];
        }

        if (!db_execute('DELETE FROM qr_logs')) {
            return ['ok' => false, 'message' => 'Unable to clear the QR scan history right now.'];
        }

        return ['ok' => true, 'message' => 'QR scan history cleared successfully.'];
    }
}

if (!function_exists('user_has_active_cash_booking')) {
    function user_has_active_cash_booking(int $userId, int $excludeBookingId = 0): bool
    {
        $row = db_select_one(
            'SELECT COUNT(*) AS total
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.user_id = ?
             AND b.booking_id <> ?
             AND b.payment_method = "cash"
             AND b.status IN ("pending", "payment_review", "confirmed")
             AND TIMESTAMP(s.departure_date, s.departure_time) > NOW()',
            'ii',
            [$userId, $excludeBookingId]
        );

        return (int) ($row['total'] ?? 0) > 0;
    }
}

if (!function_exists('maya_is_configured')) {
    function maya_is_configured(): bool
    {
        if (MAYA_PUBLIC_KEY === '' || MAYA_SECRET_KEY === '' || APP_PUBLIC_URL === '') {
            return false;
        }

        $parts = parse_url(APP_PUBLIC_URL);
        $scheme = strtolower((string) ($parts['scheme'] ?? ''));

        if (!is_array($parts) || empty($parts['host']) || !in_array($scheme, ['http', 'https'], true)) {
            return false;
        }

        $mayaParts = parse_url(MAYA_API_BASE_URL);
        $mayaScheme = strtolower((string) ($mayaParts['scheme'] ?? ''));
        if (!is_array($mayaParts) || empty($mayaParts['host']) || $mayaScheme !== 'https') {
            return false;
        }

        return APP_ENV !== 'production' || $scheme === 'https';
    }
}

if (!function_exists('maya_checkout_return_url')) {
    function maya_checkout_return_url(int $bookingId, string $state): string
    {
        return APP_PUBLIC_URL . '/payment.php?' . http_build_query([
            'booking_id' => $bookingId,
            'payment_return' => $state,
        ], '', '&', PHP_QUERY_RFC3986);
    }
}

if (!function_exists('maya_api_request')) {
    /**
     * Make a server-to-server Maya API request. API keys never leave the
     * application; the customer is sent only to Maya's hosted checkout URL.
     */
    function maya_api_request(string $method, string $path, ?array $payload = null, string $keyType = 'secret'): array
    {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'message' => 'PHP cURL is required for the GCash payment gateway.'];
        }

        $apiKey = $keyType === 'public' ? MAYA_PUBLIC_KEY : MAYA_SECRET_KEY;
        if ($apiKey === '') {
            return ['ok' => false, 'message' => 'The Maya API key is not configured.'];
        }

        $encodedPayload = $payload === null ? null : json_encode($payload, JSON_UNESCAPED_SLASHES);
        if ($payload !== null && $encodedPayload === false) {
            return ['ok' => false, 'message' => 'Unable to prepare the payment request.'];
        }

        $curl = curl_init(MAYA_API_BASE_URL . $path);
        if ($curl === false) {
            return ['ok' => false, 'message' => 'Unable to start the payment gateway connection.'];
        }

        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPAUTH => CURLAUTH_BASIC,
            CURLOPT_USERPWD => $apiKey . ':',
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/json'],
        ];
        if ($encodedPayload !== null) {
            $options[CURLOPT_POSTFIELDS] = $encodedPayload;
        }

        curl_setopt_array($curl, $options);
        $responseBody = curl_exec($curl);
        $curlError = curl_error($curl);
        $httpStatus = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);

        if ($responseBody === false || $curlError !== '') {
            error_log('Maya API request failed: ' . $curlError);
            return ['ok' => false, 'message' => 'Unable to reach the payment gateway. Please try again.'];
        }

        $response = json_decode((string) $responseBody, true);
        if (!is_array($response)) {
            error_log('Maya API returned a non-JSON response with HTTP status ' . $httpStatus . '.');
            return ['ok' => false, 'message' => 'The payment gateway returned an unexpected response. Please try again.'];
        }

        if ($httpStatus < 200 || $httpStatus >= 300) {
            $gatewayMessage = trim((string) ($response['errors'][0]['detail'] ?? $response['errors'][0]['code'] ?? ''));
            if ($gatewayMessage !== '') {
                error_log('Maya API rejected a request: ' . $gatewayMessage);
            }

            return ['ok' => false, 'message' => 'The payment gateway could not start this checkout. Please try again or choose Pay at Terminal.'];
        }

        return ['ok' => true, 'data' => $response];
    }
}

if (!function_exists('demo_gcash_is_enabled')) {
    function demo_gcash_is_enabled(): bool
    {
        return DEMO_GCASH_ENABLED;
    }
}

if (!function_exists('demo_gcash_checkout_url')) {
    function demo_gcash_checkout_url(string $checkoutToken): string
    {
        $query = http_build_query(['token' => $checkoutToken], '', '&', PHP_QUERY_RFC3986);
        if (APP_PUBLIC_URL !== '') {
            return APP_PUBLIC_URL . '/demo-gcash-checkout.php?' . $query;
        }

        $host = trim((string) ($_SERVER['HTTP_HOST'] ?? ''));
        if ($host !== '') {
            $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') ? 'https' : 'http';
            return $scheme . '://' . $host . rtrim(app_base_web_path(), '/') . '/demo-gcash-checkout.php?' . $query;
        }

        return 'demo-gcash-checkout.php?' . $query;
    }
}

if (!function_exists('start_demo_gcash_checkout')) {
    /**
     * Starts a development-only QR checkout. No external service is called and
     * no funds move; completing it exercises the same confirmation/ticket path
     * used by the real gateway.
     */
    function start_demo_gcash_checkout(int $bookingId): array
    {
        global $conn;

        if (!demo_gcash_is_enabled()) {
            return ['ok' => false, 'message' => 'The demo QR checkout is disabled.'];
        }

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.booking_reference, b.status, b.payment_status, b.number_of_passengers, b.total_amount,
                    s.departure_date, s.departure_time
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );
        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }
        if (in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This booking is no longer payable.'];
        }
        if (($booking['payment_status'] ?? '') === 'paid') {
            return ['ok' => false, 'message' => 'This booking has already been paid.'];
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        if ($departureTimestamp !== null && $departureTimestamp <= time()) {
            return ['ok' => false, 'message' => 'This trip already left and can no longer be paid.'];
        }

        $passengerCount = db_select_one(
            'SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ?',
            'i',
            [$bookingId]
        );
        if ((int) ($passengerCount['total'] ?? 0) !== (int) ($booking['number_of_passengers'] ?? 0)) {
            return ['ok' => false, 'message' => 'Please complete the passenger details before going to payment.'];
        }

        $existingCheckout = db_select_one(
            'SELECT payment_id, provider_checkout_url
             FROM payments
             WHERE booking_id = ?
               AND payment_method = "gcash"
               AND provider = "demo"
               AND status = "pending"
             ORDER BY payment_id DESC
             LIMIT 1',
            'i',
            [$bookingId]
        );
        if ($existingCheckout && trim((string) ($existingCheckout['provider_checkout_url'] ?? '')) !== '') {
            return [
                'ok' => true,
                'checkout_url' => (string) $existingCheckout['provider_checkout_url'],
                'message' => 'Your demo QR checkout is ready.',
            ];
        }
        if ($existingCheckout) {
            db_execute(
                'UPDATE payments SET status = "failed", admin_notes = "Demo checkout session was not created." WHERE payment_id = ? AND status = "pending"',
                'i',
                [(int) $existingCheckout['payment_id']]
            );
        }

        $amount = round((float) ($booking['total_amount'] ?? 0), 2);
        if ($amount < 0.01) {
            return ['ok' => false, 'message' => 'This booking has an invalid payment amount.'];
        }

        try {
            $checkoutToken = bin2hex(random_bytes(32));
        } catch (Throwable $exception) {
            return ['ok' => false, 'message' => 'Unable to create a secure demo checkout token.'];
        }

        $paymentReference = generate_reference('PAY', 8);
        $checkoutUrl = demo_gcash_checkout_url($checkoutToken);
        $conn->begin_transaction();
        try {
            if (!db_execute(
                'INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, provider, provider_checkout_id, provider_checkout_url, submitted_at)
                 VALUES (?, ?, "gcash", ?, "pending", "demo", ?, ?, NOW())',
                'isdss',
                [$bookingId, $paymentReference, $amount, $checkoutToken, $checkoutUrl]
            )) {
                throw new RuntimeException('Unable to save the demo payment record.');
            }
            $payment = db_select_one(
                'SELECT payment_id FROM payments WHERE payment_reference = ? LIMIT 1',
                's',
                [$paymentReference]
            );
            if (!$payment) {
                throw new RuntimeException('Unable to create the demo payment record.');
            }
            if (!db_execute(
                'UPDATE bookings
                 SET payment_method = "gcash", payment_status = "pending", status = "payment_review", expires_at = NULL, updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [$bookingId]
            )) {
                throw new RuntimeException('Unable to prepare this booking for demo payment.');
            }
            $conn->commit();
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }

        create_notification(
            (int) $booking['user_id'],
            'payment',
            'Demo QR checkout ready',
            'This is a development test. Scan the demo QR code and complete the test payment to automatically issue your ticket. No money will be charged.',
            $bookingId
        );
        create_audit_log(
            (int) ($_SESSION['user_id'] ?? $booking['user_id']),
            'payment.demo_checkout_created',
            'payment',
            (int) $payment['payment_id'],
            'Development-only demo QR checkout created.',
            ['payment_reference' => $paymentReference, 'amount' => $amount]
        );

        return ['ok' => true, 'checkout_url' => $checkoutUrl, 'message' => 'Your demo QR checkout is ready.'];
    }
}

if (!function_exists('get_demo_gcash_checkout')) {
    function get_demo_gcash_checkout(string $checkoutToken): ?array
    {
        if (!demo_gcash_is_enabled()) {
            return null;
        }

        $checkoutToken = trim($checkoutToken);
        if ($checkoutToken === '') {
            return null;
        }

        return db_select_one(
            'SELECT p.payment_id, p.booking_id, p.payment_reference, p.amount, p.status, p.provider_checkout_id,
                    b.booking_reference, b.user_id, b.number_of_passengers, b.status AS booking_status, b.payment_status,
                    s.departure_date, s.departure_time,
                    origin.terminal_name AS origin_name,
                    destination.terminal_name AS destination_name
             FROM payments p
             JOIN bookings b ON p.booking_id = b.booking_id
             JOIN schedules s ON b.schedule_id = s.schedule_id
             JOIN routes r ON s.route_id = r.route_id
             JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
             JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
             WHERE p.provider = "demo"
               AND p.payment_method = "gcash"
               AND p.provider_checkout_id = ?
             LIMIT 1',
            's',
            [$checkoutToken]
        ) ?: null;
    }
}

if (!function_exists('complete_demo_gcash_payment')) {
    function complete_demo_gcash_payment(string $checkoutToken): array
    {
        global $conn;

        $checkout = get_demo_gcash_checkout($checkoutToken);
        if (!$checkout) {
            return ['ok' => false, 'message' => 'This demo QR checkout is invalid or has expired.'];
        }

        if ((string) ($checkout['status'] ?? '') === 'paid' && (string) ($checkout['payment_status'] ?? '') === 'paid') {
            return ['ok' => true, 'message' => 'Demo payment was already completed. Your QR ticket is ready.', 'booking_id' => (int) $checkout['booking_id']];
        }

        if (in_array((string) ($checkout['booking_status'] ?? ''), ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This booking is no longer payable.'];
        }

        $departureTimestamp = departure_timestamp(
            (string) ($checkout['departure_date'] ?? ''),
            (string) ($checkout['departure_time'] ?? '')
        );
        if ($departureTimestamp !== null && $departureTimestamp <= time()) {
            return ['ok' => false, 'message' => 'This trip already left and can no longer be paid.'];
        }

        $conn->begin_transaction();
        try {
            $payment = db_select_one(
                'SELECT p.payment_id, p.booking_id, p.amount, p.status, b.user_id, b.status AS booking_status, b.payment_status
                 FROM payments p
                 JOIN bookings b ON p.booking_id = b.booking_id
                 WHERE p.provider = "demo"
                   AND p.payment_method = "gcash"
                   AND p.provider_checkout_id = ?
                 FOR UPDATE',
                's',
                [$checkoutToken]
            );

            if (!$payment) {
                throw new RuntimeException('This demo QR checkout is no longer available.');
            }

            if ((string) ($payment['status'] ?? '') === 'paid' && (string) ($payment['payment_status'] ?? '') === 'paid') {
                $conn->commit();
                return ['ok' => true, 'message' => 'Demo payment was already completed. Your QR ticket is ready.', 'booking_id' => (int) $payment['booking_id']];
            }

            if (!db_execute(
                'UPDATE payments
                 SET status = "paid", provider_payment_id = ?, admin_notes = "Development demo payment completed by customer.",
                     verified_at = NOW(), verified_by = NULL
                 WHERE payment_id = ? AND status = "pending"',
                'si',
                ['DEMO-' . strtoupper(substr($checkoutToken, 0, 16)), (int) $payment['payment_id']]
            )) {
                throw new RuntimeException('Unable to record the demo payment.');
            }

            if (!db_execute(
                'UPDATE bookings
                 SET status = "confirmed", payment_status = "paid", expires_at = NULL,
                     confirmed_at = COALESCE(confirmed_at, NOW()), updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [(int) $payment['booking_id']]
            )) {
                throw new RuntimeException('Unable to confirm the booking.');
            }

            if (!issue_booking_tickets((int) $payment['booking_id'])) {
                throw new RuntimeException('Unable to assign and issue the QR ticket. Please try again.');
            }

            create_notification(
                (int) $payment['user_id'],
                'payment',
                'Demo payment confirmed',
                'Your development payment was completed automatically. Your booking is confirmed and your QR ticket is ready.',
                (int) $payment['booking_id']
            );
            create_audit_log(
                null,
                'payment.demo_auto_confirmed',
                'payment',
                (int) $payment['payment_id'],
                'Development QR payment completed and ticket issued automatically.',
                ['booking_id' => (int) $payment['booking_id']]
            );

            $conn->commit();
            return ['ok' => true, 'message' => 'Demo payment completed and QR ticket issued automatically.', 'booking_id' => (int) $payment['booking_id']];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage() ?: 'Unable to complete the demo payment.'];
        }
    }
}

if (!function_exists('paymongo_is_configured')) {
    function paymongo_is_configured(): bool
    {
        $appUrl = parse_url(APP_PUBLIC_URL);
        $apiUrl = parse_url(PAYMONGO_API_BASE_URL);
        $hasPlaceholders = str_contains(PAYMONGO_PUBLIC_KEY, 'REPLACE_')
            || str_contains(PAYMONGO_SECRET_KEY, 'REPLACE_')
            || str_contains(PAYMONGO_WEBHOOK_SECRET, 'REPLACE_');
        return !$hasPlaceholders
            && PAYMONGO_PUBLIC_KEY !== '' && PAYMONGO_SECRET_KEY !== '' && APP_PUBLIC_URL !== ''
            && is_array($appUrl) && !empty($appUrl['host'])
            && in_array(strtolower((string) ($appUrl['scheme'] ?? '')), ['http', 'https'], true)
            && is_array($apiUrl) && !empty($apiUrl['host'])
            && strtolower((string) ($apiUrl['scheme'] ?? '')) === 'https'
            && (APP_ENV !== 'production' || strtolower((string) ($appUrl['scheme'] ?? '')) === 'https');
    }
}

if (!function_exists('paymongo_api_request')) {
    function paymongo_api_request(string $method, string $path, ?array $payload = null): array
    {
        if (!function_exists('curl_init')) {
            return ['ok' => false, 'message' => 'PHP cURL is required for PayMongo payments.'];
        }
        $body = $payload === null ? null : json_encode($payload, JSON_UNESCAPED_SLASHES);
        $curl = curl_init(PAYMONGO_API_BASE_URL . $path);
        if ($curl === false || ($payload !== null && $body === false)) {
            return ['ok' => false, 'message' => 'Unable to prepare the PayMongo request.'];
        }
        $options = [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 10, CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => ['Accept: application/json', 'Content-Type: application/json', 'Authorization: Basic ' . base64_encode(PAYMONGO_SECRET_KEY . ':')],
        ];
        if ($body !== null) {
            $options[CURLOPT_POSTFIELDS] = $body;
        }
        curl_setopt_array($curl, $options);
        $responseBody = curl_exec($curl);
        $error = curl_error($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
        if ($responseBody === false || $error !== '') {
            error_log('PayMongo API request failed: ' . $error);
            return ['ok' => false, 'message' => 'Unable to reach PayMongo. Please try again.'];
        }
        $response = json_decode((string) $responseBody, true);
        if (!is_array($response) || $status < 200 || $status >= 300) {
            $gatewayMessage = trim((string) ($response['errors'][0]['detail'] ?? $response['errors'][0]['code'] ?? ''));
            error_log('PayMongo API rejected a request with HTTP status ' . $status . ': ' . ($gatewayMessage !== '' ? $gatewayMessage : 'unknown error'));
            return [
                'ok' => false,
                'message' => APP_ENV === 'production'
                    ? 'PayMongo could not start this checkout. Please verify the live API keys and QRPh activation.'
                    : ('PayMongo rejected the request: ' . ($gatewayMessage !== '' ? $gatewayMessage : 'unknown error')),
            ];
        }
        return ['ok' => true, 'data' => $response];
    }
}

if (!function_exists('start_paymongo_checkout')) {
    function start_paymongo_checkout(int $bookingId): array
    {
        global $conn;
        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.booking_reference, b.status, b.payment_status, b.number_of_passengers, b.total_amount,
                    s.departure_date, s.departure_time FROM bookings b JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.booking_id = ? LIMIT 1', 'i', [$bookingId]
        );
        if (!$booking || in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This booking is no longer payable.'];
        }
        if (($booking['payment_status'] ?? '') === 'paid') {
            return ['ok' => false, 'message' => 'This booking has already been paid.'];
        }
        $departure = departure_timestamp((string) $booking['departure_date'], (string) $booking['departure_time']);
        if ($departure !== null && $departure <= time()) {
            return ['ok' => false, 'message' => 'This trip already left and can no longer be paid.'];
        }
        $passengers = db_select_one('SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ?', 'i', [$bookingId]);
        if ((int) ($passengers['total'] ?? 0) !== (int) $booking['number_of_passengers']) {
            return ['ok' => false, 'message' => 'Please complete the passenger details before payment.'];
        }
        $existing = db_select_one('SELECT provider_checkout_url FROM payments WHERE booking_id = ? AND payment_method = "qrph" AND provider = "paymongo" AND status = "pending" ORDER BY payment_id DESC LIMIT 1', 'i', [$bookingId]);
        if ($existing && filter_var((string) ($existing['provider_checkout_url'] ?? ''), FILTER_VALIDATE_URL)) {
            return ['ok' => true, 'checkout_url' => $existing['provider_checkout_url']];
        }
        $amount = round((float) $booking['total_amount'], 2);
        if ($amount < 0.01) {
            return ['ok' => false, 'message' => 'This booking has an invalid payment amount.'];
        }
        $reference = generate_reference('PAY', 8);
        $conn->begin_transaction();
        try {
            db_execute('INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, provider, submitted_at) VALUES (?, ?, "qrph", ?, "pending", "paymongo", NOW())', 'isd', [$bookingId, $reference, $amount]);
            db_execute('UPDATE bookings SET payment_method = "qrph", payment_status = "pending", status = "payment_review", expires_at = NULL, updated_at = NOW() WHERE booking_id = ?', 'i', [$bookingId]);
            $conn->commit();
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => 'Unable to save the payment record.'];
        }
        $payload = ['data' => ['attributes' => [
            'line_items' => [['currency' => 'PHP', 'amount' => (int) round($amount * 100), 'name' => 'Bus ticket ' . $booking['booking_reference'], 'quantity' => 1]],
            'payment_method_types' => ['qrph'],
            'success_url' => APP_PUBLIC_URL . '/payment.php?' . http_build_query(['booking_id' => $bookingId, 'payment_return' => 'success']),
            // PayMongo uses this URL for the customer's "Back to merchant"
            // action as well as a cancelled checkout. Keep it on the public
            // homepage; only successful returns need to revisit payment.php
            // for direct session reconciliation.
            'cancel_url' => APP_PUBLIC_URL . '/index.php',
            'reference_number' => $reference,
            'description' => 'Bus reservation ' . $booking['booking_reference'],
            'metadata' => ['booking_id' => (string) $bookingId, 'payment_reference' => $reference],
        ]]];
        $result = paymongo_api_request('POST', '/v2/checkout_sessions', $payload);
        $checkout = $result['data']['data'] ?? [];
        $checkoutId = trim((string) ($checkout['id'] ?? ''));
        $checkoutUrl = trim((string) ($checkout['attributes']['checkout_url'] ?? ''));
        if (!$result['ok'] || $checkoutId === '' || !filter_var($checkoutUrl, FILTER_VALIDATE_URL)) {
            db_execute('UPDATE payments SET status = "failed", admin_notes = "PayMongo checkout could not be created." WHERE payment_reference = ? AND status = "pending"', 's', [$reference]);
            return ['ok' => false, 'message' => $result['message'] ?? 'PayMongo could not create the checkout.'];
        }
        db_execute('UPDATE payments SET provider_checkout_id = ?, provider_checkout_url = ? WHERE payment_reference = ? AND status = "pending"', 'sss', [$checkoutId, $checkoutUrl, $reference]);
        create_audit_log((int) ($_SESSION['user_id'] ?? $booking['user_id']), 'payment.paymongo_checkout_created', 'payment', 0, 'PayMongo checkout session created.', ['payment_reference' => $reference, 'amount' => $amount]);
        return ['ok' => true, 'checkout_url' => $checkoutUrl, 'message' => 'Your secure QRPh checkout is ready.'];
    }
}

if (!function_exists('start_gcash_checkout')) {
    /**
     * Creates a one-use GCash checkout session. A booking remains pending until
     * Maya confirms that its exact amount was paid.
     */
    function start_gcash_checkout(int $bookingId): array
    {
        global $conn;

        if (!paymongo_is_configured()) {
            return [
                'ok' => false,
                'message' => 'PayMongo is not configured yet. Please choose Pay at Terminal or ask the administrator to configure the live PayMongo keys.',
            ];
        }

        return start_paymongo_checkout($bookingId);

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.booking_reference, b.status, b.payment_status, b.number_of_passengers, b.total_amount,
                    s.departure_date, s.departure_time
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }
        if (in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This booking is no longer payable.'];
        }
        if (($booking['payment_status'] ?? '') === 'paid') {
            return ['ok' => false, 'message' => 'This booking has already been paid.'];
        }

        $departureTimestamp = departure_timestamp(
            (string) ($booking['departure_date'] ?? ''),
            (string) ($booking['departure_time'] ?? '')
        );
        if ($departureTimestamp !== null && $departureTimestamp <= time()) {
            return ['ok' => false, 'message' => 'This trip already left and can no longer be paid.'];
        }

        $passengerCount = db_select_one(
            'SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ?',
            'i',
            [$bookingId]
        );
        if ((int) ($passengerCount['total'] ?? 0) !== (int) ($booking['number_of_passengers'] ?? 0)) {
            return ['ok' => false, 'message' => 'Please complete the passenger details before going to payment.'];
        }

        $existingCheckout = db_select_one(
            'SELECT payment_id, payment_reference, provider_checkout_url
             FROM payments
             WHERE booking_id = ?
             AND payment_method = "gcash"
             AND provider = "maya"
             AND status = "pending"
             ORDER BY payment_id DESC
             LIMIT 1',
            'i',
            [$bookingId]
        );
        if ($existingCheckout && filter_var((string) ($existingCheckout['provider_checkout_url'] ?? ''), FILTER_VALIDATE_URL)) {
            return [
                'ok' => true,
                'checkout_url' => (string) $existingCheckout['provider_checkout_url'],
                'message' => 'Your secure GCash checkout is ready.',
            ];
        }

        // A previous local attempt that never reached Maya is safe to close;
        // successful gateway sessions are never deleted or silently replaced.
        if ($existingCheckout) {
            db_execute(
                'UPDATE payments
                 SET status = "failed", admin_notes = "Checkout session was not created."
                 WHERE payment_id = ? AND status = "pending"',
                'i',
                [(int) $existingCheckout['payment_id']]
            );
        }

        $amount = round((float) ($booking['total_amount'] ?? 0), 2);
        if ($amount < 0.01) {
            return ['ok' => false, 'message' => 'This booking has an invalid payment amount.'];
        }

        $paymentReference = generate_reference('PAY', 8);
        $conn->begin_transaction();

        try {
            if (!db_execute(
                'INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, provider, submitted_at)
                 VALUES (?, ?, "gcash", ?, "pending", "maya", NOW())',
                'isd',
                [$bookingId, $paymentReference, $amount]
            )) {
                throw new RuntimeException('Unable to save the payment record.');
            }

            $payment = db_select_one(
                'SELECT payment_id FROM payments WHERE payment_reference = ? LIMIT 1',
                's',
                [$paymentReference]
            );
            if (!$payment) {
                throw new RuntimeException('Unable to create the payment record.');
            }

            if (!db_execute(
                'UPDATE bookings
                 SET payment_method = "gcash", payment_status = "pending", status = "payment_review",
                     expires_at = NULL, updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [$bookingId]
            )) {
                throw new RuntimeException('Unable to prepare this booking for payment.');
            }

            $conn->commit();
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }

        $request = [
            'totalAmount' => [
                'value' => $amount,
                'currency' => 'PHP',
            ],
            'items' => [[
                'name' => 'Bus ticket ' . (string) $booking['booking_reference'],
                'code' => $paymentReference,
                'description' => 'Bus reservation payment',
                'quantity' => 1,
                'amount' => ['value' => $amount],
                'totalAmount' => ['value' => $amount],
            ]],
            'redirectUrl' => [
                'success' => maya_checkout_return_url($bookingId, 'success'),
                'failure' => maya_checkout_return_url($bookingId, 'failed'),
                'cancel' => maya_checkout_return_url($bookingId, 'cancelled'),
            ],
            'requestReferenceNumber' => $paymentReference,
            'metadata' => [
                'booking_id' => (string) $bookingId,
                'payment_reference' => $paymentReference,
            ],
        ];
        $gatewayResult = maya_api_request('POST', '/checkout/v1/checkouts', $request, 'public');
        if (!$gatewayResult['ok']) {
            db_execute(
                'UPDATE payments
                 SET status = "failed", admin_notes = "Maya Checkout could not be created."
                 WHERE payment_reference = ? AND status = "pending"',
                's',
                [$paymentReference]
            );
            db_execute(
                'UPDATE bookings
                 SET status = "pending", payment_status = "failed", updated_at = NOW()
                 WHERE booking_id = ? AND payment_status = "pending"',
                'i',
                [$bookingId]
            );

            return $gatewayResult;
        }

        $checkoutId = trim((string) ($gatewayResult['data']['checkoutId'] ?? ''));
        $checkoutUrl = trim((string) ($gatewayResult['data']['redirectUrl'] ?? ''));
        $checkoutParts = parse_url($checkoutUrl);
        if ($checkoutId === '' || !is_array($checkoutParts) || strtolower((string) ($checkoutParts['scheme'] ?? '')) !== 'https' || empty($checkoutParts['host'])) {
            db_execute(
                'UPDATE payments
                 SET status = "failed", admin_notes = "Maya returned an invalid checkout session."
                 WHERE payment_reference = ? AND status = "pending"',
                's',
                [$paymentReference]
            );

            return ['ok' => false, 'message' => 'The payment gateway returned an invalid checkout link. Please try again.'];
        }

        if (!db_execute(
            'UPDATE payments
             SET provider_checkout_id = ?, provider_checkout_url = ?
             WHERE payment_reference = ? AND status = "pending"',
            'sss',
            [$checkoutId, $checkoutUrl, $paymentReference]
        )) {
            return ['ok' => false, 'message' => 'Your checkout was created but could not be saved. Please contact support before paying.'];
        }

        create_notification(
            (int) $booking['user_id'],
            'payment',
            'GCash checkout ready',
            'Complete your secure GCash payment through Maya Checkout. Your booking and QR ticket will be confirmed automatically after payment is verified.',
            $bookingId
        );
        create_audit_log(
            (int) ($_SESSION['user_id'] ?? $booking['user_id']),
            'payment.gcash_checkout_created',
            'payment',
            (int) $payment['payment_id'],
            'Maya Checkout GCash checkout created.',
            ['payment_reference' => $paymentReference, 'amount' => $amount]
        );

        return ['ok' => true, 'checkout_url' => $checkoutUrl, 'message' => 'Your secure GCash checkout is ready.'];
    }
}

if (!function_exists('maya_webhook_request_is_trusted')) {
    /**
     * Maya Checkout currently authenticates webhook delivery by source IP.
     * The handler also retrieves the payment using the secret API key before
     * it changes booking state, so an IP check is never the only validation.
     */
    function maya_webhook_request_is_trusted(): bool
    {
        $remoteAddress = trim((string) ($_SERVER['REMOTE_ADDR'] ?? ''));
        if ($remoteAddress === '') {
            return false;
        }

        $allowedIps = array_values(array_filter(array_map('trim', explode(',', MAYA_WEBHOOK_ALLOWED_IPS))));

        return in_array($remoteAddress, $allowedIps, true);
    }
}

if (!function_exists('confirm_maya_checkout_payment')) {
    /**
     * Retrieves and applies a Maya PAYMENT_SUCCESS transaction exactly once,
     * issuing the booking's signed QR tickets within the same database action.
     */
    function confirm_maya_checkout_payment(array $event): array
    {
        global $conn;

        $checkoutId = trim((string) ($event['id'] ?? ''));
        $webhookReference = trim((string) ($event['requestReferenceNumber'] ?? ''));
        if ($checkoutId === '' || $webhookReference === '') {
            return ['ok' => false, 'message' => 'Incomplete Maya webhook payload.'];
        }

        // Never trust the body alone. Fetch the transaction directly from Maya
        // with the secret key and only continue with the verified response.
        $verification = maya_api_request(
            'GET',
            '/payments/v1/payments/' . rawurlencode($checkoutId),
            null,
            'secret'
        );
        if (!$verification['ok']) {
            return ['ok' => false, 'message' => 'Unable to verify the Maya transaction.'];
        }

        $verifiedPayment = $verification['data'];
        if (is_array($verifiedPayment) && isset($verifiedPayment['data']) && is_array($verifiedPayment['data'])) {
            $verifiedPayment = $verifiedPayment['data'];
        }
        if (!is_array($verifiedPayment)) {
            return ['ok' => false, 'message' => 'Maya returned invalid payment data.'];
        }

        $verifiedCheckoutId = trim((string) ($verifiedPayment['id'] ?? ''));
        $paymentReference = trim((string) ($verifiedPayment['requestReferenceNumber'] ?? ''));
        $paymentStatus = strtoupper(trim((string) ($verifiedPayment['paymentStatus'] ?? $verifiedPayment['status'] ?? '')));
        $providerPaymentId = trim((string) (
            $verifiedPayment['transactionReferenceNumber']
            ?? $verifiedPayment['receiptNumber']
            ?? $checkoutId
        ));
        $totalAmount = $verifiedPayment['totalAmount'] ?? [];
        $paidAmount = is_array($totalAmount)
            ? (float) ($totalAmount['value'] ?? 0)
            : (float) ($verifiedPayment['amount'] ?? 0);
        $currency = strtoupper(trim((string) (
            is_array($totalAmount)
                ? ($totalAmount['currency'] ?? $verifiedPayment['currency'] ?? '')
                : ($verifiedPayment['currency'] ?? '')
        )));
        if ($paymentStatus !== 'PAYMENT_SUCCESS'
            || $verifiedCheckoutId === ''
            || !hash_equals($checkoutId, $verifiedCheckoutId)
            || $paymentReference === ''
            || !hash_equals($webhookReference, $paymentReference)
            || $providerPaymentId === ''
            || $paidAmount < 0.01
            || $currency !== 'PHP') {
            return ['ok' => false, 'message' => 'Maya did not verify this as a completed PHP payment.'];
        }

        $conn->begin_transaction();

        try {
            $payment = db_select_one(
                'SELECT p.payment_id, p.booking_id, p.payment_reference, p.amount, p.status, p.payment_method, p.provider,
                        p.provider_checkout_id, p.provider_payment_id,
                        b.user_id, b.status AS booking_status, b.payment_status
                 FROM payments p
                 JOIN bookings b ON p.booking_id = b.booking_id
                 WHERE p.provider_checkout_id = ?
                 FOR UPDATE',
                's',
                [$checkoutId]
            );

            if (!$payment
                || (string) ($payment['provider'] ?? '') !== 'maya'
                || (string) ($payment['payment_method'] ?? '') !== 'gcash'
                || !hash_equals((string) $payment['payment_reference'], $paymentReference)) {
                throw new RuntimeException('Payment record does not match this checkout session.');
            }

            if (abs($paidAmount - (float) $payment['amount']) > 0.0001) {
                throw new RuntimeException('Payment amount does not match the booking total.');
            }

            if ((string) ($payment['status'] ?? '') === 'paid') {
                if ((string) ($payment['provider_payment_id'] ?? '') !== ''
                    && !hash_equals((string) $payment['provider_payment_id'], $providerPaymentId)) {
                    throw new RuntimeException('A different payment was already recorded for this checkout.');
                }
                $conn->commit();
                return ['ok' => true, 'message' => 'Duplicate payment notification acknowledged.'];
            }

            if (!db_execute(
                'UPDATE payments
                 SET status = "paid", provider_payment_id = ?, admin_notes = "Verified automatically by Maya Checkout.",
                     verified_at = NOW(), verified_by = NULL
                 WHERE payment_id = ?',
                'si',
                [$providerPaymentId, (int) $payment['payment_id']]
            )) {
                throw new RuntimeException('Unable to record the verified payment.');
            }

            if (in_array((string) ($payment['booking_status'] ?? ''), ['cancelled', 'expired'], true)) {
                db_execute(
                    'UPDATE bookings SET payment_status = "paid", updated_at = NOW() WHERE booking_id = ?',
                    'i',
                    [(int) $payment['booking_id']]
                );
                create_notification(
                    (int) $payment['user_id'],
                    'payment',
                    'GCash payment received after booking closure',
                    'Your GCash payment was received, but the booking was already closed. Staff will contact you about the next step.',
                    (int) $payment['booking_id']
                );
                $conn->commit();

                return ['ok' => true, 'message' => 'Payment recorded for a closed booking.'];
            }

            if (!db_execute(
                'UPDATE bookings
                 SET status = "confirmed", payment_status = "paid", expires_at = NULL,
                     confirmed_at = COALESCE(confirmed_at, NOW()), updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [(int) $payment['booking_id']]
            )) {
                throw new RuntimeException('Unable to confirm the booking.');
            }

            if (!issue_booking_tickets((int) $payment['booking_id'])) {
                $conn->rollback();

                // The fare is genuine even if no final seat can be assigned.
                // Record that fact and keep the booking out of the automatic
                // ticket path so staff can resolve or refund it safely.
                return record_maya_payment_needing_attention(
                    (int) $payment['payment_id'],
                    (int) $payment['booking_id'],
                    (int) $payment['user_id'],
                    $providerPaymentId
                );
            }

            create_notification(
                (int) $payment['user_id'],
                'payment',
                'GCash payment confirmed',
                'Your GCash payment was verified automatically. Your booking is confirmed and your QR ticket is ready.',
                (int) $payment['booking_id']
            );
            create_audit_log(
                null,
                'payment.gcash_auto_confirmed',
                'payment',
                (int) $payment['payment_id'],
                'Maya Checkout verified GCash payment and issued QR ticket automatically.',
                [
                    'booking_id' => (int) $payment['booking_id'],
                    'payment_reference' => $paymentReference,
                    'provider_payment_id' => $providerPaymentId,
                ]
            );

            $conn->commit();
            return ['ok' => true, 'message' => 'Payment confirmed and QR ticket issued.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('record_maya_checkout_not_paid')) {
    /**
     * Records terminal Maya outcomes that do not collect a fare, allowing the
     * passenger to start a fresh checkout rather than being stuck on a dead link.
     */
    function record_maya_checkout_not_paid(array $event): array
    {
        $checkoutId = trim((string) ($event['id'] ?? ''));
        $webhookReference = trim((string) ($event['requestReferenceNumber'] ?? ''));
        if ($checkoutId === '' || $webhookReference === '') {
            return ['ok' => false, 'message' => 'Incomplete Maya webhook payload.'];
        }

        $verification = maya_api_request(
            'GET',
            '/payments/v1/payments/' . rawurlencode($checkoutId),
            null,
            'secret'
        );
        if (!$verification['ok']) {
            return ['ok' => false, 'message' => 'Unable to verify the Maya transaction.'];
        }

        $verifiedPayment = $verification['data'];
        if (is_array($verifiedPayment) && isset($verifiedPayment['data']) && is_array($verifiedPayment['data'])) {
            $verifiedPayment = $verifiedPayment['data'];
        }
        if (!is_array($verifiedPayment)) {
            return ['ok' => false, 'message' => 'Maya returned invalid payment data.'];
        }

        $verifiedCheckoutId = trim((string) ($verifiedPayment['id'] ?? ''));
        $paymentReference = trim((string) ($verifiedPayment['requestReferenceNumber'] ?? ''));
        $paymentStatus = strtoupper(trim((string) ($verifiedPayment['paymentStatus'] ?? $verifiedPayment['status'] ?? '')));
        if (!in_array($paymentStatus, ['PAYMENT_FAILED', 'PAYMENT_CANCELLED', 'PAYMENT_EXPIRED'], true)
            || $verifiedCheckoutId === ''
            || !hash_equals($checkoutId, $verifiedCheckoutId)
            || $paymentReference === ''
            || !hash_equals($webhookReference, $paymentReference)) {
            return ['ok' => false, 'message' => 'Maya payment outcome could not be verified.'];
        }

        $message = $paymentStatus === 'PAYMENT_EXPIRED'
            ? 'Maya checkout expired before payment was completed.'
            : ($paymentStatus === 'PAYMENT_CANCELLED'
                ? 'Maya checkout was cancelled by the customer.'
                : 'Maya Checkout reported that payment failed.');
        db_execute(
            'UPDATE payments p
             JOIN bookings b ON p.booking_id = b.booking_id
             SET p.status = "failed", p.admin_notes = ?,
                 b.status = CASE WHEN b.payment_status <> "paid" THEN "pending" ELSE b.status END,
                 b.payment_status = CASE WHEN b.payment_status <> "paid" THEN "failed" ELSE b.payment_status END,
                 b.updated_at = NOW()
             WHERE p.provider_checkout_id = ?
               AND p.provider = "maya"
               AND p.payment_reference = ?
               AND p.status = "pending"',
            'sss',
            [$message, $checkoutId, $paymentReference]
        );

        return ['ok' => true, 'message' => 'Maya checkout outcome recorded.'];
    }
}

if (!function_exists('process_maya_checkout_webhook')) {
    function process_maya_checkout_webhook(array $event): array
    {
        $paymentStatus = strtoupper(trim((string) ($event['paymentStatus'] ?? $event['status'] ?? '')));

        if ($paymentStatus === 'PAYMENT_SUCCESS') {
            return confirm_maya_checkout_payment($event);
        }

        if (in_array($paymentStatus, ['PAYMENT_FAILED', 'PAYMENT_CANCELLED', 'PAYMENT_EXPIRED'], true)) {
            return record_maya_checkout_not_paid($event);
        }

        // The endpoint may receive a replay or a future non-terminal event.
        // Acknowledge it without changing a booking.
        return ['ok' => true, 'message' => 'Maya webhook acknowledged.'];
    }
}

if (!function_exists('record_maya_payment_needing_attention')) {
    function record_maya_payment_needing_attention(int $paymentId, int $bookingId, int $userId, string $providerPaymentId): array
    {
        global $conn;

        $conn->begin_transaction();
        try {
            db_execute(
                'UPDATE payments
                 SET status = "paid", provider_payment_id = ?,
                     admin_notes = "Verified automatically by Maya Checkout; final seat assignment needs staff attention.",
                     verified_at = NOW(), verified_by = NULL
                 WHERE payment_id = ?',
                'si',
                [$providerPaymentId, $paymentId]
            );
            db_execute(
                'UPDATE bookings
                 SET status = "payment_review", payment_status = "paid", updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [$bookingId]
            );
            create_notification(
                $userId,
                'payment',
                'GCash payment verified',
                'Your GCash payment was verified automatically. Staff are finalizing your seat assignment before the QR ticket is issued.',
                $bookingId
            );
            create_audit_log(
                null,
                'payment.gcash_auto_confirmed_attention_required',
                'payment',
                $paymentId,
                'Maya Checkout verified GCash payment but automatic ticket issuance could not complete.',
                ['booking_id' => $bookingId, 'provider_payment_id' => $providerPaymentId]
            );
            $conn->commit();

            return ['ok' => true, 'message' => 'Payment recorded; ticket assignment needs staff attention.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('paymongo_webhook_signature_is_valid')) {
    function paymongo_webhook_signature_is_valid(string $payload, string $signature): bool
    {
        if (PAYMONGO_WEBHOOK_SECRET === '' || $signature === '') {
            return false;
        }
        $parts = [];
        foreach (explode(',', $signature) as $part) {
            [$key, $value] = array_pad(explode('=', $part, 2), 2, '');
            $parts[trim($key)] = trim($value);
        }
        $timestamp = $parts['t'] ?? '';
        $testSignature = $parts['te'] ?? '';
        $liveSignature = $parts['li'] ?? '';
        if ($timestamp === '' || !ctype_digit($timestamp) || abs(time() - (int) $timestamp) > 300) {
            return false;
        }
        $expected = hash_hmac('sha256', $timestamp . '.' . $payload, PAYMONGO_WEBHOOK_SECRET);
        $provided = APP_ENV === 'production' ? $liveSignature : ($liveSignature !== '' ? $liveSignature : $testSignature);
        return $provided !== '' && hash_equals($expected, $provided);
    }
}

if (!function_exists('confirm_paymongo_checkout')) {
    function confirm_paymongo_checkout(string $checkoutId): array
    {
        global $conn;
        $verification = paymongo_api_request('GET', '/v1/checkout_sessions/' . rawurlencode($checkoutId));
        $session = $verification['data']['data'] ?? [];
        $attributes = $session['attributes'] ?? [];
        $intentAttributes = $attributes['payment_intent']['attributes'] ?? [];
        $payments = is_array($attributes['payments'] ?? null) ? $attributes['payments'] : [];

        // PayMongo exposes the completed payment on the Checkout Session for
        // secret-key requests. Keep a fallback for responses that only include
        // it inside payment_intent.attributes.payments, and select the paid
        // attempt when a customer retried a failed checkout.
        if ($payments === [] && is_array($intentAttributes['payments'] ?? null)) {
            $payments = $intentAttributes['payments'];
        }
        $paymentData = [];
        foreach (array_reverse($payments) as $candidatePayment) {
            $candidateStatus = strtolower((string) ($candidatePayment['attributes']['status'] ?? ''));
            if ($candidateStatus === 'paid') {
                $paymentData = $candidatePayment;
                break;
            }
        }
        if ($paymentData === [] && $payments !== []) {
            $paymentData = $payments[count($payments) - 1];
        }

        $paymentAttributes = $paymentData['attributes'] ?? [];
        $paymentStatus = strtolower((string) ($paymentAttributes['status'] ?? ''));
        $intentStatus = strtolower((string) ($intentAttributes['status'] ?? ''));
        $checkoutStatus = strtolower((string) ($attributes['status'] ?? ''));
        $isPaid = $paymentStatus === 'paid' || $intentStatus === 'succeeded' || $checkoutStatus === 'paid';
        $paidAmount = (int) ($paymentAttributes['amount'] ?? $intentAttributes['amount'] ?? $attributes['amount'] ?? 0);
        $currency = strtoupper((string) ($paymentAttributes['currency'] ?? $intentAttributes['currency'] ?? $attributes['currency'] ?? ''));
        $providerPaymentId = trim((string) ($paymentData['id'] ?? ''));
        if (!$verification['ok'] || !$isPaid || $providerPaymentId === '' || $paidAmount < 1 || $currency !== 'PHP') {
            return ['ok' => false, 'message' => 'PayMongo did not verify a completed PHP payment.'];
        }

        $conn->begin_transaction();
        try {
            $payment = db_select_one(
            'SELECT p.*, b.user_id, b.status AS booking_status, b.payment_status
             FROM payments p
             JOIN bookings b ON p.booking_id = b.booking_id
             WHERE p.provider = "paymongo" AND p.provider_checkout_id = ?
             FOR UPDATE',
                's', [$checkoutId]
            );
            if (!$payment || abs(((float) $payment['amount'] * 100) - $paidAmount) > 0.01) {
                throw new RuntimeException('PayMongo payment does not match the booking.');
            }
            if ((string) $payment['status'] === 'paid') {
                if (!ensure_paid_booking_tickets((int) $payment['booking_id'])) {
                    throw new RuntimeException('Payment was already verified, but ticket issuance needs staff attention.');
                }
                $conn->commit();
                return ['ok' => true, 'message' => 'PayMongo payment was already confirmed and the ticket is ready.'];
            }
            db_execute('UPDATE payments SET status = "paid", provider_payment_id = ?, admin_notes = "Verified automatically by PayMongo.", verified_at = NOW(), verified_by = NULL WHERE payment_id = ?', 'si', [$providerPaymentId, (int) $payment['payment_id']]);
            if (in_array((string) $payment['booking_status'], ['cancelled', 'expired'], true)) {
                db_execute('UPDATE bookings SET payment_status = "paid", updated_at = NOW() WHERE booking_id = ?', 'i', [(int) $payment['booking_id']]);
                if (!ensure_paid_booking_tickets((int) $payment['booking_id'])) {
                    throw new RuntimeException('Payment verified but ticket issuance needs staff attention.');
                }
            } else {
                db_execute('UPDATE bookings SET status = "confirmed", payment_status = "paid", expires_at = NULL, confirmed_at = COALESCE(confirmed_at, NOW()), updated_at = NOW() WHERE booking_id = ?', 'i', [(int) $payment['booking_id']]);
                if (!issue_booking_tickets((int) $payment['booking_id'])) {
                    throw new RuntimeException('Payment verified but ticket issuance needs staff attention.');
                }
            }
            create_notification((int) $payment['user_id'], 'payment', 'GCash payment confirmed', 'Your PayMongo payment was verified automatically and your booking is confirmed.', (int) $payment['booking_id']);
            create_audit_log(null, 'payment.paymongo_auto_confirmed', 'payment', (int) $payment['payment_id'], 'PayMongo verified payment and issued QR ticket.', ['provider_payment_id' => $providerPaymentId]);
            $conn->commit();
            return ['ok' => true, 'message' => 'PayMongo payment confirmed.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('submit_payment_for_booking')) {
    function submit_payment_for_booking(int $bookingId, string $paymentMethod, float $amount, ?string $proofPath = null): array
    {
        global $conn;

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.status, b.payment_status, b.payment_method, b.number_of_passengers,
                    s.departure_date, s.departure_time
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }

        if ($paymentMethod !== 'qrph') {
            return ['ok' => false, 'message' => 'Please choose a valid payment method.'];
        }

        if ($paymentMethod === 'qrph') {
            return start_gcash_checkout($bookingId);
        }

        if (in_array($booking['status'], ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This booking is no longer payable.'];
        }

        $passengerCount = db_select_one(
            'SELECT COUNT(*) AS total FROM passengers WHERE booking_id = ?',
            'i',
            [$bookingId]
        );

        if ((int) ($passengerCount['total'] ?? 0) !== (int) ($booking['number_of_passengers'] ?? 0)) {
            return ['ok' => false, 'message' => 'Please complete the passenger details before going to payment.'];
        }

        if (user_has_active_cash_booking((int) $booking['user_id'], $bookingId)) {
            return ['ok' => false, 'message' => 'Pay at terminal is limited to one active future booking per account. Please cancel or complete your other terminal pay booking first.'];
        }

        $conn->begin_transaction();

        try {
            db_execute(
                'DELETE FROM payments WHERE booking_id = ? AND payment_method = "cash" AND status IN ("pending", "rejected")',
                'i',
                [$bookingId]
            );

            $paymentReference = generate_reference('PAY', 8);
            $paymentStatus = 'pending';
            $cashClaimDeadline = null;

            $departureTimestamp = departure_timestamp(
                (string) ($booking['departure_date'] ?? ''),
                (string) ($booking['departure_time'] ?? '')
            );

            if ($departureTimestamp === null || $departureTimestamp <= time()) {
                throw new RuntimeException('This trip already left and can no longer be claimed for terminal payment.');
            }

            $cashClaimDeadline = date('Y-m-d H:i:s', $departureTimestamp);
            ensure_booking_claim_code($bookingId, (string) ($booking['claim_code'] ?? ''));

            if (!db_execute(
                'INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, submitted_at)
                 VALUES (?, ?, "cash", ?, ?, NOW())',
                'isds',
                [$bookingId, $paymentReference, $amount, $paymentStatus]
            )) {
                throw new RuntimeException('Unable to save the payment record.');
            }

            $newBookingStatus = 'pending';
            $newPaymentStatus = 'pending';

            if (!db_execute(
                'UPDATE bookings
                 SET payment_method = ?,
                     payment_status = ?,
                     status = ?,
                     expires_at = ?,
                     confirmed_at = CASE WHEN ? = "confirmed" THEN NOW() ELSE NULL END,
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'sssssi',
                ['cash', $newPaymentStatus, $newBookingStatus, $cashClaimDeadline, $newBookingStatus, $bookingId]
            )) {
                throw new RuntimeException('Unable to update the booking payment status.');
            }

            create_notification(
                (int) $booking['user_id'],
                'payment',
                'Terminal payment pending',
                'Your terminal cash ticket is ready. Pay at the terminal before departure on ' . date('M j, Y g:i A', strtotime($cashClaimDeadline)) . '. Your seat selection stays as a preference until staff confirms payment and issues the final ticket.',
                $bookingId
            );

            create_audit_log(
                (int) ($_SESSION['user_id'] ?? $booking['user_id']),
                'payment.cash_submitted',
                'booking',
                $bookingId,
                'Terminal cash payment option selected.',
                [
                    'payment_reference' => $paymentReference,
                    'amount' => $amount,
                    'expires_at' => $cashClaimDeadline,
                ]
            );

            $conn->commit();
            return ['ok' => true, 'message' => 'Pay at terminal selected. Your terminal cash ticket is ready and stays valid until departure at ' . date('M j, Y g:i A', strtotime($cashClaimDeadline)) . '.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('complete_cash_payment_by_booking')) {
    function complete_cash_payment_by_booking(int $bookingId, int $adminUserId, string $notes = ''): array
    {
        global $conn;

        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.schedule_id, b.status, b.payment_status, b.payment_method, b.total_amount, b.expires_at,
                    s.departure_date, s.departure_time
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking record not found.'];
        }

        if (($booking['payment_method'] ?? '') !== 'cash') {
            return ['ok' => false, 'message' => 'Only terminal cash bookings can be completed from this action.'];
        }

        $departureTimestamp = departure_timestamp((string) ($booking['departure_date'] ?? ''), (string) ($booking['departure_time'] ?? ''));
        if ($departureTimestamp !== null && $departureTimestamp <= time()) {
            return ['ok' => false, 'message' => 'This trip already left. Staff or admin must close this pending cash ticket manually.'];
        }

        $rawExpiresAt = trim((string) ($booking['expires_at'] ?? ''));
        if ($rawExpiresAt !== '') {
            $parsedExpiresAt = strtotime($rawExpiresAt);
            if ($parsedExpiresAt !== false && $parsedExpiresAt <= time()) {
                return ['ok' => false, 'message' => 'This trip is already at or past departure. Staff or admin must close this pending cash ticket manually.'];
            }
        }

        if (in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)) {
            return ['ok' => false, 'message' => 'This cash booking is no longer active.'];
        }

        if (($booking['payment_status'] ?? '') === 'paid') {
            if (!in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true)) {
                db_execute(
                    'UPDATE bookings
                     SET status = "confirmed",
                         expires_at = NULL,
                         confirmed_at = COALESCE(confirmed_at, NOW()),
                         updated_at = NOW()
                     WHERE booking_id = ?',
                    'i',
                    [$bookingId]
                );
            }

            issue_booking_tickets($bookingId);

            return ['ok' => true, 'message' => 'Cash payment was already confirmed for this booking.', 'booking_id' => $bookingId];
        }

        $payment = db_select_one(
            'SELECT payment_id, status
             FROM payments
             WHERE booking_id = ?
             AND payment_method = "cash"
             ORDER BY submitted_at DESC, payment_id DESC
             LIMIT 1',
            'i',
            [$bookingId]
        );

        $conn->begin_transaction();

        try {
            if ($payment) {
                db_execute(
                    'UPDATE payments
                     SET status = "paid",
                         admin_notes = ?,
                         verified_at = NOW(),
                         verified_by = ?
                     WHERE payment_id = ?',
                    'sii',
                    [$notes, $adminUserId, (int) $payment['payment_id']]
                );
            } else {
                db_execute(
                    'INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, admin_notes, submitted_at, verified_at, verified_by)
                     VALUES (?, ?, "cash", ?, "paid", ?, NOW(), NOW(), ?)',
                    'isdsi',
                    [$bookingId, generate_reference('PAY', 8), (float) $booking['total_amount'], $notes, $adminUserId]
                );
            }

            db_execute(
                'UPDATE bookings
                 SET status = "confirmed",
                     payment_status = "paid",
                     expires_at = NULL,
                     confirmed_at = NOW(),
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [$bookingId]
            );

            if (!create_booking_tickets_from_preferences($bookingId)) {
                throw new RuntimeException('Unable to assign final seats for this cash booking. Please review the passenger details and available seats first.');
            }

            if (!issue_booking_tickets($bookingId)) {
                throw new RuntimeException('Unable to issue the final ticket for this cash booking.');
            }

            create_notification(
                (int) $booking['user_id'],
                'payment',
                'Cash payment confirmed',
                'Your terminal payment was confirmed by staff. Your final ticket is now ready.',
                $bookingId
            );

            create_audit_log(
                $adminUserId,
                'payment.cash_confirmed',
                'booking',
                $bookingId,
                'Terminal cash payment confirmed and ticket issued.',
                [
                    'amount' => (float) ($booking['total_amount'] ?? 0),
                    'schedule_id' => (int) ($booking['schedule_id'] ?? 0),
                    'notes' => $notes,
                ]
            );

            $conn->commit();

            return ['ok' => true, 'message' => 'Cash payment confirmed and final ticket issued successfully.', 'booking_id' => $bookingId];
        } catch (Throwable $exception) {
            $conn->rollback();

            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('complete_cash_payment')) {
    function complete_cash_payment(int $paymentId, int $adminUserId, string $notes = ''): array
    {
        $payment = db_select_one(
            'SELECT payment_id, booking_id, payment_method
             FROM payments
             WHERE payment_id = ?
             LIMIT 1',
            'i',
            [$paymentId]
        );

        if (!$payment) {
            return ['ok' => false, 'message' => 'Payment record not found.'];
        }

        if (($payment['payment_method'] ?? '') !== 'cash') {
            return ['ok' => false, 'message' => 'Only terminal cash payments can be completed from this queue.'];
        }

        return complete_cash_payment_by_booking((int) $payment['booking_id'], $adminUserId, $notes);
    }
}

if (!function_exists('approve_payment')) {
    function approve_payment(int $paymentId, int $adminUserId, string $notes = ''): array
    {
        // GCash is no longer approved from a receipt queue. Only the signed
        // Maya Checkout webhook can mark a gateway transaction as paid.
        return ['ok' => false, 'message' => 'GCash payments are confirmed automatically by the payment gateway and cannot be approved manually.'];

        global $conn;

        $payment = db_select_one(
            'SELECT payment_id, booking_id, payment_method, status
             FROM payments
             WHERE payment_id = ?
             LIMIT 1',
            'i',
            [$paymentId]
        );

        if (!$payment) {
            return ['ok' => false, 'message' => 'Payment record not found.'];
        }

        if ($payment['payment_method'] !== 'gcash') {
            return ['ok' => false, 'message' => 'Only GCash uploads require approval from this queue.'];
        }

        if ($payment['status'] !== 'pending') {
            return ['ok' => false, 'message' => 'This payment is no longer waiting for approval.'];
        }

        $booking = db_select_one(
            'SELECT booking_id, user_id FROM bookings WHERE booking_id = ? LIMIT 1',
            'i',
            [(int) $payment['booking_id']]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking record not found.'];
        }

        $conn->begin_transaction();

        try {
            db_execute(
                'UPDATE payments SET status = "paid", admin_notes = ?, verified_at = NOW(), verified_by = ? WHERE payment_id = ?',
                'sii',
                [$notes, $adminUserId, $paymentId]
            );
            db_execute(
                'UPDATE bookings
                 SET status = "confirmed",
                     payment_status = "paid",
                     expires_at = NULL,
                     confirmed_at = NOW(),
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [(int) $payment['booking_id']]
            );

            if (!issue_booking_tickets((int) $payment['booking_id'])) {
                throw new RuntimeException('Payment cannot be approved because no final seat is available for this booking anymore.');
            }

            create_notification(
                (int) $booking['user_id'],
                'payment',
                'Payment approved',
                'Your payment has been approved. Your e-ticket is ready.',
                (int) $payment['booking_id']
            );

            create_audit_log(
                $adminUserId,
                'payment.approved',
                'payment',
                $paymentId,
                'GCash payment approved and booking confirmed.',
                [
                    'booking_id' => (int) $payment['booking_id'],
                    'notes' => $notes,
                ]
            );

            $conn->commit();
            return ['ok' => true, 'message' => 'Payment approved and booking confirmed.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('reject_payment')) {
    function reject_payment(int $paymentId, int $adminUserId, string $notes = ''): array
    {
        // A provider-verified GCash payment must be handled through the
        // provider's refund/dispute process, never by changing local status.
        return ['ok' => false, 'message' => 'GCash payments are managed automatically by the payment gateway and cannot be rejected manually.'];

        global $conn;

        $payment = db_select_one(
            'SELECT payment_id, booking_id, payment_method, status
             FROM payments
             WHERE payment_id = ?
             LIMIT 1',
            'i',
            [$paymentId]
        );

        if (!$payment) {
            return ['ok' => false, 'message' => 'Payment record not found.'];
        }

        if ($payment['payment_method'] !== 'gcash') {
            return ['ok' => false, 'message' => 'Only GCash uploads can be rejected from this queue.'];
        }

        if ($payment['status'] !== 'pending') {
            return ['ok' => false, 'message' => 'This payment is no longer waiting for review.'];
        }

        $booking = db_select_one(
            'SELECT booking_id, user_id FROM bookings WHERE booking_id = ? LIMIT 1',
            'i',
            [(int) $payment['booking_id']]
        );

        if (!$booking) {
            return ['ok' => false, 'message' => 'Booking record not found.'];
        }

        $conn->begin_transaction();

        try {
            db_execute(
                'UPDATE payments SET status = "rejected", admin_notes = ?, verified_at = NOW(), verified_by = ? WHERE payment_id = ?',
                'sii',
                [$notes, $adminUserId, $paymentId]
            );
            db_execute(
                'UPDATE bookings
                 SET status = "pending",
                     payment_status = "failed",
                     expires_at = NULL,
                     updated_at = NOW()
                 WHERE booking_id = ?',
                'i',
                [(int) $payment['booking_id']]
            );

            create_notification(
                (int) $booking['user_id'],
                'payment',
                'Payment rejected',
                'Your payment proof was rejected. Please re-upload a valid proof.',
                (int) $payment['booking_id']
            );

            create_audit_log(
                $adminUserId,
                'payment.rejected',
                'payment',
                $paymentId,
                'GCash payment rejected.',
                [
                    'booking_id' => (int) $payment['booking_id'],
                    'notes' => $notes,
                ]
            );

            $conn->commit();
            return ['ok' => true, 'message' => 'Payment rejected.'];
        } catch (Throwable $exception) {
            $conn->rollback();
            return ['ok' => false, 'message' => $exception->getMessage()];
        }
    }
}

if (!function_exists('cancel_booking_by_admin')) {
    function cancel_booking_by_admin(int $bookingId): array
    {
        $released = release_booking_hold($bookingId, 'cancelled', true);

        return [
            'ok' => $released,
            'message' => $released ? 'Booking cancelled successfully.' : 'Unable to cancel the booking.',
        ];
    }
}

if (!function_exists('cancel_booking_by_user')) {
    function cancel_booking_by_user(int $bookingId, int $userId): array
    {
        $booking = db_select_one(
            'SELECT b.booking_id, b.user_id, b.status, b.payment_status, b.payment_method,
                    s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time
             FROM bookings b
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE b.booking_id = ?
             LIMIT 1',
            'i',
            [$bookingId]
        );

        if (!$booking || (int) $booking['user_id'] !== $userId) {
            return ['ok' => false, 'message' => 'Booking not found.'];
        }

        $cancellationState = booking_user_cancellation_state($booking);
        if (!$cancellationState['can_cancel']) {
            return ['ok' => false, 'message' => (string) ($cancellationState['message'] ?? 'This booking can no longer be cancelled.')];
        }

        $released = release_booking_hold($bookingId, 'cancelled', true);

        return [
            'ok' => $released,
            'message' => $released ? 'Booking cancelled successfully.' : 'Unable to cancel the booking.',
        ];
    }
}

if (!function_exists('validate_cash_claim_qr')) {
    function validate_cash_claim_qr(array $payloadData): array
    {
        $claimCode = strtoupper(trim((string) ($payloadData['claim_code'] ?? '')));
        $bookingId = (int) ($payloadData['booking_id'] ?? 0);
        $bookingReference = (string) ($payloadData['booking_reference'] ?? '');

        if ($claimCode !== '') {
            $booking = get_cash_claim_summary_by_code($claimCode);
            if (!$booking) {
                return ['status' => 'invalid', 'message' => 'Cash ticket not found.'];
            }

            return evaluate_cash_claim_summary($booking);
        }

        if ($bookingId < 1 || $bookingReference === '') {
            return ['status' => 'invalid', 'message' => 'Cash claim data is incomplete.'];
        }

        $booking = get_cash_claim_summary($bookingId);
        if (!$booking || (string) ($booking['booking_reference'] ?? '') !== $bookingReference) {
            return ['status' => 'invalid', 'message' => 'Cash claim booking not found.'];
        }

        if (($booking['payment_method'] ?? '') !== 'cash') {
            return ['status' => 'invalid', 'message' => 'This QR is not a terminal cash claim.'];
        }

        return evaluate_cash_claim_summary($booking);
    }
}

if (!function_exists('validate_ticket_qr')) {
    function validate_ticket_qr(string $rawPayload, int $scannerUserId = 0): array
    {
        global $conn;

        if ($scannerUserId < 1) {
            return ['status' => 'invalid', 'message' => 'An authenticated staff session is required to scan tickets.'];
        }

        $rawPayload = trim($rawPayload);
        if ($rawPayload === '') {
            return ['status' => 'invalid', 'message' => 'No QR data received.'];
        }

        $decodedJson = json_decode($rawPayload, true);
        $ticketCode = '';
        $payloadData = null;

        if (is_array($decodedJson) && isset($decodedJson['payload'], $decodedJson['sig'])) {
            $payload = (string) $decodedJson['payload'];
            $signature = (string) $decodedJson['sig'];

            if (!hash_equals(hash_hmac('sha256', $payload, APP_QR_SECRET), $signature)) {
                return ['status' => 'invalid', 'message' => 'QR signature mismatch.'];
            }

            $payloadData = json_decode(base64_decode($payload, true) ?: '', true);
            if (is_array($payloadData) && (($payloadData['type'] ?? '') === 'cash_claim')) {
                return validate_cash_claim_qr($payloadData);
            }

            $ticketCode = (string) (($payloadData['ticket_code'] ?? '') ?: '');
        } else {
            $ticketCode = $rawPayload;
        }

        if ($ticketCode === '') {
            return ['status' => 'invalid', 'message' => 'Ticket code missing from QR payload.'];
        }

        $cashClaim = get_cash_claim_summary_by_code($ticketCode);
        if ($cashClaim && ($cashClaim['payment_method'] ?? '') === 'cash') {
            return evaluate_cash_claim_summary($cashClaim);
        }

        $ticket = db_select_one(
            "SELECT t.ticket_id, t.ticket_code, t.ticket_status, t.booking_id, t.issued_at, t.used_at,
                    b.booking_reference, b.status AS booking_status, b.payment_status,
                    p.fullname AS passenger_name,
                    s2.seat_label,
                    sch.status AS schedule_status, sch.departure_date, sch.departure_time, sch.arrival_time,
                    origin.terminal_name AS origin_name,
                    destination.terminal_name AS destination_name
             FROM tickets t
             JOIN bookings b ON t.booking_id = b.booking_id
             LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
             JOIN seats s2 ON t.seat_id = s2.seat_id
             JOIN schedules sch ON t.schedule_id = sch.schedule_id
             JOIN routes r ON sch.route_id = r.route_id
             JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
             JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
             WHERE t.ticket_code = ?
             LIMIT 1",
            's',
            [$ticketCode]
        );

        if (!$ticket) {
            return ['status' => 'invalid', 'message' => 'Ticket not found.'];
        }

        $scanStatus = 'valid';
        $scanMessage = 'Ticket validated successfully.';

        $tripStatus = effective_schedule_trip_status([
            'status' => (string) ($ticket['schedule_status'] ?? 'scheduled'),
            'departure_date' => (string) ($ticket['departure_date'] ?? ''),
            'departure_time' => (string) ($ticket['departure_time'] ?? ''),
            'arrival_time' => (string) ($ticket['arrival_time'] ?? ''),
        ]);

        if (($ticket['schedule_status'] ?? '') === 'cancelled' || $tripStatus === 'cancelled') {
            $scanStatus = 'invalid';
            $scanMessage = 'This trip has been cancelled.';
        } elseif ($tripStatus === 'arrived') {
            $scanStatus = 'invalid';
            $scanMessage = 'This ticket is no longer valid because the trip has arrived.';
        } elseif ($tripStatus !== 'boarding') {
            $scanStatus = 'invalid';
            $scanMessage = 'This ticket can only be validated during the 30-minute boarding window.';
        } elseif (($ticket['ticket_status'] ?? '') === 'used') {
            $scanStatus = 'already_used';
            $scanMessage = 'This ticket has already been scanned.';
        } elseif (!in_array($ticket['booking_status'] ?? '', ['confirmed', 'used'], true)) {
            $scanStatus = 'invalid';
            $scanMessage = 'This booking is not confirmed.';
        } elseif (($ticket['ticket_status'] ?? '') !== 'issued') {
            $scanStatus = 'invalid';
            $scanMessage = 'This ticket has not been issued for boarding.';
        } else {
            $stmt = $conn->prepare(
                'UPDATE tickets
                 SET ticket_status = "used", used_at = NOW(), scanned_by = ?
                 WHERE ticket_id = ? AND ticket_status = "issued"'
            );
            if (!$stmt) {
                $scanStatus = 'invalid';
                $scanMessage = 'Unable to validate the ticket right now.';
            } else {
                $ticketId = (int) $ticket['ticket_id'];
                $stmt->bind_param('ii', $scannerUserId, $ticketId);
                $updated = $stmt->execute() && $stmt->affected_rows === 1;
                $stmt->close();

                if (!$updated) {
                    $scanStatus = 'already_used';
                    $scanMessage = 'This ticket has already been scanned.';
                } else {
                    $remainingIssued = db_select_one(
                        'SELECT COUNT(*) AS total FROM tickets WHERE booking_id = ? AND ticket_status <> "used"',
                        'i',
                        [(int) $ticket['booking_id']]
                    );

                    if ((int) ($remainingIssued['total'] ?? 0) === 0) {
                        db_execute(
                            'UPDATE bookings SET status = "used", updated_at = NOW() WHERE booking_id = ?',
                            'i',
                            [(int) $ticket['booking_id']]
                        );
                    }
                }
            }
        }

        $recentLog = db_select_one(
            'SELECT log_id
             FROM qr_logs
             WHERE ticket_id = ?
             AND scan_status = ?
             AND scan_payload = ?
             AND scanned_at >= DATE_SUB(NOW(), INTERVAL 8 SECOND)
             ORDER BY log_id DESC
             LIMIT 1',
            'iss',
            [(int) $ticket['ticket_id'], $scanStatus, $rawPayload]
        );

        if (!$recentLog) {
            db_execute(
                'INSERT INTO qr_logs (ticket_id, scanned_by, scan_status, scan_message, scan_payload) VALUES (?, ?, ?, ?, ?)',
                'iisss',
                [(int) $ticket['ticket_id'], $scannerUserId, $scanStatus, $scanMessage, $rawPayload]
            );
        }

        if ($scannerUserId > 0) {
            create_audit_log(
                $scannerUserId,
                'scanner.' . $scanStatus,
                'ticket',
                (int) $ticket['ticket_id'],
                $scanMessage,
                [
                    'booking_id' => (int) ($ticket['booking_id'] ?? 0),
                    'ticket_code' => (string) ($ticket['ticket_code'] ?? ''),
                ]
            );
        }

        return [
            'status' => $scanStatus,
            'message' => $scanMessage,
            'ticket' => $ticket,
        ];
    }
}

if (!function_exists('seed_default_roles')) {
    function seed_default_roles(): void
    {
        $roles = [
            ['admin', 'Administrator', 'Full control of the platform.'],
            ['staff', 'Staff', 'Operational access for payments, bookings, and QR validation.'],
            ['passenger', 'Passenger', 'Standard passenger account.'],
        ];

        foreach ($roles as $role) {
            db_execute(
                'INSERT INTO roles (role_key, role_name, description)
                 SELECT ?, ?, ?
                 FROM DUAL
                 WHERE NOT EXISTS (SELECT 1 FROM roles WHERE role_key = ?)',
                'ssss',
                [$role[0], $role[1], $role[2], $role[0]]
            );
        }
    }
}

if (!function_exists('backfill_user_roles')) {
    function backfill_user_roles(): void
    {
        $adminRole = db_select_one('SELECT role_id FROM roles WHERE role_key = "admin" LIMIT 1');
        $passengerRole = db_select_one('SELECT role_id FROM roles WHERE role_key = "passenger" LIMIT 1');

        if (!$adminRole || !$passengerRole) {
            return;
        }

        db_execute(
            'UPDATE users SET role_id = ? WHERE role_id IS NULL AND is_admin = 1',
            'i',
            [(int) $adminRole['role_id']]
        );
        db_execute(
            'UPDATE users SET role_id = ? WHERE role_id IS NULL AND is_admin = 0',
            'i',
            [(int) $passengerRole['role_id']]
        );
        db_execute("UPDATE users SET account_status = 'active' WHERE account_status IS NULL OR account_status = ''");
    }
}

if (!function_exists('ensure_role_account')) {
    function ensure_role_account(string $roleKey, string $email, string $password, string $fullname = 'System User', string $phone = ''): void
    {
        $normalizedPhone = normalize_ph_phone($phone);
        $phone = $normalizedPhone !== '' ? $normalizedPhone : '';

        $role = db_select_one(
            'SELECT role_id, role_key FROM roles WHERE role_key = ? LIMIT 1',
            's',
            [$roleKey]
        );

        if (!$role) {
            return;
        }

        $account = db_select_one(
            'SELECT user_id, password FROM users WHERE email = ? LIMIT 1',
            's',
            [$email]
        );

        $isAdmin = $roleKey === 'admin' ? 1 : 0;

        if ($account) {
            db_execute(
                'UPDATE users
                 SET fullname = ?,
                     phone = ?,
                     role_id = ?,
                     is_admin = ?,
                     account_status = "active",
                     updated_at = NOW()
                 WHERE user_id = ?',
                'ssiii',
                [$fullname, $phone, (int) $role['role_id'], $isAdmin, (int) $account['user_id']]
            );

            if (!verify_password_compat($password, (string) $account['password'], (int) $account['user_id'])) {
                db_execute(
                    'UPDATE users SET password = ? WHERE user_id = ?',
                    'si',
                    [password_hash($password, PASSWORD_BCRYPT), (int) $account['user_id']]
                );
            }

            return;
        }

        db_execute(
            'INSERT INTO users (fullname, email, phone, password, is_admin, role_id, account_status, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, "active", NOW(), NOW())',
            'ssssii',
            [$fullname, $email, $phone, password_hash($password, PASSWORD_BCRYPT), $isAdmin, (int) $role['role_id']]
        );
    }
}

if (!function_exists('ensure_admin_account')) {
    function ensure_admin_account(string $email, string $password, string $fullname = 'Admin User', string $phone = ''): void
    {
        ensure_role_account('admin', $email, $password, $fullname, $phone);
    }
}

if (!function_exists('ensure_staff_account')) {
    function ensure_staff_account(string $email, string $password, string $fullname = 'Staff User', string $phone = ''): void
    {
        ensure_role_account('staff', $email, $password, $fullname, $phone);
    }
}

if (!function_exists('backfill_bus_types')) {
    function backfill_bus_types(): void
    {
        db_execute(
            'UPDATE buses b
             LEFT JOIN bus_classes bc ON b.class_id = bc.class_id
             SET b.bus_name = COALESCE(NULLIF(b.bus_name, ""), b.bus_code),
                 b.bus_type = COALESCE(NULLIF(b.bus_type, ""), bc.class_name, "Regular"),
                 b.is_enabled = COALESCE(b.is_enabled, 1),
                 b.seat_map_columns = COALESCE(b.seat_map_columns, 4)'
        );
    }
}

if (!function_exists('backfill_schedule_metadata')) {
    function backfill_schedule_metadata(): void
    {
        db_execute(
            'UPDATE schedules s
             JOIN buses b ON s.bus_id = b.bus_id
             SET s.bus_type = COALESCE(NULLIF(s.bus_type, ""), b.bus_type)
             WHERE s.bus_type IS NULL OR s.bus_type = ""'
        );

        if (column_exists('schedules', 'trip_status')) {
            db_execute(
                "UPDATE schedules
                 SET trip_status = CASE
                    WHEN status = 'cancelled' THEN 'cancelled'
                    WHEN status = 'completed' THEN 'arrived'
                    ELSE 'scheduled'
                 END
                 WHERE trip_status IS NULL OR trip_status = ''"
            );
        }

        $rows = db_select_all(
            'SELECT schedule_id FROM schedules WHERE schedule_code IS NULL OR schedule_code = ""'
        );

        foreach ($rows as $row) {
            db_execute(
                'UPDATE schedules SET schedule_code = ? WHERE schedule_id = ?',
                'si',
                ['SCH-' . str_pad((string) $row['schedule_id'], 5, '0', STR_PAD_LEFT), (int) $row['schedule_id']]
            );
        }
    }
}

if (!function_exists('backfill_payment_rows')) {
    function backfill_payment_rows(): void
    {
        $bookings = db_select_all(
            'SELECT booking_id, total_amount, payment_method
             FROM bookings
             WHERE payment_status = "paid"
             AND booking_id NOT IN (SELECT booking_id FROM payments)'
        );

        foreach ($bookings as $booking) {
            db_execute(
                'INSERT INTO payments (booking_id, payment_reference, payment_method, amount, status, submitted_at, verified_at)
                 VALUES (?, ?, ?, ?, "paid", NOW(), NOW())',
                'issd',
                [
                    (int) $booking['booking_id'],
                    generate_reference('PAY', 8),
                    $booking['payment_method'] ?: 'legacy',
                    (float) $booking['total_amount'],
                ]
            );
        }
    }
}

if (!function_exists('backfill_ticket_rows')) {
    function backfill_ticket_rows(): void
    {
        $legacyPassengers = db_select_all(
            "SELECT p.passenger_id, p.booking_id, p.seat_number, b.schedule_id, s.bus_id
             FROM passengers p
             JOIN bookings b ON p.booking_id = b.booking_id
             JOIN schedules s ON b.schedule_id = s.schedule_id
             WHERE p.seat_number IS NOT NULL
             AND p.seat_number <> ''
             AND b.status IN ('confirmed', 'used')
             AND p.booking_id NOT IN (SELECT booking_id FROM tickets)"
        );

        foreach ($legacyPassengers as $passenger) {
            $seat = db_select_one(
                'SELECT seat_id FROM seats WHERE bus_id = ? AND seat_label = ? LIMIT 1',
                'is',
                [(int) $passenger['bus_id'], $passenger['seat_number']]
            );

            if (!$seat) {
                continue;
            }

            db_execute(
                'INSERT IGNORE INTO tickets (booking_id, passenger_id, schedule_id, seat_id, ticket_status)
                 VALUES (?, ?, ?, ?, "issued")',
                'iiii',
                [
                    (int) $passenger['booking_id'],
                    (int) $passenger['passenger_id'],
                    (int) $passenger['schedule_id'],
                    (int) $seat['seat_id'],
                ]
            );
        }

        $bookings = db_select_all(
            'SELECT DISTINCT booking_id FROM tickets WHERE ticket_code IS NULL OR ticket_code = ""'
        );

        foreach ($bookings as $booking) {
            issue_booking_tickets((int) $booking['booking_id']);
        }

        // Older completed bookings can have no ticket rows at all, or can
        // have reserved rows without a signed ticket. Re-run the idempotent
        // issuer for those records during the next deployment backfill.
        $completedBookings = db_select_all(
            "SELECT b.booking_id, b.number_of_passengers
             FROM bookings b
             LEFT JOIN tickets t ON t.booking_id = b.booking_id
             WHERE (b.payment_status = 'paid' OR b.status IN ('confirmed', 'used')
                    OR EXISTS(
                        SELECT 1
                        FROM payments p
                        WHERE p.booking_id = b.booking_id
                          AND p.status = 'paid'
                    ))
             GROUP BY b.booking_id, b.number_of_passengers
             HAVING COUNT(t.ticket_id) < b.number_of_passengers
                 OR SUM(CASE WHEN t.ticket_code IS NULL OR t.ticket_code = ''
                              OR t.qr_payload IS NULL OR t.qr_payload = ''
                              OR t.qr_signature IS NULL OR t.qr_signature = ''
                              OR t.ticket_status NOT IN ('issued', 'used')
                             THEN 1 ELSE 0 END) > 0"
        );

        foreach ($completedBookings as $booking) {
            ensure_paid_booking_tickets((int) $booking['booking_id']);
        }
    }
}

if (!function_exists('cleanup_legacy_pending_gcash_holds')) {
    function cleanup_legacy_pending_gcash_holds(): int
    {
        global $conn;

        if (!table_exists('tickets')) {
            return 0;
        }

        $legacyBookings = db_select_all(
            "SELECT DISTINCT b.booking_id, b.schedule_id, COALESCE(b.seat_preferences, '') AS seat_preferences
             FROM bookings b
             JOIN tickets t ON t.booking_id = b.booking_id
             WHERE b.payment_method = 'gcash'
             AND COALESCE(b.payment_status, 'pending') <> 'paid'
             AND b.status NOT IN ('confirmed', 'used')"
        );

        if ($legacyBookings === []) {
            return 0;
        }

        $deletedTickets = 0;
        $scheduleIds = [];

        $conn->begin_transaction();

        try {
            foreach ($legacyBookings as $booking) {
                $bookingId = (int) ($booking['booking_id'] ?? 0);
                $scheduleId = (int) ($booking['schedule_id'] ?? 0);
                if ($bookingId < 1) {
                    continue;
                }

                $seatPreferences = trim((string) ($booking['seat_preferences'] ?? ''));
                if ($seatPreferences === '') {
                    $seatLabels = array_map(
                        static fn(array $row): string => (string) ($row['seat_label'] ?? ''),
                        db_select_all(
                            'SELECT s.seat_label
                             FROM tickets t
                             JOIN seats s ON t.seat_id = s.seat_id
                             WHERE t.booking_id = ?
                             ORDER BY s.seat_number ASC',
                            'i',
                            [$bookingId]
                        )
                    );

                    $seatLabels = array_values(array_filter(array_map('trim', $seatLabels), static fn(string $label): bool => $label !== ''));
                    if ($seatLabels !== []) {
                        db_execute(
                            'UPDATE bookings SET seat_preferences = ?, updated_at = NOW() WHERE booking_id = ?',
                            'si',
                            [encode_booking_seat_preferences($seatLabels), $bookingId]
                        );
                    }
                }

                $ticketRows = db_select_one(
                    'SELECT COUNT(*) AS total FROM tickets WHERE booking_id = ?',
                    'i',
                    [$bookingId]
                );

                db_execute('DELETE FROM tickets WHERE booking_id = ?', 'i', [$bookingId]);

                $deletedTickets += (int) ($ticketRows['total'] ?? 0);
                if ($scheduleId > 0) {
                    $scheduleIds[$scheduleId] = true;
                }
            }

            $conn->commit();
        } catch (Throwable $exception) {
            $conn->rollback();
            return 0;
        }

        foreach (array_keys($scheduleIds) as $scheduleId) {
            sync_schedule_available_seats((int) $scheduleId);
        }

        return $deletedTickets;
    }
}

if (!function_exists('backfill_cash_claim_codes')) {
    function backfill_cash_claim_codes(): void
    {
        $bookings = db_select_all(
            'SELECT booking_id, claim_code
             FROM bookings
             WHERE payment_method = "cash"'
        );

        foreach ($bookings as $booking) {
            ensure_booking_claim_code(
                (int) ($booking['booking_id'] ?? 0),
                (string) ($booking['claim_code'] ?? '')
            );
        }
    }
}

if (!function_exists('run_runtime_housekeeping')) {
    function run_runtime_housekeeping(): void
    {
        static $completed = false;
        if ($completed) {
            return;
        }

        $completed = true;

        $lastRunAt = (int) app_runtime_meta_get('runtime_housekeeping_last_run_at', '0');
        if ($lastRunAt > 0 && (time() - $lastRunAt) < APP_HOUSEKEEPING_INTERVAL_SECONDS) {
            return;
        }

        if (!acquire_database_lock(APP_HOUSEKEEPING_LOCK_NAME, 1)) {
            return;
        }

        try {
            $lastRunAt = (int) app_runtime_meta_get('runtime_housekeeping_last_run_at', '0');
            if ($lastRunAt > 0 && (time() - $lastRunAt) < APP_HOUSEKEEPING_INTERVAL_SECONDS) {
                return;
            }

            expire_pending_bookings();
            materialize_active_schedule_recurrences();
            app_runtime_meta_set('runtime_housekeeping_last_run_at', (string) time());
        } finally {
            release_database_lock(APP_HOUSEKEEPING_LOCK_NAME);
        }
    }
}

if (!function_exists('ensure_schema_migrations')) {
    function ensure_schema_migrations(): void
    {
        global $conn;

        static $completed = false;
        if ($completed) {
            return;
        }

        ensure_app_runtime_meta_table();

        if (app_runtime_meta_get('bootstrap_version', '') === APP_BOOTSTRAP_VERSION) {
            $completed = true;
            return;
        }

        $lockAcquired = acquire_database_lock(APP_BOOTSTRAP_LOCK_NAME, 15);

        try {
            if ($lockAcquired && app_runtime_meta_get('bootstrap_version', '') === APP_BOOTSTRAP_VERSION) {
                $completed = true;
                return;
            }

            $conn->query(
            "CREATE TABLE IF NOT EXISTS roles (
                role_id INT AUTO_INCREMENT PRIMARY KEY,
                role_key VARCHAR(30) NOT NULL UNIQUE,
                role_name VARCHAR(80) NOT NULL,
                description VARCHAR(255) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS bus_operators (
                operator_id INT AUTO_INCREMENT PRIMARY KEY,
                full_name VARCHAR(120) NOT NULL,
                contact_number VARCHAR(20) NULL,
                license_number VARCHAR(60) NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_bus_operator_license (license_number),
                INDEX idx_bus_operators_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS seats (
                seat_id INT AUTO_INCREMENT PRIMARY KEY,
                bus_id INT NOT NULL,
                seat_number INT NOT NULL,
                seat_label VARCHAR(20) NOT NULL,
                seat_row INT NOT NULL,
                seat_column INT NOT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_bus_seat_number (bus_id, seat_number),
                UNIQUE KEY uniq_bus_seat_label (bus_id, seat_label),
                CONSTRAINT fk_seats_bus FOREIGN KEY (bus_id) REFERENCES buses(bus_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS payments (
                payment_id INT AUTO_INCREMENT PRIMARY KEY,
                booking_id INT NOT NULL,
                payment_reference VARCHAR(40) NOT NULL UNIQUE,
                payment_method VARCHAR(30) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                proof_image VARCHAR(255) NULL,
                provider VARCHAR(30) NULL,
                provider_checkout_id VARCHAR(100) NULL,
                provider_checkout_url VARCHAR(2048) NULL,
                provider_payment_id VARCHAR(100) NULL,
                admin_notes TEXT NULL,
                submitted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                verified_at DATETIME NULL,
                verified_by INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_payments_booking (booking_id),
                UNIQUE KEY uniq_payments_provider_checkout (provider_checkout_id),
                UNIQUE KEY uniq_payments_provider_payment (provider_payment_id),
                CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INT AUTO_INCREMENT PRIMARY KEY,
                booking_id INT NOT NULL,
                passenger_id INT NULL,
                schedule_id INT NOT NULL,
                seat_id INT NOT NULL,
                ticket_code VARCHAR(40) NULL UNIQUE,
                qr_payload LONGTEXT NULL,
                qr_signature VARCHAR(128) NULL,
                ticket_status VARCHAR(20) NOT NULL DEFAULT 'reserved',
                issued_at DATETIME NULL,
                used_at DATETIME NULL,
                scanned_by INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uniq_schedule_seat (schedule_id, seat_id),
                INDEX idx_tickets_booking (booking_id),
                CONSTRAINT fk_tickets_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
                CONSTRAINT fk_tickets_passenger FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id) ON DELETE SET NULL,
                CONSTRAINT fk_tickets_schedule FOREIGN KEY (schedule_id) REFERENCES schedules(schedule_id) ON DELETE CASCADE,
                CONSTRAINT fk_tickets_seat FOREIGN KEY (seat_id) REFERENCES seats(seat_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS qr_logs (
                log_id INT AUTO_INCREMENT PRIMARY KEY,
                ticket_id INT NOT NULL,
                scanned_by INT NULL,
                scan_status VARCHAR(20) NOT NULL,
                scan_message VARCHAR(255) NULL,
                scan_payload LONGTEXT NULL,
                scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_qr_logs_ticket (ticket_id),
                CONSTRAINT fk_qr_logs_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS notifications (
                notification_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                booking_id INT NULL,
                notification_type VARCHAR(30) NOT NULL,
                title VARCHAR(150) NOT NULL,
                message TEXT NOT NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_notifications_user (user_id),
                CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS audit_logs (
                audit_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                role_key VARCHAR(30) NOT NULL DEFAULT '',
                action_key VARCHAR(80) NOT NULL,
                entity_type VARCHAR(50) NOT NULL,
                entity_id INT NOT NULL DEFAULT 0,
                description VARCHAR(255) NOT NULL,
                context_json LONGTEXT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_audit_logs_created_at (created_at),
                INDEX idx_audit_logs_user (user_id),
                INDEX idx_audit_logs_action (action_key),
                INDEX idx_audit_logs_entity (entity_type, entity_id),
                CONSTRAINT fk_audit_logs_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS login_attempts (
                throttle_key CHAR(64) NOT NULL PRIMARY KEY,
                failed_attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
                locked_until DATETIME NULL,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_login_attempts_locked_until (locked_until)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            $conn->query(
            "CREATE TABLE IF NOT EXISTS schedule_recurrences (
                recurrence_id INT AUTO_INCREMENT PRIMARY KEY,
                route_id INT NOT NULL,
                bus_id INT NOT NULL,
                operator_id INT NULL,
                bus_type VARCHAR(60) NULL,
                departure_time TIME NOT NULL,
                arrival_time TIME NOT NULL,
                start_date DATE NOT NULL,
                price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_by INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_schedule_recurrences_active (is_active, start_date),
                INDEX idx_schedule_recurrences_route (route_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
            );

            if (!column_exists('users', 'role_id')) {
                $conn->query('ALTER TABLE users ADD COLUMN role_id INT NULL AFTER password');
            }
            if (!column_exists('users', 'account_status')) {
                $conn->query("ALTER TABLE users ADD COLUMN account_status VARCHAR(20) NOT NULL DEFAULT 'active' AFTER is_admin");
            }
            if (!column_exists('users', 'last_login_at')) {
                $conn->query('ALTER TABLE users ADD COLUMN last_login_at DATETIME NULL AFTER updated_at');
            }
            if (!column_exists('users', 'last_activity_at')) {
                $conn->query('ALTER TABLE users ADD COLUMN last_activity_at DATETIME NULL AFTER last_login_at');
            }

            if (!column_exists('buses', 'bus_name')) {
                $conn->query('ALTER TABLE buses ADD COLUMN bus_name VARCHAR(120) NULL AFTER bus_code');
            }
            if (!column_exists('buses', 'bus_type')) {
                $conn->query('ALTER TABLE buses ADD COLUMN bus_type VARCHAR(60) NULL AFTER bus_name');
            }
            if (!column_exists('buses', 'is_enabled')) {
                $conn->query('ALTER TABLE buses ADD COLUMN is_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER status');
            }
            if (!column_exists('buses', 'seat_map_columns')) {
                $conn->query('ALTER TABLE buses ADD COLUMN seat_map_columns INT NOT NULL DEFAULT 4 AFTER is_enabled');
            }

            if (!column_exists('schedules', 'schedule_code')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN schedule_code VARCHAR(30) NULL AFTER schedule_id');
            }
            if (!column_exists('schedules', 'operator_id')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN operator_id INT NULL AFTER bus_id');
            }
            if (!index_exists('schedules', 'idx_schedules_operator')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_operator (operator_id)');
            }
            if (!column_exists('schedules', 'bus_type')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN bus_type VARCHAR(60) NULL AFTER route_id');
            }
            if (!column_exists('schedules', 'is_auto_assigned')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN is_auto_assigned TINYINT(1) NOT NULL DEFAULT 0 AFTER bus_type');
            }
            if (!column_exists('schedules', 'recurrence_id')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN recurrence_id INT NULL AFTER is_auto_assigned');
            }
            if (!column_exists('schedules', 'is_recurring_generated')) {
                $conn->query('ALTER TABLE schedules ADD COLUMN is_recurring_generated TINYINT(1) NOT NULL DEFAULT 0 AFTER recurrence_id');
            }
            if (!column_exists('schedules', 'trip_status')) {
                $conn->query("ALTER TABLE schedules ADD COLUMN trip_status VARCHAR(20) NOT NULL DEFAULT 'scheduled' AFTER status");
            }
            if (!index_exists('schedules', 'idx_schedules_trip_status')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_trip_status (trip_status)');
            }
            if (!index_exists('schedules', 'idx_schedules_recurrence')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_recurrence (recurrence_id)');
            }
            if (!index_exists('schedules', 'idx_schedules_status_departure')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_status_departure (status, departure_date, departure_time)');
            }
            if (!index_exists('schedules', 'idx_schedules_route_departure')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_route_departure (route_id, departure_date, status, departure_time)');
            }
            if (!index_exists('schedules', 'idx_schedules_bus_departure')) {
                $conn->query('ALTER TABLE schedules ADD INDEX idx_schedules_bus_departure (bus_id, departure_date, status)');
            }
            if (!index_exists('schedules', 'uniq_schedules_route_departure')) {
                $duplicates = db_select_one(
                    'SELECT COUNT(*) AS total
                     FROM (
                        SELECT route_id, departure_date, departure_time
                        FROM schedules
                        GROUP BY route_id, departure_date, departure_time
                        HAVING COUNT(*) > 1
                     ) duplicates'
                );

                if ((int) ($duplicates['total'] ?? 0) === 0) {
                    $conn->query('ALTER TABLE schedules ADD UNIQUE KEY uniq_schedules_route_departure (route_id, departure_date, departure_time)');
                }
            }

            $conn->query("ALTER TABLE bookings MODIFY COLUMN status VARCHAR(30) NOT NULL DEFAULT 'pending'");
            $conn->query("ALTER TABLE bookings MODIFY COLUMN payment_status VARCHAR(30) NOT NULL DEFAULT 'pending'");
            $conn->query("ALTER TABLE bookings MODIFY COLUMN payment_method VARCHAR(40) NULL");

            if (!column_exists('bookings', 'expires_at')) {
                $conn->query('ALTER TABLE bookings ADD COLUMN expires_at DATETIME NULL AFTER updated_at');
            }
            if (!column_exists('bookings', 'confirmed_at')) {
                $conn->query('ALTER TABLE bookings ADD COLUMN confirmed_at DATETIME NULL AFTER expires_at');
            }
            if (!column_exists('bookings', 'cancelled_at')) {
                $conn->query('ALTER TABLE bookings ADD COLUMN cancelled_at DATETIME NULL AFTER confirmed_at');
            }
            if (!column_exists('bookings', 'seat_preferences')) {
                $conn->query('ALTER TABLE bookings ADD COLUMN seat_preferences TEXT NULL AFTER payment_status');
            }
            if (!column_exists('bookings', 'claim_code')) {
                $conn->query('ALTER TABLE bookings ADD COLUMN claim_code VARCHAR(40) NULL AFTER booking_reference');
            }
            if (!index_exists('bookings', 'uniq_bookings_claim_code')) {
                $conn->query('ALTER TABLE bookings ADD UNIQUE KEY uniq_bookings_claim_code (claim_code)');
            }
            if (!index_exists('bookings', 'idx_bookings_user_date')) {
                $conn->query('ALTER TABLE bookings ADD INDEX idx_bookings_user_date (user_id, booking_date)');
            }
            if (!index_exists('bookings', 'idx_bookings_schedule_status')) {
                $conn->query('ALTER TABLE bookings ADD INDEX idx_bookings_schedule_status (schedule_id, status)');
            }
            if (!index_exists('bookings', 'idx_bookings_status_payment_date')) {
                $conn->query('ALTER TABLE bookings ADD INDEX idx_bookings_status_payment_date (status, payment_status, booking_date)');
            }

            if (!column_exists('passengers', 'id_type')) {
                $conn->query('ALTER TABLE passengers ADD COLUMN id_type VARCHAR(50) NULL AFTER gender');
            }
            if (!column_exists('passengers', 'id_number')) {
                $conn->query('ALTER TABLE passengers ADD COLUMN id_number VARCHAR(50) NULL AFTER id_type');
            }

            if (!index_exists('routes', 'uniq_route_pair')) {
                $duplicates = db_select_one(
                    'SELECT COUNT(*) AS total
                     FROM (
                        SELECT origin_terminal_id, destination_terminal_id
                        FROM routes
                        GROUP BY origin_terminal_id, destination_terminal_id
                        HAVING COUNT(*) > 1
                     ) duplicates'
                );

                if ((int) ($duplicates['total'] ?? 0) === 0) {
                    $conn->query('ALTER TABLE routes ADD UNIQUE KEY uniq_route_pair (origin_terminal_id, destination_terminal_id)');
                }
            }

            if (!index_exists('fares', 'idx_fares_route_class')) {
                $conn->query('ALTER TABLE fares ADD INDEX idx_fares_route_class (route_id, class_id)');
            }
            if (!index_exists('payments', 'idx_payments_status_submitted')) {
                $conn->query('ALTER TABLE payments ADD INDEX idx_payments_status_submitted (status, submitted_at)');
            }
            if (!index_exists('payments', 'idx_payments_status_verified')) {
                $conn->query('ALTER TABLE payments ADD INDEX idx_payments_status_verified (status, verified_at)');
            }
            if (!column_exists('payments', 'provider')) {
                $conn->query('ALTER TABLE payments ADD COLUMN provider VARCHAR(30) NULL AFTER proof_image');
            }
            if (!column_exists('payments', 'provider_checkout_id')) {
                $conn->query('ALTER TABLE payments ADD COLUMN provider_checkout_id VARCHAR(100) NULL AFTER provider');
            }
            if (!column_exists('payments', 'provider_checkout_url')) {
                $conn->query('ALTER TABLE payments ADD COLUMN provider_checkout_url VARCHAR(2048) NULL AFTER provider_checkout_id');
            }
            if (!column_exists('payments', 'provider_payment_id')) {
                $conn->query('ALTER TABLE payments ADD COLUMN provider_payment_id VARCHAR(100) NULL AFTER provider_checkout_url');
            }
            if (!index_exists('payments', 'uniq_payments_provider_checkout')) {
                $conn->query('ALTER TABLE payments ADD UNIQUE KEY uniq_payments_provider_checkout (provider_checkout_id)');
            }
            if (!index_exists('payments', 'uniq_payments_provider_payment')) {
                $conn->query('ALTER TABLE payments ADD UNIQUE KEY uniq_payments_provider_payment (provider_payment_id)');
            }
            if (!index_exists('tickets', 'idx_tickets_booking_status')) {
                $conn->query('ALTER TABLE tickets ADD INDEX idx_tickets_booking_status (booking_id, ticket_status)');
            }
            if (!index_exists('notifications', 'idx_notifications_user_read_created')) {
                $conn->query('ALTER TABLE notifications ADD INDEX idx_notifications_user_read_created (user_id, is_read, created_at)');
            }

            $conn->query("UPDATE bookings SET payment_status = 'pending' WHERE payment_status = 'unpaid'");
            $conn->query(
                "UPDATE bookings
                 SET payment_status = 'failed'
                 WHERE status = 'cancelled' AND payment_status <> 'paid'"
            );
            $conn->query(
                "UPDATE payments p
                 JOIN bookings b ON b.booking_id = p.booking_id
                 SET p.status = 'failed',
                     p.admin_notes = COALESCE(p.admin_notes, 'Booking was cancelled before payment completed.')
                 WHERE b.status = 'cancelled'
                   AND b.payment_status <> 'paid'
                   AND p.status IN ('pending', 'rejected')"
            );
            $conn->query(
                'UPDATE bookings b
                 JOIN schedules s ON b.schedule_id = s.schedule_id
                 SET b.expires_at = TIMESTAMP(s.departure_date, s.departure_time)
                 WHERE b.payment_method = "cash"
                 AND b.payment_status = "pending"
                 AND b.status = "pending"
                 AND TIMESTAMP(s.departure_date, s.departure_time) > NOW()
                 AND (b.expires_at IS NULL OR b.expires_at < TIMESTAMP(s.departure_date, s.departure_time))'
            );

            seed_default_roles();
            backfill_user_roles();
            backfill_bus_types();
            backfill_schedule_metadata();
            materialize_active_schedule_recurrences();
            // Preserve operator-configured bus capacities and avoid overriding admin edits.
            sync_all_bus_seats();
            sync_all_schedule_available_seats();
            backfill_payment_rows();
            backfill_ticket_rows();
            cleanup_legacy_pending_gcash_holds();
            backfill_cash_claim_codes();

            app_runtime_meta_set('bootstrap_version', APP_BOOTSTRAP_VERSION);
            $completed = true;
        } finally {
            if ($lockAcquired) {
                release_database_lock(APP_BOOTSTRAP_LOCK_NAME);
            }
        }
    }
}

if (PHP_SAPI === 'cli' || RUN_SCHEMA_MIGRATIONS_ON_WEB) {
    ensure_schema_migrations();
}

if (PHP_SAPI === 'cli' || RUN_HOUSEKEEPING_ON_WEB) {
    run_runtime_housekeeping();
}



