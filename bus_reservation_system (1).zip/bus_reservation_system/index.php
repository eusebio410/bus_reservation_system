<?php
$base_url = '';
$page_title = 'Gonzaga Terminal Bus Guide';

include 'includes/config.php';

$fetch_total = static function ($query, $field = 'total') use ($conn) {
    $result = $conn->query($query);

    if ($result && $row = $result->fetch_assoc()) {
        return (int) $row[$field];
    }

    return 0;
};

$active_buses = $fetch_total("SELECT COUNT(*) AS total FROM buses WHERE status = 'active'");
$terminal_count = $fetch_total("SELECT COUNT(*) AS total FROM terminals");
$upcoming_trip_count = $fetch_total("SELECT COUNT(*) AS total FROM schedules WHERE departure_date >= CURDATE() AND status = 'scheduled'");
$route_count = $fetch_total("SELECT COUNT(*) AS total FROM routes");
$travel_guide_count = $fetch_total("SELECT COUNT(*) AS total FROM travel_guides");
// $blog_count = $fetch_total("SELECT COUNT(*) AS total FROM blogs"); // Table doesn't exist yet
$blog_count = 0; // Placeholder until blogs table is created

// Keep the home page useful even before a passenger starts a full search.
// This is intentionally read-only and falls back to an empty state if a query fails.
$next_departures_query = "
    SELECT
        s.schedule_id,
        s.departure_date,
        s.departure_time,
        s.price,
        s.available_seats,
        r.route_id,
        t1.terminal_name AS origin_name,
        t2.terminal_name AS destination_name,
        b.bus_code,
        bc.class_name
    FROM schedules s
    JOIN routes r ON s.route_id = r.route_id
    JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
    JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
    JOIN buses b ON s.bus_id = b.bus_id
    JOIN bus_classes bc ON b.class_id = bc.class_id
    WHERE s.status = 'scheduled'
      AND s.available_seats > 0
      AND (s.departure_date > CURDATE() OR (s.departure_date = CURDATE() AND s.departure_time > CURTIME()))
    ORDER BY s.departure_date ASC, s.departure_time ASC
    LIMIT 3
";
$next_departures = $conn->query($next_departures_query);

$spotlight_query = "
    SELECT
        r.route_id,
        t1.terminal_name AS origin_name,
        t2.terminal_name AS destination_name,
        r.distance,
        r.travel_time,
        MIN(f.base_fare) AS starting_fare,
        COUNT(DISTINCT CASE WHEN s.departure_date >= CURDATE() AND s.status = 'scheduled' THEN s.schedule_id END) AS upcoming_trips
    FROM routes r
    JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
    JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
    LEFT JOIN fares f ON f.route_id = r.route_id
    LEFT JOIN schedules s ON s.route_id = r.route_id
    GROUP BY r.route_id, t1.terminal_name, t2.terminal_name, r.distance, r.travel_time
    ORDER BY upcoming_trips DESC, starting_fare ASC
";
$spotlight_routes = $conn->query($spotlight_query);

include 'includes/header.php';
?>

<section class="home-hero">
    <div class="container home-hero-inner">
        <div class="home-hero-copy">
            <div class="home-hero-badge">
                <i class="fas fa-star"></i>
                <span>Local terminal schedule and online reservations for Gonzaga, Cagayan</span>
            </div>

            <h1 class="home-hero-title">
                Your Journey Begins<br>
                at <span>Gonzaga Terminal</span>
            </h1>

            <p class="home-hero-text">
                Reserve Gonzaga departures to Sampaloc, Cubao, and other routes you add later.
                Browse schedules, compare fares, and complete a seat reservation online in a few steps.
            </p>

            <div class="home-hero-actions">
                <a href="booking.php" class="hero-link hero-link--primary">
                    <span>Book Your Ticket</span>
                    <i class="fas fa-arrow-right"></i>
                </a>
                <a href="schedules.php" class="hero-link hero-link--secondary">
                    <span>View Schedules</span>
                </a>
            </div>
        </div>

        <aside class="home-hero-visual" aria-label="Quick travel planning links">
            <div class="home-hero-panel">
                <div class="home-hero-panel-heading">
                    <span class="home-hero-panel-kicker"><i class="fas fa-compass"></i> Passenger portal</span>
                    <h2>Plan a smoother departure.</h2>
                    <p>Everything you need for your Gonzaga trip, in one easy place.</p>
                </div>

                <div class="home-hero-quick-links">
                    <a href="booking.php" class="home-hero-quick-link">
                        <span class="home-hero-quick-link-icon"><i class="fas fa-ticket-alt"></i></span>
                        <span>
                            <small>Ready when you are</small>
                            <strong>Reserve your seat</strong>
                        </span>
                        <i class="fas fa-arrow-right home-hero-quick-link-arrow"></i>
                    </a>

                    <a href="schedules.php" class="home-hero-quick-link">
                        <span class="home-hero-quick-link-icon"><i class="fas fa-clock"></i></span>
                        <span>
                            <small>Before you leave</small>
                            <strong>Check departures</strong>
                        </span>
                        <i class="fas fa-arrow-right home-hero-quick-link-arrow"></i>
                    </a>
                </div>

                <div class="home-hero-assurance">
                    <i class="fas fa-shield-heart"></i>
                    <span>Live schedules, clear fares, and easy online reservations.</span>
                </div>
            </div>
        </aside>
    </div>

    <a href="booking.php" class="home-floating-ticket">
        <i class="fas fa-ticket-alt"></i>
        <span>Find Tickets</span>
    </a>
</section>

<section class="home-stats-bar">
    <div class="container">
        <div class="home-stats-grid">
            <div class="home-stat-card">
                <strong><?php echo number_format($active_buses); ?>+</strong>
                <span>Active Buses</span>
            </div>
            <div class="home-stat-card">
                <strong><?php echo number_format($terminal_count); ?>+</strong>
                <span>Terminals</span>
            </div>
            <div class="home-stat-card">
                <strong>80+</strong>
                <span>Years of Service</span>
            </div>
            <div class="home-stat-card">
                <strong><?php echo number_format($upcoming_trip_count); ?>+</strong>
                <span>Upcoming Trips</span>
            </div>
        </div>
    </div>
</section>

<section class="home-departure-board" aria-labelledby="next-departures-title">
    <div class="container">
        <div class="home-departure-board__header">
            <div>
                <span class="home-departure-board__eyebrow"><i class="fas fa-circle-check" aria-hidden="true"></i> Live availability</span>
                <h2 id="next-departures-title">Next available departures</h2>
                <p>See the soonest seats available, then continue to secure your preferred trip.</p>
            </div>
            <a class="home-departure-board__all-link" href="schedules.php">
                View full schedule <i class="fas fa-arrow-right" aria-hidden="true"></i>
            </a>
        </div>

        <?php if ($next_departures && $next_departures->num_rows > 0): ?>
            <div class="home-departure-list">
                <?php while ($departure = $next_departures->fetch_assoc()): ?>
                    <?php
                    $departure_date = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($departure['departure_date'] ?? ''));
                    $departure_time = DateTimeImmutable::createFromFormat('!H:i:s', (string) ($departure['departure_time'] ?? ''));
                    $today_date = new DateTimeImmutable('today');
                    $tomorrow_date = $today_date->modify('+1 day');

                    if ($departure_date && $departure_date->format('Y-m-d') === $today_date->format('Y-m-d')) {
                        $departure_day_label = 'Today';
                    } elseif ($departure_date && $departure_date->format('Y-m-d') === $tomorrow_date->format('Y-m-d')) {
                        $departure_day_label = 'Tomorrow';
                    } else {
                        $departure_day_label = $departure_date ? $departure_date->format('D, M j') : 'Upcoming';
                    }

                    $departure_time_label = $departure_time ? $departure_time->format('g:i A') : 'Time to follow';
                    $available_seats = (int) ($departure['available_seats'] ?? 0);
                    $seat_label = $available_seats === 1 ? '1 seat left' : number_format($available_seats) . ' seats left';
                    ?>
                    <article class="home-departure-card">
                        <div class="home-departure-card__time">
                            <span><?php echo htmlspecialchars($departure_day_label); ?></span>
                            <strong><?php echo htmlspecialchars($departure_time_label); ?></strong>
                        </div>

                        <div class="home-departure-card__route">
                            <strong><?php echo htmlspecialchars((string) $departure['origin_name']); ?></strong>
                            <i class="fas fa-arrow-right" aria-hidden="true"></i>
                            <strong><?php echo htmlspecialchars((string) $departure['destination_name']); ?></strong>
                            <small>
                                <?php echo htmlspecialchars((string) ($departure['bus_code'] ?: 'Assigned bus')); ?>
                                &middot;
                                <?php echo htmlspecialchars((string) ($departure['class_name'] ?: 'Standard class')); ?>
                            </small>
                        </div>

                        <div class="home-departure-card__availability">
                            <span><?php echo htmlspecialchars($seat_label); ?></span>
                            <strong>PHP <?php echo number_format((float) ($departure['price'] ?? 0), 2); ?></strong>
                        </div>

                        <a class="home-departure-card__action" href="booking.php?route_id=<?php echo (int) $departure['route_id']; ?>&amp;departure_date=<?php echo rawurlencode((string) ($departure['departure_date'] ?? '')); ?>">
                            Select trip <span class="visually-hidden">from <?php echo htmlspecialchars((string) $departure['origin_name']); ?> to <?php echo htmlspecialchars((string) $departure['destination_name']); ?></span>
                        </a>
                    </article>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="home-departure-empty">
                <i class="fas fa-calendar-days" aria-hidden="true"></i>
                <div>
                    <strong>No upcoming departures are available yet.</strong>
                    <p>Check the full schedule again soon, or contact the terminal for assistance.</p>
                </div>
                <a href="schedules.php">View schedules</a>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="home-section home-section--light" aria-labelledby="payment-methods-title">
    <div class="container">
        <div class="home-section-heading">
            <span class="section-kicker">Payment</span>
            <h2 id="payment-methods-title" class="section-title">Pay securely with QRPh</h2>
            <p class="section-copy">QRPh is the only online payment method available. PayMongo verifies your payment automatically before your booking and QR ticket are confirmed.</p>
        </div>
        <div class="service-grid">
            <article class="service-card">
                <span class="service-icon"><i class="fas fa-qrcode"></i></span>
                <h3>QRPh checkout</h3>
                <p>Scan and complete your payment through PayMongo. No receipt upload is required.</p>
            </article>
            <article class="service-card">
                <span class="service-icon"><i class="fas fa-shield-halved"></i></span>
                <h3>Automatic verification</h3>
                <p>Your payment is verified directly with PayMongo and recorded in your booking.</p>
            </article>
            <article class="service-card">
                <span class="service-icon"><i class="fas fa-ticket"></i></span>
                <h3>QR ticket issuance</h3>
                <p>Once payment is confirmed, your booking is confirmed and your boarding QR ticket is issued.</p>
            </article>
        </div>
    </div>
</section>

<section class="home-section home-section--light">
    <div class="container">
        <div class="home-section-heading">
            <span class="section-kicker">Trip Planning</span>
            <h2 class="section-title">Everything you need before you travel</h2>
            <p class="section-copy">Use direct links for booking, routes, terminal information, and pricing for the Gonzaga terminal network.</p>
        </div>

        <div class="planner-grid">
            <a class="planner-card" href="booking.php">
                <span class="planner-icon"><i class="fas fa-ticket-alt"></i></span>
                <h3>Online Booking</h3>
                <p>Reserve seats quickly and move through the passenger and payment flow online.</p>
                <span class="planner-link">Open booking</span>
            </a>

            <a class="planner-card" href="schedules.php">
                <span class="planner-icon"><i class="fas fa-clock"></i></span>
                <h3>Schedules</h3>
                <p>Check upcoming departure times, available trips, and travel timing before you leave.</p>
                <span class="planner-link">Check schedules</span>
            </a>

            <a class="planner-card" href="routes.php">
                <span class="planner-icon"><i class="fas fa-route"></i></span>
                <h3>Bus Route</h3>
                <p>Review the route network, terminal pairings, and estimated travel durations.</p>
                <span class="planner-link">See routes</span>
            </a>

            <a class="planner-card" href="fares.php?view=rates">
                <span class="planner-icon"><i class="fas fa-wallet"></i></span>
                <h3>Rates and Fares</h3>
                <p>Compare fare ranges, fare details, and route pricing before booking your trip.</p>
                <span class="planner-link">View pricing</span>
            </a>
        </div>
    </div>
</section>

<section class="home-section">
    <div class="container">
        <div class="home-section-heading">
            <span class="section-kicker">Popular Trips</span>
            <h2 class="section-title">Current Gonzaga route options</h2>
            <p class="section-copy">These route cards pull from your live Gonzaga route, fare, and schedule records so the homepage stays tied to the actual system.</p>
        </div>

        <div class="route-spotlight-grid">
            <?php if ($spotlight_routes && $spotlight_routes->num_rows > 0): ?>
                <?php while ($route = $spotlight_routes->fetch_assoc()): ?>
                    <?php
                    $travel_time = (int) ($route['travel_time'] ?? 0);
                    $hours = intdiv($travel_time, 60);
                    $minutes = $travel_time % 60;
                    $duration_parts = [];

                    if ($hours > 0) {
                        $duration_parts[] = $hours . 'h';
                    }

                    if ($minutes > 0 || empty($duration_parts)) {
                        $duration_parts[] = $minutes . 'm';
                    }

                    $duration_label = implode(' ', $duration_parts);
                    $starting_fare = $route['starting_fare'] !== null ? 'PHP ' . number_format((float) $route['starting_fare'], 2) : 'Fare to follow';
                    ?>
                    <article class="route-card">
                        <div class="route-card-top">
                            <span class="route-pill"><?php echo number_format((float) $route['distance'], 0); ?> km</span>
                            <span class="route-pill route-pill--light"><?php echo htmlspecialchars($duration_label); ?></span>
                        </div>

                        <h3><?php echo htmlspecialchars($route['origin_name']); ?></h3>
                        <p class="route-card-arrow"><i class="fas fa-arrow-right"></i></p>
                        <h4><?php echo htmlspecialchars($route['destination_name']); ?></h4>

                        <dl class="route-meta">
                            <div>
                                <dt>Starting fare</dt>
                                <dd><?php echo htmlspecialchars($starting_fare); ?></dd>
                            </div>
                            <div>
                                <dt>Scheduled trips</dt>
                                <dd><?php echo number_format((int) $route['upcoming_trips']); ?> upcoming</dd>
                            </div>
                        </dl>

                        <a class="route-cta" href="booking.php?route_id=<?php echo (int) $route['route_id']; ?>">Book this route</a>
                    </article>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="route-card route-card--empty">
                    <h3>No routes available yet</h3>
                    <p>Add routes, fares, and schedules in the admin panel to populate this section.</p>
                    <a class="route-cta" href="routes.php">Open route list</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<section class="home-section home-section--light">
    <div class="container">
        <div class="home-section-heading">
            <span class="section-kicker">Why Passengers Choose Gonzaga Terminal</span>
            <h2 class="section-title">Practical trip support, not just a booking form</h2>
        </div>

        <div class="service-grid">
            <article class="service-card">
                <span class="service-icon"><i class="fas fa-shield-heart"></i></span>
                <h3>Safe and dependable travel</h3>
                <p>Give passengers confidence with route information, terminal details, and a direct path to their trip schedule.</p>
            </article>

            <article class="service-card">
                <span class="service-icon"><i class="fas fa-bus"></i></span>
                <h3>Comfort-focused fleet</h3>
                <p>Pair fare transparency with bus class details so passengers can choose based on comfort and budget.</p>
            </article>

            <article class="service-card">
                <span class="service-icon"><i class="fas fa-headset"></i></span>
                <h3>Helpful travel resources</h3>
                <p>Link booking with FAQs, travel guides, and blog content to answer common questions before departure.</p>
            </article>
        </div>
    </div>
</section>

<section class="home-section">
    <div class="container">
        <div class="home-section-heading">
            <span class="section-kicker">Explore More</span>
            <h2 class="section-title">Support pages linked directly from the new header</h2>
            <p class="section-copy">The updated navigation now sends users straight to the page they want, including FAQ, travel guides, blog posts, route information, terminals, rates, and fares.</p>
        </div>

        <div class="resource-grid">
            <a class="resource-card" href="faq.php">
                <span class="resource-count">FAQ</span>
                <h3>Frequently asked questions</h3>
                <p>Help passengers find baggage, boarding, payment, and booking answers quickly.</p>
            </a>

            <a class="resource-card" href="travel-guides.php">
                <span class="resource-count"><?php echo number_format($travel_guide_count); ?> guides</span>
                <h3>Travel Guides</h3>
                <p>Publish destination notes, terminal guidance, and local travel tips in one place.</p>
            </a>

            <a class="resource-card" href="blog.php">
                <span class="resource-count"><?php echo number_format($blog_count); ?> posts</span>
                <h3>Blog</h3>
                <p>Keep passengers updated with announcements, promotions, and route-related content.</p>
            </a>
        </div>
    </div>
</section>

<section class="home-final-cta">
    <div class="container home-final-cta-inner">
        <div>
            <span class="section-kicker">Ready to Book</span>
            <h2 class="section-title">Start your next trip with direct booking, route details, and real fare visibility.</h2>
        </div>

        <div class="home-final-cta-actions">
            <a href="booking.php" class="hero-link hero-link--primary">Book Now</a>
            <a href="fares.php" class="hero-link hero-link--secondary hero-link--dark">Bus Fares</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
