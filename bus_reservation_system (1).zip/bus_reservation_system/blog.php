<?php
$base_url = '';
$page_title = 'Blog - Victory Liner';

include 'includes/config.php';

$blog_query = "SELECT * FROM blog_posts WHERE status = 'published' ORDER BY created_at DESC";
$blog_result = $conn->query($blog_query);

$posts = [];

if ($blog_result && $blog_result->num_rows > 0) {
    while ($post = $blog_result->fetch_assoc()) {
        $posts[] = $post;
    }
}

$published_count = count($posts);

$build_excerpt = static function ($content, $length = 260) {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags((string) $content)));

    if (strlen($text) <= $length) {
        return $text;
    }

    return rtrim(substr($text, 0, $length - 3)) . '...';
};

$estimate_read_time = static function ($content) {
    $text = trim(preg_replace('/\s+/', ' ', strip_tags((string) $content)));
    $word_count = str_word_count($text);
    $minutes = max(1, (int) ceil($word_count / 200));

    return $minutes . ' min read';
};

include 'includes/header.php';
?>

<style>
.page-blog {
    background: #eef1f5;
}

.page-blog .site-main {
    padding: 0;
}

.page-blog footer {
    margin-top: 0 !important;
}

.page-blog .blog-hero {
    background:
        linear-gradient(90deg, rgba(10, 18, 34, 0.88) 0%, rgba(10, 18, 34, 0.74) 30%, rgba(10, 18, 34, 0.44) 100%),
        url('assets/images/bus-terminal-hero-v2.jpg') center center / cover no-repeat;
    min-height: 28rem;
    overflow: hidden;
    position: relative;
}

.page-blog .blog-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.16) 0%, rgba(7, 12, 24, 0.28) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-blog .blog-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 28rem;
    padding: 4.8rem 0 3.5rem;
    position: relative;
    z-index: 1;
}

.page-blog .blog-hero__copy {
    max-width: 56rem;
}

.page-blog .blog-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.8rem, 4.8vw, 4.4rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.2rem;
}

.page-blog .blog-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.06rem, 0.97rem + 0.36vw, 1.34rem);
    line-height: 1.52;
    margin: 0 0 1.7rem;
    max-width: 48rem;
}

.page-blog .blog-hero__stats {
    display: flex;
    flex-wrap: wrap;
    gap: 0.8rem;
}

.page-blog .blog-hero__stats span {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 0.92rem;
    font-weight: 700;
    gap: 0.5rem;
    padding: 0.65rem 0.95rem;
}

.page-blog .blog-section {
    padding: 3.8rem 0 5.2rem;
}

.page-blog .blog-section__heading {
    margin-bottom: 2.2rem;
    text-align: center;
}

.page-blog .blog-section__heading h2 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.2rem, 2vw + 1rem, 3.3rem);
    font-weight: 800;
    letter-spacing: -0.05em;
    margin: 0 0 0.8rem;
}

.page-blog .blog-section__heading p {
    color: #475467;
    font-size: 1.05rem;
    margin: 0;
}

.page-blog .blog-list {
    display: grid;
    gap: 1.35rem;
}

.page-blog .blog-card {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.3rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: grid;
    grid-template-columns: minmax(0, 22rem) 1fr;
    overflow: hidden;
}

.page-blog .blog-card__media,
.page-blog .blog-card__placeholder {
    height: 100%;
    min-height: 18rem;
    width: 100%;
}

.page-blog .blog-card__media {
    object-fit: cover;
}

.page-blog .blog-card__placeholder {
    align-items: center;
    background:
        linear-gradient(180deg, rgba(20, 27, 45, 0.12) 0%, rgba(20, 27, 45, 0.2) 100%),
        linear-gradient(135deg, #d5e4f4 0%, #f6ead8 100%);
    color: #a72d2d;
    display: flex;
    font-size: 2rem;
    justify-content: center;
}

.page-blog .blog-card__body {
    display: flex;
    flex-direction: column;
    padding: 1.5rem;
}

.page-blog .blog-card__meta {
    color: #667085;
    display: flex;
    flex-wrap: wrap;
    font-size: 0.86rem;
    font-weight: 700;
    gap: 0.8rem;
    letter-spacing: 0.04em;
    margin-bottom: 0.8rem;
    text-transform: uppercase;
}

.page-blog .blog-card__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.6rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1.12;
    margin: 0 0 0.8rem;
}

.page-blog .blog-card__body p {
    color: #475467;
    line-height: 1.72;
    margin: 0 0 1rem;
}

.page-blog .blog-card__link {
    align-items: center;
    color: #a72d2d;
    display: inline-flex;
    font-weight: 800;
    gap: 0.6rem;
    margin-top: auto;
    text-decoration: none;
}

.page-blog .blog-card__link:hover {
    color: #8f2323;
}

.page-blog .blog-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-blog .blog-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.6rem;
}

.page-blog .blog-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-blog .blog-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-blog .blog-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-blog .blog-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 991px) {
    .page-blog .blog-card {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 767px) {
    .page-blog .blog-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="blog-hero">
    <div class="container blog-hero__inner">
        <div class="blog-hero__copy">
            <h1 class="blog-hero__title">News &amp; Updates</h1>
            <p>Read service updates, announcements, travel stories, and useful news related to Victory Liner routes, terminals, and passenger travel.</p>
            <div class="blog-hero__stats">
                <span><i class="fas fa-newspaper"></i> Official updates feed</span>
                <span><i class="fas fa-pen-nib"></i> <?php echo number_format($published_count); ?> published posts</span>
                <span><i class="fas fa-bullhorn"></i> Service and travel news</span>
            </div>
        </div>
    </div>
</section>

<section class="blog-section">
    <div class="container">
        <div class="blog-section__heading">
            <h2>Latest Articles</h2>
            <p>Stay informed with the latest posts published on the Victory Liner blog.</p>
        </div>

        <?php if (!empty($posts)): ?>
            <div class="blog-list">
                <?php foreach ($posts as $post): ?>
                    <article class="blog-card">
                        <?php if (!empty($post['image_url'])): ?>
                            <img class="blog-card__media" src="<?php echo htmlspecialchars($post['image_url']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>">
                        <?php else: ?>
                            <div class="blog-card__placeholder">
                                <i class="fas fa-newspaper"></i>
                            </div>
                        <?php endif; ?>

                        <div class="blog-card__body">
                            <div class="blog-card__meta">
                                <span><?php echo date('F j, Y', strtotime($post['created_at'])); ?></span>
                                <span><?php echo htmlspecialchars($estimate_read_time($post['content'] ?? '')); ?></span>
                            </div>
                            <h3 class="blog-card__title"><?php echo htmlspecialchars($post['title']); ?></h3>
                            <p><?php echo htmlspecialchars($build_excerpt($post['content'] ?? '')); ?></p>
                            <a class="blog-card__link" href="blog-detail.php?id=<?php echo (int) $post['post_id']; ?>">
                                <span>Read full article</span>
                                <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="blog-empty-state">
                <span class="blog-empty-state__icon"><i class="fas fa-newspaper"></i></span>
                <h2>No blog posts yet</h2>
                <p>Published blog entries are not available right now. When service news and travel updates are posted, they will appear here.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="blog-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
