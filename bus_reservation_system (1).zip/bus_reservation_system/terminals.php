<?php
$base_url = '';
$page_title = 'Bus Terminals - Gonzaga Terminal';

include 'includes/config.php';

$terminals_query = "SELECT * FROM terminals ORDER BY terminal_name ASC";
$terminals_result = $conn->query($terminals_query);

$terminals = [];

if ($terminals_result && $terminals_result->num_rows > 0) {
    while ($terminal = $terminals_result->fetch_assoc()) {
        $terminals[] = $terminal;
    }
}

$total_terminals = count($terminals);

include 'includes/header.php';
?>

<style>
.page-terminals {
    background: #eef1f5;
}

.page-terminals .site-main {
    padding: 0;
}

.page-terminals footer {
    margin-top: 0 !important;
}

.page-terminals .terminals-hero {
    background:
        linear-gradient(90deg, rgba(11, 18, 33, 0.88) 0%, rgba(11, 18, 33, 0.74) 32%, rgba(11, 18, 33, 0.42) 100%),
        url('assets/images/bus-terminal-hero-v2.jpg') center center / cover no-repeat;
    min-height: 34.5rem;
    overflow: hidden;
    position: relative;
}

.page-terminals .terminals-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.16) 0%, rgba(7, 12, 24, 0.26) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-terminals .terminals-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 34.5rem;
    padding: 5.3rem 0 4rem;
    position: relative;
    z-index: 1;
}

.page-terminals .terminals-hero__copy {
    max-width: 54rem;
}

.page-terminals .terminals-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(3rem, 5vw, 4.6rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.35rem;
}

.page-terminals .terminals-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.08rem, 0.98rem + 0.4vw, 1.42rem);
    line-height: 1.52;
    margin: 0;
    max-width: 48rem;
}

.page-terminals .terminals-section {
    padding: 4rem 0 5.2rem;
}

.page-terminals .terminals-section__heading {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 2rem;
}

.page-terminals .terminals-grid {
    display: grid;
    gap: 1.35rem;
    grid-template-columns: repeat(3, minmax(0, 1fr));
}

.page-terminals .terminal-card {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.2rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    min-height: 100%;
    overflow: hidden;
}

.page-terminals .terminal-card__body {
    padding: 1.35rem 1.35rem 1.1rem;
}

.page-terminals .terminal-card__head {
    align-items: flex-start;
    display: flex;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 1rem;
}

.page-terminals .terminal-card__icon {
    align-items: center;
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    border-radius: 0.95rem;
    color: #fff;
    display: inline-flex;
    flex: 0 0 auto;
    font-size: 1rem;
    height: 2.9rem;
    justify-content: center;
    width: 2.9rem;
}

.page-terminals .terminal-card__badge {
    background: #fff1c8;
    border-radius: 999px;
    color: #c48900;
    display: inline-flex;
    font-size: 0.76rem;
    font-weight: 800;
    padding: 0.38rem 0.75rem;
}

.page-terminals .terminal-card__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.42rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1.12;
    margin: 0 0 0.8rem;
}

.page-terminals .terminal-card__address,
.page-terminals .terminal-card__detail {
    align-items: flex-start;
    color: #475467;
    display: flex;
    font-size: 0.95rem;
    gap: 0.65rem;
    line-height: 1.5;
    margin: 0 0 0.8rem;
}

.page-terminals .terminal-card__address i,
.page-terminals .terminal-card__detail i {
    color: #344054;
    margin-top: 0.15rem;
}

.page-terminals .terminal-card__footer {
    border-top: 1px solid #eaecf0;
    display: grid;
    gap: 0.7rem;
    grid-template-columns: 1fr 1fr;
    margin-top: auto;
    padding: 1rem 1.35rem 1.15rem;
}

.page-terminals .terminal-card__action {
    align-items: center;
    border-radius: 0.85rem;
    display: inline-flex;
    font-size: 0.92rem;
    font-weight: 800;
    justify-content: center;
    min-height: 2.9rem;
    padding: 0.75rem 0.95rem;
    text-decoration: none;
}

.page-terminals .terminal-card__action--primary {
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    color: #fff;
}

.page-terminals .terminal-card__action--primary:hover {
    color: #fff;
}

.page-terminals .terminal-card__action--secondary {
    background: #f8fafc;
    color: #344054;
}

.page-terminals .terminal-card__action--secondary:hover {
    color: #101828;
}

.page-terminals .terminals-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-terminals .terminals-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.6rem;
}

.page-terminals .terminals-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-terminals .terminals-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-terminals .terminals-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-terminals .terminals-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 1199px) {
    .page-terminals .terminals-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 991px) {
    .page-terminals .terminals-hero {
        min-height: auto;
    }

    .page-terminals .terminals-hero__inner {
        min-height: auto;
        padding: 4.2rem 0 3.5rem;
    }
}

@media (max-width: 767px) {
    .page-terminals .terminals-grid {
        grid-template-columns: 1fr;
    }

    .page-terminals .terminal-card__footer {
        grid-template-columns: 1fr;
    }

    .page-terminals .terminals-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="terminals-hero">
    <div class="container terminals-hero__inner">
        <div class="terminals-hero__copy">
            <h1 class="terminals-hero__title">Bus Terminals</h1>
            <p>Gonzaga Terminal is the focus of this reservation system. This page shows the municipality terminal information used for the capstone project.</p>
        </div>
    </div>
</section>

<section class="terminals-section">
    <div class="container">
        <h2 class="terminals-section__heading">Gonzaga Terminal</h2>

        <?php if (!empty($terminals)): ?>
            <div class="terminals-grid">
                <?php foreach ($terminals as $terminal): ?>
                    <article class="terminal-card">
                        <div class="terminal-card__body">
                            <div class="terminal-card__head">
                                <span class="terminal-card__icon"><i class="fas fa-bus-simple"></i></span>
                                <span class="terminal-card__badge">24/7</span>
                            </div>

                            <h3 class="terminal-card__title"><?php echo htmlspecialchars($terminal['terminal_name']); ?></h3>

                            <p class="terminal-card__address">
                                <i class="fas fa-location-dot"></i>
                                <span><?php echo htmlspecialchars($terminal['address'] !== '' ? $terminal['address'] : $terminal['location']); ?></span>
                            </p>

                            <p class="terminal-card__detail">
                                <i class="fas fa-map-pin"></i>
                                <span><?php echo htmlspecialchars($terminal['location']); ?></span>
                            </p>

                            <?php if (!empty($terminal['phone'])): ?>
                                <p class="terminal-card__detail">
                                    <i class="fas fa-phone"></i>
                                    <span><?php echo htmlspecialchars($terminal['phone']); ?></span>
                                </p>
                            <?php endif; ?>

                            <?php if (!empty($terminal['email'])): ?>
                                <p class="terminal-card__detail">
                                    <i class="fas fa-envelope"></i>
                                    <span><?php echo htmlspecialchars($terminal['email']); ?></span>
                                </p>
                            <?php endif; ?>
                        </div>

                        <div class="terminal-card__footer">
                            <?php if (!empty($terminal['phone'])): ?>
                                <a class="terminal-card__action terminal-card__action--primary" href="tel:<?php echo htmlspecialchars($terminal['phone']); ?>">
                                    Call Terminal
                                </a>
                            <?php else: ?>
                                <a class="terminal-card__action terminal-card__action--primary" href="booking.php">
                                    Find Trips
                                </a>
                            <?php endif; ?>

                            <a class="terminal-card__action terminal-card__action--secondary" href="booking.php">
                                Book From Here
                            </a>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="terminals-empty-state">
                <span class="terminals-empty-state__icon"><i class="fas fa-building"></i></span>
                <h2>No terminals available</h2>
                <p>The terminal directory is empty right now. Add terminal records in the admin panel to populate this page.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="terminals-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
