<?php
declare(strict_types=1);

/**
 * PayMongo webhook endpoint for the Gonzaga Terminal Bus Reservation System.
 *
 * Place this file in the same directory as system_bootstrap.php.
 * Register this URL in the PayMongo Dashboard:
 *   https://YOUR-DOMAIN/paymongo-webhook.php
 *
 * Subscribe to the Checkout Session paid event supported by your PayMongo
 * dashboard (commonly checkout_session.payment.paid). This handler verifies
 * the webhook signature, then independently retrieves the checkout session
 * from PayMongo before the existing application function updates the booking.
 */

define('BUS_PAYMONGO_WEBHOOK_REQUEST', true);

// Prefer the common project layout (public endpoint + includes/system_bootstrap.php),
// while also supporting projects where both files sit in the same directory.
$bootstrapCandidates = [
    __DIR__ . '/includes/system_bootstrap.php',
    __DIR__ . '/system_bootstrap.php',
];
$bootstrapPath = '';
foreach ($bootstrapCandidates as $candidate) {
    if (is_file($candidate)) {
        $bootstrapPath = $candidate;
        break;
    }
}
if ($bootstrapPath === '') {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'message' => 'Application bootstrap file was not found']);
    exit;
}
require_once $bootstrapPath;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function paymongo_webhook_reply(int $status, array $body): never
{
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    paymongo_webhook_reply(405, ['ok' => false, 'message' => 'POST only']);
}

if (!function_exists('paymongo_webhook_signature_is_valid')
    || !function_exists('confirm_paymongo_checkout')) {
    error_log('PayMongo webhook: required bootstrap functions are unavailable.');
    paymongo_webhook_reply(500, ['ok' => false, 'message' => 'Webhook handler is not configured']);
}

if (PAYMONGO_WEBHOOK_SECRET === '') {
    error_log('PayMongo webhook: BUS_PAYMONGO_WEBHOOK_SECRET is not configured.');
    paymongo_webhook_reply(500, ['ok' => false, 'message' => 'Webhook secret is not configured']);
}

$rawBody = file_get_contents('php://input');
if (!is_string($rawBody) || $rawBody === '' || strlen($rawBody) > 1048576) {
    paymongo_webhook_reply(400, ['ok' => false, 'message' => 'Invalid request body']);
}

// Header name is normally mapped to HTTP_PAYMONGO_SIGNATURE by PHP/Apache.
$signature = trim((string) (
    $_SERVER['HTTP_PAYMONGO_SIGNATURE']
    ?? $_SERVER['HTTP_PAYMONGO_SIGNATURE_V1']
    ?? ''
));

if ($signature === '' || !paymongo_webhook_signature_is_valid($rawBody, $signature)) {
    error_log('PayMongo webhook: signature validation failed.');
    paymongo_webhook_reply(401, ['ok' => false, 'message' => 'Invalid webhook signature']);
}

$event = json_decode($rawBody, true);
if (!is_array($event)) {
    paymongo_webhook_reply(400, ['ok' => false, 'message' => 'Malformed JSON']);
}

$eventAttributes = $event['data']['attributes'] ?? [];
$eventType = strtolower(trim((string) ($eventAttributes['type'] ?? '')));
$eventObject = $eventAttributes['data'] ?? [];
$objectType = strtolower(trim((string) ($eventObject['type'] ?? '')));
$objectId = trim((string) ($eventObject['id'] ?? ''));

// Only confirm events that identify the Checkout Session itself. A payment.paid
// event usually contains a payment ID, not a Checkout Session ID; do not treat
// that ID as a checkout ID or mark an order paid from unverified event data.
$paidCheckoutEvents = [
    'checkout_session.payment.paid',
    'checkout_session.paid',
];

if (in_array($eventType, $paidCheckoutEvents, true)
    && $objectId !== ''
    && ($objectType === '' || $objectType === 'checkout_session')) {
    $result = confirm_paymongo_checkout($objectId);

    if (empty($result['ok'])) {
        // Return 5xx so PayMongo can retry temporary API/database failures.
        // The application function logs no credentials; avoid exposing details.
        error_log('PayMongo webhook: checkout confirmation failed: '
            . substr((string) ($result['message'] ?? 'unknown error'), 0, 500));
        paymongo_webhook_reply(500, [
            'ok' => false,
            'message' => 'Payment verification could not be completed; retry later',
        ]);
    }

    paymongo_webhook_reply(200, [
        'ok' => true,
        'message' => 'Payment event processed',
    ]);
}

// Ignore unrelated events safely. Configure the Checkout Session paid event
// in PayMongo Dashboard. Do not mark payments paid based on a browser redirect.
paymongo_webhook_reply(200, [
    'ok' => true,
    'message' => 'Event acknowledged; no booking update required',
]);
