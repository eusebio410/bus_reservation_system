<?php
$base_url = '';
$page_title = 'Select Seats';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$scheduleId = (int) isset_get('schedule_id');
if ($scheduleId < 1) {
    redirect('booking.php');
}

if (isset_get('ajax') === 'seats') {
    $ajaxSchedule = get_schedule_details($scheduleId);
    $ajaxDepartureTimestamp = departure_timestamp(
        (string) ($ajaxSchedule['departure_date'] ?? ''),
        (string) ($ajaxSchedule['departure_time'] ?? '')
    );

    header('Content-Type: application/json');
    if (
        !$ajaxSchedule
        || ($ajaxSchedule['status'] ?? '') !== 'scheduled'
        || !booking_date_within_allowed_window((string) ($ajaxSchedule['departure_date'] ?? ''))
        || ($ajaxDepartureTimestamp !== null && $ajaxDepartureTimestamp <= time())
    ) {
        echo json_encode([
            'schedule' => $ajaxSchedule,
            'seats' => [],
            'available' => 0,
            'error' => 'Trip is no longer available for booking.',
        ]);
        exit();
    }

    echo json_encode([
        'schedule' => $ajaxSchedule,
        'seats' => get_schedule_seat_map($scheduleId),
        'available' => count_available_schedule_seats($scheduleId),
    ]);
    exit();
}

$schedule = get_schedule_details($scheduleId);
if (!$schedule || ($schedule['status'] ?? '') !== 'scheduled') {
    redirect('booking.php');
}

$scheduleDepartureTimestamp = departure_timestamp(
    (string) ($schedule['departure_date'] ?? ''),
    (string) ($schedule['departure_time'] ?? '')
);
if ($scheduleDepartureTimestamp !== null && $scheduleDepartureTimestamp <= time()) {
    set_flash('error', 'This trip already left and can no longer be reserved. Please choose another departure.');
    redirect('booking.php');
}

if (!booking_date_within_allowed_window((string) ($schedule['departure_date'] ?? ''))) {
    set_flash('error', 'Bookings are limited to today through the next ' . MAX_ADVANCE_BOOKING_DAYS . ' days only.');
    redirect('booking.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentMethod = isset_post('payment_method');
    $selectedSeatIds = $_POST['seat_ids'] ?? [];
    $selectedSeatIds = is_array($selectedSeatIds) ? array_values(array_filter(array_map('intval', $selectedSeatIds))) : [];

    if ($paymentMethod !== 'qrph') {
        $error = 'Please choose a valid payment option.';
    } elseif ($selectedSeatIds === []) {
        $error = 'Please select at least one seat.';
    } else {
        global $conn;

        try {
            $currentSeatMap = get_schedule_seat_map($scheduleId);
            $seatMapById = [];
            foreach ($currentSeatMap as $seat) {
                $seatMapById[(int) $seat['seat_id']] = $seat;
            }

            $selectedSeatLabels = [];
            foreach ($selectedSeatIds as $seatId) {
                if (!isset($seatMapById[$seatId])) {
                    throw new RuntimeException('One or more selected seats are invalid.');
                }

                if (($seatMapById[$seatId]['status'] ?? '') !== 'available') {
                    throw new RuntimeException('One or more selected seats are no longer available. Please choose again.');
                }

                $selectedSeatLabels[] = (string) $seatMapById[$seatId]['seat_label'];
            }

            $bookingReference = generate_reference('GON', 8);
            $seatCount = count($selectedSeatIds);
            $totalAmount = (float) $schedule['price'] * $seatCount;
            $seatPreferences = encode_booking_seat_preferences($selectedSeatLabels);

            $stmt = $conn->prepare(
                'INSERT INTO bookings (user_id, schedule_id, booking_reference, number_of_passengers, total_amount, status, payment_method, payment_status, seat_preferences, booking_date, updated_at, expires_at)
                 VALUES (?, ?, ?, ?, ?, "pending", ?, "pending", ?, NOW(), NOW(), NULL)'
            );

            if (!$stmt) {
                throw new RuntimeException('Unable to create the booking.');
            }

            $userId = (int) $_SESSION['user_id'];
            $stmt->bind_param(
                'iisidss',
                $userId,
                $scheduleId,
                $bookingReference,
                $seatCount,
                $totalAmount,
                $paymentMethod,
                $seatPreferences
            );

            if (!$stmt->execute()) {
                $stmt->close();
                throw new RuntimeException('Unable to create the booking.');
            }

            $bookingId = (int) $stmt->insert_id;
            $stmt->close();

            create_notification(
                $userId,
                'booking',
                'Seat preference saved',
                'Your QRPh seat preference was saved. Complete the secure checkout and the final seat assignment will happen automatically after payment verification.',
                $bookingId
            );

            redirect('passenger-details.php?booking_id=' . $bookingId);
        } catch (Throwable $exception) {
            $error = $exception->getMessage();
        }
    }
}

$seatMap = get_schedule_seat_map($scheduleId);
$availableSeats = count_available_schedule_seats($scheduleId);
$selectedSeats = [];

include 'includes/header.php';
?>

<style>
.page-booking-details {
    background: #f5f7fb;
}

.page-booking-details .site-main {
    padding: 0;
}

.booking-seat-page {
    padding: 2rem 0 5rem;
}

.seat-page-back {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.9rem;
    font-weight: 800;
    gap: 0.55rem;
    margin-bottom: 1.3rem;
    text-decoration: none;
}

.seat-page-back:hover {
    color: #17257f;
}

.seat-page-heading {
    align-items: end;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-bottom: 1.7rem;
}

.seat-page-heading__eyebrow,
.seat-summary__kicker {
    align-items: center;
    color: #344da4;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 800;
    gap: 0.45rem;
    letter-spacing: 0.06em;
    text-transform: uppercase;
}

.seat-page-heading h1 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(1.85rem, 1.5rem + 1vw, 2.5rem);
    letter-spacing: -0.045em;
    margin: 0.35rem 0 0.45rem;
}

.seat-page-heading p {
    color: #667085;
    margin: 0;
}

.seat-page-heading__live {
    align-items: center;
    background: #ecfdf3;
    border: 1px solid #abefc6;
    border-radius: 999px;
    color: #067647;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 800;
    gap: 0.45rem;
    padding: 0.55rem 0.8rem;
    white-space: nowrap;
}

.seat-page-heading__live i {
    font-size: 0.48rem;
}

.seat-shell,
.seat-summary {
    background: #fff;
    border: 1px solid #e4e7ec;
    border-radius: 1.5rem;
    box-shadow: 0 18px 42px rgba(16, 24, 40, 0.07);
}

.seat-shell {
    padding: clamp(1.15rem, 2.3vw, 1.75rem);
}

.seat-shell__header {
    align-items: center;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-bottom: 1.3rem;
}

.seat-shell__header h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.18rem;
    margin: 0.35rem 0 0;
}

.seat-step {
    color: #667085;
    font-size: 0.78rem;
    font-weight: 800;
    letter-spacing: 0.045em;
    text-transform: uppercase;
}

.seat-count-pill {
    background: #fff5f3;
    border: 1px solid #fecdca;
    border-radius: 1rem;
    color: #b42318;
    min-width: 5.8rem;
    padding: 0.6rem 0.78rem;
    text-align: center;
}

.seat-count-pill strong {
    display: block;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.35rem;
    line-height: 1;
}

.seat-count-pill span {
    display: block;
    font-size: 0.68rem;
    font-weight: 800;
    margin-top: 0.25rem;
    text-transform: uppercase;
}

.seat-error {
    border: 0;
    border-radius: 0.9rem;
    font-size: 0.9rem;
    margin-bottom: 1.25rem;
}

.seat-map-stage {
    background:
        linear-gradient(90deg, rgba(52, 77, 164, 0.035) 0%, rgba(52, 77, 164, 0.035) 46%, transparent 46%, transparent 54%, rgba(52, 77, 164, 0.035) 54%, rgba(52, 77, 164, 0.035) 100%),
        #f8fafc;
    border: 1px solid #e4e7ec;
    border-radius: 1.25rem;
    padding: 1rem;
}

.driver-zone {
    align-items: center;
    background: linear-gradient(115deg, #101f46 0%, #263a93 100%);
    border-radius: 0.85rem;
    color: #fff;
    display: flex;
    font-size: 0.82rem;
    font-weight: 800;
    gap: 0.55rem;
    justify-content: center;
    letter-spacing: 0.03em;
    margin: 0 auto 1.05rem;
    max-width: 26rem;
    min-height: 3.25rem;
    text-transform: uppercase;
}

.seat-grid {
    display: grid;
    gap: 0.72rem;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    margin: 0 auto;
    max-width: 26rem;
}

.seat-card {
    align-items: center;
    background: #fff;
    border: 1px solid #d0d5dd;
    border-radius: 0.85rem;
    color: #344054;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    font-family: inherit;
    font-weight: 800;
    gap: 0.24rem;
    justify-content: center;
    min-height: 4.55rem;
    padding: 0.4rem;
    transition: background 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease, transform 0.18s ease;
}

.seat-card i {
    color: #344da4;
    font-size: 0.95rem;
}

.seat-card span {
    font-size: 0.82rem;
}

.seat-card.available:hover {
    border-color: #344da4;
    box-shadow: 0 8px 16px rgba(52, 77, 164, 0.16);
    transform: translateY(-2px);
}

.seat-card:focus-visible {
    box-shadow: 0 0 0 0.24rem rgba(52, 77, 164, 0.22);
    outline: 0;
}

.seat-card.selected {
    background: linear-gradient(145deg, #1d2e7d 0%, #344da4 100%);
    border-color: #1d2e7d;
    box-shadow: 0 8px 16px rgba(29, 46, 125, 0.24);
    color: #fff;
}

.seat-card.selected i {
    color: #ffcf3f;
}

.seat-card.reserved {
    background: #fffaeb;
    border-color: #fedf89;
    color: #b54708;
    cursor: not-allowed;
}

.seat-card.reserved i {
    color: #f79009;
}

.seat-card.booked,
.seat-card.used {
    background: #fef3f2;
    border-color: #fecdca;
    color: #b42318;
    cursor: not-allowed;
}

.seat-card.booked i,
.seat-card.used i {
    color: #f04438;
}

.seat-legend {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem 1.25rem;
    margin-top: 1.15rem;
}

.seat-legend span {
    align-items: center;
    color: #475467;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 700;
    gap: 0.42rem;
}

.seat-legend i {
    border: 1px solid #d0d5dd;
    border-radius: 0.3rem;
    display: inline-block;
    height: 0.9rem;
    width: 0.9rem;
}

.seat-legend .seat-legend__available { background: #fff; }
.seat-legend .seat-legend__selected { background: #344da4; border-color: #344da4; }
.seat-legend .seat-legend__reserved { background: #fffaeb; border-color: #fedf89; }
.seat-legend .seat-legend__booked { background: #fef3f2; border-color: #fecdca; }

.seat-summary {
    overflow: hidden;
    position: sticky;
    top: 1.25rem;
}

.seat-summary__hero {
    background:
        radial-gradient(circle at 100% 0%, rgba(255, 207, 63, 0.24) 0, transparent 8rem),
        linear-gradient(135deg, #101f46 0%, #25398e 100%);
    color: #fff;
    padding: 1.45rem;
}

.seat-summary__hero .seat-summary__kicker {
    color: #c7d7fe;
}

.seat-summary__route {
    align-items: center;
    display: grid;
    gap: 0.5rem;
    grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
    margin: 1.2rem 0;
}

.seat-summary__route span {
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1rem;
    font-weight: 800;
    overflow-wrap: anywhere;
}

.seat-summary__route span:last-child {
    text-align: right;
}

.seat-summary__route i {
    color: #ffcf3f;
}

.seat-summary__date {
    align-items: center;
    color: #e9efff;
    display: inline-flex;
    font-size: 0.84rem;
    font-weight: 700;
    gap: 0.5rem;
}

.seat-summary__body {
    padding: 1.35rem;
}

.trip-detail-grid {
    display: grid;
    gap: 0.75rem;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    margin-bottom: 1.35rem;
}

.trip-detail {
    background: #f8fafc;
    border: 1px solid #eaecf0;
    border-radius: 0.85rem;
    min-width: 0;
    padding: 0.75rem;
}

.trip-detail span {
    color: #667085;
    display: block;
    font-size: 0.7rem;
    font-weight: 800;
    margin-bottom: 0.32rem;
    text-transform: uppercase;
}

.trip-detail strong {
    color: #1d2939;
    display: block;
    font-size: 0.86rem;
    overflow-wrap: anywhere;
}

.seat-payment-field .form-label {
    color: #1d2939;
    font-size: 0.88rem;
    font-weight: 800;
    margin-bottom: 0.5rem;
}

.seat-payment-field .form-select {
    border-color: #d0d5dd;
    border-radius: 0.8rem;
    font-size: 0.92rem;
    font-weight: 700;
    min-height: 3.15rem;
}

.seat-payment-field .form-select:focus {
    border-color: #344da4;
    box-shadow: 0 0 0 0.2rem rgba(52, 77, 164, 0.14);
}

.seat-payment-note {
    align-items: flex-start;
    border: 0;
    border-radius: 0.8rem;
    display: flex;
    font-size: 0.78rem;
    gap: 0.55rem;
    line-height: 1.55;
    margin: 0.85rem 0 1.05rem;
}

.seat-payment-note i {
    margin-top: 0.18rem;
}

.seat-selection-summary {
    background: #f8fafc;
    border: 1px solid #eaecf0;
    border-radius: 0.95rem;
    margin-bottom: 1.05rem;
    padding: 0.9rem;
}

.seat-selection-summary__row {
    align-items: center;
    color: #667085;
    display: flex;
    font-size: 0.86rem;
    justify-content: space-between;
    padding: 0.36rem 0;
    text-align: right;
}

.seat-selection-summary__row strong {
    color: #1d2939;
    font-weight: 800;
    margin-left: 1rem;
}

.seat-selection-summary__row--total {
    border-top: 1px solid #e4e7ec;
    color: #344054;
    font-weight: 800;
    margin-top: 0.35rem;
    padding-top: 0.8rem;
}

.seat-selection-summary__row--total strong {
    color: #b42318;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.12rem;
}

.seat-continue-button {
    align-items: center;
    background: linear-gradient(180deg, #ef3e38 0%, #c82323 100%);
    border: 0;
    border-radius: 0.85rem;
    box-shadow: 0 10px 18px rgba(200, 35, 35, 0.22);
    color: #fff;
    display: flex;
    font-size: 0.95rem;
    font-weight: 800;
    gap: 0.6rem;
    justify-content: center;
    min-height: 3.25rem;
    transition: filter 0.2s ease, transform 0.2s ease;
    width: 100%;
}

.seat-continue-button:hover {
    color: #fff;
    filter: brightness(1.04);
    transform: translateY(-1px);
}

@media (max-width: 991px) {
    .seat-summary { position: static; }
}

@media (max-width: 767px) {
    .booking-seat-page { padding: 1.25rem 0 3.5rem; }
    .seat-page-heading { align-items: flex-start; flex-direction: column; margin-bottom: 1.25rem; }
    .seat-page-heading__live { align-self: flex-start; }
    .seat-shell, .seat-summary { border-radius: 1.1rem; }
    .seat-grid { gap: 0.55rem; }
    .seat-card { min-height: 4rem; }
    .seat-summary__hero, .seat-summary__body { padding: 1.15rem; }
}
</style>

<section class="booking-seat-page">
    <div class="container">
        <a class="seat-page-back" href="booking.php"><i class="fa-solid fa-arrow-left" aria-hidden="true"></i> Back to schedules</a>

        <div class="seat-page-heading">
            <div>
                <span class="seat-page-heading__eyebrow"><i class="fa-solid fa-ticket" aria-hidden="true"></i> Seat reservation</span>
                <h1>Choose your seats</h1>
                <p>Pick your preferred seats. Availability refreshes automatically while you book.</p>
            </div>
            <span class="seat-page-heading__live"><i class="fa-solid fa-circle" aria-hidden="true"></i> Live availability</span>
        </div>

        <div class="row g-4 booking-seat-layout">
            <div class="col-lg-7">
                <div class="seat-shell">
                    <div class="seat-shell__header">
                        <div>
                            <span class="seat-step">Step 1 of 3</span>
                            <h2>Seat layout</h2>
                        </div>
                        <div class="seat-count-pill">
                            <strong id="available-count"><?php echo $availableSeats; ?></strong>
                            <span>Available</span>
                        </div>
                    </div>

                    <?php if ($error !== ''): ?>
                        <div class="alert alert-danger seat-error"><i class="fa-solid fa-circle-exclamation me-2" aria-hidden="true"></i><?php echo e($error); ?></div>
                    <?php endif; ?>

                    <div class="seat-map-stage">
                        <div class="driver-zone">
                            <i class="fa-solid fa-steering-wheel" aria-hidden="true"></i> Driver / Front
                        </div>

                        <div id="seat-grid" class="seat-grid">
                            <?php foreach ($seatMap as $seat): ?>
                                <button
                                    type="button"
                                    class="seat-card <?php echo e($seat['status']); ?>"
                                    data-seat-id="<?php echo (int) $seat['seat_id']; ?>"
                                    data-seat-label="<?php echo e($seat['seat_label']); ?>"
                                    aria-label="Seat <?php echo e($seat['seat_label']); ?>, <?php echo e($seat['status']); ?>"
                                    aria-pressed="false"
                                    <?php echo $seat['status'] === 'available' ? '' : 'disabled'; ?>
                                >
                                    <i class="fa-solid fa-chair" aria-hidden="true"></i>
                                    <span><?php echo e($seat['seat_label']); ?></span>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="seat-legend" aria-label="Seat availability legend">
                        <span><i class="seat-legend__available" aria-hidden="true"></i> Available</span>
                        <span><i class="seat-legend__selected" aria-hidden="true"></i> Selected</span>
                        <span><i class="seat-legend__reserved" aria-hidden="true"></i> Reserved</span>
                        <span><i class="seat-legend__booked" aria-hidden="true"></i> Booked</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <aside class="seat-summary" aria-label="Trip summary">
                    <div class="seat-summary__hero">
                        <span class="seat-summary__kicker"><i class="fa-solid fa-route" aria-hidden="true"></i> Your journey</span>
                        <div class="seat-summary__route">
                            <span><?php echo e($schedule['origin_name']); ?></span>
                            <i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
                            <span><?php echo e($schedule['destination_name']); ?></span>
                        </div>
                        <span class="seat-summary__date"><i class="fa-regular fa-calendar" aria-hidden="true"></i> <?php echo date('D, F j, Y', strtotime($schedule['departure_date'])); ?> · <?php echo date('g:i A', strtotime($schedule['departure_time'])); ?></span>
                    </div>

                    <div class="seat-summary__body">
                        <div class="trip-detail-grid">
                            <div class="trip-detail">
                                <span>Bus</span>
                                <strong><?php echo e($schedule['bus_name'] ?: $schedule['bus_code']); ?></strong>
                            </div>
                            <div class="trip-detail">
                                <span>Class</span>
                                <strong><?php echo e($schedule['bus_type'] ?: $schedule['class_name']); ?></strong>
                            </div>
                            <div class="trip-detail">
                                <span>Departure</span>
                                <strong><?php echo date('g:i A', strtotime($schedule['departure_time'])); ?></strong>
                            </div>
                            <div class="trip-detail">
                                <span>Arrival</span>
                                <strong><?php echo date('g:i A', strtotime($schedule['arrival_time'])); ?></strong>
                            </div>
                        </div>

                        <form method="post" id="booking-seat-form">
                            <?php csrf_field(); ?>
                            <div class="seat-payment-field">
                                <label class="form-label" for="payment_method">Payment option</label>
                                <select class="form-select" id="payment_method" name="payment_method" required>
                                    <option value="qrph">QRPh - automatic verification</option>
                                </select>
                            </div>

                            <div id="payment-note" class="alert alert-info seat-payment-note">
                                <i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>QRPh uses secure automatic verification. Your final seat is locked and QR ticket issued after PayMongo confirms the transaction.</span>
                            </div>

                            <div class="seat-selection-summary">
                                <div class="seat-selection-summary__row">
                                    <span>Selected seats</span>
                                    <strong id="selected-seat-labels">None</strong>
                                </div>
                                <div class="seat-selection-summary__row">
                                    <span>Passengers</span>
                                    <strong id="selected-seat-count">0</strong>
                                </div>
                                <div class="seat-selection-summary__row seat-selection-summary__row--total">
                                    <span>Estimated total</span>
                                    <strong>PHP <span id="selected-total">0.00</span></strong>
                                </div>
                            </div>

                            <div id="seat-inputs"></div>

                            <button class="seat-continue-button" type="submit">
                                Continue to passenger details <i class="fa-solid fa-arrow-right" aria-hidden="true"></i>
                            </button>
                        </form>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const seatGrid = document.getElementById('seat-grid');
    const seatInputs = document.getElementById('seat-inputs');
    const selectedSeatLabels = document.getElementById('selected-seat-labels');
    const selectedSeatCount = document.getElementById('selected-seat-count');
    const selectedTotal = document.getElementById('selected-total');
    const availableCount = document.getElementById('available-count');
    const paymentMethod = document.getElementById('payment_method');
    const paymentNote = document.getElementById('payment-note');
    const pricePerSeat = <?php echo json_encode((float) $schedule['price']); ?>;
    const selectedSeats = new Map();

    function renderSelection() {
        seatInputs.innerHTML = '';
        Array.from(selectedSeats.entries()).forEach(function ([id]) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'seat_ids[]';
            input.value = id;
            seatInputs.appendChild(input);
        });

        const labels = Array.from(selectedSeats.values());
        selectedSeatLabels.textContent = labels.length ? labels.join(', ') : 'None';
        selectedSeatCount.textContent = String(labels.length);
        selectedTotal.textContent = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(labels.length * pricePerSeat);
    }

    if (seatGrid) {
        seatGrid.addEventListener('click', function (event) {
            const button = event.target.closest('.seat-card');

            if (!button || button.disabled || (!button.classList.contains('available') && !button.classList.contains('selected'))) {
                return;
            }

            const seatId = button.dataset.seatId;
            const seatLabel = button.dataset.seatLabel;

            if (selectedSeats.has(seatId)) {
                selectedSeats.delete(seatId);
                button.classList.remove('selected');
                button.classList.add('available');
                button.setAttribute('aria-pressed', 'false');
                button.setAttribute('aria-label', 'Seat ' + seatLabel + ', available');
            } else {
                selectedSeats.set(seatId, seatLabel);
                button.classList.remove('available');
                button.classList.add('selected');
                button.setAttribute('aria-pressed', 'true');
                button.setAttribute('aria-label', 'Seat ' + seatLabel + ', selected');
            }

            renderSelection();
        });
    }

    async function refreshSeats() {
        try {
            const response = await fetch('booking-details.php?schedule_id=<?php echo $scheduleId; ?>&ajax=seats', { cache: 'no-store' });
            const data = await response.json();
            if (!data || !Array.isArray(data.seats)) {
                return;
            }

            availableCount.textContent = String(data.available ?? 0);

            data.seats.forEach(function (seat) {
                const button = document.querySelector('[data-seat-id="' + seat.seat_id + '"]');
                if (!button) {
                    return;
                }

                if (selectedSeats.has(String(seat.seat_id))) {
                    return;
                }

                button.disabled = seat.status !== 'available';
                button.className = 'seat-card ' + seat.status;
                button.setAttribute('aria-pressed', 'false');
                button.setAttribute('aria-label', 'Seat ' + button.dataset.seatLabel + ', ' + seat.status);
            });
        } catch (error) {
            console.error(error);
        }
    }

    function syncPaymentNote() {
        if (!paymentMethod || !paymentNote) {
            return;
        }

        paymentNote.className = 'alert alert-info seat-payment-note';
        paymentNote.innerHTML = '<i class="fa-solid fa-circle-info" aria-hidden="true"></i><span>QRPh uses secure automatic verification. No receipt upload is needed; the final seat is locked after PayMongo confirms the transaction. Approved ID discounts are paid separately in cash by the bus operator.</span>';
    }

    renderSelection();
    syncPaymentNote();
    if (paymentMethod) {
        paymentMethod.addEventListener('change', syncPaymentNote);
    }
    window.setInterval(refreshSeats, 15000);
});
</script>

<?php include 'includes/footer.php'; ?>
