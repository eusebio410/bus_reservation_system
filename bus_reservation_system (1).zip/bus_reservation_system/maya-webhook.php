<?php
// This endpoint is deliberately exempt from browser CSRF protection. Maya
// authenticates delivery by source IP; every terminal outcome is then checked
// against Maya's Retrieve Payment API before a booking can change state.
define('BUS_MAYA_WEBHOOK_REQUEST', true);
require_once __DIR__ . '/includes/config.php';

header('Content-Type: application/json');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    echo json_encode(['ok' => false, 'message' => 'Method not allowed.']);
    exit;
}

if (!maya_webhook_request_is_trusted()) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'message' => 'Untrusted webhook source.']);
    exit;
}

$rawPayload = file_get_contents('php://input');
$event = json_decode((string) $rawPayload, true);
if (!is_array($event)) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid webhook JSON.']);
    exit;
}

$result = process_maya_checkout_webhook($event);
if (!$result['ok']) {
    error_log('Maya webhook could not be processed: ' . (string) ($result['message'] ?? 'Unknown error'));
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => 'Webhook processing failed.']);
    exit;
}

http_response_code(200);
echo json_encode(['ok' => true]);
