<?php
$base_url = '';
$page_title = 'Bus Routes - Gonzaga Terminal';

include 'includes/config.php';

$format_place_label = static function ($location, $terminal_name) {
    $location = trim((string) $location);

    if ($location !== '') {
        $parts = explode(',', $location);
        $label = trim($parts[0]);
    } else {
        $label = preg_replace('/\s+Terminal$/i', '', (string) $terminal_name);
    }

    $label = preg_replace('/\s+City$/i', '', $label);

    return $label !== '' ? $label : (string) $terminal_name;
};

$format_duration = static function ($minutes) {
    $minutes = max(0, (int) $minutes);

    if ($minutes === 0) {
        return 'Schedule varies';
    }

    $high = max(1, (int) ceil($minutes / 60));
    $low = max(1, $high - 1);

    if ($low === $high) {
        return $high . ' hour' . ($high === 1 ? '' : 's');
    }

    return $low . '-' . $high . ' hours';
};

$infer_corridor = static function ($origin_name, $destination_name, $destination_location) {
    $haystack = strtolower(trim($origin_name . ' ' . $destination_name . ' ' . $destination_location));

    if (str_contains($haystack, 'tuguegarao') || str_contains($haystack, 'cagayan')) {
        return 'NLEX, SCTEX, TPLEX';
    }

    if (str_contains($haystack, 'baguio') || str_contains($haystack, 'dagupan') || str_contains($haystack, 'pangasinan')) {
        return 'NLEX, SCTEX, TPLEX';
    }

    if (str_contains($haystack, 'olongapo') || str_contains($haystack, 'zambales')) {
        return 'NLEX, SCTEX';
    }

    return 'Main provincial corridor';
};

$routes_query = "
    SELECT
        r.route_id,
        r.distance,
        r.travel_time,
        t1.terminal_name AS origin_name,
        t1.location AS origin_location,
        t2.terminal_name AS destination_name,
        t2.location AS destination_location
    FROM routes r
    JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
    JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
    ORDER BY t1.terminal_name ASC, t2.terminal_name ASC
";

$routes_result = $conn->query($routes_query);

$route_groups = [];
$total_routes = 0;
$group_icon_map = [
    'cubao' => 'fa-location-dot',
    'pasay' => 'fa-location-dot',
    'kamias' => 'fa-location-dot',
];

if ($routes_result && $routes_result->num_rows > 0) {
    while ($route = $routes_result->fetch_assoc()) {
        $origin_label = $format_place_label($route['origin_location'] ?? '', $route['origin_name'] ?? '');
        $destination_label = $format_place_label($route['destination_location'] ?? '', $route['destination_name'] ?? '');
        $group_key = strtolower($origin_label);

        if (!isset($route_groups[$group_key])) {
            $route_groups[$group_key] = [
                'title' => $origin_label . ' Hub Routes',
                'origin_label' => $origin_label,
                'icon' => $group_icon_map[$group_key] ?? 'fa-location-dot',
                'routes' => [],
            ];
        }

        $route['origin_label'] = $origin_label;
        $route['destination_label'] = $destination_label;
        $route['duration_label'] = $format_duration($route['travel_time'] ?? 0);
        $route['corridor_label'] = $infer_corridor($route['origin_name'] ?? '', $route['destination_name'] ?? '', $route['destination_location'] ?? '');

        $route_groups[$group_key]['routes'][] = $route;
        $total_routes++;
    }
}

$terminal_count_query = "SELECT COUNT(*) AS total FROM terminals";
$terminal_count_result = $conn->query($terminal_count_query);
$terminal_count = 0;

if ($terminal_count_result && $terminal_row = $terminal_count_result->fetch_assoc()) {
    $terminal_count = (int) ($terminal_row['total'] ?? 0);
}

include 'includes/header.php';
?>

<style>
.page-routes {
    background: #eef1f5;
}

.page-routes .site-main {
    padding: 0;
}

.page-routes footer {
    margin-top: 0 !important;
}

.page-routes .routes-hero {
    background:
        linear-gradient(90deg, rgba(10, 18, 34, 0.88) 0%, rgba(10, 18, 34, 0.74) 30%, rgba(10, 18, 34, 0.42) 100%),
        url('assets/images/bus-terminal-hero.jpg') center center / cover no-repeat;
    min-height: 34rem;
    overflow: hidden;
    position: relative;
}

.page-routes .routes-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.16) 0%, rgba(7, 12, 24, 0.26) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-routes .routes-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 34rem;
    padding: 5.4rem 0 4rem;
    position: relative;
    z-index: 1;
}

.page-routes .routes-hero__copy {
    max-width: 52rem;
}

.page-routes .routes-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(3rem, 5vw, 4.6rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.35rem;
}

.page-routes .routes-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.08rem, 0.98rem + 0.42vw, 1.42rem);
    line-height: 1.5;
    margin: 0;
    max-width: 48rem;
}

.page-routes .routes-section {
    padding: 3.2rem 0 5.2rem;
}

.page-routes .routes-overview-card {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.6rem;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
    display: flex;
    flex-direction: column;
    margin-bottom: 3rem;
    padding: 2rem 2rem 2.25rem;
    text-align: center;
}

.page-routes .routes-overview-card__icon {
    align-items: center;
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 1.7rem;
    height: 4.8rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.8rem;
}

.page-routes .routes-overview-card h2 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.9rem;
}

.page-routes .routes-overview-card p {
    color: #475467;
    font-size: 1.05rem;
    line-height: 1.65;
    margin: 0 0 1.5rem;
    max-width: 44rem;
}

.page-routes .routes-overview-card__stats {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
    justify-content: center;
}

.page-routes .routes-overview-card__stats span {
    background: #f8fafc;
    border-radius: 999px;
    color: #344054;
    display: inline-flex;
    font-size: 0.94rem;
    font-weight: 700;
    gap: 0.5rem;
    padding: 0.65rem 0.95rem;
}

.page-routes .routes-overview-card__stats i {
    color: #a72d2d;
}

.page-routes .routes-group + .routes-group {
    margin-top: 2.9rem;
}

.page-routes .route-pair-pill {
    background: #fff5f1;
    border: 1px solid rgba(167, 45, 45, 0.16);
    border-radius: 999px;
    color: #a72d2d;
    display: inline-flex;
    font-size: 0.74rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    margin-bottom: 0.8rem;
    padding: 0.35rem 0.7rem;
    text-transform: uppercase;
}

.page-routes .route-card-subtitle {
    color: #667085;
    font-size: 0.95rem;
    margin-bottom: 0.7rem;
}

.page-routes .routes-group__heading {
    align-items: center;
    color: #08152f;
    display: inline-flex;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.55rem;
    font-weight: 800;
    gap: 0.85rem;
    letter-spacing: -0.04em;
    margin-bottom: 1.5rem;
}

.page-routes .routes-group__heading i {
    align-items: center;
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    border-radius: 1rem;
    color: #fff;
    display: inline-flex;
    font-size: 0.96rem;
    height: 2.3rem;
    justify-content: center;
    width: 2.3rem;
}

.page-routes .routes-card-grid {
    display: grid;
    gap: 1rem;
    grid-template-columns: repeat(3, minmax(0, 1fr));
}

.page-routes .route-network-card {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1rem;
    box-shadow: 0 16px 28px rgba(15, 23, 42, 0.05);
    color: inherit;
    display: block;
    min-height: 100%;
    padding: 1.2rem 1.25rem 1.3rem;
    text-decoration: none;
    transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
}

.page-routes .route-network-card:hover {
    border-color: rgba(167, 45, 45, 0.18);
    box-shadow: 0 22px 34px rgba(15, 23, 42, 0.08);
    color: inherit;
    transform: translateY(-3px);
}

.page-routes .route-network-card h3 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.22rem;
    font-weight: 700;
    letter-spacing: -0.03em;
    line-height: 1.15;
    margin: 0 0 0.85rem;
}

.page-routes .route-network-card p {
    color: #475467;
    font-size: 0.96rem;
    margin: 0 0 0.45rem;
}

.page-routes .route-network-card strong {
    color: #344054;
    font-weight: 700;
}

.page-routes .routes-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-routes .routes-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.6rem;
}

.page-routes .routes-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-routes .routes-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-routes .routes-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-routes .routes-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 1199px) {
    .page-routes .routes-card-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 991px) {
    .page-routes .routes-hero {
        min-height: auto;
    }

    .page-routes .routes-hero__inner {
        min-height: auto;
        padding: 4.2rem 0 3.6rem;
    }
}

@media (max-width: 767px) {
    .page-routes .routes-card-grid {
        grid-template-columns: 1fr;
    }

    .page-routes .routes-section {
        padding-top: 2.4rem;
    }

    .page-routes .routes-overview-card {
        border-radius: 1.2rem;
        padding: 1.5rem 1.2rem 1.7rem;
    }

    .page-routes .routes-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="routes-hero">
    <div class="container routes-hero__inner">
        <div class="routes-hero__copy">
            <h1 class="routes-hero__title">Bus Routes</h1>
            <p>Explore the Gonzaga Terminal route network and the destination records currently available in your system. Use these cards as the base that admins can expand after terminal interviews.</p>
        </div>
    </div>
</section>

<section class="routes-section">
    <div class="container">
        <article class="routes-overview-card">
            <span class="routes-overview-card__icon"><i class="fas fa-bus-simple"></i></span>
            <h2>Extensive Route Network</h2>
            <p>From Gonzaga, Cagayan to Manila terminals and other destinations you add later, this page keeps your capstone route network centered on the municipality terminal.</p>

            <div class="routes-overview-card__stats">
                <span><i class="fas fa-route"></i> <?php echo number_format($total_routes); ?> active routes</span>
                <span><i class="fas fa-building"></i> <?php echo number_format($terminal_count); ?> terminals in network</span>
                <span><i class="fas fa-ticket-alt"></i> Direct booking links available</span>
            </div>
        </article>

        <?php if (!empty($route_groups)): ?>
            <?php foreach ($route_groups as $group): ?>
                <section class="routes-group">
                    <h2 class="routes-group__heading">
                        <i class="fas <?php echo htmlspecialchars($group['icon']); ?>"></i>
                        <span><?php echo htmlspecialchars($group['title']); ?></span>
                    </h2>

                    <div class="routes-card-grid">
                        <?php foreach ($group['routes'] as $route): ?>
                            <a class="route-network-card" href="booking.php?route_id=<?php echo (int) $route['route_id']; ?>">
                                <div class="route-pair-pill">Route Pairing</div>
                                <h3><?php echo htmlspecialchars($route['origin_name']); ?> → <?php echo htmlspecialchars($route['destination_name']); ?></h3>
                                <p class="route-card-subtitle"><?php echo htmlspecialchars($route['origin_label']); ?> to <?php echo htmlspecialchars($route['destination_label']); ?></p>
                                <p><strong>Via:</strong> <?php echo htmlspecialchars($route['corridor_label']); ?></p>
                                <p><strong>Travel:</strong> <?php echo htmlspecialchars($route['duration_label']); ?> · <?php echo number_format((float) $route['distance'], 0); ?> km</p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="routes-empty-state">
                <span class="routes-empty-state__icon"><i class="fas fa-route"></i></span>
                <h2>No routes available</h2>
                <p>The route network has not been populated yet. Add route records in the admin panel to show destination cards on this page.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="routes-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
