<?php
/**
 * Refreshes daily recurring schedules through the current booking window.
 *
 * Run this from Windows Task Scheduler (or cron on Linux) every 5-15 minutes:
 * php scripts/run_schedule_recurrences.php
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This script can only run from the command line.');
}

require_once __DIR__ . '/../includes/config.php';

if (!acquire_database_lock(APP_HOUSEKEEPING_LOCK_NAME, 5)) {
    fwrite(STDERR, "Another schedule refresh is already running." . PHP_EOL);
    exit(1);
}

try {
    $result = materialize_active_schedule_recurrences();
    echo 'Recurring schedules refreshed: ' . (int) ($result['created'] ?? 0) . ' created, '
        . (int) ($result['skipped_duplicate'] ?? 0) . ' already present, '
        . (int) ($result['skipped_conflict'] ?? 0) . ' blocked by a bus or operator conflict.' . PHP_EOL;
} finally {
    release_database_lock(APP_HOUSEKEEPING_LOCK_NAME);
}
