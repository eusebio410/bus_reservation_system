<?php
/**
 * Creates the first administrator for a new deployment.
 * Run only from the command line; no credentials are embedded in the project.
 *
 * Example:
 * php scripts/create_initial_admin.php --email=admin@example.com --name="Terminal Administrator" --phone=09171234567
 */
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This setup utility can only run from the command line.');
}

require_once __DIR__ . '/../includes/config.php';

$options = getopt('', ['email:', 'name:', 'phone::']);
$email = normalize_email_address((string) ($options['email'] ?? ''));
$fullname = trim((string) ($options['name'] ?? ''));
$phoneInput = trim((string) ($options['phone'] ?? ''));
$phone = normalize_ph_phone($phoneInput);

if ($email === '' || $fullname === '') {
    fwrite(STDERR, "Usage: php scripts/create_initial_admin.php --email=admin@example.com --name=\"Terminal Administrator\" [--phone=09171234567]\n");
    exit(1);
}

if (!is_valid_email_address($email)) {
    fwrite(STDERR, "A valid email address is required.\n");
    exit(1);
}

if ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
    fwrite(STDERR, "Phone must use a Philippine mobile number such as 09171234567 or +639171234567.\n");
    exit(1);
}

$existingUser = db_select_one('SELECT user_id FROM users WHERE email = ? LIMIT 1', 's', [$email]);
if ($existingUser) {
    fwrite(STDERR, "An account already uses this email. Use User Management to assign its role instead of resetting it here.\n");
    exit(1);
}

$adminRole = db_select_one('SELECT role_id FROM roles WHERE role_key = "admin" LIMIT 1');
if (!$adminRole) {
    fwrite(STDERR, "The admin role is missing. Check the database migration.\n");
    exit(1);
}

fwrite(STDOUT, "Enter a new administrator password (input is visible): ");
$password = trim((string) fgets(STDIN));
if (strlen($password) < 12) {
    fwrite(STDERR, "Administrator passwords must be at least 12 characters long.\n");
    exit(1);
}

$created = db_execute(
    'INSERT INTO users (fullname, email, phone, password, is_admin, role_id, account_status, created_at, updated_at)
     VALUES (?, ?, ?, ?, 1, ?, "active", NOW(), NOW())',
    'ssssi',
    [$fullname, $email, $phone, password_hash($password, PASSWORD_BCRYPT), (int) $adminRole['role_id']]
);

if (!$created) {
    fwrite(STDERR, "The administrator account could not be created. Review the PHP error log and database connection.\n");
    exit(1);
}

fwrite(STDOUT, "Initial administrator created. Sign in at /admin/login.php and keep this password in a password manager.\n");
