<?php
require dirname(__DIR__) . '/includes/config.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$scheduleWindowDays = 30;

$routeDefinitions = [
    'gonzaga-sampaloc' => ['origin' => 'Gonzaga Terminal', 'destination' => 'Sampaloc Terminal'],
    'gonzaga-cubao' => ['origin' => 'Gonzaga Terminal', 'destination' => 'Cubao Terminal'],
];

$scheduleTemplates = [
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-01', 'departure' => '12:30:00', 'arrival' => '00:30:00', 'price' => 1450],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-02', 'departure' => '14:00:00', 'arrival' => '02:00:00', 'price' => 1450],
    ['route' => 'gonzaga-cubao', 'bus' => 'GON-DELUXE-03', 'departure' => '14:30:00', 'arrival' => '03:00:00', 'price' => 1500],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-04', 'departure' => '15:00:00', 'arrival' => '03:00:00', 'price' => 1450],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-SLEEPER-01', 'departure' => '16:20:00', 'arrival' => '04:20:00', 'price' => 1850],
];

$routeIds = [];
$busData = [];
$updated = 0;
$inserted = 0;

try {
    $conn->begin_transaction();

    foreach ($routeDefinitions as $routeKey => $route) {
        $row = db_select_one(
            'SELECT r.route_id
             FROM routes r
             JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
             JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
             WHERE origin.terminal_name = ?
             AND destination.terminal_name = ?
             LIMIT 1',
            'ss',
            [$route['origin'], $route['destination']]
        );

        if (!$row) {
            throw new RuntimeException('Missing route: ' . $route['origin'] . ' to ' . $route['destination']);
        }

        $routeIds[$routeKey] = (int) $row['route_id'];
    }

    foreach ($scheduleTemplates as $template) {
        $busCode = (string) $template['bus'];
        if (isset($busData[$busCode])) {
            continue;
        }

        $row = db_select_one(
            'SELECT b.bus_id, b.total_seats, COALESCE(NULLIF(b.bus_type, ""), bc.class_name) AS bus_type
             FROM buses b
             LEFT JOIN bus_classes bc ON b.class_id = bc.class_id
             WHERE b.bus_code = ?
             LIMIT 1',
            's',
            [$busCode]
        );

        if (!$row) {
            throw new RuntimeException('Missing bus: ' . $busCode);
        }

        $busData[$busCode] = [
            'bus_id' => (int) $row['bus_id'],
            'total_seats' => max(1, (int) ($row['total_seats'] ?? fixed_bus_seat_capacity())),
            'bus_type' => (string) ($row['bus_type'] ?? ''),
        ];
    }

    $today = new DateTimeImmutable('today', app_timezone());

    for ($day = 0; $day < $scheduleWindowDays; $day++) {
        $departureDate = $today->modify("+$day day")->format('Y-m-d');

        foreach ($scheduleTemplates as $template) {
            $bus = $busData[$template['bus']];
            $routeId = $routeIds[$template['route']];
            $busId = (int) $bus['bus_id'];

            $existing = db_select_one(
                'SELECT schedule_id
                 FROM schedules
                 WHERE bus_id = ?
                 AND departure_date = ?
                 LIMIT 1',
                'is',
                [$busId, $departureDate]
            );

            if ($existing) {
                $ok = db_execute(
                    'UPDATE schedules
                     SET route_id = ?, bus_type = ?, is_auto_assigned = 0, departure_time = ?, arrival_time = ?, price = ?
                     WHERE schedule_id = ?',
                    'isssdi',
                    [
                        $routeId,
                        $bus['bus_type'],
                        $template['departure'],
                        $template['arrival'],
                        (float) $template['price'],
                        (int) $existing['schedule_id'],
                    ]
                );

                if (!$ok) {
                    throw new RuntimeException('Failed to update schedule #' . (int) $existing['schedule_id']);
                }

                $updated++;
                continue;
            }

            $ok = db_execute(
                'INSERT INTO schedules (bus_id, route_id, bus_type, is_auto_assigned, departure_time, arrival_time, departure_date, price, available_seats, status, trip_status)
                 VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, "scheduled", "scheduled")',
                'iissssdi',
                [
                    $busId,
                    $routeId,
                    $bus['bus_type'],
                    $template['departure'],
                    $template['arrival'],
                    $departureDate,
                    (float) $template['price'],
                    (int) $bus['total_seats'],
                ]
            );

            if (!$ok) {
                throw new RuntimeException('Failed to insert schedule for bus ' . $template['bus'] . ' on ' . $departureDate);
            }

            $scheduleId = db_last_insert_id();

            if (column_exists('schedules', 'schedule_code')) {
                db_execute(
                    'UPDATE schedules SET schedule_code = ? WHERE schedule_id = ?',
                    'si',
                    ['SCH-' . str_pad((string) $scheduleId, 5, '0', STR_PAD_LEFT), $scheduleId]
                );
            }

            $inserted++;
        }
    }

    $conn->commit();

    echo "Gonzaga daily schedule synced." . PHP_EOL;
    echo "Window days: $scheduleWindowDays" . PHP_EOL;
    echo "Updated: $updated" . PHP_EOL;
    echo "Inserted: $inserted" . PHP_EOL;
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, 'Sync failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}
