<?php
/**
 * Applies application-managed schema upgrades before the site is opened to
 * visitors. Run once after importing database.sql and after each release.
 *
 * Usage: php scripts/prepare_system.php
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('This script can only run from the command line.');
}

require_once __DIR__ . '/../includes/config.php';

// The CLI bootstrap has already run the idempotent migration. Calling this
// explicitly keeps the script safe if that bootstrap behavior changes later.
ensure_schema_migrations();
run_runtime_housekeeping();

echo 'System preparation completed.' . PHP_EOL;
echo 'Schema version: ' . APP_BOOTSTRAP_VERSION . PHP_EOL;
echo 'Next: create the first administrator with scripts/create_initial_admin.php.' . PHP_EOL;
