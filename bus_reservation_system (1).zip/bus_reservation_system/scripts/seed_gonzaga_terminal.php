<?php
require dirname(__DIR__) . '/includes/config.php';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$classes = [
    'Regular AC' => [
        'capacity' => 48,
        'description' => 'Standard air-conditioned provincial coach',
        'amenities' => 'Air-conditioned, Reclining Seats',
    ],
    'First Class / Deluxe' => [
        'capacity' => 29,
        'description' => 'Deluxe bus used for Gonzaga departures',
        'amenities' => 'Air-conditioned, Larger Seats, Charging Ports',
    ],
    'Premium - Victory Royal Sleeper' => [
        'capacity' => 32,
        'description' => 'Sleeper configuration for overnight provincial service',
        'amenities' => 'Sleeper Seats, Curtains, Charging Ports',
    ],
];

$terminals = [
    [
        'name' => 'Gonzaga Terminal',
        'location' => 'Gonzaga, Cagayan',
        'address' => 'Municipal Bus Terminal, Centro, Gonzaga, Cagayan',
        'phone' => '0912-345-0101',
        'email' => 'gonzaga.terminal@local.test',
    ],
    [
        'name' => 'Sampaloc Terminal',
        'location' => 'Sampaloc, Manila',
        'address' => 'Sampaloc, City of Manila',
        'phone' => '0912-345-0102',
        'email' => 'sampaloc.terminal@local.test',
    ],
    [
        'name' => 'Cubao Terminal',
        'location' => 'Cubao, Quezon City',
        'address' => 'New York Avenue, Cubao, Quezon City',
        'phone' => '0912-345-0103',
        'email' => 'cubao.terminal@local.test',
    ],
];

$routes = [
    [
        'key' => 'gonzaga-sampaloc',
        'origin' => 'Gonzaga Terminal',
        'destination' => 'Sampaloc Terminal',
        'distance' => 620,
        'travel_time' => 720,
    ],
    [
        'key' => 'gonzaga-cubao',
        'origin' => 'Gonzaga Terminal',
        'destination' => 'Cubao Terminal',
        'distance' => 635,
        'travel_time' => 750,
    ],
];

$fares = [
    ['route' => 'gonzaga-sampaloc', 'class' => 'First Class / Deluxe', 'base_fare' => 1450, 'discount' => 0],
    ['route' => 'gonzaga-sampaloc', 'class' => 'Premium - Victory Royal Sleeper', 'base_fare' => 1850, 'discount' => 0],
    ['route' => 'gonzaga-cubao', 'class' => 'First Class / Deluxe', 'base_fare' => 1500, 'discount' => 0],
];

$buses = [
    ['code' => 'GON-DELUXE-01', 'class' => 'First Class / Deluxe', 'registration' => 'GON-001', 'model' => 'Deluxe Coach', 'year' => 2024, 'seats' => 29, 'status' => 'active'],
    ['code' => 'GON-DELUXE-02', 'class' => 'First Class / Deluxe', 'registration' => 'GON-002', 'model' => 'Deluxe Coach', 'year' => 2024, 'seats' => 29, 'status' => 'active'],
    ['code' => 'GON-DELUXE-03', 'class' => 'First Class / Deluxe', 'registration' => 'GON-003', 'model' => 'Deluxe Coach', 'year' => 2023, 'seats' => 29, 'status' => 'active'],
    ['code' => 'GON-DELUXE-04', 'class' => 'First Class / Deluxe', 'registration' => 'GON-004', 'model' => 'Deluxe Coach', 'year' => 2023, 'seats' => 29, 'status' => 'active'],
    ['code' => 'GON-SLEEPER-01', 'class' => 'Premium - Victory Royal Sleeper', 'registration' => 'GON-101', 'model' => 'Sleeper Coach', 'year' => 2025, 'seats' => 32, 'status' => 'active'],
];

$schedule_templates = [
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-01', 'departure' => '12:30:00', 'arrival' => '00:30:00', 'price' => 1450],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-02', 'departure' => '14:00:00', 'arrival' => '02:00:00', 'price' => 1450],
    ['route' => 'gonzaga-cubao', 'bus' => 'GON-DELUXE-03', 'departure' => '14:30:00', 'arrival' => '03:00:00', 'price' => 1500],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-DELUXE-04', 'departure' => '15:00:00', 'arrival' => '03:00:00', 'price' => 1450],
    ['route' => 'gonzaga-sampaloc', 'bus' => 'GON-SLEEPER-01', 'departure' => '16:20:00', 'arrival' => '04:20:00', 'price' => 1850],
];

$scheduleWindowDays = 30;

$terminalIds = [];
$classIds = [];
$routeIds = [];
$busData = [];

try {
    $conn->begin_transaction();

    foreach ($classes as $className => $classData) {
        $classNameSafe = $conn->real_escape_string($className);
        $descriptionSafe = $conn->real_escape_string($classData['description']);
        $amenitiesSafe = $conn->real_escape_string($classData['amenities']);

        $conn->query("INSERT INTO bus_classes (class_name, capacity, description, amenities) VALUES ('$classNameSafe', {$classData['capacity']}, '$descriptionSafe', '$amenitiesSafe') ON DUPLICATE KEY UPDATE capacity = VALUES(capacity), description = VALUES(description), amenities = VALUES(amenities)");
    }

    $classResult = $conn->query('SELECT class_id, class_name FROM bus_classes');
    while ($row = $classResult->fetch_assoc()) {
        $classIds[$row['class_name']] = (int) $row['class_id'];
    }

    $conn->query('SET FOREIGN_KEY_CHECKS = 0');
    foreach (['passengers', 'bookings', 'schedules', 'fares', 'routes', 'buses', 'terminals'] as $table) {
        $conn->query("TRUNCATE TABLE $table");
    }
    $conn->query('SET FOREIGN_KEY_CHECKS = 1');

    foreach ($terminals as $terminal) {
        $name = $conn->real_escape_string($terminal['name']);
        $location = $conn->real_escape_string($terminal['location']);
        $address = $conn->real_escape_string($terminal['address']);
        $phone = $conn->real_escape_string($terminal['phone']);
        $email = $conn->real_escape_string($terminal['email']);

        $conn->query("INSERT INTO terminals (terminal_name, location, address, phone, email) VALUES ('$name', '$location', '$address', '$phone', '$email')");
        $terminalIds[$terminal['name']] = (int) $conn->insert_id;
    }

    foreach ($routes as $route) {
        $originId = $terminalIds[$route['origin']];
        $destinationId = $terminalIds[$route['destination']];

        $conn->query("INSERT INTO routes (origin_terminal_id, destination_terminal_id, distance, travel_time) VALUES ($originId, $destinationId, {$route['distance']}, {$route['travel_time']})");
        $routeIds[$route['key']] = (int) $conn->insert_id;
    }

    foreach ($buses as $bus) {
        $classId = $classIds[$bus['class']];
        $code = $conn->real_escape_string($bus['code']);
        $registration = $conn->real_escape_string($bus['registration']);
        $model = $conn->real_escape_string($bus['model']);
        $status = $conn->real_escape_string($bus['status']);

        $conn->query("INSERT INTO buses (bus_code, class_id, registration_number, model, year_manufactured, total_seats, status) VALUES ('$code', $classId, '$registration', '$model', {$bus['year']}, {$bus['seats']}, '$status')");
        $busData[$bus['code']] = ['id' => (int) $conn->insert_id, 'seats' => (int) $bus['seats']];
    }

    foreach ($fares as $fare) {
        $routeId = $routeIds[$fare['route']];
        $classId = $classIds[$fare['class']];
        $conn->query("INSERT INTO fares (route_id, class_id, base_fare, discount_percentage) VALUES ($routeId, $classId, {$fare['base_fare']}, {$fare['discount']})");
    }

    $today = new DateTimeImmutable('today', new DateTimeZone('Asia/Manila'));
    for ($day = 0; $day < $scheduleWindowDays; $day++) {
        $departureDate = $today->modify("+$day day")->format('Y-m-d');

        foreach ($schedule_templates as $template) {
            $routeId = $routeIds[$template['route']];
            $busId = $busData[$template['bus']]['id'];
            $availableSeats = $busData[$template['bus']]['seats'];
            $departure = $conn->real_escape_string($template['departure']);
            $arrival = $conn->real_escape_string($template['arrival']);

            $conn->query("INSERT INTO schedules (bus_id, route_id, departure_time, arrival_time, departure_date, price, available_seats, status) VALUES ($busId, $routeId, '$departure', '$arrival', '$departureDate', {$template['price']}, $availableSeats, 'scheduled')");
        }
    }

    $conn->commit();

    echo "Gonzaga Terminal seed completed." . PHP_EOL;
    echo 'Terminals: ' . count($terminals) . PHP_EOL;
    echo 'Routes: ' . count($routes) . PHP_EOL;
    echo 'Buses: ' . count($buses) . PHP_EOL;
    echo 'Fares: ' . count($fares) . PHP_EOL;
    echo 'Schedules: ' . (count($schedule_templates) * $scheduleWindowDays) . PHP_EOL;
} catch (Throwable $exception) {
    $conn->rollback();
    fwrite(STDERR, 'Seed failed: ' . $exception->getMessage() . PHP_EOL);
    exit(1);
}
?>
