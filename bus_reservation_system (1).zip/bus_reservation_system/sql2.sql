-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: bus_reservation_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bus_reservation_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bus_reservation_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `bus_reservation_db`;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `blog_posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL,
  `booking_reference` varchar(20) NOT NULL,
  `claim_code` varchar(40) DEFAULT NULL,
  `number_of_passengers` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `payment_method` varchar(40) DEFAULT NULL,
  `payment_status` varchar(30) NOT NULL DEFAULT 'pending',
  `seat_preferences` text DEFAULT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_reference` (`booking_reference`),
  UNIQUE KEY `uniq_bookings_claim_code` (`claim_code`),
  KEY `user_id` (`user_id`),
  KEY `schedule_id` (`schedule_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus_classes`
--

DROP TABLE IF EXISTS `bus_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(50) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amenities` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`class_id`),
  UNIQUE KEY `class_name` (`class_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_classes`
--

LOCK TABLES `bus_classes` WRITE;
/*!40000 ALTER TABLE `bus_classes` DISABLE KEYS */;
INSERT INTO `bus_classes` VALUES (1,'Regular AC',48,'45-49 seater bus with 2x2 configuration','Air-conditioned, On-board TV','2026-04-04 12:51:31'),(2,'First Class / Deluxe',29,'29 seater bus with 2x1 configuration','Spacious Legroom, Free Snacks, On-board Restroom, Electric Sockets, TV','2026-04-04 12:51:31'),(3,'Premium - Victory Royal Sleeper',32,'Premium experience with lie-flat seats','Lie-flat Seats, Premium Amenities, VIP Service, Priority Boarding','2026-04-04 12:51:31');
/*!40000 ALTER TABLE `bus_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buses`
--

DROP TABLE IF EXISTS `buses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buses` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_code` varchar(20) NOT NULL,
  `bus_name` varchar(120) DEFAULT NULL,
  `bus_type` varchar(60) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `registration_number` varchar(20) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year_manufactured` int(11) DEFAULT NULL,
  `total_seats` int(11) DEFAULT NULL,
  `status` enum('active','maintenance','retired') DEFAULT 'active',
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `seat_map_columns` int(11) NOT NULL DEFAULT 4,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`bus_id`),
  UNIQUE KEY `bus_code` (`bus_code`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `buses_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `bus_classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buses`
--

LOCK TABLES `buses` WRITE;
/*!40000 ALTER TABLE `buses` DISABLE KEYS */;
INSERT INTO `buses` VALUES (1,'VL-001','VL-001','Regular AC',1,'NQZ-001','Isuzu',2021,48,'active',1,4,'2026-04-04 12:51:31'),(2,'VL-002','VL-002','Regular AC',1,'NQZ-002','Isuzu',2021,48,'active',1,4,'2026-04-04 12:51:31'),(3,'VL-003','VL-003','First Class / Deluxe',2,'NQZ-003','Hino',2022,29,'active',1,4,'2026-04-04 12:51:31'),(4,'VL-004','VL-004','Premium - Victory Royal Sleeper',3,'NQZ-004','Volvo',2023,32,'active',1,4,'2026-04-04 12:51:31'),(5,'VL-005','VL-005','Regular AC',1,'NQZ-005','Isuzu',2020,48,'active',1,4,'2026-04-04 12:51:31');
/*!40000 ALTER TABLE `buses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`faq_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'Booking','How do I book a ticket?','You can book tickets through our website by selecting your route, date, and preferred bus class. Provide passenger details and proceed to payment.','2026-04-04 12:51:31'),(2,'Booking','Can I cancel my booking?','Yes, you can cancel up to 24 hours before departure for a full refund. Cancellations within 24 hours will have a 25% cancellation fee.','2026-04-04 12:51:31'),(3,'Baggage','What is the baggage allowance?','Passengers are allowed 1 piece of luggage (max 25kg) for free. Additional luggage costs ???100 per piece.','2026-04-04 12:51:31'),(4,'Baggage','Can I bring oversized baggage?','Oversized baggage can be accommodated for an additional charge. Please contact our office for details.','2026-04-04 12:51:31'),(5,'Travel','What time should I arrive at the terminal?','Please arrive 30 minutes before departure for domestic trips.','2026-04-04 12:51:31'),(6,'Travel','Are meals provided during the journey?','Yes, complimentary snacks and drinks are provided on all services. Full meals are served on longer routes.','2026-04-04 12:51:31'),(7,'Refund','What is the refund policy?','Full refunds are available for cancellations 24 hours before departure. Partial refunds are applicable for cancellations within 24 hours.','2026-04-04 12:51:31'),(8,'Accessibility','Is the bus wheelchair accessible?','Most of our buses have wheelchair accessibility features. Please inform us when booking if you require assistance.','2026-04-04 12:51:31');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fares`
--

DROP TABLE IF EXISTS `fares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fares` (
  `fare_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `base_fare` decimal(10,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`fare_id`),
  KEY `route_id` (`route_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `fares_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `routes` (`route_id`),
  CONSTRAINT `fares_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `bus_classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fares`
--

LOCK TABLES `fares` WRITE;
/*!40000 ALTER TABLE `fares` DISABLE KEYS */;
INSERT INTO `fares` VALUES (1,1,1,485.00,0.00,'2026-04-04 12:51:31'),(2,1,2,800.00,5.00,'2026-04-04 12:51:31'),(3,1,3,950.00,10.00,'2026-04-04 12:51:31'),(4,2,1,496.00,0.00,'2026-04-04 12:51:31'),(5,2,2,800.00,5.00,'2026-04-04 12:51:31'),(6,3,1,950.00,0.00,'2026-04-04 12:51:31'),(7,3,2,1800.00,5.00,'2026-04-04 12:51:31'),(8,4,1,250.00,0.00,'2026-04-04 12:51:31'),(9,5,1,350.00,0.00,'2026-04-04 12:51:31'),(10,6,1,380.00,0.00,'2026-04-04 12:51:31');
/*!40000 ALTER TABLE `fares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `notification_type` varchar(30) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `idx_notifications_user` (`user_id`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passengers`
--

DROP TABLE IF EXISTS `passengers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` enum('M','F') DEFAULT 'M',
  `id_type` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`passenger_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `passengers_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passengers`
--

LOCK TABLES `passengers` WRITE;
/*!40000 ALTER TABLE `passengers` DISABLE KEYS */;
/*!40000 ALTER TABLE `passengers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `payment_reference` varchar(40) NOT NULL,
  `payment_method` varchar(30) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `proof_image` varchar(255) DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `verified_at` datetime DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `payment_reference` (`payment_reference`),
  KEY `idx_payments_booking` (`booking_id`),
  CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_logs`
--

DROP TABLE IF EXISTS `qr_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qr_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `scan_status` varchar(20) NOT NULL,
  `scan_message` varchar(255) DEFAULT NULL,
  `scan_payload` longtext DEFAULT NULL,
  `scanned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_qr_logs_ticket` (`ticket_id`),
  CONSTRAINT `fk_qr_logs_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`ticket_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_logs`
--

LOCK TABLES `qr_logs` WRITE;
/*!40000 ALTER TABLE `qr_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `qr_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_key` varchar(30) NOT NULL,
  `role_name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_key` (`role_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrator','Full control of the platform','2026-04-04 12:51:31'),(2,'staff','Staff','Operational access for payments, bookings, and QR validation','2026-04-04 12:51:31'),(3,'passenger','Passenger','Standard passenger account','2026-04-04 12:51:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `origin_terminal_id` int(11) NOT NULL,
  `destination_terminal_id` int(11) NOT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  `travel_time` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`route_id`),
  UNIQUE KEY `uniq_route_pair` (`origin_terminal_id`,`destination_terminal_id`),
  KEY `destination_terminal_id` (`destination_terminal_id`),
  CONSTRAINT `routes_ibfk_1` FOREIGN KEY (`origin_terminal_id`) REFERENCES `terminals` (`terminal_id`),
  CONSTRAINT `routes_ibfk_2` FOREIGN KEY (`destination_terminal_id`) REFERENCES `terminals` (`terminal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routes`
--

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (1,1,4,250.00,360,'2026-04-04 12:51:31'),(2,2,4,260.00,380,'2026-04-04 12:51:31'),(3,3,6,550.00,780,'2026-04-04 12:51:31'),(4,1,7,150.00,180,'2026-04-04 12:51:31'),(5,1,5,200.00,240,'2026-04-04 12:51:31'),(6,1,8,180.00,210,'2026-04-04 12:51:31');
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` varchar(30) DEFAULT NULL,
  `bus_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `bus_type` varchar(60) DEFAULT NULL,
  `is_auto_assigned` tinyint(1) NOT NULL DEFAULT 0,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `available_seats` int(11) NOT NULL,
  `status` enum('scheduled','cancelled','completed') DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`schedule_id`),
  KEY `bus_id` (`bus_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`bus_id`),
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `routes` (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,'SCH-00001',1,1,'Regular AC',0,'06:00:00','12:00:00','2026-04-04',485.00,48,'scheduled','2026-04-04 12:51:31'),(2,'SCH-00002',2,1,'Regular AC',0,'10:00:00','16:00:00','2026-04-04',485.00,48,'scheduled','2026-04-04 12:51:31'),(3,'SCH-00003',3,1,'First Class / Deluxe',0,'14:00:00','20:00:00','2026-04-04',800.00,29,'scheduled','2026-04-04 12:51:31'),(4,'SCH-00004',1,2,'Regular AC',0,'07:00:00','13:00:00','2026-04-04',496.00,48,'scheduled','2026-04-04 12:51:31'),(5,'SCH-00005',4,3,'Premium - Victory Royal Sleeper',0,'18:00:00','04:00:00','2026-04-04',950.00,32,'scheduled','2026-04-04 12:51:31'),(6,'SCH-00006',1,4,'Regular AC',0,'09:00:00','11:00:00','2026-04-04',250.00,48,'scheduled','2026-04-04 12:51:31'),(7,'SCH-00007',2,5,'Regular AC',0,'08:30:00','12:30:00','2026-04-04',350.00,48,'scheduled','2026-04-04 12:51:31'),(8,'SCH-00008',1,6,'Regular AC',0,'11:00:00','12:50:00','2026-04-04',380.00,48,'scheduled','2026-04-04 12:51:31');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seats`
--

DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seats` (
  `seat_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `seat_number` int(11) NOT NULL,
  `seat_label` varchar(20) NOT NULL,
  `seat_row` int(11) NOT NULL,
  `seat_column` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`seat_id`),
  UNIQUE KEY `uniq_bus_seat_number` (`bus_id`,`seat_number`),
  UNIQUE KEY `uniq_bus_seat_label` (`bus_id`,`seat_label`),
  CONSTRAINT `fk_seats_bus` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`bus_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=206 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats`
--

LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES (1,1,1,'S01',1,1,1,'2026-04-04 12:52:02'),(2,1,2,'S02',1,2,1,'2026-04-04 12:52:02'),(3,1,3,'S03',1,3,1,'2026-04-04 12:52:02'),(4,1,4,'S04',1,4,1,'2026-04-04 12:52:02'),(5,1,5,'S05',2,1,1,'2026-04-04 12:52:02'),(6,1,6,'S06',2,2,1,'2026-04-04 12:52:02'),(7,1,7,'S07',2,3,1,'2026-04-04 12:52:02'),(8,1,8,'S08',2,4,1,'2026-04-04 12:52:02'),(9,1,9,'S09',3,1,1,'2026-04-04 12:52:02'),(10,1,10,'S10',3,2,1,'2026-04-04 12:52:02'),(11,1,11,'S11',3,3,1,'2026-04-04 12:52:02'),(12,1,12,'S12',3,4,1,'2026-04-04 12:52:02'),(13,1,13,'S13',4,1,1,'2026-04-04 12:52:02'),(14,1,14,'S14',4,2,1,'2026-04-04 12:52:02'),(15,1,15,'S15',4,3,1,'2026-04-04 12:52:02'),(16,1,16,'S16',4,4,1,'2026-04-04 12:52:02'),(17,1,17,'S17',5,1,1,'2026-04-04 12:52:02'),(18,1,18,'S18',5,2,1,'2026-04-04 12:52:02'),(19,1,19,'S19',5,3,1,'2026-04-04 12:52:02'),(20,1,20,'S20',5,4,1,'2026-04-04 12:52:02'),(21,1,21,'S21',6,1,1,'2026-04-04 12:52:02'),(22,1,22,'S22',6,2,1,'2026-04-04 12:52:02'),(23,1,23,'S23',6,3,1,'2026-04-04 12:52:02'),(24,1,24,'S24',6,4,1,'2026-04-04 12:52:02'),(25,1,25,'S25',7,1,1,'2026-04-04 12:52:02'),(26,1,26,'S26',7,2,1,'2026-04-04 12:52:02'),(27,1,27,'S27',7,3,1,'2026-04-04 12:52:02'),(28,1,28,'S28',7,4,1,'2026-04-04 12:52:02'),(29,1,29,'S29',8,1,1,'2026-04-04 12:52:02'),(30,1,30,'S30',8,2,1,'2026-04-04 12:52:02'),(31,1,31,'S31',8,3,1,'2026-04-04 12:52:02'),(32,1,32,'S32',8,4,1,'2026-04-04 12:52:02'),(33,1,33,'S33',9,1,1,'2026-04-04 12:52:02'),(34,1,34,'S34',9,2,1,'2026-04-04 12:52:02'),(35,1,35,'S35',9,3,1,'2026-04-04 12:52:02'),(36,1,36,'S36',9,4,1,'2026-04-04 12:52:02'),(37,1,37,'S37',10,1,1,'2026-04-04 12:52:02'),(38,1,38,'S38',10,2,1,'2026-04-04 12:52:02'),(39,1,39,'S39',10,3,1,'2026-04-04 12:52:02'),(40,1,40,'S40',10,4,1,'2026-04-04 12:52:02'),(41,1,41,'S41',11,1,1,'2026-04-04 12:52:02'),(42,1,42,'S42',11,2,1,'2026-04-04 12:52:02'),(43,1,43,'S43',11,3,1,'2026-04-04 12:52:02'),(44,1,44,'S44',11,4,1,'2026-04-04 12:52:02'),(45,1,45,'S45',12,1,1,'2026-04-04 12:52:02'),(46,1,46,'S46',12,2,1,'2026-04-04 12:52:02'),(47,1,47,'S47',12,3,1,'2026-04-04 12:52:02'),(48,1,48,'S48',12,4,1,'2026-04-04 12:52:02'),(49,2,1,'S01',1,1,1,'2026-04-04 12:52:02'),(50,2,2,'S02',1,2,1,'2026-04-04 12:52:02'),(51,2,3,'S03',1,3,1,'2026-04-04 12:52:02'),(52,2,4,'S04',1,4,1,'2026-04-04 12:52:02'),(53,2,5,'S05',2,1,1,'2026-04-04 12:52:02'),(54,2,6,'S06',2,2,1,'2026-04-04 12:52:02'),(55,2,7,'S07',2,3,1,'2026-04-04 12:52:02'),(56,2,8,'S08',2,4,1,'2026-04-04 12:52:02'),(57,2,9,'S09',3,1,1,'2026-04-04 12:52:02'),(58,2,10,'S10',3,2,1,'2026-04-04 12:52:02'),(59,2,11,'S11',3,3,1,'2026-04-04 12:52:02'),(60,2,12,'S12',3,4,1,'2026-04-04 12:52:02'),(61,2,13,'S13',4,1,1,'2026-04-04 12:52:02'),(62,2,14,'S14',4,2,1,'2026-04-04 12:52:02'),(63,2,15,'S15',4,3,1,'2026-04-04 12:52:02'),(64,2,16,'S16',4,4,1,'2026-04-04 12:52:02'),(65,2,17,'S17',5,1,1,'2026-04-04 12:52:02'),(66,2,18,'S18',5,2,1,'2026-04-04 12:52:02'),(67,2,19,'S19',5,3,1,'2026-04-04 12:52:02'),(68,2,20,'S20',5,4,1,'2026-04-04 12:52:02'),(69,2,21,'S21',6,1,1,'2026-04-04 12:52:02'),(70,2,22,'S22',6,2,1,'2026-04-04 12:52:02'),(71,2,23,'S23',6,3,1,'2026-04-04 12:52:02'),(72,2,24,'S24',6,4,1,'2026-04-04 12:52:02'),(73,2,25,'S25',7,1,1,'2026-04-04 12:52:02'),(74,2,26,'S26',7,2,1,'2026-04-04 12:52:02'),(75,2,27,'S27',7,3,1,'2026-04-04 12:52:02'),(76,2,28,'S28',7,4,1,'2026-04-04 12:52:02'),(77,2,29,'S29',8,1,1,'2026-04-04 12:52:02'),(78,2,30,'S30',8,2,1,'2026-04-04 12:52:02'),(79,2,31,'S31',8,3,1,'2026-04-04 12:52:02'),(80,2,32,'S32',8,4,1,'2026-04-04 12:52:02'),(81,2,33,'S33',9,1,1,'2026-04-04 12:52:02'),(82,2,34,'S34',9,2,1,'2026-04-04 12:52:02'),(83,2,35,'S35',9,3,1,'2026-04-04 12:52:02'),(84,2,36,'S36',9,4,1,'2026-04-04 12:52:02'),(85,2,37,'S37',10,1,1,'2026-04-04 12:52:02'),(86,2,38,'S38',10,2,1,'2026-04-04 12:52:02'),(87,2,39,'S39',10,3,1,'2026-04-04 12:52:02'),(88,2,40,'S40',10,4,1,'2026-04-04 12:52:02'),(89,2,41,'S41',11,1,1,'2026-04-04 12:52:02'),(90,2,42,'S42',11,2,1,'2026-04-04 12:52:02'),(91,2,43,'S43',11,3,1,'2026-04-04 12:52:02'),(92,2,44,'S44',11,4,1,'2026-04-04 12:52:02'),(93,2,45,'S45',12,1,1,'2026-04-04 12:52:02'),(94,2,46,'S46',12,2,1,'2026-04-04 12:52:02'),(95,2,47,'S47',12,3,1,'2026-04-04 12:52:02'),(96,2,48,'S48',12,4,1,'2026-04-04 12:52:02'),(97,3,1,'S01',1,1,1,'2026-04-04 12:52:02'),(98,3,2,'S02',1,2,1,'2026-04-04 12:52:02'),(99,3,3,'S03',1,3,1,'2026-04-04 12:52:02'),(100,3,4,'S04',1,4,1,'2026-04-04 12:52:02'),(101,3,5,'S05',2,1,1,'2026-04-04 12:52:02'),(102,3,6,'S06',2,2,1,'2026-04-04 12:52:02'),(103,3,7,'S07',2,3,1,'2026-04-04 12:52:02'),(104,3,8,'S08',2,4,1,'2026-04-04 12:52:02'),(105,3,9,'S09',3,1,1,'2026-04-04 12:52:02'),(106,3,10,'S10',3,2,1,'2026-04-04 12:52:02'),(107,3,11,'S11',3,3,1,'2026-04-04 12:52:02'),(108,3,12,'S12',3,4,1,'2026-04-04 12:52:02'),(109,3,13,'S13',4,1,1,'2026-04-04 12:52:02'),(110,3,14,'S14',4,2,1,'2026-04-04 12:52:02'),(111,3,15,'S15',4,3,1,'2026-04-04 12:52:02'),(112,3,16,'S16',4,4,1,'2026-04-04 12:52:02'),(113,3,17,'S17',5,1,1,'2026-04-04 12:52:02'),(114,3,18,'S18',5,2,1,'2026-04-04 12:52:02'),(115,3,19,'S19',5,3,1,'2026-04-04 12:52:02'),(116,3,20,'S20',5,4,1,'2026-04-04 12:52:02'),(117,3,21,'S21',6,1,1,'2026-04-04 12:52:02'),(118,3,22,'S22',6,2,1,'2026-04-04 12:52:02'),(119,3,23,'S23',6,3,1,'2026-04-04 12:52:02'),(120,3,24,'S24',6,4,1,'2026-04-04 12:52:02'),(121,3,25,'S25',7,1,1,'2026-04-04 12:52:02'),(122,3,26,'S26',7,2,1,'2026-04-04 12:52:02'),(123,3,27,'S27',7,3,1,'2026-04-04 12:52:02'),(124,3,28,'S28',7,4,1,'2026-04-04 12:52:02'),(125,3,29,'S29',8,1,1,'2026-04-04 12:52:02'),(126,4,1,'S01',1,1,1,'2026-04-04 12:52:02'),(127,4,2,'S02',1,2,1,'2026-04-04 12:52:02'),(128,4,3,'S03',1,3,1,'2026-04-04 12:52:02'),(129,4,4,'S04',1,4,1,'2026-04-04 12:52:02'),(130,4,5,'S05',2,1,1,'2026-04-04 12:52:02'),(131,4,6,'S06',2,2,1,'2026-04-04 12:52:02'),(132,4,7,'S07',2,3,1,'2026-04-04 12:52:02'),(133,4,8,'S08',2,4,1,'2026-04-04 12:52:02'),(134,4,9,'S09',3,1,1,'2026-04-04 12:52:02'),(135,4,10,'S10',3,2,1,'2026-04-04 12:52:02'),(136,4,11,'S11',3,3,1,'2026-04-04 12:52:02'),(137,4,12,'S12',3,4,1,'2026-04-04 12:52:02'),(138,4,13,'S13',4,1,1,'2026-04-04 12:52:02'),(139,4,14,'S14',4,2,1,'2026-04-04 12:52:02'),(140,4,15,'S15',4,3,1,'2026-04-04 12:52:02'),(141,4,16,'S16',4,4,1,'2026-04-04 12:52:02'),(142,4,17,'S17',5,1,1,'2026-04-04 12:52:02'),(143,4,18,'S18',5,2,1,'2026-04-04 12:52:02'),(144,4,19,'S19',5,3,1,'2026-04-04 12:52:02'),(145,4,20,'S20',5,4,1,'2026-04-04 12:52:02'),(146,4,21,'S21',6,1,1,'2026-04-04 12:52:02'),(147,4,22,'S22',6,2,1,'2026-04-04 12:52:02'),(148,4,23,'S23',6,3,1,'2026-04-04 12:52:02'),(149,4,24,'S24',6,4,1,'2026-04-04 12:52:02'),(150,4,25,'S25',7,1,1,'2026-04-04 12:52:02'),(151,4,26,'S26',7,2,1,'2026-04-04 12:52:02'),(152,4,27,'S27',7,3,1,'2026-04-04 12:52:02'),(153,4,28,'S28',7,4,1,'2026-04-04 12:52:02'),(154,4,29,'S29',8,1,1,'2026-04-04 12:52:02'),(155,4,30,'S30',8,2,1,'2026-04-04 12:52:02'),(156,4,31,'S31',8,3,1,'2026-04-04 12:52:02'),(157,4,32,'S32',8,4,1,'2026-04-04 12:52:02'),(158,5,1,'S01',1,1,1,'2026-04-04 12:52:02'),(159,5,2,'S02',1,2,1,'2026-04-04 12:52:02'),(160,5,3,'S03',1,3,1,'2026-04-04 12:52:02'),(161,5,4,'S04',1,4,1,'2026-04-04 12:52:02'),(162,5,5,'S05',2,1,1,'2026-04-04 12:52:02'),(163,5,6,'S06',2,2,1,'2026-04-04 12:52:02'),(164,5,7,'S07',2,3,1,'2026-04-04 12:52:02'),(165,5,8,'S08',2,4,1,'2026-04-04 12:52:02'),(166,5,9,'S09',3,1,1,'2026-04-04 12:52:02'),(167,5,10,'S10',3,2,1,'2026-04-04 12:52:02'),(168,5,11,'S11',3,3,1,'2026-04-04 12:52:02'),(169,5,12,'S12',3,4,1,'2026-04-04 12:52:02'),(170,5,13,'S13',4,1,1,'2026-04-04 12:52:02'),(171,5,14,'S14',4,2,1,'2026-04-04 12:52:02'),(172,5,15,'S15',4,3,1,'2026-04-04 12:52:02'),(173,5,16,'S16',4,4,1,'2026-04-04 12:52:02'),(174,5,17,'S17',5,1,1,'2026-04-04 12:52:02'),(175,5,18,'S18',5,2,1,'2026-04-04 12:52:02'),(176,5,19,'S19',5,3,1,'2026-04-04 12:52:02'),(177,5,20,'S20',5,4,1,'2026-04-04 12:52:02'),(178,5,21,'S21',6,1,1,'2026-04-04 12:52:02'),(179,5,22,'S22',6,2,1,'2026-04-04 12:52:02'),(180,5,23,'S23',6,3,1,'2026-04-04 12:52:02'),(181,5,24,'S24',6,4,1,'2026-04-04 12:52:02'),(182,5,25,'S25',7,1,1,'2026-04-04 12:52:02'),(183,5,26,'S26',7,2,1,'2026-04-04 12:52:02'),(184,5,27,'S27',7,3,1,'2026-04-04 12:52:02'),(185,5,28,'S28',7,4,1,'2026-04-04 12:52:02'),(186,5,29,'S29',8,1,1,'2026-04-04 12:52:02'),(187,5,30,'S30',8,2,1,'2026-04-04 12:52:02'),(188,5,31,'S31',8,3,1,'2026-04-04 12:52:02'),(189,5,32,'S32',8,4,1,'2026-04-04 12:52:02'),(190,5,33,'S33',9,1,1,'2026-04-04 12:52:02'),(191,5,34,'S34',9,2,1,'2026-04-04 12:52:02'),(192,5,35,'S35',9,3,1,'2026-04-04 12:52:02'),(193,5,36,'S36',9,4,1,'2026-04-04 12:52:02'),(194,5,37,'S37',10,1,1,'2026-04-04 12:52:02'),(195,5,38,'S38',10,2,1,'2026-04-04 12:52:02'),(196,5,39,'S39',10,3,1,'2026-04-04 12:52:02'),(197,5,40,'S40',10,4,1,'2026-04-04 12:52:02'),(198,5,41,'S41',11,1,1,'2026-04-04 12:52:02'),(199,5,42,'S42',11,2,1,'2026-04-04 12:52:02'),(200,5,43,'S43',11,3,1,'2026-04-04 12:52:02'),(201,5,44,'S44',11,4,1,'2026-04-04 12:52:02'),(202,5,45,'S45',12,1,1,'2026-04-04 12:52:02'),(203,5,46,'S46',12,2,1,'2026-04-04 12:52:02'),(204,5,47,'S47',12,3,1,'2026-04-04 12:52:02'),(205,5,48,'S48',12,4,1,'2026-04-04 12:52:02');
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminals`
--

DROP TABLE IF EXISTS `terminals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminals` (
  `terminal_id` int(11) NOT NULL AUTO_INCREMENT,
  `terminal_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`terminal_id`),
  UNIQUE KEY `terminal_name` (`terminal_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminals`
--

LOCK TABLES `terminals` WRITE;
/*!40000 ALTER TABLE `terminals` DISABLE KEYS */;
INSERT INTO `terminals` VALUES (1,'Cubao Terminal','Cubao, Quezon City','123 EDSA, Cubao, Quezon City','02-123-4567','cubao@victoryliner.com','2026-04-04 12:51:31'),(2,'Pasay Terminal','Pasay City','456 EDSA, Pasay City','02-234-5678','pasay@victoryliner.com','2026-04-04 12:51:31'),(3,'Kamias Terminal','Kamias, Quezon City','789 Kamias Rd, Quezon City','02-345-6789','kamias@victoryliner.com','2026-04-04 12:51:31'),(4,'Baguio Terminal','Baguio City','101 Upper Session Rd, Baguio City','074-442-6111','baguio@victoryliner.com','2026-04-04 12:51:31'),(5,'Dagupan Terminal','Dagupan City','202 Pe??afrancia Ave, Dagupan City','075-516-5010','dagupan@victoryliner.com','2026-04-04 12:51:31'),(6,'Tuguegarao Terminal','Tuguegarao City','303 Florencio St, Tuguegarao','078-844-1919','tuguegarao@victoryliner.com','2026-04-04 12:51:31'),(7,'Olongapo Terminal','Olongapo City','404 Magsaysay Ave, Olongapo','047-222-2525','olongapo@victoryliner.com','2026-04-04 12:51:31'),(8,'Zambales Terminal','Sta. Cruz, Zambales','505 National Rd, Sta. Cruz','047-631-1234','zambales@victoryliner.com','2026-04-04 12:51:31');
/*!40000 ALTER TABLE `terminals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `passenger_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) NOT NULL,
  `seat_id` int(11) NOT NULL,
  `ticket_code` varchar(40) DEFAULT NULL,
  `qr_payload` longtext DEFAULT NULL,
  `qr_signature` varchar(128) DEFAULT NULL,
  `ticket_status` varchar(20) NOT NULL DEFAULT 'reserved',
  `issued_at` datetime DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `uniq_schedule_seat` (`schedule_id`,`seat_id`),
  UNIQUE KEY `ticket_code` (`ticket_code`),
  KEY `idx_tickets_booking` (`booking_id`),
  KEY `fk_tickets_passenger` (`passenger_id`),
  KEY `fk_tickets_seat` (`seat_id`),
  CONSTRAINT `fk_tickets_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tickets_passenger` FOREIGN KEY (`passenger_id`) REFERENCES `passengers` (`passenger_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tickets_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tickets_seat` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_guides`
--

DROP TABLE IF EXISTS `travel_guides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_guides` (
  `guide_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`guide_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `travel_guides_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_guides`
--

LOCK TABLES `travel_guides` WRITE;
/*!40000 ALTER TABLE `travel_guides` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_guides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_admin` int(11) DEFAULT 0,
  `account_status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login_at` datetime DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin User','admin@victoryliner.com','','$2y$10$FvDgFa8PMPS9tiOmRye5O.4n8IorGTA0jWWVT/EW0BC2hIRzRWbwy',1,NULL,1,'active','2026-04-04 12:51:31','2026-04-04 12:53:29',NULL,NULL),(2,'Main Admin','admin@gmail.com','+639171234567','$2y$10$ndaFCJ4AOoxPTWOJVqr9mOxKENs9HgwLz0ZuyFKvSj907IcmpWhvq',1,NULL,1,'active','2026-04-04 12:52:02','2026-04-04 12:53:29',NULL,NULL),(3,'Operations Staff','staff@gmail.com','+639170001111','$2y$10$0/UdH3LoypP4cmGFZsfO4uC3f2D38iHqvLGiln8OsNFZ1BAotbBM2',2,NULL,0,'active','2026-04-04 12:52:03','2026-04-04 12:53:29',NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-04 20:53:31
