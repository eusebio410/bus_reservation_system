<?php
$base_url = '';
$page_title = 'Online Booking - Gonzaga Terminal';

include 'includes/config.php';

// Keep booking access aligned with the current flow.
if (!is_logged_in()) {
    redirect('login.php');
}

$search_results = [];
$error = consume_flash('error');
$today = date('Y-m-d');
$maxAdvanceDate = max_advance_booking_date();
$bus_classes = db_select_all('SELECT class_id, class_name FROM bus_classes ORDER BY class_name ASC');

$format_duration = static function ($minutes) {
    $minutes = max(0, (int) $minutes);
    $hours = intdiv($minutes, 60);
    $remaining_minutes = $minutes % 60;
    $parts = [];

    if ($hours > 0) {
        $parts[] = $hours . 'h';
    }

    if ($remaining_minutes > 0 || empty($parts)) {
        $parts[] = $remaining_minutes . 'm';
    }

    return implode(' ', $parts);
};

$prefill_origin = '';
$prefill_destination = '';
$route_id = (int) isset_get('route_id');
$prefill_departure_date = isset_get('departure_date');

// A schedule card can point to a specific upcoming date. Keep that date when
// opening the booking form instead of silently falling back to today.
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $prefill_departure_date)) {
    $prefill_departure_date = '';
}

if ($route_id > 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    $prefill_query = "SELECT origin_terminal_id, destination_terminal_id FROM routes WHERE route_id = " . $route_id . " LIMIT 1";
    $prefill_result = $conn->query($prefill_query);

    if ($prefill_result && $prefill_result->num_rows > 0) {
        $prefill_route = $prefill_result->fetch_assoc();
        $prefill_origin = (string) $prefill_route['origin_terminal_id'];
        $prefill_destination = (string) $prefill_route['destination_terminal_id'];
    }
}

$selected_origin = $_POST['origin'] ?? $prefill_origin;
$selected_destination = $_POST['destination'] ?? $prefill_destination;
$selected_departure_date = $_POST['departure_date'] ?? ($prefill_departure_date !== '' ? $prefill_departure_date : $today);
$selected_return_date = $_POST['return_date'] ?? '';
$selected_passengers = isset($_POST['passengers']) ? max(1, min(10, (int) $_POST['passengers'])) : 1;
$selected_bus_class_id = max(0, (int) ($_POST['bus_class_id'] ?? isset_get('bus_class_id')));
$selected_trip_type = ($_POST['trip_type'] ?? 'oneway') === 'roundtrip' ? 'roundtrip' : 'oneway';
$is_date_filter_only = isset_post('date_filter_only') === '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $origin = (int) isset_post('origin');
    $destination = (int) isset_post('destination');
    $departure_date = isset_post('departure_date');
    $return_date = isset_post('return_date');
    $passengers = max(1, min(10, (int) isset_post('passengers')));
    $busClassId = max(0, (int) isset_post('bus_class_id'));
    $trip_type = isset_post('trip_type') === 'roundtrip' ? 'roundtrip' : 'oneway';

    $selected_origin = (string) $origin;
    $selected_destination = (string) $destination;
    $selected_departure_date = $departure_date;
    $selected_return_date = $return_date;
    $selected_passengers = $passengers;
    $selected_bus_class_id = $busClassId;
    $selected_trip_type = $trip_type;

    if ($departure_date === '') {
        $error = 'Please choose a travel date.';
    } elseif (!$is_date_filter_only && ($origin < 1 || $destination < 1)) {
        $error = 'Please choose both an origin and a destination.';
    } elseif ($origin > 0 && $destination > 0 && $origin === $destination) {
        $error = 'Origin and destination must be different.';
    } elseif (!booking_date_within_allowed_window($departure_date)) {
        $error = 'Bookings are limited to today through the next ' . MAX_ADVANCE_BOOKING_DAYS . ' days only.';
    } elseif ($trip_type === 'roundtrip') {
        $error = 'Round-trip booking is not available yet. Please choose one-way.';
    } else {
        $route_condition = '';

        if ($origin > 0 && $destination > 0) {
            $route_condition = "AND r.origin_terminal_id = " . $origin . "
                                AND r.destination_terminal_id = " . $destination;
        }
        $bus_class_condition = $busClassId > 0 ? 'AND b.class_id = ' . $busClassId : '';

        $query = "SELECT
                    s.schedule_id,
                    s.departure_time,
                    s.arrival_time,
                    s.departure_date,
                    s.price,
                    s.available_seats,
                    r.distance,
                    r.travel_time,
                    b.bus_code,
                    b.model,
                    bc.class_id,
                    bc.class_name,
                    bo.full_name AS operator_name,
                    t1.terminal_name AS origin_name,
                    t2.terminal_name AS destination_name
                  FROM schedules s
                  JOIN routes r ON s.route_id = r.route_id
                  JOIN buses b ON s.bus_id = b.bus_id
                  JOIN bus_classes bc ON b.class_id = bc.class_id
                  LEFT JOIN bus_operators bo ON s.operator_id = bo.operator_id
                  JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
                  JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
                  WHERE s.departure_date = '" . sanitize($departure_date) . "'
                  " . $route_condition . "
                  " . $bus_class_condition . "
                  AND s.status = 'scheduled'
                  AND (s.departure_date > CURDATE() OR s.departure_time > CURTIME())
                  AND s.available_seats >= " . $passengers . "
                  ORDER BY bc.class_name ASC, s.departure_time ASC, s.schedule_id ASC";

        $search_results = $conn->query($query);

        if ($search_results === false) {
            $error = 'Unable to search trips right now. Please try again.';
            $search_results = [];
        }
    }
}

$origins = [];
$destinations = [];
$terminal_lookup = [];
$origins_query = "
    SELECT DISTINCT t.terminal_id AS id, t.terminal_name AS name
    FROM routes r
    JOIN terminals t ON r.origin_terminal_id = t.terminal_id
    ORDER BY t.terminal_name ASC
";
$origins_result = $conn->query($origins_query);

if ($origins_result && $origins_result->num_rows > 0) {
    while ($terminal = $origins_result->fetch_assoc()) {
        $origins[] = $terminal;
        $terminal_lookup[(string) $terminal['id']] = $terminal['name'];
    }
}

$destinations_query = "
    SELECT DISTINCT t.terminal_id AS id, t.terminal_name AS name
    FROM routes r
    JOIN terminals t ON r.destination_terminal_id = t.terminal_id
    ORDER BY t.terminal_name ASC
";
$destinations_result = $conn->query($destinations_query);

if ($destinations_result && $destinations_result->num_rows > 0) {
    while ($terminal = $destinations_result->fetch_assoc()) {
        $destinations[] = $terminal;
        $terminal_lookup[(string) $terminal['id']] = $terminal['name'];
    }
}

if ($selected_origin === '' && count($origins) === 1) {
    $selected_origin = (string) $origins[0]['id'];
}

$selected_origin_name = $terminal_lookup[(string) $selected_origin] ?? 'Selected origin';
$selected_destination_name = $terminal_lookup[(string) $selected_destination] ?? 'Selected destination';
$selected_bus_class_name = '';
foreach ($bus_classes as $bus_class) {
    if ((int) $bus_class['class_id'] === $selected_bus_class_id) {
        $selected_bus_class_name = (string) $bus_class['class_name'];
        break;
    }
}
$is_roundtrip_selected = $selected_trip_type === 'roundtrip';
$selected_date_object = DateTimeImmutable::createFromFormat('!Y-m-d', $selected_departure_date) ?: new DateTimeImmutable($today);
$today_date_object = new DateTimeImmutable($today);
$max_date_object = new DateTimeImmutable($maxAdvanceDate);
$result_dates = [];

for ($day_offset = 0; $day_offset < 5; $day_offset++) {
    $result_date = $selected_date_object->modify('+' . $day_offset . ' day');

    if ($result_date > $max_date_object) {
        break;
    }

    $result_dates[] = $result_date;
}

// Keep date browsing continuous. A five-day jump disabled the previous arrow
// near today even when the immediately previous date was still selectable.
$previous_result_date = $selected_date_object->modify('-1 day');
$next_result_date = $selected_date_object->modify('+1 day');

if ($previous_result_date < $today_date_object) {
    $previous_result_date = null;
}

if ($next_result_date > $max_date_object) {
    $next_result_date = null;
}

$result_date_counts = [];
$selected_origin_id = (int) $selected_origin;
$selected_destination_id = (int) $selected_destination;
$selected_bus_class_id = (int) $selected_bus_class_id;

if (!empty($result_dates)) {
    $date_range_start = $result_dates[0]->format('Y-m-d');
    $date_range_end = $result_dates[count($result_dates) - 1]->format('Y-m-d');
    $date_route_condition = '';

    if ($selected_origin_id > 0 && $selected_destination_id > 0) {
        $date_route_condition = "AND r.origin_terminal_id = " . $selected_origin_id . "
                                 AND r.destination_terminal_id = " . $selected_destination_id;
    }
        $date_bus_class_condition = $selected_bus_class_id > 0 ? 'AND bus.class_id = ' . $selected_bus_class_id : '';

    $date_count_query = "SELECT s.departure_date, COUNT(*) AS trip_count
                         FROM schedules s
                         JOIN routes r ON s.route_id = r.route_id
                                                 JOIN buses bus ON s.bus_id = bus.bus_id
                         WHERE s.departure_date BETWEEN '" . sanitize($date_range_start) . "' AND '" . sanitize($date_range_end) . "'
                           " . $date_route_condition . "
                                                     " . $date_bus_class_condition . "
                           AND s.status = 'scheduled'
                           AND s.available_seats >= " . $selected_passengers . "
                           AND (s.departure_date > CURDATE() OR (s.departure_date = CURDATE() AND s.departure_time > CURTIME()))
                           GROUP BY s.departure_date";
    $date_count_result = $conn->query($date_count_query);

    if ($date_count_result) {
        while ($date_count = $date_count_result->fetch_assoc()) {
            $result_date_counts[(string) $date_count['departure_date']] = (int) $date_count['trip_count'];
        }
    }
}

include 'includes/header.php';
?>

<style>
.page-booking {
    background: #f4f5f7;
}

.page-booking .site-main {
    padding: 0;
}

.page-booking footer {
    margin-top: 0 !important;
}

.page-booking .booking-hero {
    background:
        linear-gradient(180deg, rgba(10, 16, 29, 0.38) 0%, rgba(10, 16, 29, 0.72) 100%),
        url('assets/images/bus-terminal-hero-v3.jpg') center 58% / cover no-repeat;
    overflow: hidden;
    padding: 2.2rem 0 6.4rem;
    position: relative;
}

.page-booking .booking-hero::before {
    background:
        radial-gradient(circle at 50% 18%, rgba(255, 255, 255, 0.1) 0, rgba(255, 255, 255, 0.03) 12rem, transparent 18rem),
        linear-gradient(180deg, rgba(4, 10, 24, 0.06) 0%, rgba(4, 10, 24, 0.34) 52%, rgba(4, 10, 24, 0.76) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-booking .booking-hero::after {
    background:
        linear-gradient(180deg, rgba(255, 255, 255, 0) 0%, rgba(13, 18, 30, 0.08) 54%, rgba(13, 18, 30, 0.72) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-booking .booking-hero__inner {
    align-items: center;
    display: flex;
    flex-direction: column;
    max-width: 1280px;
    min-height: 40.5rem;
    position: relative;
    text-align: center;
    z-index: 1;
}

.page-booking .booking-hero__badge {
    align-items: center;
    background: rgba(93, 102, 123, 0.48);
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 999px;
    box-shadow: 0 10px 20px rgba(8, 12, 24, 0.2);
    color: #fff;
    display: inline-flex;
    font-size: 0.98rem;
    font-weight: 700;
    gap: 0.6rem;
    margin-top: 2rem;
    padding: 0.78rem 1.3rem;
}

.page-booking .booking-hero__badge i {
    color: #fff;
}

.page-booking .booking-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(3.3rem, 5.35vw, 5rem);
    font-weight: 800;
    letter-spacing: -0.08em;
    line-height: 1.02;
    margin: 1.7rem 0 1rem;
    text-shadow: 0 6px 18px rgba(8, 12, 24, 0.42);
}

.page-booking .booking-hero__lead {
    color: #fff;
    font-size: clamp(1.12rem, 0.98rem + 0.35vw, 1.42rem);
    margin: 0 0 0.55rem;
}

.page-booking .booking-hero__copy {
    color: rgba(255, 255, 255, 0.82);
    font-size: 1rem;
    margin: 0;
}

.page-booking .booking-search-shell {
    background: #fff9eb;
    border: 1px solid rgba(232, 218, 191, 0.9);
    border-radius: 1.2rem;
    box-shadow: 0 14px 36px rgba(12, 18, 30, 0.24);
    margin-top: 2.7rem;
    padding: 1.5rem 1.55rem 1.7rem;
    width: 100%;
}

.page-booking .booking-search-alert {
    align-items: center;
    display: flex;
    gap: 0.7rem;
    margin-bottom: 1.25rem;
    text-align: left;
}

.page-booking .booking-trip-toggle {
    display: flex;
    flex-wrap: wrap;
    gap: 2.1rem;
    justify-content: center;
    margin-bottom: 1.65rem;
}

.page-booking .booking-trip-option {
    align-items: center;
    color: #1f2937;
    cursor: pointer;
    display: inline-flex;
    font-weight: 500;
    gap: 0.7rem;
}

.page-booking .booking-trip-input {
    accent-color: #c82727;
    cursor: pointer;
    height: 1.15rem;
    margin: 0;
    width: 1.15rem;
}

.page-booking .booking-trip-option span {
    font-size: 0.98rem;
}

.page-booking .booking-search-grid {
    align-items: end;
    display: grid;
    gap: 0.95rem;
    grid-template-columns: 1.05fr 1.05fr 1.25fr 1fr 1fr 1fr 1.1fr;
}

.page-booking .booking-field {
    text-align: left;
}

.page-booking .booking-field label {
    color: #344054;
    display: block;
    font-size: 0.92rem;
    font-weight: 500;
    margin-bottom: 0.6rem;
}

.page-booking .booking-field--action {
    align-self: end;
}

.page-booking .booking-input-wrap {
    position: relative;
}

.page-booking .booking-input-icon {
    color: #667085;
    font-size: 0.98rem;
    left: 0.95rem;
    pointer-events: none;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    z-index: 1;
}

.page-booking .booking-search-shell .form-control,
.page-booking .booking-search-shell .form-select {
    background: #fff;
    border: 1px solid #d9dde5;
    border-radius: 0.95rem;
    box-shadow: none;
    color: #344054;
    font-size: 0.98rem;
    min-height: 3.35rem;
    padding: 0.8rem 0.95rem 0.8rem 2.7rem;
}

.page-booking .booking-search-shell .form-control:disabled {
    background: #fcf6e8;
    color: #98a2b3;
}

.page-booking .booking-search-shell .form-control:focus,
.page-booking .booking-search-shell .form-select:focus {
    border-color: rgba(200, 39, 39, 0.42);
    box-shadow: 0 0 0 0.2rem rgba(200, 39, 39, 0.12);
}

.page-booking .booking-search-button {
    background: linear-gradient(180deg, #ffd447 0%, #f6b800 100%);
    border: none;
    border-radius: 0.95rem;
    box-shadow: none;
    color: #0f172a;
    font-size: 1rem;
    font-weight: 800;
    min-height: 3.35rem;
    padding: 0.8rem 1.25rem;
    transition: transform 0.2s ease, filter 0.2s ease;
    width: 100%;
}

.page-booking .booking-search-button:hover {
    filter: brightness(0.98);
    transform: translateY(-2px);
}

.page-booking .booking-bus-type-shortcuts {
    align-items: center;
    display: flex;
    flex-wrap: wrap;
    gap: 0.5rem;
    margin: 0 0 1rem;
}

.page-booking .booking-bus-type-shortcuts__label {
    color: #344054;
    font-size: 0.88rem;
    font-weight: 700;
    margin-right: 0.25rem;
}

.page-booking .booking-bus-type-filter {
    background: #fff;
    border: 1px solid #d0d5dd;
    border-radius: 999px;
    color: #344054;
    font-size: 0.84rem;
    font-weight: 700;
    min-height: 2.35rem;
    padding: 0.4rem 0.85rem;
}

.page-booking .booking-bus-type-filter:hover,
.page-booking .booking-bus-type-filter.is-active {
    background: #172b4d;
    border-color: #172b4d;
    color: #fff;
}

.page-booking .booking-hero__trust {
    color: rgba(255, 255, 255, 0.96);
    display: flex;
    flex-wrap: wrap;
    gap: 1rem 2.5rem;
    justify-content: center;
    margin-top: 2rem;
}

.page-booking .booking-hero__trust span {
    align-items: center;
    display: inline-flex;
    font-size: 0.95rem;
    font-weight: 500;
    gap: 0.65rem;
}

.page-booking .booking-hero__trust i {
    color: #f6c71a;
}

.page-booking .booking-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-booking .booking-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 1199px) {
    .page-booking .booking-search-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
    }

    .page-booking .booking-field--action {
        grid-column: span 3;
    }
}

@media (max-width: 991px) {
    .page-booking .booking-hero {
        padding-top: 2.75rem;
    }

    .page-booking .booking-hero__inner {
        min-height: 38rem;
    }
}

@media (max-width: 767px) {
    .page-booking .booking-hero {
        padding-bottom: 4.6rem;
    }

    .page-booking .booking-hero__badge {
        font-size: 0.92rem;
        margin-top: 1.2rem;
    }

    .page-booking .booking-hero__title {
        font-size: clamp(2.7rem, 12vw, 4rem);
    }

    .page-booking .booking-hero__lead,
    .page-booking .booking-hero__copy {
        font-size: 1rem;
    }

    .page-booking .booking-search-shell {
        border-radius: 1rem;
        padding: 1.1rem;
    }

    .page-booking .booking-trip-toggle,
    .page-booking .booking-hero__trust {
        justify-content: flex-start;
    }

    .page-booking .booking-search-grid {
        grid-template-columns: 1fr;
    }

    .page-booking .booking-field--action {
        grid-column: auto;
    }

    .page-booking .booking-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="booking-hero">
    <div class="container booking-hero__inner">
        <div class="booking-hero__badge">
            <i class="fas fa-bus-simple"></i>
            <span>Most Trusted Bus Service</span>
        </div>

        <h1 class="booking-hero__title">Book Your Bus Journey</h1>
        <p class="booking-hero__lead">Reserve Gonzaga Terminal departures to Manila and beyond</p>
        <p class="booking-hero__copy">Fast, safe, and reliable transportation to your favorite destinations</p>

        <div class="booking-search-shell" id="booking-search-panel">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show booking-search-alert" role="alert">
                    <i class="fas fa-exclamation-circle"></i>
                    <span><?php echo htmlspecialchars($error); ?></span>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST" class="booking-search-form">
                <?php csrf_field(); ?>
                <input type="hidden" id="date_filter_only" name="date_filter_only" value="0">
                <div class="booking-trip-toggle" role="radiogroup" aria-label="Trip type">
                    <label class="booking-trip-option" for="trip_oneway">
                        <input
                            class="booking-trip-input"
                            type="radio"
                            name="trip_type"
                            id="trip_oneway"
                            value="oneway"
                            <?php echo $selected_trip_type === 'oneway' ? 'checked' : ''; ?>
                        >
                        <span>One Way</span>
                    </label>

                    <label class="booking-trip-option" for="trip_roundtrip">
                        <input
                            class="booking-trip-input"
                            type="radio"
                            name="trip_type"
                            id="trip_roundtrip"
                            value="roundtrip"
                            <?php echo $selected_trip_type === 'roundtrip' ? 'checked' : ''; ?>
                        >
                        <span>Round Trip</span>
                    </label>
                </div>

                <div class="booking-search-grid">
                    <div class="booking-field">
                        <label for="origin">From</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-location-dot"></i></span>
                            <select class="form-select" id="origin" name="origin" required>
                                <option value="">Select origin</option>
                                <?php foreach ($origins as $terminal): ?>
                                    <option value="<?php echo (int) $terminal['id']; ?>" <?php echo (string) $selected_origin === (string) $terminal['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($terminal['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="booking-field">
                        <label for="destination">To</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-location-dot"></i></span>
                            <select class="form-select" id="destination" name="destination" required>
                                <option value="">Select destination</option>
                                <?php foreach ($destinations as $terminal): ?>
                                    <option value="<?php echo (int) $terminal['id']; ?>" <?php echo (string) $selected_destination === (string) $terminal['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($terminal['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="booking-field">
                        <label for="bus_class_id">Bus type</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-bus"></i></span>
                            <select class="form-select" id="bus_class_id" name="bus_class_id">
                                <option value="0">Any bus type</option>
                                <?php foreach ($bus_classes as $bus_class): ?>
                                    <option value="<?php echo (int) $bus_class['class_id']; ?>" <?php echo $selected_bus_class_id === (int) $bus_class['class_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($bus_class['class_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="booking-field">
                        <label for="departure_date">Departure</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-calendar-days"></i></span>
                            <input
                                type="date"
                                class="form-control"
                                id="departure_date"
                                name="departure_date"
                                min="<?php echo htmlspecialchars($today); ?>"
                                max="<?php echo htmlspecialchars($maxAdvanceDate); ?>"
                                value="<?php echo htmlspecialchars($selected_departure_date); ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="booking-field">
                        <label for="return_date">Return</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-calendar-days"></i></span>
                            <input
                                type="date"
                                class="form-control"
                                id="return_date"
                                name="return_date"
                                min="<?php echo htmlspecialchars($selected_departure_date ?: $today); ?>"
                                max="<?php echo htmlspecialchars($maxAdvanceDate); ?>"
                                value="<?php echo htmlspecialchars($selected_return_date); ?>"
                                <?php echo $is_roundtrip_selected ? '' : 'disabled'; ?>
                            >
                        </div>
                    </div>

                    <div class="booking-field">
                        <label for="passengers">Passengers</label>
                        <div class="booking-input-wrap">
                            <span class="booking-input-icon"><i class="fas fa-users"></i></span>
                            <select class="form-select" id="passengers" name="passengers">
                                <?php for ($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $selected_passengers === $i ? 'selected' : ''; ?>>
                                        <?php echo $i; ?> <?php echo $i === 1 ? 'Person' : 'People'; ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div>

                    <div class="booking-field booking-field--action">
                        <button type="submit" class="booking-search-button">
                            Search Trips
                        </button>
                    </div>
                </div>
                <div class="form-text mt-2 text-start">Bookings are available from today up to <?php echo MAX_ADVANCE_BOOKING_DAYS; ?> days in advance only.</div>
            </form>
        </div>

        <div class="booking-hero__trust">
            <span><i class="fas fa-check"></i> Instant Confirmation</span>
            <span><i class="fas fa-check"></i> Best Price Guarantee</span>
            <span><i class="fas fa-check"></i> 24/7 Customer Support</span>
        </div>
    </div>
</section>

<section class="booking-results booking-results--controls">
    <div class="container">
        <div class="booking-results-toolbar">
            <div class="booking-results-toolbar__copy">
                <span class="booking-results-toolbar__eyebrow"><i class="fa-solid fa-sliders" aria-hidden="true"></i> Trip finder</span>
                <p>Refine the schedules shown below</p>
            </div>

            <div class="booking-results-toolbar__actions">
                <button class="booking-filter-toggle" type="button" aria-controls="trip-filter-panel" aria-expanded="false">
                    <i class="fa-solid fa-sliders" aria-hidden="true"></i>
                    <span>Filters</span>
                    <span class="booking-filter-count" hidden>0</span>
                    <i class="fa-solid fa-chevron-down booking-filter-toggle__chevron" aria-hidden="true"></i>
                </button>

                <label class="booking-availability-toggle" for="hide-fully-booked">
                    <input type="checkbox" id="hide-fully-booked">
                    <span class="booking-toggle-control" aria-hidden="true"></span>
                    <span>Available seats only</span>
                </label>
            </div>
        </div>

        <div class="booking-bus-type-shortcuts" role="group" aria-label="Filter trips by bus type">
            <span class="booking-bus-type-shortcuts__label">Bus type</span>
            <button class="booking-bus-type-filter<?php echo $selected_bus_class_id === 0 ? ' is-active' : ''; ?>" type="button" data-bus-class-filter="0" aria-pressed="<?php echo $selected_bus_class_id === 0 ? 'true' : 'false'; ?>">All</button>
            <?php foreach ($bus_classes as $bus_class): ?>
                <?php $is_selected_bus_class = $selected_bus_class_id === (int) $bus_class['class_id']; ?>
                <button class="booking-bus-type-filter<?php echo $is_selected_bus_class ? ' is-active' : ''; ?>" type="button" data-bus-class-filter="<?php echo (int) $bus_class['class_id']; ?>" aria-pressed="<?php echo $is_selected_bus_class ? 'true' : 'false'; ?>"><?php echo htmlspecialchars($bus_class['class_name']); ?></button>
            <?php endforeach; ?>
        </div>

        <div class="booking-filter-panel" id="trip-filter-panel" hidden>
            <div class="booking-filter-panel__field">
                <label for="trip-time-filter">Departure time</label>
                <div class="booking-filter-panel__select-wrap">
                    <i class="fa-regular fa-clock" aria-hidden="true"></i>
                    <select id="trip-time-filter" class="form-select">
                        <option value="all">Any time</option>
                        <option value="morning">Morning (before 12:00 PM)</option>
                        <option value="afternoon">Afternoon (12:00 PM–5:59 PM)</option>
                        <option value="evening">Evening (from 6:00 PM)</option>
                    </select>
                </div>
            </div>
            <div class="booking-filter-panel__actions">
                <span><i class="fa-solid fa-bolt" aria-hidden="true"></i> Updates instantly</span>
                <button class="booking-filter-clear" type="button">
                    <i class="fa-solid fa-rotate-left" aria-hidden="true"></i> Clear filters
                </button>
            </div>
        </div>

        <nav class="booking-date-strip" aria-label="Search dates">
            <button class="booking-date-strip__arrow" type="button" data-trip-date="<?php echo $previous_result_date ? htmlspecialchars($previous_result_date->format('Y-m-d')) : ''; ?>" <?php echo $previous_result_date ? '' : 'disabled'; ?> aria-label="Previous day">
                <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
            </button>
            <div class="booking-date-strip__dates">
                <?php foreach ($result_dates as $result_date): ?>
                    <?php
                    $result_date_value = $result_date->format('Y-m-d');
                    $is_selected_result_date = $result_date_value === $selected_date_object->format('Y-m-d');
                    $result_date_count = $result_date_counts[$result_date_value] ?? null;
                    $result_date_label = $result_date_count === null
                        ? 'Choose route'
                        : ($result_date_count === 1 ? '1 trip' : $result_date_count . ' trips');
                    ?>
                    <button class="booking-date-strip__date<?php echo $is_selected_result_date ? ' is-selected' : ''; ?>" type="button" data-trip-date="<?php echo htmlspecialchars($result_date->format('Y-m-d')); ?>" aria-pressed="<?php echo $is_selected_result_date ? 'true' : 'false'; ?>">
                        <strong><?php echo htmlspecialchars($result_date->format('D, d M')); ?></strong>
                        <span><?php echo htmlspecialchars($result_date_label); ?></span>
                    </button>
                <?php endforeach; ?>
            </div>
            <button class="booking-date-strip__arrow" type="button" data-trip-date="<?php echo $next_result_date ? htmlspecialchars($next_result_date->format('Y-m-d')) : ''; ?>" <?php echo $next_result_date ? '' : 'disabled'; ?> aria-label="Next day">
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
            </button>
        </nav>
    </div>
</section>

<?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)): ?>
    <section class="booking-results booking-results--trip-list">
        <div class="container">
            <?php if (is_object($search_results) && $search_results->num_rows > 0): ?>
                <?php $result_count = (int) $search_results->num_rows; ?>
                <?php $has_selected_route = (int) $selected_origin > 0 && (int) $selected_destination > 0; ?>
                <div class="booking-results__heading">
                    <div>
                        <span class="booking-results__kicker">Available Trips</span>
                        <h2>
                            <?php echo $result_count; ?> trip<?php echo $result_count === 1 ? '' : 's'; ?>
                            <?php if ($has_selected_route): ?>
                                from <?php echo htmlspecialchars($selected_origin_name); ?> to <?php echo htmlspecialchars($selected_destination_name); ?>
                            <?php else: ?>
                                available on <?php echo date('F j, Y', strtotime($selected_departure_date)); ?>
                            <?php endif; ?>
                        </h2>
                        <p>
                            <?php echo $has_selected_route ? date('F j, Y', strtotime($selected_departure_date)) : 'All routes'; ?>
                            | <?php echo (int) $selected_passengers; ?> passenger<?php echo $selected_passengers === 1 ? '' : 's'; ?>
                            <?php if ($selected_bus_class_name !== ''): ?> | Bus type: <?php echo htmlspecialchars($selected_bus_class_name); ?><?php endif; ?>
                        </p>
                    </div>
                </div>

                <div class="booking-results__grid">
                    <?php while ($schedule = $search_results->fetch_assoc()): ?>
                        <?php
                        $duration_label = $format_duration($schedule['travel_time'] ?? 0);
                        $departure_time = date('g:i A', strtotime($schedule['departure_time']));
                        $arrival_time = date('g:i A', strtotime($schedule['arrival_time']));
                        $departure_hour = (int) date('G', strtotime($schedule['departure_time']));
                        ?>
                        <article class="booking-result-card booking-result-card--list" data-departure-hour="<?php echo $departure_hour; ?>" data-available-seats="<?php echo (int) $schedule['available_seats']; ?>">
                            <div class="booking-result-card__primary-row">
                                <div class="booking-result-card__operator">
                                    <span class="booking-result-card__operator-icon"><i class="fa-solid fa-bus-simple" aria-hidden="true"></i></span>
                                    <span>
                                        <strong>Gonzaga Terminal</strong>
                                        <small><i class="fa-solid fa-steering-wheel me-1" aria-hidden="true"></i>Driver: <?php echo htmlspecialchars($schedule['operator_name'] ?: 'Operator assignment pending'); ?></small>
                                    </span>
                                </div>
                                <time class="booking-result-card__time" datetime="<?php echo htmlspecialchars($schedule['departure_time']); ?>"><?php echo $departure_time; ?></time>
                                <div class="booking-result-card__route">
                                    <strong><?php echo htmlspecialchars($schedule['origin_name']); ?></strong>
                                    <i class="fa-solid fa-arrow-right-long" aria-hidden="true"></i>
                                    <strong><?php echo htmlspecialchars($schedule['destination_name']); ?></strong>
                                </div>
                                <span class="booking-result-card__fare">PHP <?php echo number_format((float) $schedule['price'], 2); ?></span>
                            </div>

                            <div class="booking-result-card__secondary-row">
                                <dl class="booking-result-card__trip-details">
                                    <div>
                                        <dt>Bus type</dt>
                                        <dd><?php echo htmlspecialchars($schedule['class_name']); ?> &middot; <?php echo htmlspecialchars($schedule['model']); ?></dd>
                                    </div>
                                    <div>
                                        <dt>Trip details</dt>
                                        <dd><?php echo htmlspecialchars($schedule['bus_code']); ?> &middot; <?php echo htmlspecialchars($duration_label); ?> &middot; <?php echo number_format((float) $schedule['distance'], 0); ?> km</dd>
                                    </div>
                                </dl>
                                <div class="booking-result-card__actions">
                                    <span class="booking-result-card__seats"><i class="fa-solid fa-circle" aria-hidden="true"></i> <?php echo (int) $schedule['available_seats']; ?> left</span>
                                    <a href="booking-details.php?schedule_id=<?php echo (int) $schedule['schedule_id']; ?>" class="booking-result-card__button">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i> Show Seats
                                    </a>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <?php $has_selected_route = (int) $selected_origin > 0 && (int) $selected_destination > 0; ?>
                <div class="booking-empty-state">
                    <span class="booking-empty-state__icon"><i class="fas fa-bus"></i></span>
                    <h2>No available trips found</h2>
                    <p>
                        <?php if ($has_selected_route): ?>
                            There are no reservable buses for <?php echo htmlspecialchars($selected_origin_name); ?> to <?php echo htmlspecialchars($selected_destination_name); ?> on <?php echo date('F j, Y', strtotime($selected_departure_date)); ?>.
                        <?php else: ?>
                            There are no reservable buses on <?php echo date('F j, Y', strtotime($selected_departure_date)); ?>.
                        <?php endif; ?>
                        Trips that already left are no longer shown. Try another date or route.
                    </p>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<a href="#booking-search-panel" class="booking-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const tripInputs = document.querySelectorAll('input[name="trip_type"]');
    const departureInput = document.getElementById('departure_date');
    const returnInput = document.getElementById('return_date');
    const searchForm = document.querySelector('.booking-search-form');
    const dateFilterOnly = document.getElementById('date_filter_only');
    const busClassInput = document.getElementById('bus_class_id');
    const filterToggle = document.querySelector('.booking-filter-toggle');
    const filterPanel = document.getElementById('trip-filter-panel');
    const timeFilter = document.getElementById('trip-time-filter');
    const hideFullyBooked = document.getElementById('hide-fully-booked');
    const clearFilters = document.querySelector('.booking-filter-clear');
    const filterCount = document.querySelector('.booking-filter-count');
    const resultCards = document.querySelectorAll('.booking-result-card');

    if (!tripInputs.length || !departureInput || !returnInput) {
        return;
    }

    const syncReturnField = function () {
        const selectedTrip = document.querySelector('input[name="trip_type"]:checked');
        const isRoundTrip = selectedTrip && selectedTrip.value === 'roundtrip';

        returnInput.disabled = !isRoundTrip;
        returnInput.min = departureInput.value || '<?php echo htmlspecialchars($today); ?>';
        returnInput.max = '<?php echo htmlspecialchars($maxAdvanceDate); ?>';

        if (!isRoundTrip) {
            returnInput.value = '';
        }
    };

    tripInputs.forEach(function (input) {
        input.addEventListener('change', syncReturnField);
    });

    document.querySelectorAll('[data-bus-class-filter]').forEach(function (button) {
        button.addEventListener('click', function () {
            if (!searchForm || !busClassInput) {
                return;
            }

            busClassInput.value = button.dataset.busClassFilter || '0';
            if (dateFilterOnly) {
                dateFilterOnly.value = '0';
            }
            searchForm.requestSubmit();
        });
    });

    departureInput.addEventListener('change', function () {
        if (departureInput.value && departureInput.value > '<?php echo htmlspecialchars($maxAdvanceDate); ?>') {
            departureInput.value = '<?php echo htmlspecialchars($maxAdvanceDate); ?>';
        }

        returnInput.min = departureInput.value || '<?php echo htmlspecialchars($today); ?>';

        if (returnInput.value && returnInput.value < returnInput.min) {
            returnInput.value = '';
        }

        if (returnInput.value && returnInput.value > '<?php echo htmlspecialchars($maxAdvanceDate); ?>') {
            returnInput.value = '';
        }
    });

    document.querySelectorAll('[data-trip-date]').forEach(function (button) {
        button.addEventListener('click', function () {
            const tripDate = button.dataset.tripDate;

            if (!tripDate) {
                return;
            }

            departureInput.value = tripDate;
            document.querySelectorAll('.booking-date-strip__date').forEach(function (dateButton) {
                const isSelected = dateButton.dataset.tripDate === tripDate;
                dateButton.classList.toggle('is-selected', isSelected);
                dateButton.setAttribute('aria-pressed', String(isSelected));
            });

            if (!searchForm) {
                return;
            }

            if (dateFilterOnly) {
                dateFilterOnly.value = '1';
            }

            // Date browsing must work even before a From/To route is selected.
            // submit() intentionally bypasses the route fields' required validation.
            searchForm.submit();
        });
    });

    const applyResultFilters = function () {
        const selectedTime = timeFilter ? timeFilter.value : 'all';
        const hideUnavailable = hideFullyBooked && hideFullyBooked.checked;
        let activeFilterCount = selectedTime === 'all' ? 0 : 1;

        if (hideUnavailable) {
            activeFilterCount++;
        }

        resultCards.forEach(function (card) {
            const hour = Number(card.dataset.departureHour);
            const seats = Number(card.dataset.availableSeats);
            const matchesTime = selectedTime === 'all'
                || (selectedTime === 'morning' && hour < 12)
                || (selectedTime === 'afternoon' && hour >= 12 && hour < 18)
                || (selectedTime === 'evening' && hour >= 18);

            card.hidden = !matchesTime || (hideUnavailable && seats === 0);
        });

        if (filterCount) {
            filterCount.hidden = activeFilterCount === 0;
            filterCount.textContent = activeFilterCount;
        }
    };

    if (filterToggle && filterPanel) {
        filterToggle.addEventListener('click', function () {
            const willShow = filterPanel.hidden;
            filterPanel.hidden = !willShow;
            filterToggle.setAttribute('aria-expanded', String(willShow));
        });
    }

    if (timeFilter) {
        timeFilter.addEventListener('change', applyResultFilters);
    }

    if (hideFullyBooked) {
        hideFullyBooked.addEventListener('change', applyResultFilters);
    }

    if (clearFilters) {
        clearFilters.addEventListener('click', function () {
            if (timeFilter) {
                timeFilter.value = 'all';
            }

            if (hideFullyBooked) {
                hideFullyBooked.checked = false;
            }

            applyResultFilters();
        });
    }

    syncReturnField();
    applyResultFilters();
});
</script>

<?php include 'includes/footer.php'; ?>
