<?php
$base_url = '../';
$page_title = 'Control Portal Sign In';
require_once '../includes/config.php';

if (is_logged_in() && can_access_admin_panel()) {
    redirect('dashboard.php');
}

$error = consume_flash('error');
$success = consume_flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(isset_post('email'));
    $password = $_POST['password'] ?? '';
    $rateLimit = login_rate_limit_status($email);

    if ($rateLimit['blocked']) {
        $error = 'Too many sign-in attempts. Please wait 15 minutes and try again.';
    } elseif ($email === '' || $password === '') {
        $error = 'Please enter both email and password.';
    } else {
        $user = db_select_one(
            "SELECT u.*, r.role_key, r.role_name
             FROM users u
             LEFT JOIN roles r ON u.role_id = r.role_id
             WHERE u.email = ?
             LIMIT 1",
            's',
            [$email]
        );

        if (!$user
            || ($user['account_status'] ?? 'active') !== 'active'
            || !in_array((string) ($user['role_key'] ?? ''), ['admin', 'staff'], true)
            || !verify_password_compat($password, (string) ($user['password'] ?? ''), (int) ($user['user_id'] ?? 0))) {
            record_failed_login($email);
            $error = 'Invalid email or password.';
        } else {
            clear_failed_logins($email);
            login_user($user);
            redirect('dashboard.php');
        }
    }
}

include '../includes/header.php';
$brand_logo = '../assets/images/bus-terminal-logo.svg';
?>

<section class="auth-shell auth-shell--portal">
    <div class="container auth-shell__container">
        <div class="row g-4 align-items-stretch justify-content-center auth-layout">
            <div class="col-xl-5 col-lg-6 d-none d-lg-block">
                <aside class="auth-promo">
                    <img class="auth-promo__logo" src="<?php echo e($brand_logo); ?>" alt="Bus Terminal logo">
                    <span class="auth-promo__kicker">Bus Terminal Control Portal</span>
                    <h1>Professional access for dispatch, payments, and terminal operations.</h1>
                    <p>The control portal now matches the same blue-orange brand language as the public booking experience while keeping the admin side polished and focused.</p>

                    <div class="auth-promo__points">
                        <span><i class="fa-solid fa-calendar-days"></i>Monitor schedules and departure readiness</span>
                        <span><i class="fa-solid fa-wallet"></i>Review payment queues and confirmations</span>
                        <span><i class="fa-solid fa-users-gear"></i>Manage staff, users, reports, and operations</span>
                    </div>
                </aside>
            </div>

            <div class="col-xl-5 col-lg-6">
                <div class="auth-card auth-card--portal">
                    <div class="auth-card__header">
                        <img class="auth-card__logo" src="<?php echo e($brand_logo); ?>" alt="Bus Terminal logo">
                        <div class="auth-card__header-copy">
                            <span class="auth-card__eyebrow">Admin And Staff Access</span>
                            <h1 class="auth-card__title">Control Portal Sign In</h1>
                            <p class="auth-card__subtitle">Secure access for operations, dispatch, and portal management.</p>
                        </div>
                    </div>
                    <div class="auth-card__body">
                        <?php if ($error !== ''): ?>
                            <div class="alert alert-danger"><?php echo e($error); ?></div>
                        <?php endif; ?>
                        <?php if ($success !== ''): ?>
                            <div class="alert alert-success"><?php echo e($success); ?></div>
                        <?php endif; ?>

                        <form method="post" class="auth-form d-grid gap-3" autocomplete="on">
                            <?php csrf_field(); ?>
                            <div class="auth-field">
                                <label class="form-label auth-field__label" for="email">Work email <span>Required</span></label>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-envelope" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="email" id="email" name="email" value="<?php echo e($_POST['email'] ?? ''); ?>" placeholder="name@terminal.com" autocomplete="email" required>
                                </div>
                            </div>
                            <div class="auth-field">
                                <div class="d-flex align-items-center justify-content-between gap-3">
                                    <label class="form-label auth-field__label mb-0" for="password">Password <span>Required</span></label>
                                    <span class="auth-field-hint">Restricted access</span>
                                </div>
                                <div class="auth-input-wrap">
                                    <i class="fa-solid fa-lock" aria-hidden="true"></i>
                                    <input class="form-control form-control-lg" type="password" id="password" name="password" autocomplete="current-password" required>
                                    <button class="auth-password-toggle" type="button" data-password-toggle data-password-target="password" aria-label="Show password" aria-pressed="false">
                                        <i class="fa-regular fa-eye" aria-hidden="true"></i>
                                    </button>
                                </div>
                            </div>
                            <button class="btn btn-danger btn-lg auth-submit" type="submit">
                                <i class="fa-solid fa-shield-halved me-2"></i>Enter Control Portal
                                <i class="fa-solid fa-arrow-right auth-submit__arrow" aria-hidden="true"></i>
                            </button>
                        </form>

                        <div class="auth-divider"><span>Need passenger access instead?</span></div>
                        <div class="auth-card__link-row">
                            <span>Book and manage personal trips.</span>
                            <a href="../login.php">Passenger sign in <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../includes/footer.php'; ?>
