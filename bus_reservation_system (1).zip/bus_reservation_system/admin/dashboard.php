<?php
require_once '../includes/config.php';
require_once '../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('login.php');
}

if (!function_exists('dash_money')) {
    function dash_money(float $amount): string
    {
        return 'PHP ' . number_format($amount, 2);
    }
}

if (!function_exists('dash_departure_label')) {
    function dash_departure_label(?string $date, ?string $time): string
    {
        $timestamp = departure_timestamp((string) $date, (string) $time);
        return $timestamp !== null ? date('M j, Y g:i A', $timestamp) : 'Schedule unavailable';
    }
}

if (!function_exists('dash_trip_tone')) {
    function dash_trip_tone(string $status): string
    {
        return match ($status) {
            'boarding' => 'warning',
            'departed' => 'soft',
            'arrived' => 'success',
            'cancelled' => 'danger',
            default => 'soft',
        };
    }
}

if (!function_exists('dash_status_tone')) {
    function dash_status_tone(string $status): string
    {
        return match ($status) {
            'confirmed', 'paid', 'used' => 'success',
            'cancelled', 'expired', 'failed', 'rejected', 'refunded' => 'danger',
            default => 'warning',
        };
    }
}

$roleKey = current_role_key();
$isStaff = $roleKey === 'staff';
$currentUser = current_user_record();
$displayName = $currentUser['fullname'] ?? ($_SESSION['user_name'] ?? ($isStaff ? 'Operations Staff' : 'Administrator'));
$today = date('Y-m-d');
$now = time();
$brandLogo = '../assets/images/bus-terminal-logo.svg';

$bookingStats = db_select_one(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN status IN ('pending', 'payment_review') THEN 1 ELSE 0 END), 0) AS pending,
            COALESCE(SUM(CASE WHEN status = 'confirmed' THEN 1 ELSE 0 END), 0) AS confirmed,
            COALESCE(SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END), 0) AS cancelled
     FROM bookings"
);

$paymentStats = db_select_one(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END), 0) AS pending,
            COALESCE(SUM(CASE WHEN payment_method = 'cash' AND status = 'pending' THEN 1 ELSE 0 END), 0) AS cash_pending,
            COALESCE(SUM(CASE WHEN payment_method = 'gcash' AND status = 'pending' THEN 1 ELSE 0 END), 0) AS gcash_pending,
            COALESCE(SUM(CASE WHEN status = 'paid' AND DATE(COALESCE(verified_at, submitted_at)) = CURDATE() THEN amount ELSE 0 END), 0) AS paid_today
     FROM payments"
);

$busStats = db_select_one(
    "SELECT COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN status = 'active' AND is_enabled = 1 THEN 1 ELSE 0 END), 0) AS active,
            COALESCE(SUM(CASE WHEN status = 'maintenance' THEN 1 ELSE 0 END), 0) AS maintenance
     FROM buses"
);

$userStats = !$isStaff
    ? db_select_one(
        "SELECT COUNT(*) AS total,
                COALESCE(SUM(CASE WHEN account_status = 'active' THEN 1 ELSE 0 END), 0) AS active
         FROM users"
    )
    : ['total' => 0, 'active' => 0];

$schedules = db_select_all(
    "SELECT s.schedule_id, s.schedule_code, s.status, s.trip_status, s.departure_date, s.departure_time, s.arrival_time, s.available_seats,
            b.bus_name, b.bus_code, b.total_seats,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name,
            COALESCE(bs.reserved_seats, 0) AS reserved_seats
     FROM schedules s
     JOIN buses b ON s.bus_id = b.bus_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     LEFT JOIN (
         SELECT schedule_id,
                COALESCE(SUM(CASE WHEN status NOT IN ('cancelled', 'expired') THEN number_of_passengers ELSE 0 END), 0) AS reserved_seats
         FROM bookings
         GROUP BY schedule_id
     ) AS bs ON bs.schedule_id = s.schedule_id
     ORDER BY s.schedule_id DESC"
);

$schedules = array_map(static function (array $schedule): array {
    $schedule['effective_trip_status'] = effective_schedule_trip_status($schedule);
    $schedule['effective_status'] = effective_schedule_status($schedule);
    $schedule['departure_timestamp'] = departure_timestamp(
        (string) ($schedule['departure_date'] ?? ''),
        (string) ($schedule['departure_time'] ?? '')
    );
    $totalSeats = max(1, (int) ($schedule['total_seats'] ?? 0));
    $reservedSeats = max(0, (int) ($schedule['reserved_seats'] ?? 0));
    $schedule['load_percent'] = min(100, (int) round(($reservedSeats / $totalSeats) * 100));
    return $schedule;
}, $schedules);

$todayTrips = count(array_filter($schedules, static fn(array $s): bool => ($s['departure_date'] ?? '') === $today && ($s['effective_status'] ?? '') !== 'cancelled'));
$liveTrips = count(array_filter($schedules, static fn(array $s): bool => in_array((string) ($s['effective_trip_status'] ?? ''), ['boarding', 'departed'], true)));
$lowSeatTrips = count(array_filter($schedules, static fn(array $s): bool => (int) ($s['available_seats'] ?? 0) <= 5 && ($s['departure_timestamp'] ?? 0) >= $now && ($s['effective_status'] ?? '') !== 'cancelled'));

$upcomingTrips = array_values(array_filter(
    $schedules,
    static fn(array $s): bool => (int) ($s['departure_timestamp'] ?? 0) >= ($now - 3600)
        && !in_array((string) ($s['effective_status'] ?? ''), ['cancelled', 'completed'], true)
));
$upcomingTrips = array_slice($upcomingTrips, 0, 5);
$nextTrip = $upcomingTrips[0] ?? null;

$pendingPayments = db_select_all(
    "SELECT p.payment_reference, p.payment_method, p.amount, p.status,
            b.booking_id, b.booking_reference, b.claim_code,
            u.fullname,
            sch.departure_date, sch.departure_time,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM payments p
     JOIN bookings b ON p.booking_id = b.booking_id
     JOIN users u ON b.user_id = u.user_id
     JOIN schedules sch ON b.schedule_id = sch.schedule_id
     JOIN routes r ON sch.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE p.status = 'pending'
     ORDER BY p.submitted_at DESC, p.payment_id DESC
     LIMIT 5"
);

foreach ($pendingPayments as &$payment) {
    if (($payment['payment_method'] ?? '') === 'cash') {
        $payment['claim_code'] = ensure_booking_claim_code((int) ($payment['booking_id'] ?? 0), (string) ($payment['claim_code'] ?? ''));
    }
}
unset($payment);

$recentBookings = db_select_all(
    "SELECT b.booking_id, b.booking_reference, b.status, b.total_amount, b.number_of_passengers, b.booking_date,
            u.fullname,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN users u ON b.user_id = u.user_id
     JOIN schedules sch ON b.schedule_id = sch.schedule_id
     JOIN routes r ON sch.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     ORDER BY b.booking_date DESC, b.booking_id DESC
     LIMIT 5"
);

$cashClaims = $isStaff
    ? db_select_all(
        "SELECT b.booking_id, b.claim_code, b.total_amount, b.expires_at, u.fullname,
                origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
         FROM bookings b
         JOIN users u ON b.user_id = u.user_id
         JOIN schedules sch ON b.schedule_id = sch.schedule_id
         JOIN routes r ON sch.route_id = r.route_id
         JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
         JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
         WHERE b.payment_method = 'cash'
           AND b.payment_status <> 'paid'
           AND b.status NOT IN ('cancelled', 'expired', 'used')
         ORDER BY b.booking_date DESC, b.booking_id DESC
         LIMIT 5"
    )
    : [];

foreach ($cashClaims as &$claim) {
    $claim['claim_code'] = ensure_booking_claim_code((int) ($claim['booking_id'] ?? 0), (string) ($claim['claim_code'] ?? ''));
}
unset($claim);

$routeDemand = !$isStaff
    ? db_select_all(
        "SELECT origin.terminal_name AS origin_name,
                destination.terminal_name AS destination_name,
                COUNT(*) AS total_bookings,
                COALESCE(SUM(b.total_amount), 0) AS total_revenue
         FROM bookings b
         JOIN schedules s ON b.schedule_id = s.schedule_id
         JOIN routes r ON s.route_id = r.route_id
         JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
         JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
         GROUP BY r.route_id, origin.terminal_name, destination.terminal_name
         ORDER BY total_bookings DESC"
    )
    : [];

$recentActivity = !$isStaff && table_exists('audit_logs') ? get_audit_logs([], 5) : [];

$pageActions = $isStaff
    ? [
        ['label' => 'Open QR Scanner', 'href' => 'pages/ticket-scanner.php', 'icon' => 'fa-qrcode', 'class' => 'btn btn-accent'],
        ['label' => 'Review Payments', 'href' => 'pages/manage-payments.php', 'icon' => 'fa-wallet', 'class' => 'btn btn-outline-secondary'],
    ]
    : [
        ['label' => 'Dispatch Schedules', 'href' => 'pages/manage-schedules.php', 'icon' => 'fa-calendar-days', 'class' => 'btn btn-accent'],
        ['label' => 'Review Payments', 'href' => 'pages/manage-payments.php', 'icon' => 'fa-wallet', 'class' => 'btn btn-outline-secondary'],
        ['label' => 'Open Reports', 'href' => 'pages/reports.php', 'icon' => 'fa-chart-line', 'class' => 'btn btn-outline-secondary'],
    ];

$stats = $isStaff
    ? [
        ['label' => 'Departures Today', 'value' => number_format($todayTrips), 'hint' => $liveTrips . ' active trips now', 'icon' => 'fa-bus-simple', 'tone' => 'blue'],
        ['label' => 'Pending Payments', 'value' => number_format((int) ($paymentStats['pending'] ?? 0)), 'hint' => (int) ($paymentStats['cash_pending'] ?? 0) . ' cash claims waiting', 'icon' => 'fa-wallet', 'tone' => 'amber'],
        ['label' => 'Low Seat Alerts', 'value' => number_format($lowSeatTrips), 'hint' => 'Trips with five or fewer seats left', 'icon' => 'fa-triangle-exclamation', 'tone' => 'rose'],
        ['label' => 'Active Fleet', 'value' => number_format((int) ($busStats['active'] ?? 0)), 'hint' => (int) ($busStats['maintenance'] ?? 0) . ' in maintenance', 'icon' => 'fa-tower-broadcast', 'tone' => 'teal'],
    ]
    : [
        ['label' => 'Paid Today', 'value' => dash_money((float) ($paymentStats['paid_today'] ?? 0)), 'hint' => number_format((int) ($paymentStats['pending'] ?? 0)) . ' payments waiting for review', 'icon' => 'fa-arrow-trend-up', 'tone' => 'green'],
        ['label' => 'Live Trips', 'value' => number_format($liveTrips), 'hint' => number_format($todayTrips) . ' departures scheduled today', 'icon' => 'fa-tower-broadcast', 'tone' => 'blue'],
        ['label' => 'Active Fleet', 'value' => number_format((int) ($busStats['active'] ?? 0)), 'hint' => (int) ($busStats['maintenance'] ?? 0) . ' in maintenance', 'icon' => 'fa-bus-simple', 'tone' => 'amber'],
        ['label' => 'Active Accounts', 'value' => number_format((int) ($userStats['active'] ?? 0)), 'hint' => number_format((int) ($userStats['total'] ?? 0)) . ' registered users', 'icon' => 'fa-users', 'tone' => 'violet'],
    ];

admin_render_header($isStaff ? 'Staff Dashboard' : 'Admin Dashboard', 'dashboard');
admin_page_header(
    $isStaff ? 'Staff Dashboard' : 'Admin Dashboard',
    $isStaff
        ? 'Handle payments, departures, and final ticket validation from one cleaner operations dashboard.'
        : 'Monitor payments, fleet status, passenger activity, and dispatch readiness from one admin landing page.',
    $pageActions
);
?>

<style>
.dash-hero{background:linear-gradient(132deg,rgba(8,26,51,.98),rgba(11,45,95,.96) 54%,rgba(21,82,163,.92) 80%,rgba(242,138,29,.82));border:1px solid rgba(255,255,255,.1);border-radius:1.8rem;box-shadow:0 28px 62px rgba(8,26,51,.24);color:#fff;margin-bottom:1.5rem;overflow:hidden;padding:1.5rem;position:relative}
.dash-hero::after{background:radial-gradient(circle at top right,rgba(255,255,255,.16),transparent 32%),linear-gradient(120deg,rgba(255,255,255,.06) 0 2px,transparent 2px 100%);background-size:auto,220px 220px;content:'';inset:0;opacity:.55;pointer-events:none;position:absolute}
.dash-hero>*{position:relative;z-index:1}
.dash-brand-row{align-items:center;display:flex;gap:1rem;margin-bottom:1rem}
.dash-brand-row img{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);border-radius:1rem;display:block;filter:drop-shadow(0 18px 28px rgba(4,10,19,.24));padding:.28rem;width:5rem}
.dash-brand-copy{display:grid;gap:.18rem}
.dash-brand-copy span{color:rgba(255,225,178,.86);font-size:.72rem;font-weight:800;letter-spacing:.18em;text-transform:uppercase}
.dash-brand-copy strong{color:#fff;font-family:'Space Grotesk',sans-serif;font-size:1.15rem;font-weight:700;letter-spacing:-.03em;line-height:1.05}
.dash-kicker{color:rgba(255,255,255,.72);display:inline-flex;font-size:.78rem;font-weight:800;letter-spacing:.1em;margin-bottom:.75rem;text-transform:uppercase}
.dash-hero h2{font-family:'Space Grotesk',sans-serif;font-size:clamp(2rem,3vw,3rem);font-weight:700;letter-spacing:-.05em;margin:0}
.dash-hero p{color:rgba(255,255,255,.78);margin:.85rem 0 1rem;max-width:48rem}
.dash-chip-row{display:flex;flex-wrap:wrap;gap:.6rem}
.dash-chip-row .chip{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.1);color:#fff}
.dash-panel{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.14);border-radius:1.2rem;box-shadow:inset 0 1px 0 rgba(255,255,255,.08);padding:1rem}
.dash-panel span{color:rgba(255,255,255,.66);display:block;font-size:.76rem;font-weight:700;letter-spacing:.08em;margin-bottom:.3rem;text-transform:uppercase}
.dash-panel strong{display:block;font-family:'Space Grotesk',sans-serif;font-size:1.18rem;margin-bottom:.2rem}
.dash-panel small{color:rgba(255,255,255,.72);display:block;line-height:1.5}
.dash-list,.dash-actions{display:grid;gap:.9rem}
.dash-item,.dash-action{background:linear-gradient(180deg,rgba(255,255,255,.96),rgba(248,250,252,.98));border:1px solid rgba(15,23,42,.08);border-radius:1.15rem;color:inherit;display:block;padding:1rem;text-decoration:none}
.dash-item-title,.dash-action-title{font-weight:700;margin-bottom:.2rem}
.dash-item-sub,.dash-action-copy,.dash-muted{color:var(--admin-muted);font-size:.88rem}
.dash-progress{background:rgba(15,23,42,.08);border-radius:999px;height:.55rem;margin-top:.7rem;overflow:hidden}
.dash-progress span{background:linear-gradient(90deg,#2b7eea,#f28a1d);display:block;height:100%}
.dash-action-icon{align-items:center;background:linear-gradient(135deg,rgba(21,82,163,.12),rgba(242,138,29,.18));border-radius:1rem;color:#0f4fa7;display:inline-flex;height:3rem;justify-content:center;margin-bottom:.75rem;width:3rem}
.dash-empty{border:1px dashed rgba(15,23,42,.14);border-radius:1.1rem;color:var(--admin-muted);padding:1rem;text-align:center}
.insight-grid{display:grid;gap:1rem;grid-template-columns:repeat(3,minmax(0,1fr))}
.insight-card{background:linear-gradient(135deg,rgba(248,250,252,1),rgba(255,255,255,1));border:1px solid rgba(15,23,42,.06);border-radius:1.2rem;padding:1rem}
.insight-label{color:var(--admin-muted);display:block;font-size:.74rem;font-weight:700;letter-spacing:.08em;margin-bottom:.35rem;text-transform:uppercase}
.insight-card strong{display:block;font-family:'Space Grotesk',sans-serif;font-size:1.02rem;line-height:1.35;margin-bottom:.3rem}
.insight-card p{color:var(--admin-muted);font-size:.9rem;margin:0}
@media (max-width: 991px){.insight-grid{grid-template-columns:1fr}}
</style>

<style>
/* Dashboard experience refresh: shared by the admin and staff workspaces. */
.dash-hero {
    background:
        radial-gradient(circle at 88% 16%, rgba(108, 190, 255, 0.3) 0 7rem, transparent 7.2rem),
        radial-gradient(circle at 65% 112%, rgba(255, 180, 61, 0.32) 0 14rem, transparent 14.2rem),
        linear-gradient(126deg, #06152d 0%, #0a3774 54%, #155a9e 100%);
    border: 1px solid rgba(255, 255, 255, 0.16);
    border-radius: 2rem;
    box-shadow: 0 30px 68px rgba(3, 17, 42, 0.28);
    margin-bottom: 1.7rem;
    padding: clamp(1.45rem, 2.6vw, 2.25rem);
}

.dash-hero--staff {
    background:
        radial-gradient(circle at 88% 16%, rgba(122, 226, 202, 0.22) 0 7rem, transparent 7.2rem),
        radial-gradient(circle at 65% 112%, rgba(255, 180, 61, 0.28) 0 14rem, transparent 14.2rem),
        linear-gradient(126deg, #061d32 0%, #075169 54%, #0d6b85 100%);
}

.dash-hero::after {
    background:
        linear-gradient(120deg, rgba(255, 255, 255, 0.065) 0 1px, transparent 1px 100%),
        linear-gradient(30deg, transparent 0 48%, rgba(255, 255, 255, 0.06) 49% 50%, transparent 51% 100%);
    background-size: 170px 170px, 260px 260px;
    opacity: 0.58;
}

.dash-brand-row {
    margin-bottom: 1.45rem;
}

.dash-brand-row img {
    background: rgba(255, 255, 255, 0.1);
    border-color: rgba(255, 255, 255, 0.2);
    border-radius: 1.1rem;
    padding: 0.35rem;
    width: 4.65rem;
}

.dash-brand-copy strong {
    font-size: 1.24rem;
}

.dash-hero-status {
    align-items: center;
    background: rgba(255, 255, 255, 0.11);
    border: 1px solid rgba(255, 255, 255, 0.15);
    border-radius: 999px;
    color: rgba(255, 255, 255, 0.9);
    display: inline-flex;
    font-size: 0.73rem;
    font-weight: 800;
    gap: 0.5rem;
    letter-spacing: 0.08em;
    margin-bottom: 0.8rem;
    padding: 0.48rem 0.75rem;
    text-transform: uppercase;
}

.dash-hero-status::before {
    background: #65ddac;
    border-radius: 50%;
    box-shadow: 0 0 0 0.22rem rgba(101, 221, 172, 0.15);
    content: '';
    height: 0.44rem;
    width: 0.44rem;
}

.dash-hero h2 {
    font-size: clamp(2rem, 1.5rem + 1.9vw, 3.2rem);
    letter-spacing: -0.065em;
    line-height: 1;
    max-width: 42rem;
}

.dash-hero p {
    font-size: 0.98rem;
    line-height: 1.65;
    margin: 0.9rem 0 1.35rem;
    max-width: 43rem;
}

.dash-chip-row {
    gap: 0.55rem;
}

.dash-chip-row .chip {
    backdrop-filter: blur(8px);
    background: rgba(255, 255, 255, 0.1);
    font-size: 0.75rem;
    padding: 0.46rem 0.7rem;
}

.dash-panel {
    background: linear-gradient(155deg, rgba(255, 255, 255, 0.16), rgba(255, 255, 255, 0.08));
    border-color: rgba(255, 255, 255, 0.2);
    border-radius: 1.3rem;
    min-height: 8.6rem;
    padding: 1.05rem 1.1rem;
    transition: background-color 0.2s ease, transform 0.2s ease;
}

.dash-panel:hover {
    background: rgba(255, 255, 255, 0.16);
    transform: translateY(-2px);
}

.dash-panel span {
    color: rgba(255, 226, 170, 0.86);
    font-size: 0.68rem;
}

.dash-panel strong {
    font-size: clamp(1.05rem, 0.9rem + 0.6vw, 1.35rem);
    line-height: 1.2;
}

.dash-stat-tile {
    background: linear-gradient(155deg, #ffffff 0%, #f8fbff 100%);
    border-color: rgba(15, 43, 82, 0.09);
    border-radius: 1.35rem;
    display: grid;
    gap: 0.75rem;
    grid-template-columns: minmax(0, 1fr) auto;
    min-height: 10.25rem;
    overflow: hidden;
    padding: 1.15rem;
}

.dash-stat-tile::after {
    background: radial-gradient(circle at top right, var(--dash-glow, rgba(42, 122, 223, 0.16)), transparent 62%);
}

.dash-stat-tile .label {
    font-size: 0.72rem;
    letter-spacing: 0.09em;
}

.dash-stat-tile .value {
    font-size: clamp(1.65rem, 1.3rem + 1.25vw, 2.35rem);
    margin-top: 0.3rem;
}

.dash-stat-tile .hint {
    font-size: 0.78rem;
    line-height: 1.45;
}

.dash-stat-icon {
    align-items: center;
    background: var(--dash-icon-bg, #eaf3ff);
    border: 1px solid rgba(255, 255, 255, 0.72);
    border-radius: 1rem;
    color: var(--dash-icon, #1968bb);
    display: inline-flex;
    font-size: 1.05rem;
    height: 3rem;
    justify-content: center;
    width: 3rem;
}

.dash-stat-tile--blue { --dash-icon-bg: #e9f3ff; --dash-icon: #1769be; --dash-glow: rgba(44, 129, 228, 0.2); }
.dash-stat-tile--green { --dash-icon-bg: #e7f8ee; --dash-icon: #128456; --dash-glow: rgba(45, 175, 105, 0.17); }
.dash-stat-tile--amber { --dash-icon-bg: #fff5df; --dash-icon: #c87a08; --dash-glow: rgba(239, 166, 42, 0.2); }
.dash-stat-tile--rose { --dash-icon-bg: #fff0ee; --dash-icon: #d04438; --dash-glow: rgba(221, 81, 69, 0.17); }
.dash-stat-tile--teal { --dash-icon-bg: #e6f8f7; --dash-icon: #087d79; --dash-glow: rgba(18, 160, 151, 0.16); }
.dash-stat-tile--violet { --dash-icon-bg: #f0edff; --dash-icon: #6953c7; --dash-glow: rgba(113, 88, 207, 0.17); }

.admin-card {
    border-radius: 1.4rem;
}

.admin-card-header {
    background: linear-gradient(180deg, rgba(247, 250, 254, 0.8), rgba(255, 255, 255, 0.8));
    min-height: 4.9rem;
}

.admin-card-header h2::before {
    background: linear-gradient(180deg, #1f78cf, #f0a126);
    border-radius: 999px;
    content: '';
    display: inline-block;
    height: 1.1rem;
    margin-right: 0.65rem;
    vertical-align: -0.15rem;
    width: 0.3rem;
}

.dash-insight-card {
    background: linear-gradient(145deg, #fbfdff, #f3f8ff);
    border: 1px solid rgba(20, 69, 127, 0.09);
    border-radius: 1.15rem;
    min-height: 100%;
    padding: 1.05rem;
    position: relative;
}

.dash-insight-card::after {
    border: 1px solid rgba(46, 119, 200, 0.12);
    border-radius: 50%;
    content: '';
    height: 4.7rem;
    position: absolute;
    right: -1.6rem;
    top: -1.9rem;
    width: 4.7rem;
}

.dash-insight-icon {
    align-items: center;
    background: #eaf3ff;
    border-radius: 0.75rem;
    color: #1769be;
    display: inline-flex;
    font-size: 0.9rem;
    height: 2.35rem;
    justify-content: center;
    margin-bottom: 0.8rem;
    width: 2.35rem;
}

.dash-insight-card:nth-child(2) .dash-insight-icon { background: #fff5df; color: #be7409; }
.dash-insight-card:nth-child(3) .dash-insight-icon { background: #e8f8f3; color: #16885e; }

.dash-insight-card strong {
    font-size: 1.03rem;
    max-width: 95%;
}

.dash-list {
    gap: 0.72rem;
}

.dash-item {
    background: linear-gradient(145deg, #ffffff, #f8fbff);
    border: 1px solid rgba(20, 56, 102, 0.08);
    border-radius: 1.05rem;
    box-shadow: 0 8px 18px rgba(19, 56, 98, 0.035);
    transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
}

.dash-item:hover {
    border-color: rgba(29, 105, 190, 0.28);
    box-shadow: 0 15px 26px rgba(19, 56, 98, 0.1);
    color: inherit;
    transform: translateY(-2px);
}

.dash-item-shell {
    align-items: flex-start;
    display: grid;
    gap: 0.85rem;
    grid-template-columns: 2.75rem minmax(0, 1fr) auto;
}

.dash-list-icon {
    align-items: center;
    background: #eaf3ff;
    border-radius: 0.8rem;
    color: #1769be;
    display: inline-flex;
    height: 2.75rem;
    justify-content: center;
    width: 2.75rem;
}

.dash-list-icon--payment { background: #fff5df; color: #bd7309; }
.dash-list-icon--booking { background: #e8f8f3; color: #138359; }
.dash-list-icon--claim { background: #fff0ed; color: #d34d3d; }
.dash-list-icon--route { background: #f0edff; color: #6954c6; }

.dash-item-title {
    color: #152c4d;
    font-size: 0.94rem;
}

.dash-item-sub {
    line-height: 1.45;
    margin-top: 0.15rem;
}

.dash-muted {
    font-size: 0.77rem;
    margin-top: 0.4rem;
}

.dash-item-side {
    min-width: 5.5rem;
    text-align: right;
}

.dash-progress-label {
    color: #79889c;
    display: flex;
    font-size: 0.72rem;
    font-weight: 700;
    justify-content: space-between;
    margin: 0.85rem 0 0.38rem;
}

.dash-progress {
    height: 0.42rem;
    margin-top: 0;
}

.dash-progress span {
    background: linear-gradient(90deg, #1b75ce, #36b696);
}

.dash-actions {
    gap: 0.72rem;
}

.dash-action {
    background: linear-gradient(145deg, #ffffff, #f7fbff);
    border-radius: 1.05rem;
    display: grid;
    grid-template-columns: 3rem minmax(0, 1fr) auto;
    gap: 0.85rem;
    padding: 1rem;
    transition: border-color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
}

.dash-action::after {
    align-self: center;
    color: #728399;
    content: '\f061';
    font-family: 'Font Awesome 6 Free';
    font-size: 0.8rem;
    font-weight: 900;
}

.dash-action:hover {
    border-color: rgba(29, 105, 190, 0.28);
    box-shadow: 0 15px 26px rgba(19, 56, 98, 0.1);
    color: inherit;
    transform: translateY(-2px);
}

.dash-action-icon {
    height: 3rem;
    margin: 0;
    width: 3rem;
}

.dash-action-title {
    align-self: end;
    color: #152c4d;
    font-size: 0.92rem;
}

.dash-action-copy {
    align-self: start;
    grid-column: 2 / 3;
    line-height: 1.45;
}

@media (max-width: 767px) {
    .dash-hero { border-radius: 1.45rem; }
    .dash-brand-row { margin-bottom: 1rem; }
    .dash-brand-row img { width: 3.75rem; }
    .dash-panel { min-height: auto; }
    .dash-stat-tile { min-height: 0; }
    .dash-item-shell { gap: 0.7rem; grid-template-columns: 2.45rem minmax(0, 1fr); }
    .dash-list-icon { height: 2.45rem; width: 2.45rem; }
    .dash-item-side { grid-column: 2 / 3; min-width: 0; text-align: left; }
    .dash-item-side .dash-muted { display: inline-block; margin: 0 0 0 0.55rem; }
    .dash-action { grid-template-columns: 2.7rem minmax(0, 1fr) auto; }
    .dash-action-icon { height: 2.7rem; width: 2.7rem; }
}

@media (prefers-reduced-motion: reduce) {
    .dash-panel,
    .dash-item,
    .dash-action { transition: none; }
}
</style>

<section class="dash-hero dash-hero--<?php echo e($isStaff ? 'staff' : 'admin'); ?>">
    <div class="row g-4 align-items-stretch">
        <div class="col-lg-8">
            <div class="dash-brand-row">
                <img src="<?php echo e($brandLogo); ?>" alt="Bus Terminal logo">
                <div class="dash-brand-copy">
                    <span>Gonzaga Terminal</span>
                    <strong><?php echo e($isStaff ? 'Operations Portal' : 'Admin Control Portal'); ?></strong>
                </div>
            </div>
            <span class="dash-hero-status">System monitoring active</span>
            <span class="dash-kicker"><?php echo e($isStaff ? 'Operations Command View' : 'Admin Control Center'); ?></span>
            <h2><?php echo e('Welcome back, ' . $displayName); ?></h2>
            <p><?php echo e($isStaff ? 'This dashboard keeps terminal cash actions, QR validation, and automatic GCash transaction monitoring visible during the shift.' : 'This redesigned admin home screen gives you a cleaner read on dispatch, payments, fleet health, and operational activity.'); ?></p>
            <div class="dash-chip-row">
                <span class="chip"><i class="fa-regular fa-calendar me-1"></i><?php echo e(date('l, F j')); ?></span>
                <span class="chip"><i class="fa-solid fa-bus me-1"></i><?php echo e(number_format((int) ($busStats['active'] ?? 0))); ?> active buses</span>
                <span class="chip"><i class="fa-solid fa-wallet me-1"></i><?php echo e(number_format((int) ($paymentStats['pending'] ?? 0))); ?> payments waiting</span>
            </div>
        </div>
        <div class="col-lg-4 d-grid gap-3">
            <div class="dash-panel">
                <span><?php echo e($isStaff ? 'Next Departure' : 'Paid Today'); ?></span>
                <strong><?php echo e($isStaff ? ($nextTrip ? (($nextTrip['origin_name'] ?? '') . ' to ' . ($nextTrip['destination_name'] ?? '')) : 'No upcoming trip') : dash_money((float) ($paymentStats['paid_today'] ?? 0))); ?></strong>
                <small><?php echo e($isStaff ? ($nextTrip ? dash_departure_label((string) ($nextTrip['departure_date'] ?? ''), (string) ($nextTrip['departure_time'] ?? '')) : 'Create a new schedule to populate this panel.') : number_format((int) ($paymentStats['gcash_pending'] ?? 0)) . ' GCash checkouts await gateway confirmation; ' . number_format((int) ($paymentStats['cash_pending'] ?? 0)) . ' cash items need staff action'); ?></small>
            </div>
            <div class="dash-panel">
                <span><?php echo e($isStaff ? 'Shift Focus' : 'System Snapshot'); ?></span>
                <strong><?php echo e($isStaff ? number_format($lowSeatTrips) . ' low-seat alerts' : number_format((int) ($bookingStats['confirmed'] ?? 0)) . ' confirmed bookings'); ?></strong>
                <small><?php echo e($isStaff ? number_format((int) ($bookingStats['cancelled'] ?? 0)) . ' bookings are cancelled; use the QR scanner for final ticket validation and terminal cash confirmation.' : number_format((int) ($bookingStats['pending'] ?? 0)) . ' bookings still need action; ' . number_format((int) ($bookingStats['cancelled'] ?? 0)) . ' are cancelled.'); ?></small>
            </div>
        </div>
    </div>
</section>

<div class="stats-grid">
    <?php foreach ($stats as $stat): ?>
        <div class="stat-tile">
            <span class="label"><?php echo e($stat['label']); ?></span>
            <span class="value"><?php echo e($stat['value']); ?></span>
            <span class="hint"><?php echo e($stat['hint']); ?></span>
        </div>
    <?php endforeach; ?>
</div>

<div class="row g-4 mb-4">
    <div class="col-12">
        <div class="admin-card">
            <div class="admin-card-header">
                <h2><?php echo e($isStaff ? 'Shift Focus' : 'Analytics Snapshot'); ?></h2>
                <span class="chip soft"><?php echo e($isStaff ? 'Operations overview' : 'Revenue and activity pulse'); ?></span>
            </div>
            <div class="admin-card-body">
                <div class="insight-grid">
                    <?php if ($isStaff): ?>
                        <div class="insight-card">
                            <span class="insight-label">Ready to board</span>
                            <strong><?php echo e(number_format((int) count($upcomingTrips))); ?> active trips</strong>
                            <p>Departure activity that needs staff attention before passenger boarding.</p>
                        </div>
                        <div class="insight-card">
                            <span class="insight-label">Payment monitor</span>
                            <strong><?php echo e(number_format((int) ($paymentStats['pending'] ?? 0))); ?> pending payments</strong>
                            <p>GCash is verified automatically by Maya Checkout; staff only confirm terminal cash.</p>
                        </div>
                        <div class="insight-card">
                            <span class="insight-label">Cash claims</span>
                            <strong><?php echo e(number_format(count($cashClaims))); ?> waiting claims</strong>
                            <p>Terminal payment requests that should be cleared quickly during the shift.</p>
                        </div>
                    <?php else: ?>
                        <div class="insight-card">
                            <span class="insight-label">Top route demand</span>
                            <strong><?php echo e($routeDemand === [] ? 'No route demand yet' : ($routeDemand[0]['origin_name'] ?? 'Route') . ' → ' . ($routeDemand[0]['destination_name'] ?? 'Destination')); ?></strong>
                            <p><?php echo e($routeDemand === [] ? 'Route demand and revenue insights will appear once bookings are made.' : number_format((int) ($routeDemand[0]['total_bookings'] ?? 0)) . ' bookings • ' . dash_money((float) ($routeDemand[0]['total_revenue'] ?? 0))); ?></p>
                        </div>
                        <div class="insight-card">
                            <span class="insight-label">Recent activity</span>
                            <strong><?php echo e($recentActivity === [] ? 'No recent activity yet' : ((string) ($recentActivity[0]['actor_name'] ?? 'System'))); ?></strong>
                            <p><?php echo e($recentActivity === [] ? 'Audit logs will populate here as operations are recorded.' : ((string) ($recentActivity[0]['description'] ?? 'Activity recorded'))); ?></p>
                        </div>
                        <div class="insight-card">
                            <span class="insight-label">Fleet readiness</span>
                            <strong><?php echo e(number_format((int) ($busStats['active'] ?? 0))); ?> active buses</strong>
                            <p><?php echo e(number_format((int) ($busStats['maintenance'] ?? 0)) . ' buses are currently in maintenance.'); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-7">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2><?php echo e($isStaff ? 'Departure Board' : 'Live Operations'); ?></h2>
                <span class="chip soft"><?php echo e(number_format(count($upcomingTrips))); ?> active routes</span>
            </div>
            <div class="admin-card-body">
                <?php if ($upcomingTrips === []): ?>
                    <div class="dash-empty">No upcoming trips are available yet.</div>
                <?php else: ?>
                    <div class="dash-list">
                        <?php foreach ($upcomingTrips as $trip): ?>
                            <a class="dash-item" href="pages/manage-schedules.php?action=edit&id=<?php echo (int) $trip['schedule_id']; ?>">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div>
                                        <div class="dash-item-title"><?php echo e($trip['origin_name']); ?> to <?php echo e($trip['destination_name']); ?></div>
                                        <div class="dash-item-sub"><?php echo e(($trip['bus_name'] ?: $trip['bus_code']) . ' | ' . dash_departure_label((string) ($trip['departure_date'] ?? ''), (string) ($trip['departure_time'] ?? ''))); ?></div>
                                        <div class="dash-muted"><?php echo number_format((int) ($trip['reserved_seats'] ?? 0)); ?> reserved of <?php echo number_format((int) ($trip['total_seats'] ?? 0)); ?> seats</div>
                                    </div>
                                    <span class="chip <?php echo e(dash_trip_tone((string) ($trip['effective_trip_status'] ?? 'scheduled'))); ?>"><?php echo e(ucfirst((string) ($trip['effective_trip_status'] ?? 'scheduled'))); ?></span>
                                </div>
                                <div class="dash-progress"><span style="width: <?php echo (int) ($trip['load_percent'] ?? 0); ?>%;"></span></div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Quick Actions</h2>
            </div>
            <div class="admin-card-body">
                <div class="dash-actions">
                    <a class="dash-action" href="<?php echo e($isStaff ? 'pages/ticket-scanner.php' : 'pages/manage-schedules.php'); ?>">
                        <span class="dash-action-icon"><i class="fa-solid <?php echo e($isStaff ? 'fa-qrcode' : 'fa-calendar-days'); ?>"></i></span>
                        <div class="dash-action-title"><?php echo e($isStaff ? 'Validate Tickets' : 'Dispatch Schedules'); ?></div>
                        <div class="dash-action-copy"><?php echo e($isStaff ? 'Scan QR tickets and confirm cash claims without leaving the shift dashboard.' : 'Create schedules, assign buses, and keep departures organized from the admin side.'); ?></div>
                    </a>
                    <a class="dash-action" href="pages/manage-payments.php">
                        <span class="dash-action-icon"><i class="fa-solid fa-wallet"></i></span>
                        <div class="dash-action-title">Monitor Payments</div>
                        <div class="dash-action-copy">Track automatic GCash verification and confirm terminal cash claims.</div>
                    </a>
                    <a class="dash-action" href="<?php echo e($isStaff ? 'pages/manage-bookings.php' : 'pages/reports.php'); ?>">
                        <span class="dash-action-icon"><i class="fa-solid <?php echo e($isStaff ? 'fa-ticket' : 'fa-chart-line'); ?>"></i></span>
                        <div class="dash-action-title"><?php echo e($isStaff ? 'Manage Bookings' : 'Open Reports'); ?></div>
                        <div class="dash-action-copy"><?php echo e($isStaff ? 'Open passenger bookings quickly when exceptions, changes, or support requests happen.' : 'Check route demand, revenue, and performance without digging through separate pages.'); ?></div>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mt-1">
    <div class="col-xl-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Pending Payments</h2>
                <a class="btn btn-sm btn-outline-secondary" href="pages/manage-payments.php">Open Page</a>
            </div>
            <div class="admin-card-body">
                <?php if ($pendingPayments === []): ?>
                    <div class="dash-empty">No payments are awaiting gateway confirmation or terminal action right now.</div>
                <?php else: ?>
                    <div class="dash-list">
                        <?php foreach ($pendingPayments as $payment): ?>
                            <a class="dash-item" href="pages/manage-payments.php">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div>
                                        <div class="dash-item-title"><?php echo e($payment['fullname']); ?></div>
                                        <div class="dash-item-sub"><?php echo e($payment['origin_name']); ?> to <?php echo e($payment['destination_name']); ?></div>
                                        <div class="dash-muted"><?php echo e(($payment['payment_method'] ?? '') === 'cash' ? ('Claim ' . ($payment['claim_code'] ?? 'Pending code')) : ('Ref ' . ($payment['payment_reference'] ?? ''))); ?></div>
                                    </div>
                                    <div class="text-end">
                                        <span class="chip <?php echo e(dash_status_tone((string) ($payment['status'] ?? 'pending'))); ?>"><?php echo e(strtoupper((string) ($payment['payment_method'] ?? 'pending'))); ?></span>
                                        <div class="dash-muted mt-2"><?php echo e(dash_money((float) ($payment['amount'] ?? 0))); ?></div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-xl-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Recent Bookings</h2>
                <a class="btn btn-sm btn-outline-secondary" href="pages/manage-bookings.php">Open Page</a>
            </div>
            <div class="admin-card-body">
                <?php if ($recentBookings === []): ?>
                    <div class="dash-empty">No bookings have been recorded yet.</div>
                <?php else: ?>
                    <div class="dash-list">
                        <?php foreach ($recentBookings as $booking): ?>
                            <a class="dash-item" href="pages/booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
                                <div class="d-flex justify-content-between align-items-start gap-3">
                                    <div>
                                        <div class="dash-item-title"><?php echo e($booking['booking_reference']); ?></div>
                                        <div class="dash-item-sub"><?php echo e($booking['fullname']); ?> | <?php echo e((string) ($booking['number_of_passengers'] ?? 0)); ?> passengers</div>
                                        <div class="dash-muted"><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                                    </div>
                                    <div class="text-end">
                                        <span class="chip <?php echo e(dash_status_tone((string) ($booking['status'] ?? 'pending'))); ?>"><?php echo e(ucfirst((string) ($booking['status'] ?? 'pending'))); ?></span>
                                        <div class="dash-muted mt-2"><?php echo e(dash_money((float) ($booking['total_amount'] ?? 0))); ?></div>
                                    </div>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2><?php echo e($isStaff ? 'Cash Claim Queue' : 'Route Demand And Recent Activity'); ?></h2>
    </div>
    <div class="admin-card-body">
        <?php if ($isStaff): ?>
            <?php if ($cashClaims === []): ?>
                <div class="dash-empty">No terminal cash claims are waiting for staff confirmation.</div>
            <?php else: ?>
                <div class="dash-list">
                    <?php foreach ($cashClaims as $claim): ?>
                        <a class="dash-item" href="pages/ticket-scanner.php">
                            <div class="d-flex justify-content-between align-items-start gap-3">
                                <div>
                                    <div class="dash-item-title"><?php echo e((string) ($claim['claim_code'] ?? 'Pending code')); ?></div>
                                    <div class="dash-item-sub"><?php echo e($claim['fullname']); ?></div>
                                    <div class="dash-muted"><?php echo e($claim['origin_name']); ?> to <?php echo e($claim['destination_name']); ?></div>
                                </div>
                                <div class="text-end">
                                    <span class="chip warning">Cash</span>
                                    <div class="dash-muted mt-2"><?php echo e(dash_money((float) ($claim['total_amount'] ?? 0))); ?></div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="row g-4">
                <div class="col-lg-6">
                    <?php if ($routeDemand === []): ?>
                        <div class="dash-empty">Route demand will appear here once bookings are created.</div>
                    <?php else: ?>
                        <div class="dash-list">
                            <?php foreach ($routeDemand as $route): ?>
                                <a class="dash-item" href="pages/reports.php">
                                    <div class="d-flex justify-content-between align-items-start gap-3">
                                        <div>
                                            <div class="dash-item-title"><?php echo e($route['origin_name']); ?> to <?php echo e($route['destination_name']); ?></div>
                                            <div class="dash-item-sub"><?php echo number_format((int) ($route['total_bookings'] ?? 0)); ?> bookings</div>
                                        </div>
                                        <div class="dash-muted"><?php echo e(dash_money((float) ($route['total_revenue'] ?? 0))); ?></div>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="col-lg-6">
                    <?php if ($recentActivity === []): ?>
                        <div class="dash-empty">No audit activity is available yet.</div>
                    <?php else: ?>
                        <div class="dash-list">
                            <?php foreach ($recentActivity as $activity): ?>
                                <a class="dash-item" href="pages/audit-logs.php">
                                    <div class="dash-item-title"><?php echo e($activity['actor_name'] ?: 'System'); ?></div>
                                    <div class="dash-item-sub"><?php echo e(ucwords(str_replace(['.', '_'], ' ', (string) ($activity['action_key'] ?? 'activity')))); ?></div>
                                    <div class="dash-muted"><?php echo e((string) ($activity['description'] ?? 'No description available.')); ?></div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php admin_render_footer(); ?>
