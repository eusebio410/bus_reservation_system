<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$error = '';
$success = consume_flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $paymentId = (int) ($_POST['payment_id'] ?? 0);
    $decision = isset_post('decision');
    $notes = isset_post('admin_notes');

    if ($paymentId < 1) {
        $error = 'Invalid payment selection.';
    } elseif ($decision === 'approve') {
        $result = approve_payment($paymentId, (int) $_SESSION['user_id'], $notes);
        if ($result['ok']) {
            set_flash('success', $result['message']);
            redirect('manage-payments.php');
        }
        $error = $result['message'];
    } elseif ($decision === 'reject') {
        $result = reject_payment($paymentId, (int) $_SESSION['user_id'], $notes);
        if ($result['ok']) {
            set_flash('success', $result['message']);
            redirect('manage-payments.php');
        }
        $error = $result['message'];
    } elseif ($decision === 'mark_paid') {
        $result = complete_cash_payment($paymentId, (int) $_SESSION['user_id'], $notes);
        if ($result['ok']) {
            set_flash('success', $result['message']);
            redirect('manage-payments.php');
        }
        $error = $result['message'];
    }
}

$filterStatus = isset_get('status');
$sql = "SELECT p.*, b.booking_reference, b.claim_code, b.status AS booking_status, b.expires_at, u.fullname,
               s.departure_date, origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
        FROM payments p
        JOIN bookings b ON p.booking_id = b.booking_id
        JOIN users u ON b.user_id = u.user_id
        JOIN schedules s ON b.schedule_id = s.schedule_id
        JOIN routes r ON s.route_id = r.route_id
        JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
        JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
        WHERE 1 = 1";
$types = '';
$params = [];

if ($filterStatus !== '') {
    $sql .= ' AND p.status = ?';
    $types .= 's';
    $params[] = $filterStatus;
}

$sql .= ' ORDER BY p.submitted_at DESC';
$payments = db_select_all($sql, $types, $params);

$pendingCount = 0;
$paidCount = 0;
$rejectedCount = 0;
$cashPendingCount = 0;
$gcashPendingCount = 0;
$paidTodayAmount = 0.0;
foreach ($payments as $payment) {
    $paymentStatus = (string) ($payment['status'] ?? '');
    $paymentMethod = (string) ($payment['payment_method'] ?? '');

    if ($paymentStatus === 'pending') {
        $pendingCount++;
        if ($paymentMethod === 'cash') {
            $cashPendingCount++;
        }
        if ($paymentMethod === 'gcash') {
            $gcashPendingCount++;
        }
    }

    if ($paymentStatus === 'paid') {
        $paidCount++;
        if (substr((string) ($payment['verified_at'] ?? $payment['submitted_at'] ?? ''), 0, 10) === date('Y-m-d')) {
            $paidTodayAmount += (float) ($payment['amount'] ?? 0);
        }
    }

    if (in_array($paymentStatus, ['rejected', 'failed', 'refunded'], true)) {
        $rejectedCount++;
    }
}

$activeFilterCount = $filterStatus !== '' ? 1 : 0;
$filterSummary = $filterStatus !== ''
    ? 'Focused on ' . ucfirst($filterStatus) . ' payments only.'
    : 'Showing gateway-verified GCash transactions and terminal cash claims.';

admin_render_header('Payment Management', 'payments');
admin_page_header(
    'Payment Management',
    'Monitor automatic GCash verification and confirm terminal cash only after staff receive the fare.',
    [
        ['label' => 'Open Scanner', 'href' => 'ticket-scanner.php', 'icon' => 'fa-qrcode', 'class' => 'btn btn-outline-secondary'],
        ['label' => 'Booking Board', 'href' => 'manage-bookings.php', 'icon' => 'fa-ticket', 'class' => 'btn btn-outline-secondary'],
    ]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-toolbar-card">
    <div class="admin-toolbar-grid">
        <div class="admin-toolbar-copy">
            <span class="admin-toolbar-eyebrow">Payment Queue</span>
            <h2>Transaction monitor for GCash and terminal cash</h2>
            <p><?php echo e($filterSummary); ?> Maya Checkout confirms valid GCash transactions and releases QR tickets automatically; this page is for monitoring, not receipt approval.</p>
        </div>
        <div class="admin-toolbar-actions">
            <a class="btn btn-outline-light" href="ticket-scanner.php">
                <i class="fa-solid fa-qrcode me-1"></i>QR Scanner
            </a>
            <a class="btn btn-outline-light" href="manage-bookings.php">
                <i class="fa-solid fa-ticket me-1"></i>Booking Board
            </a>
        </div>
    </div>
</div>

<div class="admin-metric-grid">
    <div class="admin-metric-card">
        <span class="admin-metric-label">Pending Reviews</span>
        <span class="admin-metric-value"><?php echo number_format($pendingCount); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($gcashPendingCount); ?> GCash checkouts are awaiting gateway confirmation; <?php echo number_format($cashPendingCount); ?> cash items still need staff action.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Paid Today</span>
        <span class="admin-metric-value">PHP <?php echo number_format($paidTodayAmount, 2); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($paidCount); ?> payment records in the current filtered list are already complete.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Rejected Or Failed</span>
        <span class="admin-metric-value"><?php echo number_format($rejectedCount); ?></span>
        <span class="admin-metric-copy">Gateway failures and refunds should be handled from Maya Business, with the transaction record retained here.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Transactions Shown</span>
        <span class="admin-metric-value"><?php echo number_format(count($payments)); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($activeFilterCount); ?> filters are active on this payment board.</span>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <div>
            <h2>Filter Reviews</h2>
            <div class="admin-list-meta">Use status filters when the queue gets crowded and you need to isolate only pending or completed transactions.</div>
        </div>
        <span class="chip soft"><?php echo number_format($activeFilterCount); ?> active filters</span>
    </div>
    <div class="admin-card-body">
        <form method="get" class="row g-3">
            <div class="col-md-4">
                <label class="form-label" for="status">Payment Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All statuses</option>
                    <?php foreach (['pending', 'paid', 'rejected', 'failed', 'refunded'] as $statusOption): ?>
                        <option value="<?php echo e($statusOption); ?>" <?php echo $filterStatus === $statusOption ? 'selected' : ''; ?>>
                            <?php echo e(ucfirst($statusOption)); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 d-flex gap-2">
                <button class="btn btn-accent" type="submit">Apply</button>
                <a class="btn btn-outline-secondary" href="manage-payments.php">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h2>Transaction Review Board</h2>
            <div class="admin-list-meta">Every row keeps the passenger, trip, amount, verification source, and any terminal-cash action together.</div>
        </div>
        <span class="chip soft"><?php echo number_format(count($payments)); ?> rows</span>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Payment</th>
                        <th>Passenger</th>
                        <th>Trip</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Verification</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($payments === []): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">No payments match the current filter.</td></tr>
                    <?php else: ?>
                        <?php foreach ($payments as $payment): ?>
                            <?php
                            $paymentLabel = (($payment['payment_method'] ?? '') === 'cash' && !empty($payment['claim_code']))
                                ? (string) $payment['claim_code']
                                : (string) $payment['booking_reference'];
                            ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($payment['payment_reference']); ?></div>
                                    <div class="small text-muted"><?php echo e($paymentLabel); ?> | <?php echo strtoupper(e($payment['payment_method'])); ?></div>
                                    <div class="small text-muted"><?php echo e(date('M j, Y g:i A', strtotime((string) ($payment['submitted_at'] ?? 'now')))); ?></div>
                                </td>
                                <td><?php echo e($payment['fullname']); ?></td>
                                <td>
                                    <div><?php echo e($payment['origin_name']); ?> to <?php echo e($payment['destination_name']); ?></div>
                                    <div class="small text-muted"><?php echo date('M j, Y', strtotime($payment['departure_date'])); ?></div>
                                    <?php if (($payment['payment_method'] ?? '') === 'cash' && !empty($payment['expires_at'])): ?>
                                        <div class="small text-muted">Valid until departure: <?php echo date('M j, g:i A', strtotime($payment['expires_at'])); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>PHP <?php echo number_format((float) $payment['amount'], 2); ?></td>
                                <td><span class="chip <?php echo $payment['status'] === 'paid' ? 'success' : ($payment['status'] === 'pending' ? 'warning' : 'danger'); ?>"><?php echo e(ucfirst($payment['status'])); ?></span></td>
                                <td>
                                    <?php if (($payment['provider'] ?? '') === 'maya' && ($payment['status'] ?? '') === 'paid'): ?>
                                        <span class="text-success small"><i class="fa-solid fa-shield-check me-1"></i>Verified automatically by Maya Checkout</span>
                                    <?php elseif (($payment['provider'] ?? '') === 'maya'): ?>
                                        <span class="text-muted small">Awaiting Maya confirmation</span>
                                    <?php elseif (!empty($payment['proof_image'])): ?>
                                        <a class="btn btn-sm btn-outline-secondary" href="payment-proof.php?payment_id=<?php echo (int) $payment['payment_id']; ?>" target="_blank" rel="noopener">Legacy Proof</a>
                                    <?php elseif (($payment['payment_method'] ?? '') === 'cash'): ?>
                                        <span class="text-muted small">Confirmed at terminal</span>
                                    <?php else: ?>
                                        <span class="text-muted small">No gateway record</span>
                                    <?php endif; ?>
                                </td>
                                <td style="min-width:280px;">
                                    <?php if ($payment['status'] === 'pending' && ($payment['payment_method'] ?? '') === 'gcash'): ?>
                                        <div class="small text-muted">No manual approval. Maya Checkout will confirm a valid payment and issue the ticket automatically.</div>
                                    <?php elseif ($payment['status'] === 'pending' && ($payment['payment_method'] ?? '') === 'cash'): ?>
                                        <form method="post" class="d-grid gap-2">
                                            <?php csrf_field(); ?>
                                            <input type="hidden" name="payment_id" value="<?php echo (int) $payment['payment_id']; ?>">
                                            <textarea class="form-control form-control-sm" name="admin_notes" rows="2" placeholder="Optional terminal payment note"></textarea>
                                            <button class="btn btn-sm btn-accent" type="submit" name="decision" value="mark_paid">Mark Paid and Issue Ticket</button>
                                        </form>
                                    <?php elseif (($payment['payment_method'] ?? '') === 'cash'): ?>
                                        <div class="small text-muted">Terminal cash payment already confirmed.</div>
                                    <?php else: ?>
                                        <div class="small text-muted"><?php echo e($payment['admin_notes'] ?: 'Verified automatically by the payment gateway.'); ?></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
