<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$userId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');
$currentAdminId = (int) ($_SESSION['user_id'] ?? 0);

if ($action === 'delete' && $userId > 0) {
    $currentUserId = (int) ($_SESSION['user_id'] ?? 0);
    $targetUser = db_select_one('SELECT user_id, fullname, email, account_status FROM users WHERE user_id = ? LIMIT 1', 'i', [$userId]);
    if ($userId === $currentUserId) {
        $error = 'You cannot delete your own account.';
    } elseif (db_execute('DELETE FROM users WHERE user_id = ?', 'i', [$userId])) {
        create_audit_log(
            $currentAdminId,
            'user.deleted',
            'user',
            $userId,
            'User account deleted from admin management.',
            [
                'fullname' => (string) ($targetUser['fullname'] ?? ''),
                'email' => (string) ($targetUser['email'] ?? ''),
                'previous_account_status' => (string) ($targetUser['account_status'] ?? ''),
            ]
        );
        set_flash('success', 'User deleted successfully.');
        redirect('manage-users.php');
    } else {
        $error = 'Unable to delete the user.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['user_id'] ?? 0);
    $fullname = isset_post('fullname');
    $email = normalize_email_address(isset_post('email'));
    $phoneInput = isset_post('phone');
    $phone = normalize_ph_phone($phoneInput);
    $address = isset_post('address');
    $roleId = (int) ($_POST['role_id'] ?? 0);
    $accountStatus = isset_post('account_status') ?: 'active';

    if ($fullname === '' || $email === '' || $roleId < 1) {
        $error = 'Full name, email, and role are required.';
    } elseif (!is_valid_email_address($email)) {
        $error = 'Please use a valid email address.';
    } elseif ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
        $error = 'Please use a valid Philippine mobile number, such as 09171234567 or +639171234567.';
    } else {
        $existingUser = db_select_one(
            'SELECT user_id, fullname, email, role_id, account_status FROM users WHERE user_id = ? LIMIT 1',
            'i',
            [$editId]
        );
        $duplicate = db_select_one(
            'SELECT user_id FROM users WHERE email = ? AND user_id <> ? LIMIT 1',
            'si',
            [$email, $editId]
        );

        if ($duplicate) {
            $error = 'That email address is already in use.';
        } else {
            $role = db_select_one('SELECT role_key FROM roles WHERE role_id = ? LIMIT 1', 'i', [$roleId]);
            $isAdmin = ($role['role_key'] ?? '') === 'admin' ? 1 : 0;

            $ok = db_execute(
                'UPDATE users SET fullname = ?, email = ?, phone = ?, address = ?, role_id = ?, is_admin = ?, account_status = ?, updated_at = NOW() WHERE user_id = ?',
                'ssssiisi',
                [$fullname, $email, $phone, $address, $roleId, $isAdmin, $accountStatus, $editId]
            );

            if ($ok) {
                create_audit_log(
                    $currentAdminId,
                    'user.updated',
                    'user',
                    $editId,
                    'User profile, role, or account status updated.',
                    [
                        'fullname' => $fullname,
                        'email' => $email,
                        'role_id' => $roleId,
                        'previous_role_id' => (int) ($existingUser['role_id'] ?? 0),
                        'account_status' => $accountStatus,
                        'previous_account_status' => (string) ($existingUser['account_status'] ?? ''),
                    ]
                );
                set_flash('success', 'User updated successfully.');
                redirect('manage-users.php');
            }

            $error = 'Unable to update the user.';
        }
    }
}

$editUser = null;
if ($action === 'edit' && $userId > 0) {
    $editUser = db_select_one('SELECT * FROM users WHERE user_id = ? LIMIT 1', 'i', [$userId]);
}

$roles = db_select_all('SELECT role_id, role_name, role_key FROM roles ORDER BY role_name ASC');
$users = db_select_all(
    "SELECT u.*, r.role_name, r.role_key, COUNT(DISTINCT b.booking_id) AS booking_count
     FROM users u
     LEFT JOIN roles r ON u.role_id = r.role_id
     LEFT JOIN bookings b ON u.user_id = b.user_id
     GROUP BY u.user_id
     ORDER BY u.created_at DESC"
);

admin_render_header('User Management', 'users');
admin_page_header('User Management', 'Assign roles, activate or deactivate accounts, and review booking ownership.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editUser ? 'Edit User' : 'Select a User to Edit'; ?></h2>
        </div>
        <div class="admin-card-body">
            <?php if (!$editUser): ?>
                <p class="text-muted mb-0">Choose any row from the registry below to update role, status, or profile details.</p>
            <?php else: ?>
                <form method="post" class="row g-3">
                    <?php csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo (int) $editUser['user_id']; ?>">
                    <div class="col-md-6">
                        <label class="form-label" for="fullname">Full Name</label>
                        <input class="form-control" type="text" id="fullname" name="fullname" value="<?php echo e($editUser['fullname']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="email">Email</label>
                        <input class="form-control" type="email" id="email" name="email" value="<?php echo e($editUser['email']); ?>" placeholder="name@example.com" required>
                        <div class="form-text">Use a valid email address for portal access and notifications.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="phone">Phone</label>
                        <input class="form-control" type="tel" id="phone" name="phone" inputmode="tel" pattern="(?:09\d{9}|\+639\d{9})" maxlength="13" placeholder="09171234567" value="<?php echo e($editUser['phone']); ?>">
                        <div class="form-text">Use a Philippine mobile number like <code>09171234567</code> or <code>+639171234567</code>.</div>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="address">Address</label>
                        <input class="form-control" type="text" id="address" name="address" value="<?php echo e($editUser['address']); ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="role_id">Role</label>
                        <select class="form-select" id="role_id" name="role_id" required>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?php echo (int) $role['role_id']; ?>" <?php echo ((int) $editUser['role_id'] === (int) $role['role_id']) ? 'selected' : ''; ?>>
                                    <?php echo e($role['role_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="account_status">Account Status</label>
                        <select class="form-select" id="account_status" name="account_status">
                            <option value="active" <?php echo (($editUser['account_status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo (($editUser['account_status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button class="btn btn-accent" type="submit">Update User</button>
                        <a class="btn btn-outline-secondary" href="manage-users.php">Cancel</a>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>User Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Total Users</span>
                    <span class="value"><?php echo number_format(count($users)); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Privileged Accounts</span>
                    <span class="value"><?php echo number_format(count(array_filter($users, static fn($user) => in_array($user['role_key'], ['admin', 'staff'], true)))); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Inactive Accounts</span>
                    <span class="value"><?php echo number_format(count(array_filter($users, static fn($user) => ($user['account_status'] ?? 'active') !== 'active'))); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>User Registry</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Bookings</th>
                        <th>Last Login</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users === []): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No users found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($user['fullname']); ?></div>
                                    <div class="small text-muted"><?php echo e($user['email']); ?></div>
                                </td>
                                <td><span class="chip soft"><?php echo e($user['role_name'] ?: 'Passenger'); ?></span></td>
                                <td><span class="chip <?php echo (($user['account_status'] ?? 'active') === 'active') ? 'success' : 'danger'; ?>"><?php echo e(ucfirst($user['account_status'] ?? 'active')); ?></span></td>
                                <td><?php echo number_format((int) $user['booking_count']); ?></td>
                                <td><?php echo $user['last_login_at'] ? date('M j, Y g:i A', strtotime($user['last_login_at'])) : '<span class="text-muted">Never</span>'; ?></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-users.php?action=edit&id=<?php echo (int) $user['user_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-users.php?action=delete&id=<?php echo (int) $user['user_id']; ?>" onclick="return confirm('Delete this user?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
