<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$bookingId = (int) ($_REQUEST['booking_id'] ?? isset_get('booking_id'));
if ($bookingId < 1) {
    redirect('manage-bookings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_post('action') === 'cancel_booking') {
    $result = cancel_booking_by_admin($bookingId);
    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('booking-view.php?booking_id=' . $bookingId);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_post('action') === 'review_discount') {
    $passengerId = (int) ($_POST['passenger_id'] ?? 0);
    $decision = isset_post('decision');
    $result = review_passenger_discount($passengerId, $decision);
    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('booking-view.php?booking_id=' . $bookingId);
}

$error = consume_flash('error');
$success = consume_flash('success');

$booking = db_select_one(
    "SELECT b.*, s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time, s.price,
            u.fullname AS passenger_name, u.email AS passenger_email, u.phone AS passenger_phone,
            bus.bus_code, bus.bus_name, bus.bus_type,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN users u ON b.user_id = u.user_id
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN buses bus ON s.bus_id = bus.bus_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.booking_id = ?
     LIMIT 1",
    'i',
    [$bookingId]
);

if (!$booking) {
    redirect('manage-bookings.php');
}

$passengers = db_select_all(
    'SELECT * FROM passengers WHERE booking_id = ? ORDER BY passenger_id ASC',
    'i',
    [$bookingId]
);
$tickets = db_select_all(
    'SELECT t.*, s.seat_label, p.fullname AS passenger_name, p.email AS passenger_email
     FROM tickets t
     JOIN seats s ON t.seat_id = s.seat_id
     LEFT JOIN passengers p ON t.passenger_id = p.passenger_id
     WHERE t.booking_id = ?
     ORDER BY s.seat_number ASC',
    'i',
    [$bookingId]
);

$usedTicketCount = count(array_filter($tickets, static fn($ticket) => ($ticket['ticket_status'] ?? '') === 'used'));
$missedPaidTrip = booking_is_missed_paid_trip($booking + ['used_ticket_count' => $usedTicketCount]);
$timeline = booking_live_countdown_context($booking + ['used_ticket_count' => $usedTicketCount]);
$effectiveTripStatus = (string) ($timeline['effective_trip_status'] ?? 'scheduled');
$statusLabel = $missedPaidTrip ? 'Missed' : ucwords(str_replace('_', ' ', (string) ($booking['status'] ?? '')));
$statusClass = $missedPaidTrip
    ? 'warning'
    : (in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true)
        ? 'success'
        : (((string) ($booking['status'] ?? '') === 'payment_review' || (string) ($booking['status'] ?? '') === 'pending') ? 'warning' : 'danger'));
$paymentClass = ((string) ($booking['payment_status'] ?? '') === 'paid')
    ? 'success'
    : (((string) ($booking['payment_status'] ?? '') === 'pending') ? 'warning' : 'danger');
$tripChipClass = match ($effectiveTripStatus) {
    'boarding' => 'warning',
    'departed' => 'soft',
    'arrived' => 'success',
    'cancelled' => 'danger',
    default => 'soft',
};
$departureTimestamp = $timeline['departure_timestamp'];
$canChangeSeats = !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
    && $departureTimestamp !== null
    && $departureTimestamp > time();
$canCancel = !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true);
$cashClaimActive = ($booking['payment_method'] ?? '') === 'cash'
    && ($booking['payment_status'] ?? '') !== 'paid'
    && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired'], true)
    && ((string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled');
$cashClaimBundle = $cashClaimActive ? build_cash_claim_payload($booking) : null;
$cashClaimCode = (string) (($cashClaimBundle['claim_code'] ?? '') ?: ($booking['claim_code'] ?? ''));
$preferredSeatLabels = decode_booking_seat_preferences($booking['seat_preferences'] ?? '');
$finalTicketReady = !$missedPaidTrip
    && (string) ($booking['schedule_status'] ?? 'scheduled') !== 'cancelled'
    && ($booking['payment_status'] ?? '') === 'paid'
    && $tickets !== [];

admin_render_header('Booking Details', 'bookings');
admin_page_header('Booking Details', 'Open one booking record, review passengers and tickets, and only manually cancel when needed.');
?>

<div class="alert alert-warning rounded-4">Discount IDs are reviewed manually. Compare the ID with the passenger and follow terminal verification policy; this system does not authenticate IDs against government records.</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<style>
.admin-booking-countdown {
    background: linear-gradient(180deg, #fff7ed, #fff);
    border: 1px solid rgba(251, 146, 60, 0.24);
    border-radius: 1.25rem;
}
.admin-booking-countdown-grid {
    display: grid;
    gap: 0.75rem;
    grid-template-columns: repeat(4, minmax(0, 1fr));
}
.admin-booking-countdown-unit {
    background: #fff;
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1rem;
    padding: 0.95rem 0.7rem;
    text-align: center;
}
.admin-booking-countdown-unit strong {
    display: block;
    font-size: 1.45rem;
    line-height: 1;
}
.admin-booking-countdown-unit span {
    color: var(--admin-muted);
    display: block;
    font-size: 0.76rem;
    font-weight: 600;
    letter-spacing: 0.04em;
    margin-top: 0.4rem;
    text-transform: uppercase;
}
.admin-qr-shell {
    align-items: center;
    background: linear-gradient(180deg, #ffffff, #f8fafc);
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1.25rem;
    display: flex;
    justify-content: center;
    min-height: 200px;
    padding: 1rem;
}
.admin-qr-canvas {
    background: #fff;
    border-radius: 1rem;
    box-shadow: 0 18px 35px rgba(15, 23, 42, 0.12);
    padding: 12px;
}
@media (max-width: 767px) {
    .admin-booking-countdown-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}
</style>

<div class="d-flex flex-wrap gap-2 mb-4">
    <a class="btn btn-outline-secondary" href="manage-bookings.php">
        <i class="fa-solid fa-arrow-left me-2"></i>Back to Bookings
    </a>
    <?php if ($canChangeSeats): ?>
        <a class="btn btn-outline-primary" href="change-seats.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
            <i class="fa-solid fa-chair me-2"></i>Change Seats
        </a>
    <?php endif; ?>
    <?php if ($canCancel): ?>
        <form method="post" onsubmit="return confirm('Cancel this booking?');">
            <?php csrf_field(); ?>
            <input type="hidden" name="action" value="cancel_booking">
            <input type="hidden" name="booking_id" value="<?php echo (int) $booking['booking_id']; ?>">
            <button class="btn btn-outline-danger" type="submit">
                <i class="fa-solid fa-ban me-2"></i>Cancel Booking
            </button>
        </form>
    <?php endif; ?>
</div>

<div class="stats-grid mb-4">
    <div class="stat-tile">
        <span class="label">Reference</span>
        <span class="value" style="font-size:1.15rem;"><?php echo e($booking['booking_reference']); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Booking Status</span>
        <span class="value" style="font-size:1.15rem;"><?php echo e($statusLabel); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Payment</span>
        <span class="value" style="font-size:1.15rem;"><?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['payment_status'] ?? 'pending')))); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Trip Progress</span>
        <span class="value" style="font-size:1.15rem;"><?php echo e(ucfirst($effectiveTripStatus)); ?></span>
    </div>
</div>

<?php if ((bool) ($timeline['is_live'] ?? false)): ?>
    <div class="admin-booking-countdown p-3 p-lg-4 mb-4">
        <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
            <div>
                <div class="small text-uppercase text-muted fw-semibold mb-1"><?php echo e((string) ($timeline['label'] ?? 'Live countdown')); ?></div>
                <div class="fw-semibold"><?php echo e((string) ($timeline['note'] ?? '')); ?></div>
            </div>
            <div class="d-flex flex-wrap gap-2">
                <span class="chip <?php echo e($statusClass); ?>"><?php echo e($statusLabel); ?></span>
                <span class="chip <?php echo e($paymentClass); ?>"><?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['payment_status'] ?? '')))); ?></span>
                <span class="chip <?php echo e($tripChipClass); ?>"><?php echo e(ucfirst($effectiveTripStatus)); ?></span>
            </div>
        </div>
        <div
            class="admin-booking-countdown-grid live-countdown"
            data-countdown-target="<?php echo (int) ($timeline['target_timestamp'] ?? 0); ?>"
            data-expired-label="<?php echo e((string) ($timeline['expired_label'] ?? 'Closed')); ?>"
        >
            <div class="admin-booking-countdown-unit"><strong data-unit="days">00</strong><span>Days</span></div>
            <div class="admin-booking-countdown-unit"><strong data-unit="hours">00</strong><span>Hours</span></div>
            <div class="admin-booking-countdown-unit"><strong data-unit="minutes">00</strong><span>Minutes</span></div>
            <div class="admin-booking-countdown-unit"><strong data-unit="seconds">00</strong><span>Seconds</span></div>
        </div>
    </div>
<?php elseif ((string) ($timeline['note'] ?? '') !== ''): ?>
    <div class="alert alert-light border rounded-4 mb-4"><?php echo e((string) ($timeline['note'] ?? '')); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Trip and Passenger Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="row g-3">
                <div class="col-12">
                    <div class="small text-muted">Passenger</div>
                    <div class="fw-semibold"><?php echo e($booking['passenger_name']); ?></div>
                    <div class="small text-muted"><?php echo e($booking['passenger_email']); ?><?php echo !empty($booking['passenger_phone']) ? ' | ' . e($booking['passenger_phone']) : ''; ?></div>
                </div>
                <div class="col-12">
                    <div class="small text-muted">Route</div>
                    <div class="fw-semibold"><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Travel Date</div>
                    <div class="fw-semibold"><?php echo date('F j, Y', strtotime((string) $booking['departure_date'])); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Departure</div>
                    <div class="fw-semibold"><?php echo date('g:i A', strtotime((string) $booking['departure_time'])); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Arrival</div>
                    <div class="fw-semibold"><?php echo date('g:i A', strtotime((string) $booking['arrival_time'])); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Bus</div>
                    <div class="fw-semibold"><?php echo e($booking['bus_name'] ?: $booking['bus_code']); ?><?php echo $booking['bus_type'] ? ' | ' . e($booking['bus_type']) : ''; ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Passengers</div>
                    <div class="fw-semibold"><?php echo number_format((int) ($booking['number_of_passengers'] ?? 0)); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Amount</div>
                    <div class="fw-semibold text-danger">PHP <?php echo number_format((float) ($booking['total_amount'] ?? 0), 2); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $cashClaimActive ? 'Terminal Cash Ticket' : 'Ticket State'; ?></h2>
        </div>
        <div class="admin-card-body">
            <?php if ($cashClaimActive && $cashClaimBundle): ?>
                <div class="small text-muted">Cash Ticket Code</div>
                <div class="fw-semibold"><?php echo e($cashClaimCode !== '' ? $cashClaimCode : 'Pending code'); ?></div>
                <div class="small text-muted mt-3">Preferred Seats</div>
                <div class="fw-semibold"><?php echo e($preferredSeatLabels !== [] ? implode(', ', $preferredSeatLabels) : 'Seat will be assigned at the terminal'); ?></div>
                <div class="small text-muted mt-3">Terminal Payment</div>
                <div class="fw-semibold">Pending before departure</div>
                <div class="admin-qr-shell mt-3">
                    <div class="admin-qr-canvas qr-canvas" data-qr="<?php echo e($cashClaimBundle['qr_text']); ?>"></div>
                </div>
            <?php elseif ($finalTicketReady): ?>
                <div class="small text-muted">Ticket State</div>
                <div class="fw-semibold">Ready for QR scan</div>
                <div class="small text-muted mt-2">Issued tickets: <?php echo number_format(count($tickets)); ?></div>
            <?php else: ?>
                <div class="small text-muted">Ticket State</div>
                <div class="fw-semibold">Pending confirmation</div>
                <div class="small text-muted mt-2">Use Payments or QR Scanner for confirmation workflow.</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="row g-4 mt-1">
    <div class="col-lg-5">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Passengers</h2>
            </div>
            <div class="admin-card-body">
                <?php if ($passengers === []): ?>
                    <p class="text-muted mb-0">Passenger records are not available yet.</p>
                <?php else: ?>
                    <div class="d-grid gap-3">
                        <?php foreach ($passengers as $passenger): ?>
                            <div class="border rounded-4 p-3">
                                <div class="fw-semibold"><?php echo e($passenger['fullname']); ?></div>
                                <div class="small text-muted"><?php echo e($passenger['email']); ?></div>
                                <div class="small text-muted"><?php echo e($passenger['phone']); ?></div>
                                <div class="small mt-2">Seat: <strong><?php echo e($passenger['seat_number']); ?></strong></div>
                                <?php if (!empty($passenger['id_type'])): ?>
                                    <?php $discountStatus = (string) ($passenger['discount_status'] ?? 'pending'); ?>
                                    <div class="small mt-2">Discount ID: <strong><?php echo e($passenger['id_type']); ?></strong></div>
                                    <div class="small">Review: <strong><?php echo e(ucfirst($discountStatus)); ?></strong><?php if ($discountStatus === 'approved'): ?> · <?php echo number_format((float) $passenger['discount_percentage'], 2); ?>%<?php endif; ?></div>
                                    <?php if ($discountStatus === 'approved'): ?>
                                        <div class="small">Cash discount: <strong>PHP <?php echo number_format((float) $passenger['discount_cash_amount'], 2); ?></strong> · <?php echo e(ucfirst((string) $passenger['discount_cash_status'])); ?></div>
                                    <?php endif; ?>
                                    <?php if (!empty($passenger['id_proof_path'])): ?>
                                        <a class="btn btn-sm btn-outline-secondary mt-2" href="discount-id-proof.php?passenger_id=<?php echo (int) $passenger['passenger_id']; ?>" target="_blank" rel="noopener">
                                            <i class="fa-solid fa-id-card me-1"></i>View ID proof
                                        </a>
                                    <?php endif; ?>
                                    <?php if ($discountStatus === 'pending' && ($booking['payment_status'] ?? '') === 'paid'): ?>
                                        <div class="d-flex flex-wrap gap-2 mt-2">
                                            <?php foreach (['approve' => 'Approve cash discount', 'reject' => 'Decline'] as $decision => $label): ?>
                                                <form method="post">
                                                    <?php csrf_field(); ?>
                                                    <input type="hidden" name="action" value="review_discount">
                                                    <input type="hidden" name="booking_id" value="<?php echo (int) $bookingId; ?>">
                                                    <input type="hidden" name="passenger_id" value="<?php echo (int) $passenger['passenger_id']; ?>">
                                                    <input type="hidden" name="decision" value="<?php echo e($decision); ?>">
                                                    <button class="btn btn-sm <?php echo $decision === 'approve' ? 'btn-success' : 'btn-outline-danger'; ?>" type="submit"><?php echo e($label); ?></button>
                                                </form>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php elseif ($discountStatus === 'pending'): ?>
                                        <div class="small text-muted mt-2">ID review opens after PayMongo confirms payment.</div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Tickets</h2>
            </div>
            <div class="admin-card-body">
                <?php if ($tickets === []): ?>
                    <p class="text-muted mb-0">No tickets have been issued yet.</p>
                <?php else: ?>
                    <div class="d-grid gap-3">
                        <?php foreach ($tickets as $ticket): ?>
                            <?php
                            $qrText = (string) ($ticket['ticket_code'] ?? '');
                            if ($qrText === '' && !empty($ticket['qr_payload']) && !empty($ticket['qr_signature'])) {
                                $qrText = json_encode(['payload' => $ticket['qr_payload'], 'sig' => $ticket['qr_signature']], JSON_UNESCAPED_SLASHES);
                            }
                            ?>
                            <div class="border rounded-4 p-3">
                                <div class="row g-3 align-items-center">
                                    <div class="col-md-8">
                                        <div class="small text-muted">Ticket Code</div>
                                        <div class="fw-semibold"><?php echo e($ticket['ticket_code'] ?: 'Pending issuance'); ?></div>
                                        <div class="small text-muted mt-2">Passenger</div>
                                        <div class="fw-semibold"><?php echo e($ticket['passenger_name'] ?: 'Passenger pending'); ?></div>
                                        <div class="small text-muted mt-2">Seat</div>
                                        <div class="fw-semibold"><?php echo e($ticket['seat_label']); ?></div>
                                        <div class="small text-muted mt-2">Ticket Status</div>
                                        <div class="fw-semibold text-uppercase"><?php echo e((string) ($ticket['ticket_status'] ?? 'pending')); ?></div>
                                    </div>
                                    <div class="col-md-4 text-center">
                                        <?php if ($qrText !== '' && $finalTicketReady): ?>
                                            <div class="admin-qr-shell">
                                                <div class="admin-qr-canvas qr-canvas" data-qr="<?php echo e($qrText); ?>"></div>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted">QR will appear after confirmation.</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.qr-canvas').forEach(function (node) {
        const qrText = node.dataset.qr;
        if (!qrText) {
            return;
        }

        node.innerHTML = '';
        new QRCode(node, {
            text: qrText,
            width: 156,
            height: 156,
            colorDark: '#10203b',
            colorLight: '#ffffff',
            correctLevel: QRCode.CorrectLevel.M
        });
    });

    const countdowns = Array.from(document.querySelectorAll('.live-countdown'));
    if (countdowns.length === 0) {
        return;
    }

    function updateCountdown(node) {
        const targetSeconds = Number(node.dataset.countdownTarget || '0');
        const targetMillis = targetSeconds * 1000;
        const remaining = Math.max(0, targetMillis - Date.now());
        const totalSeconds = Math.floor(remaining / 1000);
        const days = Math.floor(totalSeconds / 86400);
        const hours = Math.floor((totalSeconds % 86400) / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
        const values = {
            days: String(days).padStart(2, '0'),
            hours: String(hours).padStart(2, '0'),
            minutes: String(minutes).padStart(2, '0'),
            seconds: String(seconds).padStart(2, '0')
        };

        Object.keys(values).forEach(function (key) {
            const target = node.querySelector('[data-unit="' + key + '"]');
            if (target) {
                target.textContent = values[key];
            }
        });
    }

    function tickAll() {
        countdowns.forEach(updateCountdown);
    }

    tickAll();
    window.setInterval(tickAll, 1000);
});
</script>

<?php admin_render_footer(); ?>
