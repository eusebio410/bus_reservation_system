<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$faqId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');

if ($action === 'delete' && $faqId > 0) {
    if (db_execute('DELETE FROM faqs WHERE faq_id = ?', 'i', [$faqId])) {
        set_flash('success', 'FAQ entry deleted successfully.');
        redirect('manage-faq.php');
    } else {
        $error = 'Unable to delete the FAQ entry.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['faq_id'] ?? 0);
    $category = isset_post('category');
    $question = isset_post('question');
    $answer = isset_post('answer');

    if ($category === '' || $question === '' || $answer === '') {
        $error = 'Category, question, and answer are required.';
    } else {
        if ($editId > 0) {
            $ok = db_execute(
                'UPDATE faqs SET category = ?, question = ?, answer = ? WHERE faq_id = ?',
                'sssi',
                [$category, $question, $answer, $editId]
            );
            $message = 'FAQ entry updated successfully.';
        } else {
            $ok = db_execute(
                'INSERT INTO faqs (category, question, answer) VALUES (?, ?, ?)',
                'sss',
                [$category, $question, $answer]
            );
            $message = 'FAQ entry added successfully.';
        }

        if ($ok) {
            set_flash('success', $message);
            redirect('manage-faq.php');
        }

        $error = 'Unable to save the FAQ entry.';
    }
}

$editFaq = null;
if ($action === 'edit' && $faqId > 0) {
    $editFaq = db_select_one('SELECT * FROM faqs WHERE faq_id = ? LIMIT 1', 'i', [$faqId]);
}

$faqs = db_select_all('SELECT * FROM faqs ORDER BY category ASC, faq_id ASC');
$faqCount = count($faqs);
$categoryNames = array_values(array_unique(array_filter(array_map(
    static fn($faq) => trim((string) ($faq['category'] ?? '')),
    $faqs
))));
sort($categoryNames);
$categoryCount = count($categoryNames);

$defaultCategories = ['Booking', 'Baggage', 'Travel', 'Refund', 'Accessibility', 'General'];
$categorySuggestions = array_values(array_unique(array_merge($defaultCategories, $categoryNames)));
sort($categorySuggestions);

admin_render_header('FAQ Management', 'faq');
admin_page_header(
    'FAQ Management',
    'Manage the FAQ content shown on the public support page used by passengers.',
    [
        ['label' => 'Preview Public FAQ', 'href' => '../../faq.php', 'icon' => 'fa-arrow-up-right-from-square', 'class' => 'btn-outline-secondary'],
    ]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editFaq ? 'Edit FAQ Entry' : 'Add FAQ Entry'; ?></h2>
        </div>
        <div class="admin-card-body">
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="faq_id" value="<?php echo (int) ($editFaq['faq_id'] ?? 0); ?>">
                <div class="col-12">
                    <label class="form-label" for="category">Category</label>
                    <input class="form-control" type="text" id="category" name="category" list="faq-categories" value="<?php echo e($editFaq['category'] ?? ''); ?>" placeholder="Booking" required>
                    <datalist id="faq-categories">
                        <?php foreach ($categorySuggestions as $categoryOption): ?>
                            <option value="<?php echo e($categoryOption); ?>">
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="col-12">
                    <label class="form-label" for="question">Question</label>
                    <input class="form-control" type="text" id="question" name="question" value="<?php echo e($editFaq['question'] ?? ''); ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label" for="answer">Answer</label>
                    <textarea class="form-control" id="answer" name="answer" rows="6" required><?php echo e($editFaq['answer'] ?? ''); ?></textarea>
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editFaq ? 'Update FAQ Entry' : 'Add FAQ Entry'; ?></button>
                    <?php if ($editFaq): ?>
                        <a class="btn btn-outline-secondary" href="manage-faq.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>FAQ Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Total Entries</span>
                    <span class="value"><?php echo number_format($faqCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Categories</span>
                    <span class="value"><?php echo number_format($categoryCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Visible To Users</span>
                    <span class="value"><?php echo number_format($faqCount); ?></span>
                    <span class="hint">This page updates the public FAQ page directly.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>FAQ Library</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Question</th>
                        <th>Answer Preview</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($faqs === []): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">No FAQ entries found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($faqs as $faq): ?>
                            <tr>
                                <td><span class="chip soft"><?php echo e($faq['category'] ?: 'General'); ?></span></td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($faq['question']); ?></div>
                                </td>
                                <td class="text-muted">
                                    <?php
                                    $answerPreview = trim((string) ($faq['answer'] ?? ''));
                                    echo e(strlen($answerPreview) > 120 ? substr($answerPreview, 0, 120) . '...' : $answerPreview);
                                    ?>
                                </td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-faq.php?action=edit&id=<?php echo (int) $faq['faq_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-faq.php?action=delete&id=<?php echo (int) $faq['faq_id']; ?>" onclick="return confirm('Delete this FAQ entry?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
