<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$operatorId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');
$currentUserId = (int) ($_SESSION['user_id'] ?? 0);

if ($action === 'delete' && $operatorId > 0) {
    $operatorForAudit = db_select_one(
        'SELECT operator_id, full_name FROM bus_operators WHERE operator_id = ? LIMIT 1',
        'i',
        [$operatorId]
    );
    $assignedSchedules = db_select_one(
        'SELECT COUNT(*) AS total FROM schedules WHERE operator_id = ?',
        'i',
        [$operatorId]
    );

    if (!$operatorForAudit) {
        $error = 'The selected bus operator could not be found.';
    } elseif ((int) ($assignedSchedules['total'] ?? 0) > 0) {
        $error = 'This bus operator is assigned to schedules. Reassign those trips or mark the operator inactive instead.';
    } elseif (db_execute('DELETE FROM bus_operators WHERE operator_id = ?', 'i', [$operatorId])) {
        create_audit_log(
            $currentUserId,
            'operator.deleted',
            'bus_operator',
            $operatorId,
            'Bus operator removed from the directory.',
            ['full_name' => (string) ($operatorForAudit['full_name'] ?? '')]
        );
        set_flash('success', 'Bus operator removed successfully.');
        redirect('manage-operators.php');
    } else {
        $error = 'Unable to remove the selected bus operator.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['operator_id'] ?? 0);
    $fullName = isset_post('full_name');
    $rawContactNumber = isset_post('contact_number');
    $contactNumber = $rawContactNumber === '' ? '' : normalize_ph_phone($rawContactNumber);
    $licenseNumber = strtoupper(isset_post('license_number'));
    $status = isset_post('status') === 'inactive' ? 'inactive' : 'active';

    if ($fullName === '') {
        $error = 'Please enter the bus operator’s full name.';
    } elseif (strlen($fullName) > 120) {
        $error = 'The bus operator name must be 120 characters or fewer.';
    } elseif ($rawContactNumber !== '' && $contactNumber === '') {
        $error = 'Please use a valid Philippine mobile number, such as 09171234567 or +639171234567.';
    } elseif (strlen($licenseNumber) > 60) {
        $error = 'The license number must be 60 characters or fewer.';
    }

    if ($error === '' && $licenseNumber !== '') {
        $duplicate = db_select_one(
            'SELECT operator_id FROM bus_operators WHERE license_number = ? AND operator_id <> ? LIMIT 1',
            'si',
            [$licenseNumber, $editId]
        );

        if ($duplicate) {
            $error = 'That license number is already assigned to another bus operator.';
        }
    }

    if ($error === '') {
        if ($editId > 0) {
            $ok = db_execute(
                'UPDATE bus_operators
                 SET full_name = ?, contact_number = NULLIF(?, ""), license_number = NULLIF(?, ""), status = ?
                 WHERE operator_id = ?',
                'ssssi',
                [$fullName, $contactNumber, $licenseNumber, $status, $editId]
            );
            $savedOperatorId = $editId;
            $message = 'Bus operator updated successfully.';
            $auditAction = 'operator.updated';
            $auditDescription = 'Bus operator details updated in the driver directory.';
        } else {
            $ok = db_execute(
                'INSERT INTO bus_operators (full_name, contact_number, license_number, status)
                 VALUES (?, NULLIF(?, ""), NULLIF(?, ""), ?)',
                'ssss',
                [$fullName, $contactNumber, $licenseNumber, $status]
            );
            $savedOperatorId = db_last_insert_id();
            $message = 'Bus operator added successfully.';
            $auditAction = 'operator.created';
            $auditDescription = 'New bus operator added to the driver directory.';
        }

        if ($ok) {
            create_audit_log(
                $currentUserId,
                $auditAction,
                'bus_operator',
                $savedOperatorId,
                $auditDescription,
                [
                    'full_name' => $fullName,
                    'license_number' => $licenseNumber,
                    'status' => $status,
                ]
            );
            set_flash('success', $message);
            redirect('manage-operators.php');
        }

        $error = 'Unable to save the bus operator.';
    }
}

$editOperator = null;
if ($action === 'edit' && $operatorId > 0) {
    $editOperator = db_select_one(
        'SELECT * FROM bus_operators WHERE operator_id = ? LIMIT 1',
        'i',
        [$operatorId]
    );
}

$operators = db_select_all(
    "SELECT bo.*, COUNT(s.schedule_id) AS schedule_count,
            MIN(CASE WHEN s.status = 'scheduled' AND TIMESTAMP(s.departure_date, s.departure_time) > NOW()
                THEN TIMESTAMP(s.departure_date, s.departure_time) END) AS next_departure
     FROM bus_operators bo
     LEFT JOIN schedules s ON s.operator_id = bo.operator_id
     GROUP BY bo.operator_id
     ORDER BY FIELD(bo.status, 'active', 'inactive'), bo.full_name ASC"
);

$activeCount = count(array_filter($operators, static fn(array $operator): bool => ($operator['status'] ?? '') === 'active'));
$assignedCount = count(array_filter($operators, static fn(array $operator): bool => (int) ($operator['schedule_count'] ?? 0) > 0));
$upcomingCount = count(array_filter($operators, static fn(array $operator): bool => !empty($operator['next_departure'])));

admin_render_header('Bus Operator Management', 'operators');
admin_page_header('Bus Operator Management', 'Keep a clear driver directory, assign each trip with confidence, and prevent double-booking a driver.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <div>
                <h2><?php echo $editOperator ? 'Edit Bus Operator' : 'Add Bus Operator'; ?></h2>
                <div class="admin-list-meta">A bus operator is the person assigned to drive a specific scheduled trip.</div>
            </div>
            <span class="chip soft"><i class="fa-solid fa-steering-wheel me-1"></i>Driver record</span>
        </div>
        <div class="admin-card-body">
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="operator_id" value="<?php echo (int) ($editOperator['operator_id'] ?? 0); ?>">
                <div class="col-12">
                    <label class="form-label" for="full_name">Full Name</label>
                    <input class="form-control" type="text" id="full_name" name="full_name" value="<?php echo e($editOperator['full_name'] ?? ''); ?>" placeholder="e.g. Juan Dela Cruz" maxlength="120" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="contact_number">Contact Number <span class="text-muted">(admin only)</span></label>
                    <input class="form-control" type="tel" id="contact_number" name="contact_number" value="<?php echo e($editOperator['contact_number'] ?? ''); ?>" placeholder="09171234567" maxlength="20">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="license_number">License Number <span class="text-muted">(admin only)</span></label>
                    <input class="form-control text-uppercase" type="text" id="license_number" name="license_number" value="<?php echo e($editOperator['license_number'] ?? ''); ?>" maxlength="60">
                </div>
                <div class="col-12">
                    <label class="form-label" for="status">Availability</label>
                    <select class="form-select" id="status" name="status">
                        <option value="active" <?php echo ($editOperator['status'] ?? 'active') === 'active' ? 'selected' : ''; ?>>Active — available for schedule assignment</option>
                        <option value="inactive" <?php echo ($editOperator['status'] ?? '') === 'inactive' ? 'selected' : ''; ?>>Inactive — keep record, prevent new assignment</option>
                    </select>
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editOperator ? 'Update Operator' : 'Add Operator'; ?></button>
                    <?php if ($editOperator): ?>
                        <a class="btn btn-outline-secondary" href="manage-operators.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <div>
                <h2>Driver Coverage</h2>
                <div class="admin-list-meta">A quick view of who is ready to be assigned before you create the next departure.</div>
            </div>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Active Drivers</span>
                    <span class="value"><?php echo number_format($activeCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">With Schedules</span>
                    <span class="value"><?php echo number_format($assignedCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Upcoming Trips</span>
                    <span class="value"><?php echo number_format($upcomingCount); ?></span>
                </div>
            </div>
            <div class="alert alert-info rounded-4 mt-4 mb-0 small">
                Contact and license details stay in this admin directory. Passengers only see the operator’s name on their own trip schedule.
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <div>
            <h2>Operator Directory</h2>
            <div class="admin-list-meta">Assign active operators from the schedule editor. Inactive operators remain here for record keeping.</div>
        </div>
        <span class="chip soft"><?php echo number_format(count($operators)); ?> total</span>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Bus Operator</th>
                        <th>Contact</th>
                        <th>License</th>
                        <th>Schedules</th>
                        <th>Availability</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($operators === []): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No bus operators added yet. Add a driver, then assign them while creating a schedule.</td></tr>
                    <?php else: ?>
                        <?php foreach ($operators as $operator): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><i class="fa-solid fa-steering-wheel text-primary me-2" aria-hidden="true"></i><?php echo e($operator['full_name']); ?></div>
                                    <?php if (!empty($operator['next_departure'])): ?>
                                        <div class="small text-muted">Next trip: <?php echo date('M j, g:i A', strtotime((string) $operator['next_departure'])); ?></div>
                                    <?php else: ?>
                                        <div class="small text-muted">No upcoming trip assigned</div>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($operator['contact_number'] ?: '—'); ?></td>
                                <td><?php echo e($operator['license_number'] ?: '—'); ?></td>
                                <td><span class="chip soft"><?php echo number_format((int) $operator['schedule_count']); ?> trip<?php echo (int) $operator['schedule_count'] === 1 ? '' : 's'; ?></span></td>
                                <td><span class="chip <?php echo ($operator['status'] ?? '') === 'active' ? 'success' : 'warning'; ?>"><?php echo e(ucfirst((string) $operator['status'])); ?></span></td>
                                <td>
                                    <div class="admin-inline-actions">
                                        <a class="btn btn-sm btn-outline-secondary" href="manage-operators.php?action=edit&id=<?php echo (int) $operator['operator_id']; ?>">Edit</a>
                                        <a class="btn btn-sm btn-outline-danger" href="manage-operators.php?action=delete&id=<?php echo (int) $operator['operator_id']; ?>" onclick="return confirm('Remove this bus operator?');">Remove</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
