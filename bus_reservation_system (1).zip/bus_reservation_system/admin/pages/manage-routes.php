<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$routeId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');

if ($action === 'delete' && $routeId > 0) {
    $result = db_execute('DELETE FROM routes WHERE route_id = ?', 'i', [$routeId]);
    if ($result) {
        set_flash('success', 'Route deleted successfully.');
        redirect('manage-routes.php');
    }
    $error = 'Unable to delete that route. Remove related schedules or fares first.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['route_id'] ?? 0);
    $originTerminalId = (int) ($_POST['origin_terminal_id'] ?? 0);
    $destinationTerminalId = (int) ($_POST['destination_terminal_id'] ?? 0);
    $distance = $_POST['distance'] !== '' ? round((float) $_POST['distance'], 2) : 0;
    $travelTime = (int) ($_POST['travel_time'] ?? 0);

    if ($originTerminalId < 1 || $destinationTerminalId < 1) {
        $error = 'Please choose both origin and destination terminals.';
    } elseif ($originTerminalId === $destinationTerminalId) {
        $error = 'Origin and destination must be different.';
    } elseif ($travelTime < 1) {
        $error = 'Travel time must be at least 1 minute.';
    } else {
        $duplicate = db_select_one(
            'SELECT route_id FROM routes WHERE origin_terminal_id = ? AND destination_terminal_id = ? AND route_id <> ? LIMIT 1',
            'iii',
            [$originTerminalId, $destinationTerminalId, $editId]
        );

        if ($duplicate) {
            $error = 'That route already exists.';
        } else {
            if ($editId > 0) {
                $ok = db_execute(
                    'UPDATE routes SET origin_terminal_id = ?, destination_terminal_id = ?, distance = ?, travel_time = ? WHERE route_id = ?',
                    'iidii',
                    [$originTerminalId, $destinationTerminalId, $distance, $travelTime, $editId]
                );
                $message = 'Route updated successfully.';
            } else {
                $ok = db_execute(
                    'INSERT INTO routes (origin_terminal_id, destination_terminal_id, distance, travel_time) VALUES (?, ?, ?, ?)',
                    'iidi',
                    [$originTerminalId, $destinationTerminalId, $distance, $travelTime]
                );
                $message = 'Route added successfully.';
            }

            if ($ok) {
                set_flash('success', $message);
                redirect('manage-routes.php');
            }

            $error = 'Unable to save the route.';
        }
    }
}

$editRoute = null;
if ($action === 'edit' && $routeId > 0) {
    $editRoute = db_select_one(
        'SELECT r.*, origin.terminal_name AS origin_terminal_name, destination.terminal_name AS destination_terminal_name
         FROM routes r
         JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
         JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
         WHERE r.route_id = ?
         LIMIT 1',
        'i',
        [$routeId]
    );
}

$terminals = db_select_all('SELECT terminal_id, terminal_name, location FROM terminals ORDER BY terminal_name ASC');
$routes = db_select_all(
    "SELECT r.*, origin.terminal_name AS origin_name, origin.location AS origin_location,
            destination.terminal_name AS destination_name, destination.location AS destination_location,
            COUNT(DISTINCT s.schedule_id) AS schedule_count
     FROM routes r
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     LEFT JOIN schedules s ON s.route_id = r.route_id
     GROUP BY r.route_id
     ORDER BY origin.terminal_name ASC, destination.terminal_name ASC"
);

admin_render_header('Route Management', 'routes');
admin_page_header('Route Management', 'Create origin-destination pairs, enforce duplicates protection, and monitor route demand.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editRoute ? 'Edit Route' : 'Add Route'; ?></h2>
        </div>
        <div class="admin-card-body">
            <?php if (!$editRoute): ?>
                <div class="alert alert-info rounded-4 mb-3">
                    Add routes by selecting an existing origin and destination terminal from the list.
                </div>
            <?php endif; ?>
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="route_id" value="<?php echo (int) ($editRoute['route_id'] ?? 0); ?>">
                <div class="col-12">
                    <label class="form-label" for="origin_terminal_id">Origin Terminal</label>
                    <select class="form-select" id="origin_terminal_id" name="origin_terminal_id" required>
                        <option value="">Select origin</option>
                        <?php foreach ($terminals as $terminal): ?>
                            <option value="<?php echo (int) $terminal['terminal_id']; ?>" <?php echo ((int) ($editRoute['origin_terminal_id'] ?? 0) === (int) $terminal['terminal_id']) ? 'selected' : ''; ?>>
                                <?php echo e($terminal['terminal_name'] . ' - ' . $terminal['location']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label" for="destination_terminal_id">Destination Terminal</label>
                    <select class="form-select" id="destination_terminal_id" name="destination_terminal_id" required>
                        <option value="">Select destination</option>
                        <?php foreach ($terminals as $terminal): ?>
                            <option value="<?php echo (int) $terminal['terminal_id']; ?>" <?php echo ((int) ($editRoute['destination_terminal_id'] ?? 0) === (int) $terminal['terminal_id']) ? 'selected' : ''; ?>>
                                <?php echo e($terminal['terminal_name'] . ' - ' . $terminal['location']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="distance">Distance (km)</label>
                    <input class="form-control" type="number" step="0.01" min="0" id="distance" name="distance" value="<?php echo e($editRoute['distance'] ?? ''); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="travel_time">Travel Time (minutes)</label>
                    <input class="form-control" type="number" min="1" id="travel_time" name="travel_time" value="<?php echo e($editRoute['travel_time'] ?? ''); ?>" required>
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editRoute ? 'Update Route' : 'Add Route'; ?></button>
                    <?php if ($editRoute): ?>
                        <a class="btn btn-outline-secondary" href="manage-routes.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Route Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Total Routes</span>
                    <span class="value"><?php echo number_format(count($routes)); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">With Schedules</span>
                    <span class="value"><?php echo number_format(count(array_filter($routes, static fn($route) => (int) $route['schedule_count'] > 0))); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Longest Route</span>
                    <span class="value"><?php echo number_format((float) max(array_map(static fn($route) => (float) $route['distance'], $routes ?: [['distance' => 0]])), 0); ?></span>
                    <span class="hint">Kilometers</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Route Registry</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Route</th>
                        <th>Distance</th>
                        <th>Travel Time</th>
                        <th>Schedules</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($routes === []): ?>
                        <tr><td colspan="5" class="text-center text-muted py-4">No routes configured yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($routes as $route): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($route['origin_name']); ?> to <?php echo e($route['destination_name']); ?></div>
                                    <div class="small text-muted"><?php echo e($route['origin_location']); ?> → <?php echo e($route['destination_location']); ?></div>
                                </td>
                                <td><?php echo number_format((float) $route['distance'], 0); ?> km</td>
                                <td><?php echo number_format((int) $route['travel_time']); ?> mins</td>
                                <td><span class="chip soft"><?php echo number_format((int) $route['schedule_count']); ?></span></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-routes.php?action=edit&id=<?php echo (int) $route['route_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-routes.php?action=delete&id=<?php echo (int) $route['route_id']; ?>" onclick="return confirm('Delete this route?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
