<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$error = '';
$success = consume_flash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset_post('action');

    if ($action === 'clear_history') {
        $result = clear_admin_booking_history();
        if ($result['ok']) {
            set_flash('success', $result['message']);
            redirect('manage-bookings.php');
        }
        $error = $result['message'];
    } elseif ($action === 'cancel_booking') {
        $bookingId = (int) ($_POST['booking_id'] ?? 0);
        if ($bookingId < 1) {
            $error = 'Invalid booking selection.';
        } else {
            $result = cancel_booking_by_admin($bookingId);
            if ($result['ok']) {
                set_flash('success', $result['message']);
                redirect('manage-bookings.php');
            }
            $error = $result['message'];
        }
    }
}

$filterDate = isset_get('date');
$filterStatus = isset_get('status');
$filterRoute = (int) isset_get('route_id');

$sql = "SELECT b.*, u.fullname AS passenger_name, u.email AS passenger_email,
               s.status AS schedule_status, s.departure_date, s.departure_time, s.arrival_time,
               origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
        FROM bookings b
        JOIN users u ON b.user_id = u.user_id
        JOIN schedules s ON b.schedule_id = s.schedule_id
        JOIN routes r ON s.route_id = r.route_id
        JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
        JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
        WHERE 1 = 1";
$types = '';
$params = [];

if ($filterDate !== '') {
    $sql .= ' AND s.departure_date = ?';
    $types .= 's';
    $params[] = $filterDate;
}
if ($filterStatus !== '') {
    $sql .= ' AND b.status = ?';
    $types .= 's';
    $params[] = $filterStatus;
}
if ($filterRoute > 0) {
    $sql .= ' AND r.route_id = ?';
    $types .= 'i';
    $params[] = $filterRoute;
}

$sql .= ' ORDER BY b.booking_date DESC';
$bookings = db_select_all($sql, $types, $params);

$routes = db_select_all(
    "SELECT r.route_id, origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
     FROM routes r
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     ORDER BY origin.terminal_name ASC, destination.terminal_name ASC"
);

$activeCount = 0;
$pendingActionCount = 0;
$cancelledCount = 0;
$confirmedCount = 0;
$todayBookingCount = 0;
$cashQueueCount = 0;
foreach ($bookings as $booking) {
    if (in_array((string) ($booking['status'] ?? ''), ['pending', 'payment_review', 'confirmed'], true)) {
        $activeCount++;
    }
    if (
        (string) ($booking['payment_status'] ?? '') !== 'paid'
        && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
    ) {
        $pendingActionCount++;
    }
    if ((string) ($booking['status'] ?? '') === 'cancelled') {
        $cancelledCount++;
    }
    if ((string) ($booking['status'] ?? '') === 'confirmed') {
        $confirmedCount++;
    }
    if (substr((string) ($booking['booking_date'] ?? ''), 0, 10) === date('Y-m-d')) {
        $todayBookingCount++;
    }
    if (
        (string) ($booking['payment_method'] ?? '') === 'cash'
        && (string) ($booking['payment_status'] ?? '') !== 'paid'
        && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
    ) {
        $cashQueueCount++;
    }
}

$activeFilterCount = 0;
$filterSummaryParts = [];
if ($filterDate !== '') {
    $activeFilterCount++;
    $filterSummaryParts[] = 'Departure ' . date('M j, Y', strtotime($filterDate));
}
if ($filterRoute > 0) {
    $activeFilterCount++;
    foreach ($routes as $route) {
        if ((int) $route['route_id'] === $filterRoute) {
            $filterSummaryParts[] = $route['origin_name'] . ' to ' . $route['destination_name'];
            break;
        }
    }
}
if ($filterStatus !== '') {
    $activeFilterCount++;
    $filterSummaryParts[] = ucwords(str_replace('_', ' ', $filterStatus));
}
$filterSummary = $filterSummaryParts === []
    ? 'Showing all bookings across every route and departure window.'
    : 'Focused on ' . implode(' • ', $filterSummaryParts) . '.';

admin_render_header('Booking Management', 'bookings');
admin_page_header(
    'Booking Management',
    'Review booking details, open the dedicated view page, and manually handle cancellation only. Payment confirmation and ticket issuance stay in Payments or QR Scanner.',
    [
        ['label' => 'Review Payments', 'href' => 'manage-payments.php', 'icon' => 'fa-wallet', 'class' => 'btn btn-outline-secondary'],
        ['label' => 'Open Scanner', 'href' => 'ticket-scanner.php', 'icon' => 'fa-qrcode', 'class' => 'btn btn-outline-secondary'],
    ]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-toolbar-card">
    <div class="admin-toolbar-grid">
        <div class="admin-toolbar-copy">
            <span class="admin-toolbar-eyebrow">Booking Queue</span>
            <h2>Passenger activity and trip actions</h2>
            <p><?php echo e($filterSummary); ?> Use this view when you need one fast board for seat changes, payment follow-up, and manual cancellation decisions.</p>
        </div>
        <div class="admin-toolbar-actions">
            <a class="btn btn-outline-light" href="manage-payments.php">
                <i class="fa-solid fa-wallet me-1"></i>Payment Queue
            </a>
            <a class="btn btn-outline-light" href="ticket-scanner.php">
                <i class="fa-solid fa-qrcode me-1"></i>QR Scanner
            </a>
            <form method="post" onsubmit="return confirm('Clear old cancelled, expired, and used booking history from the operations list?');">
                <?php csrf_field(); ?>
                <input type="hidden" name="action" value="clear_history">
                <button class="btn btn-outline-light" type="submit">
                    <i class="fa-solid fa-trash-can me-1"></i>Clear Old History
                </button>
            </form>
        </div>
    </div>
</div>

<div class="admin-metric-grid">
    <div class="admin-metric-card">
        <span class="admin-metric-label">Filtered Bookings</span>
        <span class="admin-metric-value"><?php echo number_format(count($bookings)); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($todayBookingCount); ?> booking records were created today.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Active Queue</span>
        <span class="admin-metric-value"><?php echo number_format($activeCount); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($confirmedCount); ?> are already confirmed and ready for final operations.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Need Payment Action</span>
        <span class="admin-metric-value"><?php echo number_format($pendingActionCount); ?></span>
        <span class="admin-metric-copy"><?php echo number_format($cashQueueCount); ?> of them are still waiting for terminal cash confirmation.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Cancelled Or Closed</span>
        <span class="admin-metric-value"><?php echo number_format($cancelledCount); ?></span>
        <span class="admin-metric-copy">Use Clear Old History once the legacy queue no longer needs to stay visible.</span>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <div>
            <h2>Filter Queue</h2>
            <div class="admin-list-meta">Focus the board by departure date, route, or booking status when the queue gets busy.</div>
        </div>
        <span class="chip soft"><?php echo number_format($activeFilterCount); ?> active filters</span>
    </div>
    <div class="admin-card-body">
        <form method="get" class="row g-3">
            <div class="col-md-4">
                <label class="form-label" for="date">Departure Date</label>
                <input class="form-control" type="date" id="date" name="date" value="<?php echo e($filterDate); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="route_id">Route</label>
                <select class="form-select" id="route_id" name="route_id">
                    <option value="">All routes</option>
                    <?php foreach ($routes as $route): ?>
                        <option value="<?php echo (int) $route['route_id']; ?>" <?php echo $filterRoute === (int) $route['route_id'] ? 'selected' : ''; ?>>
                            <?php echo e($route['origin_name'] . ' to ' . $route['destination_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="status">Booking Status</label>
                <select class="form-select" id="status" name="status">
                    <option value="">All statuses</option>
                    <?php foreach (['pending', 'payment_review', 'confirmed', 'cancelled', 'expired', 'used'] as $statusOption): ?>
                        <option value="<?php echo e($statusOption); ?>" <?php echo $filterStatus === $statusOption ? 'selected' : ''; ?>>
                            <?php echo e(ucwords(str_replace('_', ' ', $statusOption))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 d-flex gap-2">
                <button class="btn btn-accent" type="submit">Apply Filters</button>
                <a class="btn btn-outline-secondary" href="manage-bookings.php">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h2>Passenger Booking Board</h2>
            <div class="admin-list-meta">Each row keeps the passenger, trip, payment state, and next action visible without opening another page first.</div>
        </div>
        <span class="chip soft"><?php echo number_format(count($bookings)); ?> rows</span>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Passenger</th>
                        <th>Trip</th>
                        <th>Departure</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Payment</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($bookings === []): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No bookings match the current filters.</td></tr>
                    <?php else: ?>
                        <?php foreach ($bookings as $booking): ?>
                            <?php
                            $departureTimestamp = departure_timestamp((string) ($booking['departure_date'] ?? ''), (string) ($booking['departure_time'] ?? ''));
                            $canChangeSeats = !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
                                && $departureTimestamp !== null
                                && $departureTimestamp > time();
                            $canCancel = !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true);
                            $needsPaymentReview = (string) ($booking['payment_status'] ?? '') !== 'paid'
                                && !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true);
                            ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($booking['booking_reference']); ?></div>
                                    <div class="small text-muted"><?php echo (int) $booking['number_of_passengers']; ?> pax</div>
                                    <div class="small text-muted text-uppercase"><?php echo e((string) ($booking['payment_method'] ?? 'online')); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($booking['passenger_name']); ?></div>
                                    <div class="small text-muted"><?php echo e($booking['passenger_email']); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                                    <div class="small text-muted">Trip: <?php echo e(ucfirst(effective_schedule_trip_status($booking))); ?></div>
                                </td>
                                <td>
                                    <?php echo $departureTimestamp !== null ? e(date('M j, Y g:i A', $departureTimestamp)) : 'Schedule unavailable'; ?>
                                </td>
                                <td>PHP <?php echo number_format((float) $booking['total_amount'], 2); ?></td>
                                <td>
                                    <span class="chip <?php echo in_array((string) ($booking['status'] ?? ''), ['confirmed', 'used'], true) ? 'success' : (((string) ($booking['status'] ?? '') === 'cancelled' || (string) ($booking['status'] ?? '') === 'expired') ? 'danger' : 'warning'); ?>">
                                        <?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['status'] ?? 'pending')))); ?>
                                    </span>
                                </td>
                                <td>
                                    <span class="chip <?php echo (string) ($booking['payment_status'] ?? '') === 'paid' ? 'success' : (((string) ($booking['payment_status'] ?? '') === 'pending') ? 'warning' : 'danger'); ?>">
                                        <?php echo e(ucwords(str_replace('_', ' ', (string) ($booking['payment_status'] ?? 'pending')))); ?>
                                    </span>
                                </td>
                                <td style="min-width: 320px;">
                                    <div class="admin-inline-actions">
                                        <a class="btn btn-sm btn-outline-secondary" href="booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">View</a>
                                        <?php if ($canChangeSeats): ?>
                                            <a class="btn btn-sm btn-outline-primary" href="change-seats.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">Change Seats</a>
                                        <?php endif; ?>
                                        <?php if ($needsPaymentReview): ?>
                                            <?php if ((string) ($booking['payment_method'] ?? '') === 'cash'): ?>
                                                <a class="btn btn-sm btn-outline-secondary" href="ticket-scanner.php">Confirm Cash</a>
                                            <?php else: ?>
                                                <a class="btn btn-sm btn-outline-secondary" href="manage-payments.php">Review Payment</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <?php if ($canCancel): ?>
                                            <form method="post" onsubmit="return confirm('Cancel this booking?');">
                                                <?php csrf_field(); ?>
                                                <input type="hidden" name="action" value="cancel_booking">
                                                <input type="hidden" name="booking_id" value="<?php echo (int) $booking['booking_id']; ?>">
                                                <button class="btn btn-sm btn-outline-danger" type="submit">Cancel</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="small text-muted align-self-center">Automatic updates only</span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
