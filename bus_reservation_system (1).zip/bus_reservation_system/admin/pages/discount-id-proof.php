<?php
require_once '../../includes/config.php';

if (!is_logged_in() || !can_access_admin_panel()) {
    http_response_code(403);
    exit('Access denied.');
}

$passengerId = (int) isset_get('passenger_id');
$passenger = db_select_one(
    'SELECT id_proof_path FROM passengers WHERE passenger_id = ? LIMIT 1',
    'i',
    [$passengerId]
);
$proofPath = trim(str_replace('\\', '/', (string) ($passenger['id_proof_path'] ?? '')), '/');
$projectRoot = realpath(dirname(__DIR__, 2));
$isAllowedPath = strpos($proofPath, 'storage/discount-ids/') === 0;
$absolutePath = $projectRoot && $isAllowedPath
    ? realpath($projectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $proofPath))
    : false;

if (!$absolutePath || !$projectRoot || strpos($absolutePath, $projectRoot . DIRECTORY_SEPARATOR) !== 0 || !is_file($absolutePath)) {
    http_response_code(404);
    exit('ID proof not found.');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = $finfo ? (string) finfo_file($finfo, $absolutePath) : '';
if ($finfo) {
    finfo_close($finfo);
}

$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
if (!in_array($mimeType, $allowedMimeTypes, true)) {
    http_response_code(404);
    exit('ID proof is unavailable.');
}

$extension = strtolower(pathinfo($absolutePath, PATHINFO_EXTENSION));
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . (string) filesize($absolutePath));
header('Content-Disposition: inline; filename="passenger-id-' . $passengerId . '.' . $extension . '"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($absolutePath);
exit();
