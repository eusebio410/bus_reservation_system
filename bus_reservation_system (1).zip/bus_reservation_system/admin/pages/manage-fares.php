<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$fareId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');

if ($action === 'delete' && $fareId > 0) {
    if (db_execute('DELETE FROM fares WHERE fare_id = ?', 'i', [$fareId])) {
        set_flash('success', 'Fare deleted successfully.');
        redirect('manage-fares.php');
    } else {
        $error = 'Unable to delete the selected fare.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['fare_id'] ?? 0);
    $routeId = (int) ($_POST['route_id'] ?? 0);
    $classId = (int) ($_POST['class_id'] ?? 0);
    $baseFare = round((float) ($_POST['base_fare'] ?? 0), 2);
    $discountPercentage = round((float) ($_POST['discount_percentage'] ?? 0), 2);

    if ($routeId < 1 || $classId < 1) {
        $error = 'Please choose a route and a bus class.';
    } elseif ($baseFare <= 0) {
        $error = 'Base fare must be greater than zero.';
    } elseif ($discountPercentage < 0 || $discountPercentage > 100) {
        $error = 'Discount percentage must be between 0 and 100.';
    } else {
        $duplicate = db_select_one(
            'SELECT fare_id FROM fares WHERE route_id = ? AND class_id = ? AND fare_id <> ? LIMIT 1',
            'iii',
            [$routeId, $classId, $editId]
        );

        if ($duplicate) {
            $error = 'A fare already exists for that route and bus class.';
        } else {
            if ($editId > 0) {
                $ok = db_execute(
                    'UPDATE fares
                     SET route_id = ?, class_id = ?, base_fare = ?, discount_percentage = ?
                     WHERE fare_id = ?',
                    'iiddi',
                    [$routeId, $classId, $baseFare, $discountPercentage, $editId]
                );
                $message = 'Fare updated successfully.';
            } else {
                $ok = db_execute(
                    'INSERT INTO fares (route_id, class_id, base_fare, discount_percentage)
                     VALUES (?, ?, ?, ?)',
                    'iidd',
                    [$routeId, $classId, $baseFare, $discountPercentage]
                );
                $message = 'Fare added successfully.';
            }

            if ($ok) {
                set_flash('success', $message);
                redirect('manage-fares.php');
            }

            $error = 'Unable to save the fare record.';
        }
    }
}

$editFare = null;
if ($action === 'edit' && $fareId > 0) {
    $editFare = db_select_one('SELECT * FROM fares WHERE fare_id = ? LIMIT 1', 'i', [$fareId]);
}

$fares = db_select_all(
    "SELECT f.fare_id, f.route_id, f.class_id, f.base_fare, f.discount_percentage,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name,
            bc.class_name
     FROM fares f
     JOIN routes r ON f.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     JOIN bus_classes bc ON f.class_id = bc.class_id
     ORDER BY origin.terminal_name ASC, destination.terminal_name ASC, bc.class_name ASC"
);

$routes = db_select_all(
    "SELECT r.route_id,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM routes r
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     ORDER BY origin.terminal_name ASC, destination.terminal_name ASC"
);

$busClasses = db_select_all('SELECT class_id, class_name FROM bus_classes ORDER BY class_name ASC');

$fareCount = count($fares);
$averageBaseFare = $fareCount > 0
    ? array_sum(array_map(static fn($fare) => (float) $fare['base_fare'], $fares)) / $fareCount
    : 0;
$discountedCount = count(array_filter($fares, static fn($fare) => (float) $fare['discount_percentage'] > 0));

admin_render_header('Fare Management', 'fares');
admin_page_header(
    'Fare Management',
    'Maintain route pricing, discounts, and the public fare matrix shown to passengers.',
    [
        ['label' => 'Preview Public Fares', 'href' => '../../fares.php', 'icon' => 'fa-arrow-up-right-from-square', 'class' => 'btn-outline-secondary'],
    ]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editFare ? 'Edit Fare' : 'Add Fare'; ?></h2>
        </div>
        <div class="admin-card-body">
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="fare_id" value="<?php echo (int) ($editFare['fare_id'] ?? 0); ?>">
                <div class="col-md-6">
                    <label class="form-label" for="route_id">Route</label>
                    <select class="form-select" id="route_id" name="route_id" required>
                        <option value="">Select route</option>
                        <?php foreach ($routes as $route): ?>
                            <option value="<?php echo (int) $route['route_id']; ?>" <?php echo ((int) ($editFare['route_id'] ?? 0) === (int) $route['route_id']) ? 'selected' : ''; ?>>
                                <?php echo e($route['origin_name'] . ' to ' . $route['destination_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="class_id">Bus Class</label>
                    <select class="form-select" id="class_id" name="class_id" required>
                        <option value="">Select class</option>
                        <?php foreach ($busClasses as $class): ?>
                            <option value="<?php echo (int) $class['class_id']; ?>" <?php echo ((int) ($editFare['class_id'] ?? 0) === (int) $class['class_id']) ? 'selected' : ''; ?>>
                                <?php echo e($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="base_fare">Base Fare</label>
                    <input class="form-control" type="number" step="0.01" min="0.01" id="base_fare" name="base_fare" value="<?php echo e($editFare['base_fare'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="discount_percentage">Discount Percentage</label>
                    <input class="form-control" type="number" step="0.01" min="0" max="100" id="discount_percentage" name="discount_percentage" value="<?php echo e($editFare['discount_percentage'] ?? '0'); ?>">
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editFare ? 'Update Fare' : 'Add Fare'; ?></button>
                    <?php if ($editFare): ?>
                        <a class="btn btn-outline-secondary" href="manage-fares.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Fare Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Fare Entries</span>
                    <span class="value"><?php echo number_format($fareCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Discounted Entries</span>
                    <span class="value"><?php echo number_format($discountedCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Average Base Fare</span>
                    <span class="value">PHP <?php echo number_format($averageBaseFare, 2); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Fare Matrix</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Route</th>
                        <th>Class</th>
                        <th>Base Fare</th>
                        <th>Discount</th>
                        <th>Final Fare</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($fares === []): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No fares found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($fares as $fare): ?>
                            <?php $finalFare = (float) $fare['base_fare'] - ((float) $fare['base_fare'] * ((float) $fare['discount_percentage'] / 100)); ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($fare['origin_name'] . ' to ' . $fare['destination_name']); ?></div>
                                </td>
                                <td><span class="chip soft"><?php echo e($fare['class_name']); ?></span></td>
                                <td>PHP <?php echo number_format((float) $fare['base_fare'], 2); ?></td>
                                <td><?php echo number_format((float) $fare['discount_percentage'], 2); ?>%</td>
                                <td class="fw-semibold text-success">PHP <?php echo number_format($finalFare, 2); ?></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-fares.php?action=edit&id=<?php echo (int) $fare['fare_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-fares.php?action=delete&id=<?php echo (int) $fare['fare_id']; ?>" onclick="return confirm('Delete this fare?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
