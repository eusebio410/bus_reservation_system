<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$bookingId = (int) isset_get('booking_id');
if ($bookingId < 1) {
    redirect('manage-bookings.php');
}

$booking = db_select_one(
    "SELECT b.booking_id, b.booking_reference, b.schedule_id, b.status, b.payment_status, b.payment_method,
            b.number_of_passengers, b.total_amount,
            u.fullname AS passenger_name, u.email AS passenger_email,
            s.departure_date, s.departure_time,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN users u ON b.user_id = u.user_id
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.booking_id = ?
     LIMIT 1",
    'i',
    [$bookingId]
);

if (!$booking) {
    redirect('manage-bookings.php');
}

$error = '';
$success = consume_flash('success');

$passengers = db_select_all(
    'SELECT passenger_id, fullname, email, phone, seat_number
     FROM passengers
     WHERE booking_id = ?
     ORDER BY passenger_id ASC',
    'i',
    [$bookingId]
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seatAssignments = [];
    foreach ($passengers as $passenger) {
        $passengerId = (int) ($passenger['passenger_id'] ?? 0);
        $seatAssignments[$passengerId] = isset_post('seat_' . $passengerId);
    }

    $result = change_booking_seats($bookingId, $seatAssignments, (int) ($_SESSION['user_id'] ?? 0));
    if ($result['ok']) {
        set_flash('success', $result['message']);
        redirect('change-seats.php?booking_id=' . $bookingId);
    }

    $error = $result['message'];
}

$ticketRows = db_select_all(
    'SELECT t.ticket_id, t.passenger_id, s.seat_label
     FROM tickets t
     JOIN seats s ON t.seat_id = s.seat_id
     WHERE t.booking_id = ?
     ORDER BY t.ticket_id ASC',
    'i',
    [$bookingId]
);

$ownedSeatLabels = [];
foreach ($ticketRows as $ticketRow) {
    $label = trim((string) ($ticketRow['seat_label'] ?? ''));
    if ($label !== '') {
        $ownedSeatLabels[] = $label;
    }
}

$selectableSeats = [];
foreach (get_schedule_seat_map((int) $booking['schedule_id']) as $seatRow) {
    $seatLabel = trim((string) ($seatRow['seat_label'] ?? ''));
    if ($seatLabel === '') {
        continue;
    }

    if (($seatRow['status'] ?? '') === 'available' || in_array($seatLabel, $ownedSeatLabels, true)) {
        $selectableSeats[] = $seatLabel;
    }
}

$selectableSeats = array_values(array_unique($selectableSeats));
natsort($selectableSeats);
$selectableSeats = array_values($selectableSeats);

$departureTimestamp = departure_timestamp((string) ($booking['departure_date'] ?? ''), (string) ($booking['departure_time'] ?? ''));
$canEditSeats = !in_array((string) ($booking['status'] ?? ''), ['cancelled', 'expired', 'used'], true)
    && $departureTimestamp !== null
    && $departureTimestamp > time();

$paymentLabel = strtoupper((string) ($booking['payment_method'] ?? ''));
$isCashPending = (($booking['payment_method'] ?? '') === 'cash' && ($booking['payment_status'] ?? '') !== 'paid');

admin_render_header('Change Seats', 'bookings');
admin_page_header('Change Seats', 'Handle passenger seat-change requests with staff or admin approval before the trip departs.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="d-flex flex-wrap gap-2 mb-4">
    <a class="btn btn-outline-secondary" href="manage-bookings.php">
        <i class="fa-solid fa-arrow-left me-2"></i>Back to Bookings
    </a>
    <a class="btn btn-outline-secondary" href="booking-view.php?booking_id=<?php echo (int) $booking['booking_id']; ?>">
        <i class="fa-solid fa-eye me-2"></i>View Booking
    </a>
</div>

<div class="stats-grid">
    <div class="stat-tile">
        <span class="label">Booking</span>
        <span class="value" style="font-size:1.2rem;"><?php echo e($booking['booking_reference']); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Passenger</span>
        <span class="value" style="font-size:1.2rem;"><?php echo e($booking['passenger_name']); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Payment</span>
        <span class="value" style="font-size:1.2rem;"><?php echo e($paymentLabel !== '' ? $paymentLabel : 'PENDING'); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Selectable Seats</span>
        <span class="value" style="font-size:1.2rem;"><?php echo number_format(count($selectableSeats)); ?></span>
    </div>
</div>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Trip Details</h2>
        </div>
        <div class="admin-card-body">
            <div class="row g-3">
                <div class="col-12">
                    <div class="small text-muted">Route</div>
                    <div class="fw-semibold"><?php echo e($booking['origin_name']); ?> to <?php echo e($booking['destination_name']); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Departure</div>
                    <div class="fw-semibold">
                        <?php echo $departureTimestamp !== null ? e(date('M j, Y g:i A', $departureTimestamp)) : 'Schedule unavailable'; ?>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Booking Status</div>
                    <div class="fw-semibold text-capitalize"><?php echo e(str_replace('_', ' ', (string) ($booking['status'] ?? 'pending'))); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Payment Status</div>
                    <div class="fw-semibold text-capitalize"><?php echo e(str_replace('_', ' ', (string) ($booking['payment_status'] ?? 'pending'))); ?></div>
                </div>
                <div class="col-md-6">
                    <div class="small text-muted">Passengers</div>
                    <div class="fw-semibold"><?php echo number_format((int) ($booking['number_of_passengers'] ?? 0)); ?></div>
                </div>
            </div>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Seat Policy</h2>
        </div>
        <div class="admin-card-body">
            <?php if ($isCashPending): ?>
                <div class="alert alert-warning rounded-4 mb-0">
                    This is still a pay at terminal booking. Changing seats here updates the preferred seats only. The final seat lock will happen after terminal payment is confirmed by staff.
                </div>
            <?php else: ?>
                <div class="alert alert-info rounded-4 mb-0">
                    This booking already has live reserved or issued seats. Changing seats here updates the passenger seat assignment directly so the latest ticket details stay correct.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Passenger Seat Assignment</h2>
    </div>
    <div class="admin-card-body">
        <?php if ($passengers === []): ?>
            <div class="alert alert-warning rounded-4 mb-0">
                Passenger details are not complete yet for this booking. Complete the passenger manifest first before changing seats.
            </div>
        <?php elseif (!$canEditSeats): ?>
            <div class="alert alert-warning rounded-4 mb-0">
                This booking can no longer be edited because it is inactive or the trip has already departed.
            </div>
        <?php elseif ($selectableSeats === []): ?>
            <div class="alert alert-warning rounded-4 mb-0">
                No selectable seats are available right now for this trip.
            </div>
        <?php else: ?>
            <form method="post" class="d-grid gap-4">
                <?php csrf_field(); ?>
                <?php foreach ($passengers as $passenger): ?>
                    <?php
                    $passengerId = (int) ($passenger['passenger_id'] ?? 0);
                    $currentSeat = trim((string) ($passenger['seat_number'] ?? ''));
                    $postedSeat = isset_post('seat_' . $passengerId);
                    $selectedSeat = $postedSeat !== '' ? $postedSeat : $currentSeat;
                    $currentSeatSelectable = $currentSeat !== '' && in_array($currentSeat, $selectableSeats, true);
                    ?>
                    <div class="rounded-4 border p-4">
                        <div class="row g-3 align-items-end">
                            <div class="col-lg-4">
                                <div class="small text-muted">Passenger</div>
                                <div class="fw-semibold"><?php echo e($passenger['fullname']); ?></div>
                                <div class="small text-muted mt-2">
                                    Current seat:
                                    <strong><?php echo e($currentSeat !== '' ? $currentSeat : 'Not assigned'); ?></strong>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <label class="form-label fw-semibold" for="seat_<?php echo $passengerId; ?>">New Seat</label>
                                <select class="form-select" id="seat_<?php echo $passengerId; ?>" name="seat_<?php echo $passengerId; ?>" required>
                                    <?php if (!$currentSeatSelectable && $currentSeat !== ''): ?>
                                        <option value="">Choose a new seat. Current seat <?php echo e($currentSeat); ?> is no longer available.</option>
                                    <?php endif; ?>
                                    <?php foreach ($selectableSeats as $seatLabel): ?>
                                        <option value="<?php echo e($seatLabel); ?>" <?php echo $selectedSeat === $seatLabel ? 'selected' : ''; ?>>
                                            <?php echo e($seatLabel); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="d-flex flex-wrap gap-2">
                    <button class="btn btn-accent" type="submit">
                        <i class="fa-solid fa-chair me-2"></i>Save Seat Changes
                    </button>
                    <a class="btn btn-outline-secondary" href="manage-bookings.php">Cancel</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<?php admin_render_footer(); ?>
