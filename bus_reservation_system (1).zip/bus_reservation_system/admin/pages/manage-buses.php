<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$busId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');

if ($action === 'delete' && $busId > 0) {
    $hasSchedules = db_select_one('SELECT COUNT(*) AS total FROM schedules WHERE bus_id = ?', 'i', [$busId]);
    if ((int) ($hasSchedules['total'] ?? 0) > 0) {
        $error = 'This bus already has schedules. Disable it or reassign schedules first.';
    } elseif (db_execute('DELETE FROM buses WHERE bus_id = ?', 'i', [$busId])) {
        set_flash('success', 'Bus deleted successfully.');
        redirect('manage-buses.php');
    } else {
        $error = 'Unable to delete the selected bus.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['bus_id'] ?? 0);
    $busCode = isset_post('bus_code');
    $busName = isset_post('bus_name');
    $busType = isset_post('bus_type');
    $classId = (int) ($_POST['class_id'] ?? 0);
    $registrationNumber = isset_post('registration_number');
    $model = isset_post('model');
    $year = (int) ($_POST['year_manufactured'] ?? 0);
    $totalSeats = max(1, (int) ($_POST['total_seats'] ?? fixed_bus_seat_capacity()));
    $status = isset_post('status') ?: 'active';
    $isEnabled = isset($_POST['is_enabled']) ? 1 : 0;

    if ($busCode === '' || $busName === '' || $busType === '' || $classId < 1) {
        $error = 'Bus code, bus name, bus type, and class are required.';
    } else {
        if ($editId > 0) {
            $overflowAssignments = db_select_one(
                'SELECT COUNT(*) AS total
                 FROM seats s
                 JOIN tickets t ON s.seat_id = t.seat_id
                 WHERE s.bus_id = ? AND s.seat_number > ?',
                'ii',
                [$editId, $totalSeats]
            );

            if ((int) ($overflowAssignments['total'] ?? 0) > 0) {
                $error = 'Seat capacity cannot be reduced below seats already assigned to active tickets.';
            }
        }
    }

    if ($error === '') {
        $duplicate = db_select_one(
            'SELECT bus_id FROM buses WHERE bus_code = ? AND bus_id <> ? LIMIT 1',
            'si',
            [$busCode, $editId]
        );

        if ($duplicate) {
            $error = 'That bus code is already in use.';
        } else {
            if ($editId > 0) {
                $ok = db_execute(
                    'UPDATE buses
                     SET bus_code = ?, bus_name = ?, bus_type = ?, class_id = ?, registration_number = ?, model = ?, year_manufactured = ?, total_seats = ?, status = ?, is_enabled = ?
                     WHERE bus_id = ?',
                    'sssissiisii',
                    [$busCode, $busName, $busType, $classId, $registrationNumber, $model, $year, $totalSeats, $status, $isEnabled, $editId]
                );
                $savedBusId = $editId;
                $message = 'Bus updated successfully.';
            } else {
                $ok = db_execute(
                    'INSERT INTO buses (bus_code, bus_name, bus_type, class_id, registration_number, model, year_manufactured, total_seats, status, is_enabled)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                    'sssissiisi',
                    [$busCode, $busName, $busType, $classId, $registrationNumber, $model, $year, $totalSeats, $status, $isEnabled]
                );
                $savedBusId = db_last_insert_id();
                $message = 'Bus added successfully.';
            }

            if ($ok) {
                sync_bus_seats($savedBusId, $totalSeats);
                set_flash('success', $message);
                redirect('manage-buses.php');
            }

            $error = 'Unable to save the bus record.';
        }
    }
}

$editBus = null;
if ($action === 'edit' && $busId > 0) {
    $editBus = db_select_one('SELECT * FROM buses WHERE bus_id = ? LIMIT 1', 'i', [$busId]);
}

$busClasses = db_select_all('SELECT class_id, class_name FROM bus_classes ORDER BY class_name ASC');
$buses = db_select_all(
    "SELECT b.*, bc.class_name, COUNT(DISTINCT s.schedule_id) AS schedule_count
     FROM buses b
     LEFT JOIN bus_classes bc ON b.class_id = bc.class_id
     LEFT JOIN schedules s ON s.bus_id = b.bus_id
     GROUP BY b.bus_id
     ORDER BY b.bus_code ASC"
);

admin_render_header('Bus Management', 'buses');
admin_page_header('Bus Management', 'Manage fleet capacity, generated seats, bus availability, and schedule readiness.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editBus ? 'Edit Bus' : 'Add Bus'; ?></h2>
        </div>
        <div class="admin-card-body">
            <?php if (!$editBus): ?>
                <div class="alert alert-info rounded-4 mb-3">
                    Add buses manually with a custom fleet code, capacity, type, and registration details. This form does not auto-populate bus records.
                </div>
            <?php endif; ?>
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="bus_id" value="<?php echo (int) ($editBus['bus_id'] ?? 0); ?>">
                <div class="col-md-6">
                    <label class="form-label" for="bus_code">Bus Number / Code</label>
                    <input class="form-control" type="text" id="bus_code" name="bus_code" value="<?php echo e($editBus['bus_code'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="bus_name">Bus Name</label>
                    <input class="form-control" type="text" id="bus_name" name="bus_name" value="<?php echo e($editBus['bus_name'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="bus_type">Bus Type</label>
                    <input class="form-control" type="text" id="bus_type" name="bus_type" value="<?php echo e($editBus['bus_type'] ?? ''); ?>" placeholder="Deluxe, Sleeper, Regular" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="class_id">Fare Class</label>
                    <select class="form-select" id="class_id" name="class_id" required>
                        <option value="">Select class</option>
                        <?php foreach ($busClasses as $class): ?>
                            <option value="<?php echo (int) $class['class_id']; ?>" <?php echo ((int) ($editBus['class_id'] ?? 0) === (int) $class['class_id']) ? 'selected' : ''; ?>>
                                <?php echo e($class['class_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="registration_number">Registration Number</label>
                    <input class="form-control" type="text" id="registration_number" name="registration_number" value="<?php echo e($editBus['registration_number'] ?? ''); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="model">Model</label>
                    <input class="form-control" type="text" id="model" name="model" value="<?php echo e($editBus['model'] ?? ''); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="year_manufactured">Year</label>
                    <input class="form-control" type="number" min="2000" max="2099" id="year_manufactured" name="year_manufactured" value="<?php echo e($editBus['year_manufactured'] ?? date('Y')); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="total_seats">Seat Capacity</label>
                    <input class="form-control" type="number" min="1" max="100" id="total_seats" name="total_seats" value="<?php echo e($editBus ? (int) $editBus['total_seats'] : ''); ?>" placeholder="Enter total seats" required>
                    <div class="form-text">Enter seating capacity manually. Do not leave this blank.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="status">Fleet Status</label>
                    <select class="form-select" id="status" name="status">
                        <?php foreach (['active', 'maintenance', 'retired'] as $statusOption): ?>
                            <option value="<?php echo e($statusOption); ?>" <?php echo (($editBus['status'] ?? 'active') === $statusOption) ? 'selected' : ''; ?>>
                                <?php echo e(ucfirst($statusOption)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="is_enabled" name="is_enabled" <?php echo !isset($editBus['is_enabled']) || (int) $editBus['is_enabled'] === 1 ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="is_enabled">Enabled for automatic schedule assignment</label>
                    </div>
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editBus ? 'Update Bus' : 'Add Bus'; ?></button>
                    <?php if ($editBus): ?>
                        <a class="btn btn-outline-secondary" href="manage-buses.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Fleet Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Fleet Size</span>
                    <span class="value"><?php echo number_format(count($buses)); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Enabled Buses</span>
                    <span class="value"><?php echo number_format(count(array_filter($buses, static fn($bus) => (int) $bus['is_enabled'] === 1))); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Generated Seats</span>
                    <span class="value"><?php echo number_format(array_sum(array_map(static fn($bus) => (int) $bus['total_seats'], $buses))); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Fleet Registry</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Bus</th>
                        <th>Type / Class</th>
                        <th>Capacity</th>
                        <th>Schedules</th>
                        <th>Status</th>
                        <th>Enabled</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($buses === []): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">No buses registered yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($buses as $bus): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($bus['bus_name'] ?: $bus['bus_code']); ?></div>
                                    <div class="small text-muted"><?php echo e($bus['bus_code']); ?><?php echo $bus['registration_number'] ? ' • ' . e($bus['registration_number']) : ''; ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($bus['bus_type']); ?></div>
                                    <div class="small text-muted"><?php echo e($bus['class_name'] ?: 'No class'); ?></div>
                                </td>
                                <td><?php echo number_format((int) $bus['total_seats']); ?> seats</td>
                                <td><span class="chip soft"><?php echo number_format((int) $bus['schedule_count']); ?> trips</span></td>
                                <td><span class="chip <?php echo $bus['status'] === 'active' ? 'success' : ($bus['status'] === 'maintenance' ? 'warning' : 'danger'); ?>"><?php echo e(ucfirst($bus['status'])); ?></span></td>
                                <td><span class="chip <?php echo (int) $bus['is_enabled'] === 1 ? 'success' : 'danger'; ?>"><?php echo (int) $bus['is_enabled'] === 1 ? 'Enabled' : 'Disabled'; ?></span></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-buses.php?action=edit&id=<?php echo (int) $bus['bus_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-buses.php?action=delete&id=<?php echo (int) $bus['bus_id']; ?>" onclick="return confirm('Delete this bus?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
