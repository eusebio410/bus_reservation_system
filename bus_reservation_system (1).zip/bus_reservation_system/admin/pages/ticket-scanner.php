<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_get('ajax') === '' && isset_post('action') === 'clear_logs') {
    $result = clear_qr_scan_history();
    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('ticket-scanner.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_get('ajax') === 'scan') {
    header('Content-Type: application/json');
    $payload = trim((string) ($_POST['payload'] ?? ''));
    echo json_encode(validate_ticket_qr($payload, (int) $_SESSION['user_id']));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_get('ajax') === 'confirm_cash') {
    header('Content-Type: application/json');
    $bookingId = (int) ($_POST['booking_id'] ?? 0);
    $notes = isset_post('notes');
    $result = complete_cash_payment_by_booking($bookingId, (int) $_SESSION['user_id'], $notes);

    if ($result['ok']) {
        echo json_encode([
            'status' => 'cash_claim_paid',
            'message' => $result['message'],
            'booking_claim' => get_cash_claim_summary($bookingId),
        ]);
    } else {
        echo json_encode([
            'status' => 'invalid',
            'message' => $result['message'],
        ]);
    }
    exit();
}

$error = consume_flash('error');
$success = consume_flash('success');

admin_render_header('QR Ticket Scanner', 'scanner');
admin_page_header('QR Ticket Scanner', 'Scan final boarding tickets or terminal cash tickets. Staff can confirm cash payment here before issuing the final seat and ticket.');
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="d-flex justify-content-end mb-4">
    <form method="post" onsubmit="return confirm('Clear all QR scan history logs from the scanner?');">
        <?php csrf_field(); ?>
        <input type="hidden" name="action" value="clear_logs">
        <button class="btn btn-outline-danger" type="submit">
            <i class="fa-solid fa-trash-can me-2"></i>Clear Scan Logs
        </button>
    </form>
</div>

<style>
#reader {
    background: radial-gradient(circle at top, rgba(16, 32, 59, 0.08), rgba(255, 255, 255, 0.96));
    border: 1px solid rgba(15, 23, 42, 0.08);
    border-radius: 1.25rem;
    min-height: 340px;
    overflow: hidden;
    padding: 1rem;
}
#reader video,
#reader img {
    border-radius: 1rem;
}
#reader video {
    background: #0f172a;
    object-fit: cover;
    width: 100% !important;
}
#reader__scan_region {
    align-items: center;
    display: flex;
    justify-content: center;
}
#reader__dashboard,
#reader__dashboard_section,
#reader__dashboard_section_csr {
    border: 0 !important;
    box-shadow: none !important;
}
.scanner-status {
    margin-bottom: 1rem;
}
.scanner-controls {
    display: flex;
    flex-wrap: wrap;
    gap: 0.75rem;
}
.scanner-result .alert {
    margin-bottom: 0;
}
.scanner-meta {
    display: grid;
    gap: 0.45rem;
}
.scanner-meta div {
    border-top: 1px solid rgba(255, 255, 255, 0.18);
    padding-top: 0.45rem;
}
.scanner-input {
    font-family: Consolas, Monaco, monospace;
}
</style>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Camera Scanner</h2>
            </div>
            <div class="admin-card-body">
                <div id="scanner-status" class="alert alert-secondary rounded-4 scanner-status" role="status" aria-live="polite">
                    Camera is idle. Start the scanner and hold the QR code steady inside the frame.
                </div>
                <div id="reader"></div>
                <div class="scanner-controls mt-3">
                    <button class="btn btn-accent" type="button" id="start-scan">Start Camera</button>
                    <button class="btn btn-outline-secondary" type="button" id="stop-scan" disabled>Stop Camera</button>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Manual Validation</h2>
            </div>
            <div class="admin-card-body">
                <form id="manual-scan-form" class="d-grid gap-3">
                    <div>
                        <label class="form-label" for="manual_payload">Paste a cash ticket code, passenger ticket code, or older QR JSON</label>
                        <textarea class="form-control scanner-input" id="manual_payload" rows="5" placeholder="CTK260403ABCDEFGH"></textarea>
                    </div>
                    <button class="btn btn-accent" type="submit">Validate Ticket</button>
                </form>
                <div id="scan-result" class="scanner-result mt-4"></div>
            </div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const readerNode = document.getElementById('reader');
    const resultNode = document.getElementById('scan-result');
    const statusNode = document.getElementById('scanner-status');
    const startButton = document.getElementById('start-scan');
    const stopButton = document.getElementById('stop-scan');
    const manualForm = document.getElementById('manual-scan-form');
    const manualPayload = document.getElementById('manual_payload');
    const scanner = new Html5Qrcode('reader');
    const csrfToken = <?php echo json_encode(csrf_token()); ?>;
    let scannerStarted = false;
    let isValidating = false;
    let lastDecodedText = '';
    let lastScanAt = 0;
    const duplicateWindowMs = 8000;
    const AudioContextClass = window.AudioContext || window.webkitAudioContext || null;
    let audioContext = null;

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (character) {
            return ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#39;'
            })[character];
        });
    }

    function setStatus(message, tone) {
        statusNode.className = 'alert alert-' + (tone || 'secondary') + ' rounded-4 scanner-status';
        statusNode.textContent = message;
    }

    function syncButtons() {
        startButton.disabled = scannerStarted;
        stopButton.disabled = !scannerStarted;
        startButton.textContent = scannerStarted ? 'Camera Running' : 'Start Camera';
    }

    async function unlockAudio() {
        if (!AudioContextClass) {
            return;
        }

        if (!audioContext) {
            audioContext = new AudioContextClass();
        }

        if (audioContext.state === 'suspended') {
            await audioContext.resume();
        }
    }

    function playBeep(mode) {
        if (!audioContext || audioContext.state !== 'running') {
            return;
        }

        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();
        const now = audioContext.currentTime;
        const frequency = mode === 'warning' ? 740 : 1046;

        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(frequency, now);

        gainNode.gain.setValueAtTime(0.0001, now);
        gainNode.gain.exponentialRampToValueAtTime(0.08, now + 0.01);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.13);

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.start(now);
        oscillator.stop(now + 0.14);
    }

    function renderResult(data) {
        if (!data) {
            return;
        }

        const status = data.status || 'invalid';
        const tone = (status === 'valid' || status === 'cash_claim_paid')
            ? 'success'
            : ((status === 'already_used' || status === 'cash_claim_pending') ? 'warning' : 'danger');
        let html = '<div class="alert alert-' + tone + ' rounded-4">';
        html += '<div class="fw-bold mb-2">' + escapeHtml(data.message || 'Scan completed') + '</div>';

        if (data.ticket) {
            html += '<div class="scanner-meta">';
            html += '<div><strong>Ticket:</strong> ' + escapeHtml(data.ticket.ticket_code || '') + '</div>';
            html += '<div><strong>Booking:</strong> ' + escapeHtml(data.ticket.booking_reference || '') + '</div>';
            html += '<div><strong>Passenger:</strong> ' + escapeHtml(data.ticket.passenger_name || '') + '</div>';
            html += '<div><strong>Seat:</strong> ' + escapeHtml(data.ticket.seat_label || '') + '</div>';
            html += '<div><strong>Trip:</strong> ' + escapeHtml(data.ticket.origin_name || '') + ' to ' + escapeHtml(data.ticket.destination_name || '') + '</div>';
            html += '</div>';
        }

        if (data.booking_claim) {
            html += '<div class="scanner-meta">';
            html += '<div><strong>Cash Ticket:</strong> ' + escapeHtml(data.booking_claim.claim_code || data.booking_claim.booking_reference || '') + '</div>';
            html += '<div><strong>Passenger:</strong> ' + escapeHtml(data.booking_claim.account_name || '') + '</div>';
            html += '<div><strong>Preferred Seats:</strong> ' + escapeHtml(data.booking_claim.preferred_seats || 'Not set') + '</div>';
            html += '<div><strong>Passengers:</strong> ' + escapeHtml(data.booking_claim.number_of_passengers || '') + '</div>';
            html += '<div><strong>Trip:</strong> ' + escapeHtml(data.booking_claim.origin_name || '') + ' to ' + escapeHtml(data.booking_claim.destination_name || '') + '</div>';
            html += '<div><strong>Departure:</strong> ' + escapeHtml(data.booking_claim.departure_label || ((data.booking_claim.departure_date || '') + ' ' + (data.booking_claim.departure_time || ''))) + '</div>';
            html += '<div><strong>Amount:</strong> PHP ' + escapeHtml(Number(data.booking_claim.total_amount || 0).toFixed(2)) + '</div>';
            html += '<div><strong>Valid Until Departure:</strong> ' + escapeHtml(data.booking_claim.expires_at_label || data.booking_claim.expires_at || 'Until departure') + '</div>';
            html += '</div>';

            if (status === 'cash_claim_pending') {
                html += '<div class="mt-3">';
                html += '<button class="btn btn-accent" type="button" data-action="confirm-cash" data-booking-id="' + escapeHtml(data.booking_claim.booking_id || '') + '">';
                html += '<i class="fa-solid fa-money-bill-wave me-1"></i>Receive Cash and Issue Ticket';
                html += '</button>';
                html += '</div>';
            }
        }

        html += '</div>';
        resultNode.innerHTML = html;
    }

    async function validatePayload(payload) {
        const body = new FormData();
        body.append('payload', payload);
        body.append('_csrf_token', csrfToken);

        const response = await fetch('ticket-scanner.php?ajax=scan', {
            method: 'POST',
            body
        });
        if (!response.ok) {
            throw new Error('Unable to validate the ticket right now.');
        }
        const data = await response.json();
        renderResult(data);
        return data;
    }

    async function confirmCashClaim(bookingId, notes) {
        const body = new FormData();
        body.append('booking_id', bookingId);
        body.append('notes', notes || '');
        body.append('_csrf_token', csrfToken);

        const response = await fetch('ticket-scanner.php?ajax=confirm_cash', {
            method: 'POST',
            body
        });
        if (!response.ok) {
            throw new Error('Unable to confirm the cash payment right now.');
        }

        const data = await response.json();
        renderResult(data);
        return data;
    }

    async function handleDecodedText(decodedText) {
        const normalizedText = String(decodedText || '').trim();
        const now = Date.now();

        if (!normalizedText || isValidating) {
            return;
        }

        if (normalizedText === lastDecodedText && (now - lastScanAt) < duplicateWindowMs) {
            return;
        }

        lastDecodedText = normalizedText;
        lastScanAt = now;
        isValidating = true;
        setStatus('Validating ticket...', 'warning');

        try {
            const data = await validatePayload(normalizedText);
            if ((data.status || '') === 'valid') {
                playBeep('success');
                setStatus('Ticket accepted. Keep the camera open for the next passenger.', 'success');
            } else if ((data.status || '') === 'cash_claim_pending') {
                playBeep('warning');
                setStatus('Cash ticket found. Collect payment, then confirm it from the panel.', 'warning');
            } else if ((data.status || '') === 'cash_claim_paid') {
                playBeep('success');
                setStatus('Cash ticket already paid. The final ticket is ready.', 'success');
            } else if ((data.status || '') === 'already_used') {
                playBeep('warning');
                setStatus('Already-used ticket detected. You can continue scanning.', 'warning');
            } else {
                setStatus('No valid ticket confirmed. Adjust the QR code and try again.', 'danger');
            }
        } catch (error) {
            lastDecodedText = '';
            lastScanAt = 0;
            renderResult({ status: 'invalid', message: 'Unable to validate the ticket right now.' });
            setStatus('Validation failed. The camera is still open and ready to scan again.', 'danger');
        } finally {
            isValidating = false;
        }
    }

    async function runScanner(cameraTarget, config) {
        await scanner.start(
            cameraTarget,
            config,
            function (decodedText) {
                void handleDecodedText(decodedText);
            },
            function () {
                // html5-qrcode emits frequent decode misses while searching;
                // we keep this silent for a smoother scanning experience.
            }
        );

        scannerStarted = true;
        syncButtons();
        setStatus('Camera is live. Hold the QR code steady inside the frame.', 'success');
    }

    async function startScanner() {
        if (scannerStarted) {
            return;
        }

        await unlockAudio();

        const readerWidth = readerNode.clientWidth || 320;
        const qrSize = Math.max(200, Math.min(260, readerWidth - 56));
        const config = {
            fps: 8,
            qrbox: { width: qrSize, height: qrSize },
            aspectRatio: 16 / 9,
            disableFlip: true
        };

        try {
            await runScanner({ facingMode: 'environment' }, config);
        } catch (error) {
            try {
                const cameras = await Html5Qrcode.getCameras();
                const fallbackCamera = (cameras || []).find(function (camera) {
                    return /back|rear|environment/i.test(camera.label || '');
                }) || (cameras || [])[0];

                if (!fallbackCamera) {
                    throw error;
                }

                await runScanner(fallbackCamera.id, config);
            } catch (fallbackError) {
                renderResult({ status: 'invalid', message: 'Unable to access the camera. Use manual validation instead.' });
                setStatus('Camera access failed. Manual validation is still available.', 'danger');
                scannerStarted = false;
                syncButtons();
            }
        }
    }

    async function stopScanner() {
        if (!scannerStarted) {
            return;
        }

        try {
            await scanner.stop();
        } catch (error) {
        }

        try {
            await scanner.clear();
        } catch (error) {
        }

        scannerStarted = false;
        isValidating = false;
        syncButtons();
        setStatus('Camera stopped. Start it again whenever you are ready.', 'secondary');
    }

    startButton.addEventListener('click', startScanner);
    stopButton.addEventListener('click', stopScanner);

    manualForm.addEventListener('submit', async function (event) {
        event.preventDefault();
        if (!manualPayload.value.trim()) {
            renderResult({ status: 'invalid', message: 'Paste QR data or a ticket code first.' });
            setStatus('Manual validation needs QR data or a ticket code.', 'warning');
            return;
        }

        try {
            await unlockAudio();
            setStatus('Validating pasted ticket data...', 'warning');
            const data = await validatePayload(manualPayload.value.trim());
            if ((data.status || '') === 'valid') {
                playBeep('success');
                setStatus('Manual validation succeeded.', 'success');
            } else if ((data.status || '') === 'cash_claim_pending') {
                playBeep('warning');
                setStatus('Cash ticket found. Collect payment, then confirm it below.', 'warning');
            } else if ((data.status || '') === 'cash_claim_paid') {
                playBeep('success');
                setStatus('Cash ticket already paid and converted to the final ticket.', 'success');
            } else if ((data.status || '') === 'already_used') {
                playBeep('warning');
                setStatus('That ticket was already used.', 'warning');
            } else {
                setStatus('Manual validation failed. Review the QR data and try again.', 'danger');
            }
        } catch (error) {
            renderResult({ status: 'invalid', message: 'Unable to validate the ticket right now.' });
            setStatus('Manual validation failed. Please try again.', 'danger');
        }
    });

    resultNode.addEventListener('click', async function (event) {
        const button = event.target.closest('[data-action="confirm-cash"]');
        if (!button) {
            return;
        }

        const bookingId = button.getAttribute('data-booking-id');
        if (!bookingId) {
            return;
        }

        const staffNote = window.prompt('Optional staff note for this terminal payment:', '') || '';
        button.disabled = true;
        setStatus('Confirming terminal payment and issuing the final ticket...', 'warning');

        try {
            const data = await confirmCashClaim(bookingId, staffNote);
            if ((data.status || '') === 'cash_claim_paid') {
                playBeep('success');
                setStatus('Terminal payment confirmed. Final seat and ticket are now issued.', 'success');
            } else {
                setStatus(data.message || 'Unable to confirm the cash payment right now.', 'danger');
            }
        } catch (error) {
            renderResult({ status: 'invalid', message: 'Unable to confirm the cash payment right now.' });
            setStatus('Cash confirmation failed. Please try again.', 'danger');
            button.disabled = false;
        }
    });

    window.addEventListener('pagehide', function () {
        if (scannerStarted) {
            scanner.stop().catch(function () {});
        }
    });

    syncButtons();
});
</script>

<?php admin_render_footer(); ?>
