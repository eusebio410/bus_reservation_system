<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$scheduleId = (int) isset_get('schedule_id');
$requestedDate = isset_get('departure_date');

if ($requestedDate !== '') {
    $dateObject = DateTimeImmutable::createFromFormat('!Y-m-d', $requestedDate, app_timezone());
    $dateErrors = DateTimeImmutable::getLastErrors();
    $isValidRequestedDate = $dateObject instanceof DateTimeImmutable
        && $dateObject->format('Y-m-d') === $requestedDate
        && ($dateErrors === false || ($dateErrors['warning_count'] === 0 && $dateErrors['error_count'] === 0));

    if (!$isValidRequestedDate) {
        $requestedDate = '';
    }
}

$selectedScheduleSummary = $scheduleId > 0
    ? db_select_one('SELECT schedule_id, departure_date FROM schedules WHERE schedule_id = ? LIMIT 1', 'i', [$scheduleId])
    : null;

$nextSchedule = db_select_one(
    'SELECT departure_date FROM schedules WHERE departure_date >= CURDATE() ORDER BY departure_date ASC, departure_time ASC LIMIT 1'
);

$activeDate = $requestedDate
    ?: ($selectedScheduleSummary['departure_date'] ?? ($nextSchedule['departure_date'] ?? date('Y-m-d')));

$schedules = db_select_all(
    "SELECT s.schedule_id, s.departure_date, s.departure_time, s.status,
            origin.terminal_name AS origin_name, destination.terminal_name AS destination_name,
            COALESCE(NULLIF(b.bus_name, ''), b.bus_code, 'Unassigned bus') AS bus_label
     FROM schedules s
     LEFT JOIN routes r ON s.route_id = r.route_id
     LEFT JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     LEFT JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     LEFT JOIN buses b ON s.bus_id = b.bus_id
     WHERE s.departure_date = ?
     ORDER BY s.departure_time ASC, s.schedule_id ASC",
    's',
    [$activeDate]
);

$scheduleIds = array_map(static fn(array $schedule): int => (int) $schedule['schedule_id'], $schedules);
if (!in_array($scheduleId, $scheduleIds, true) && $schedules !== []) {
    $scheduleId = (int) $schedules[0]['schedule_id'];
}

if ($schedules === []) {
    $scheduleId = 0;
}

$selectedSchedule = $scheduleId > 0 ? get_schedule_details($scheduleId) : null;
$seatMap = $scheduleId > 0 ? get_schedule_seat_map($scheduleId) : [];

admin_render_header('Seat Management', 'seats');
admin_page_header('Seat Management', 'Choose a departure date first, then load any schedule at that time to inspect its live seat map.');
?>

<style>
.seat-monitor-grid {
    display: grid;
    gap: 0.85rem;
    grid-template-columns: repeat(4, minmax(0, 1fr));
}
.seat-monitor-card {
    align-items: center;
    border-radius: 1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    min-height: 92px;
    padding: 0.75rem;
    text-align: center;
}
.seat-monitor-card.available {
    background: #fff;
    border: 1px solid rgba(15,23,42,0.08);
}
.seat-monitor-card.reserved {
    background: #fffaeb;
    border: 1px solid #fdb022;
}
.seat-monitor-card.booked,
.seat-monitor-card.used {
    background: #fef3f2;
    border: 1px solid #f97066;
}
</style>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <h2>Seat Monitor Filters</h2>
    </div>
    <div class="admin-card-body">
        <form method="get" class="row g-3" id="seat-monitor-filters">
            <div class="col-md-4">
                <label class="form-label" for="departure_date">Departure date</label>
                <input class="form-control" type="date" id="departure_date" name="departure_date" value="<?php echo e($activeDate); ?>" onchange="this.form.submit()">
            </div>
            <div class="col-md-5">
                <label class="form-label" for="schedule_id">Schedule</label>
                <select class="form-select" id="schedule_id" name="schedule_id" <?php echo $schedules === [] ? 'disabled' : ''; ?> onchange="this.form.submit()">
                    <?php if ($schedules === []): ?>
                        <option value="">No schedules on this date</option>
                    <?php else: ?>
                    <?php foreach ($schedules as $schedule): ?>
                        <option value="<?php echo (int) $schedule['schedule_id']; ?>" <?php echo $scheduleId === (int) $schedule['schedule_id'] ? 'selected' : ''; ?>>
                            <?php echo e($schedule['origin_name'] . ' to ' . $schedule['destination_name'] . ' • ' . date('M j, Y g:i A', strtotime($schedule['departure_date'] . ' ' . $schedule['departure_time']))); ?>
                        </option>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button class="btn btn-accent w-100" type="submit" <?php echo $schedules === [] ? 'disabled' : ''; ?>>Load Seat Map</button>
            </div>
            <div class="col-12">
                <div class="form-text">All departures for the selected date are shown, including early-morning trips such as 3:00 AM.</div>
            </div>
        </form>
    </div>
</div>

<?php if (!$selectedSchedule): ?>
    <div class="admin-card">
        <div class="admin-card-body">
            <p class="text-muted mb-0">No schedules were found for <?php echo e(date('F j, Y', strtotime($activeDate))); ?>. Choose another departure date to inspect its seat availability.</p>
        </div>
    </div>
<?php else: ?>
    <div class="stats-grid">
        <div class="stat-tile">
            <span class="label">Available Seats</span>
            <span class="value"><?php echo number_format(count(array_filter($seatMap, static fn($seat) => $seat['status'] === 'available'))); ?></span>
        </div>
        <div class="stat-tile">
            <span class="label">Reserved Seats</span>
            <span class="value"><?php echo number_format(count(array_filter($seatMap, static fn($seat) => $seat['status'] === 'reserved'))); ?></span>
        </div>
        <div class="stat-tile">
            <span class="label">Booked Seats</span>
            <span class="value"><?php echo number_format(count(array_filter($seatMap, static fn($seat) => $seat['status'] === 'booked'))); ?></span>
        </div>
        <div class="stat-tile">
            <span class="label">Used Seats</span>
            <span class="value"><?php echo number_format(count(array_filter($seatMap, static fn($seat) => $seat['status'] === 'used'))); ?></span>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo e($selectedSchedule['origin_name']); ?> to <?php echo e($selectedSchedule['destination_name']); ?></h2>
            <span class="chip soft"><?php echo e($selectedSchedule['bus_name'] ?: $selectedSchedule['bus_code']); ?> • <?php echo date('M j, Y g:i A', strtotime($selectedSchedule['departure_date'] . ' ' . $selectedSchedule['departure_time'])); ?></span>
        </div>
        <div class="admin-card-body">
            <div class="rounded-4 text-center text-white py-3 mb-4" style="background:linear-gradient(135deg,#10203b,#223a65);">
                <i class="fa-solid fa-steering-wheel me-2"></i>Driver / Front
            </div>
            <div class="seat-monitor-grid">
                <?php foreach ($seatMap as $seat): ?>
                    <div class="seat-monitor-card <?php echo e($seat['status']); ?>">
                        <strong><?php echo e($seat['seat_label']); ?></strong>
                        <small class="mt-1"><?php echo e(ucfirst($seat['status'])); ?></small>
                        <?php if (!empty($seat['meta']['booking_reference'])): ?>
                            <small class="text-muted mt-1"><?php echo e($seat['meta']['booking_reference']); ?></small>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php admin_render_footer(); ?>
