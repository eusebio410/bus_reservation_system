<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$dailyRevenue = db_select_all(
    "SELECT DATE(verified_at) AS report_date, COALESCE(SUM(amount), 0) AS total_revenue, COUNT(*) AS payments
     FROM payments
     WHERE status = 'paid'
     GROUP BY DATE(verified_at)
     ORDER BY report_date DESC
     LIMIT 30"
);

$monthlyRevenue = db_select_all(
    "SELECT DATE_FORMAT(verified_at, '%Y-%m') AS report_month, COALESCE(SUM(amount), 0) AS total_revenue, COUNT(*) AS payments
     FROM payments
     WHERE status = 'paid'
     GROUP BY YEAR(verified_at), MONTH(verified_at)
     ORDER BY report_month DESC
     LIMIT 12"
);

$popularRoutes = db_select_all(
    "SELECT origin.terminal_name AS origin_name, destination.terminal_name AS destination_name,
            COUNT(*) AS total_bookings, COALESCE(SUM(b.total_amount), 0) AS route_revenue
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     GROUP BY r.route_id
     ORDER BY total_bookings DESC
     LIMIT 10"
);

if (isset_get('export') === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="bus_reservation_report_' . date('Ymd_His') . '.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Category', 'Label', 'Bookings/Payments', 'Revenue']);

    foreach ($dailyRevenue as $row) {
        fputcsv($output, ['Daily Revenue', $row['report_date'], $row['payments'], $row['total_revenue']]);
    }
    foreach ($monthlyRevenue as $row) {
        fputcsv($output, ['Monthly Revenue', $row['report_month'], $row['payments'], $row['total_revenue']]);
    }
    foreach ($popularRoutes as $row) {
        fputcsv($output, ['Popular Route', $row['origin_name'] . ' to ' . $row['destination_name'], $row['total_bookings'], $row['route_revenue']]);
    }

    fclose($output);
    exit();
}

admin_render_header('Reports and Analytics', 'reports');
admin_page_header(
    'Reports and Analytics',
    'Review revenue, demand, and route performance. Export CSV for Excel or print this page to PDF.',
    [
        ['label' => 'Export CSV', 'href' => 'reports.php?export=csv', 'icon' => 'fa-file-csv', 'class' => 'btn btn-accent'],
    ]
);
?>

<div class="stats-grid">
    <div class="stat-tile">
        <span class="label">Revenue Days Tracked</span>
        <span class="value"><?php echo number_format(count($dailyRevenue)); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Months Tracked</span>
        <span class="value"><?php echo number_format(count($monthlyRevenue)); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Popular Routes</span>
        <span class="value"><?php echo number_format(count($popularRoutes)); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Print Friendly</span>
        <span class="value"><button class="btn btn-outline-secondary btn-sm" onclick="window.print()">Save PDF</button></span>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Daily Revenue</h2>
            </div>
            <div class="admin-card-body">
                <div class="table-responsive">
                    <table class="table admin-table align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Payments</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dailyRevenue as $row): ?>
                                <tr>
                                    <td><?php echo e($row['report_date']); ?></td>
                                    <td><?php echo number_format((int) $row['payments']); ?></td>
                                    <td>₱<?php echo number_format((float) $row['total_revenue'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-6">
        <div class="admin-card h-100">
            <div class="admin-card-header">
                <h2>Monthly Revenue</h2>
            </div>
            <div class="admin-card-body">
                <div class="table-responsive">
                    <table class="table admin-table align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Payments</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monthlyRevenue as $row): ?>
                                <tr>
                                    <td><?php echo e($row['report_month']); ?></td>
                                    <td><?php echo number_format((int) $row['payments']); ?></td>
                                    <td>₱<?php echo number_format((float) $row['total_revenue'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="admin-card">
            <div class="admin-card-header">
                <h2>Most Popular Routes</h2>
            </div>
            <div class="admin-card-body">
                <div class="table-responsive">
                    <table class="table admin-table align-middle mb-0">
                        <thead>
                            <tr>
                                <th>Route</th>
                                <th>Total Bookings</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($popularRoutes as $route): ?>
                                <tr>
                                    <td><?php echo e($route['origin_name']); ?> to <?php echo e($route['destination_name']); ?></td>
                                    <td><?php echo number_format((int) $route['total_bookings']); ?></td>
                                    <td>₱<?php echo number_format((float) $route['route_revenue'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
