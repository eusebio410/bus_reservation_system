<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

$action = isset_get('action');
$scheduleId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');
$currentUserId = (int) ($_SESSION['user_id'] ?? 0);

if ($action === 'delete' && $scheduleId > 0) {
    $scheduleForAudit = db_select_one(
        'SELECT schedule_id, schedule_code, recurrence_id, status, trip_status FROM schedules WHERE schedule_id = ? LIMIT 1',
        'i',
        [$scheduleId]
    );
    $hasBookings = db_select_one('SELECT COUNT(*) AS total FROM bookings WHERE schedule_id = ?', 'i', [$scheduleId]);

    if ((int) ($hasBookings['total'] ?? 0) > 0) {
        $error = 'This schedule already has bookings. Cancel the schedule instead of deleting it.';
    } elseif ((int) ($scheduleForAudit['recurrence_id'] ?? 0) > 0) {
        db_execute(
            'UPDATE schedules SET status = "cancelled", trip_status = "cancelled" WHERE schedule_id = ?',
            'i',
            [$scheduleId]
        );
        create_audit_log(
            $currentUserId,
            'schedule.cancelled',
            'schedule',
            $scheduleId,
            'Recurring schedule occurrence cancelled from dispatch calendar.',
            ['recurrence_id' => (int) $scheduleForAudit['recurrence_id']]
        );
        set_flash('success', 'This recurring occurrence was cancelled so it will not be automatically recreated for the same date and time.');
        redirect('manage-schedules.php');
    } elseif (db_execute('DELETE FROM schedules WHERE schedule_id = ?', 'i', [$scheduleId])) {
        create_audit_log(
            $currentUserId,
            'schedule.deleted',
            'schedule',
            $scheduleId,
            'Schedule deleted from dispatch calendar.',
            [
                'schedule_code' => (string) ($scheduleForAudit['schedule_code'] ?? ''),
                'status' => (string) ($scheduleForAudit['status'] ?? ''),
                'trip_status' => (string) ($scheduleForAudit['trip_status'] ?? ''),
            ]
        );
        set_flash('success', 'Schedule deleted successfully.');
        redirect('manage-schedules.php');
    } else {
        $error = 'Unable to delete the schedule.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_post('recurrence_action') === 'toggle') {
    $recurrenceId = (int) isset_post('recurrence_id');
    $recurrence = $recurrenceId > 0
        ? db_select_one('SELECT recurrence_id, is_active FROM schedule_recurrences WHERE recurrence_id = ? LIMIT 1', 'i', [$recurrenceId])
        : null;

    if (!$recurrence) {
        $error = 'The daily continuation plan could not be found.';
    } else {
        $isActive = (int) ($recurrence['is_active'] ?? 0) === 1 ? 0 : 1;
        if (db_execute('UPDATE schedule_recurrences SET is_active = ? WHERE recurrence_id = ?', 'ii', [$isActive, $recurrenceId])) {
            if ($isActive === 1) {
                materialize_schedule_recurrence($recurrenceId);
            }
            create_audit_log(
                $currentUserId,
                $isActive === 1 ? 'schedule.recurrence_resumed' : 'schedule.recurrence_paused',
                'schedule_recurrence',
                $recurrenceId,
                $isActive === 1 ? 'Daily schedule continuation resumed.' : 'Daily schedule continuation paused.',
                ['recurrence_id' => $recurrenceId]
            );
            set_flash('success', $isActive === 1
                ? 'Daily continuation resumed and the booking window was refreshed.'
                : 'Daily continuation paused. Existing trips stay unchanged.');
            redirect('manage-schedules.php');
        }
        $error = 'Unable to update the daily continuation plan.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset_post('recurrence_action') !== 'toggle') {
    $editId = (int) ($_POST['schedule_id'] ?? 0);
    $routeId = (int) ($_POST['route_id'] ?? 0);
    $busId = (int) ($_POST['bus_id'] ?? 0);
    $operatorId = (int) ($_POST['operator_id'] ?? 0);
    $departureDate = isset_post('departure_date');
    $departureTime = isset_post('departure_time');
    $arrivalTime = isset_post('arrival_time');
    $status = strtolower(isset_post('status') ?: 'scheduled');
    $status = $status === 'cancelled' ? 'cancelled' : 'scheduled';
    $tripStatus = $status === 'cancelled' ? 'cancelled' : 'scheduled';
    $repeatDaily = $editId === 0 && isset_post('repeat_daily') === '1';
    $existingScheduleForEdit = $editId > 0
        ? db_select_one(
            'SELECT schedule_id, schedule_code, route_id, operator_id, recurrence_id, departure_date, departure_time, status, trip_status
             FROM schedules WHERE schedule_id = ? LIMIT 1',
            'i',
            [$editId]
        )
        : null;

    if ($routeId < 1 || $departureDate === '' || $departureTime === '' || $arrivalTime === '') {
        $error = 'Please complete the route and schedule timing fields.';
    } elseif ($busId < 1) {
        $error = 'Please assign a specific bus to the schedule.';
    } elseif (!booking_date_within_allowed_window($departureDate)) {
        $error = 'Departure date must be from today through the next ' . MAX_ADVANCE_BOOKING_DAYS . ' days only.';
    } elseif ($repeatDaily && $status === 'cancelled') {
        $error = 'A cancelled schedule cannot start a daily continuation. Set it to scheduled or turn off automatic continuation.';
    } elseif (
        (int) ($existingScheduleForEdit['recurrence_id'] ?? 0) > 0
        && (
            $routeId !== (int) $existingScheduleForEdit['route_id']
            || $departureDate !== (string) $existingScheduleForEdit['departure_date']
            || $departureTime !== (string) $existingScheduleForEdit['departure_time']
        )
    ) {
        $error = 'The route, departure date, and departure time are locked for a recurring occurrence so the system does not recreate the original trip. Create a new schedule instead.';
    } elseif (schedule_duplicate_exists($routeId, $departureDate, $departureTime, $editId)) {
        $error = 'A schedule for this route already departs at that date and time. Edit the existing schedule or choose a different departure time.';
    } else {
        $fareRow = db_select_one('SELECT MIN(base_fare) AS price FROM fares WHERE route_id = ? LIMIT 1', 'i', [$routeId]);
        $price = round((float) ($fareRow['price'] ?? 0), 2);
        $selectedBus = db_select_one('SELECT * FROM buses WHERE bus_id = ? LIMIT 1', 'i', [$busId]);
        $selectedOperator = $operatorId > 0
            ? db_select_one('SELECT operator_id, full_name, status FROM bus_operators WHERE operator_id = ? LIMIT 1', 'i', [$operatorId])
            : null;

        if (!$selectedBus) {
            $error = 'The selected bus is invalid. Please choose a valid bus.';
        } elseif ($operatorId > 0 && (!$selectedOperator || ($selectedOperator['status'] ?? '') !== 'active')) {
            $error = 'The selected bus operator is unavailable. Please choose an active operator.';
        } elseif (bus_has_schedule_conflict($busId, $departureDate, $departureTime, $arrivalTime, $editId)) {
            $error = 'That bus already has a conflicting schedule at the selected time.';
        } elseif (operator_has_schedule_conflict($operatorId, $departureDate, $departureTime, $arrivalTime, $editId)) {
            $error = 'That bus operator already has a conflicting schedule at the selected time.';
        } else {
            $busType = $selectedBus['bus_type'] ?? '';
            $availableSeats = fixed_bus_seat_capacity();
            $existingSchedule = $existingScheduleForEdit;
            $recurrenceId = 0;

            if ($editId === 0 && $repeatDaily) {
                $recurrenceId = create_schedule_recurrence(
                    $routeId,
                    $busId,
                    $operatorId,
                    $busType,
                    $departureDate,
                    $departureTime,
                    $arrivalTime,
                    $price,
                    $currentUserId
                );

                if ($recurrenceId < 1) {
                    $error = 'Unable to enable the daily schedule continuation. No schedule was created.';
                }
            }

            if ($error === '' && $editId > 0) {
                $ok = db_execute(
                    'UPDATE schedules
                     SET bus_id = ?, route_id = ?, operator_id = ?, bus_type = ?, is_auto_assigned = ?, departure_date = ?, departure_time = ?, arrival_time = ?, price = ?, status = ?, trip_status = ?
                     WHERE schedule_id = ?',
                    'iiisisssdssi',
                    [$busId, $routeId, $operatorId, $busType, 0, $departureDate, $departureTime, $arrivalTime, $price, $status, $tripStatus, $editId]
                );
                $savedScheduleId = $editId;
                $scheduleCode = (string) ($existingSchedule['schedule_code'] ?? '');
                $message = 'Schedule updated successfully.';
                $auditAction = 'schedule.updated';
                $auditDescription = 'Schedule details updated in dispatch calendar.';
            } elseif ($error === '') {
                $scheduleCode = generate_reference('SCH', 6);
                $ok = db_execute(
                    'INSERT INTO schedules (schedule_code, bus_id, route_id, operator_id, bus_type, is_auto_assigned, recurrence_id, is_recurring_generated, departure_time, arrival_time, departure_date, price, available_seats, status, trip_status)
                     VALUES (?, ?, ?, ?, ?, 0, ?, 0, ?, ?, ?, ?, ?, ?, ?)',
                    'siiisisssdiss',
                    [$scheduleCode, $busId, $routeId, $operatorId, $busType, $recurrenceId ?: null, $departureTime, $arrivalTime, $departureDate, $price, $availableSeats, $status, $tripStatus]
                );
                $savedScheduleId = db_last_insert_id();
                $message = $recurrenceId > 0
                    ? 'Schedule created and daily continuation enabled.'
                    : 'Schedule created successfully.';
                $auditAction = 'schedule.created';
                $auditDescription = 'New schedule created in dispatch calendar.';
            }

            if (($ok ?? false) === true) {
                sync_schedule_available_seats($savedScheduleId);
                $generatedScheduleCount = 0;
                if ($recurrenceId > 0) {
                    $recurrenceResult = materialize_schedule_recurrence($recurrenceId);
                    $generatedScheduleCount = (int) ($recurrenceResult['created'] ?? 0);
                    $skippedConflictCount = (int) ($recurrenceResult['skipped_conflict'] ?? 0);
                    if ($generatedScheduleCount > 0) {
                        $message .= ' ' . $generatedScheduleCount . ' additional bookable day' . ($generatedScheduleCount === 1 ? ' was' : 's were') . ' added.';
                    }
                    if ($skippedConflictCount > 0) {
                        $message .= ' ' . $skippedConflictCount . ' future day' . ($skippedConflictCount === 1 ? ' was' : 's were') . ' skipped because the bus or operator already has a conflicting trip.';
                    }
                }
                create_audit_log(
                    $currentUserId,
                    $auditAction,
                    'schedule',
                    $savedScheduleId,
                    $auditDescription,
                    [
                        'schedule_code' => $scheduleCode,
                        'route_id' => $routeId,
                        'bus_id' => $busId,
                        'operator_id' => $operatorId,
                        'operator_name' => (string) ($selectedOperator['full_name'] ?? ''),
                        'bus_type' => $busType,
                        'departure_date' => $departureDate,
                        'departure_time' => $departureTime,
                        'arrival_time' => $arrivalTime,
                        'price' => $price,
                        'schedule_status' => $status,
                        'trip_status' => $tripStatus,
                        'recurrence_id' => $recurrenceId ?: (int) ($existingSchedule['recurrence_id'] ?? 0),
                        'daily_continuation_enabled' => $recurrenceId > 0,
                        'generated_schedule_count' => $generatedScheduleCount,
                        'auto_trip_status' => effective_schedule_trip_status([
                            'status' => $status,
                            'trip_status' => $tripStatus,
                            'departure_date' => $departureDate,
                            'departure_time' => $departureTime,
                            'arrival_time' => $arrivalTime,
                        ]),
                        'previous_schedule_status' => (string) ($existingSchedule['status'] ?? ''),
                        'previous_trip_status' => (string) ($existingSchedule['trip_status'] ?? ''),
                        'previous_operator_id' => (int) ($existingSchedule['operator_id'] ?? 0),
                    ]
                );
                set_flash('success', $message);
                redirect('manage-schedules.php');
            }

            if ($error === '') {
                if ($recurrenceId > 0) {
                    db_execute('UPDATE schedule_recurrences SET is_active = 0 WHERE recurrence_id = ?', 'i', [$recurrenceId]);
                }
                $error = 'Unable to save the schedule.';
            }
        }
    }
}

$editSchedule = null;
if ($action === 'edit' && $scheduleId > 0) {
    $editSchedule = db_select_one(
        'SELECT s.*, sr.is_active AS recurrence_is_active
         FROM schedules s
         LEFT JOIN schedule_recurrences sr ON s.recurrence_id = sr.recurrence_id
         WHERE s.schedule_id = ?
         LIMIT 1',
        'i',
        [$scheduleId]
    );
}

$routes = db_select_all(
    "SELECT r.route_id, origin.terminal_name AS origin_name, origin.location AS origin_location,
            destination.terminal_name AS destination_name, destination.location AS destination_location
     FROM routes r
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     ORDER BY origin.terminal_name ASC, destination.terminal_name ASC"
);

$buses = db_select_all(
    'SELECT bus_id, bus_code, bus_name, bus_type, total_seats
     FROM buses
     WHERE status = "active" AND is_enabled = 1
     ORDER BY bus_name ASC, bus_code ASC'
);

$operators = db_select_all(
    'SELECT operator_id, full_name, status
     FROM bus_operators
     WHERE status = "active"
        OR operator_id = ?
     ORDER BY FIELD(status, "active", "inactive"), full_name ASC',
    'i',
    [(int) ($editSchedule['operator_id'] ?? 0)]
);

$schedules = db_select_all(
    "SELECT s.*, sr.is_active AS recurrence_is_active, b.bus_code, b.bus_name, b.bus_type AS assigned_bus_type, b.total_seats,
            bo.full_name AS operator_name,
            origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
     FROM schedules s
     JOIN buses b ON s.bus_id = b.bus_id
     LEFT JOIN schedule_recurrences sr ON s.recurrence_id = sr.recurrence_id
     LEFT JOIN bus_operators bo ON s.operator_id = bo.operator_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     ORDER BY s.schedule_id DESC"
);

$schedules = array_map(static function (array $schedule): array {
    $schedule['effective_trip_status'] = effective_schedule_trip_status($schedule);
    $schedule['effective_status'] = effective_schedule_status($schedule);
    $schedule['departure_timestamp'] = departure_timestamp(
        (string) ($schedule['departure_date'] ?? ''),
        (string) ($schedule['departure_time'] ?? '')
    );
    $totalSeats = max(1, (int) ($schedule['total_seats'] ?? 0));
    $usedSeats = max(0, $totalSeats - (int) ($schedule['available_seats'] ?? 0));
    $schedule['load_percent'] = min(100, (int) round(($usedSeats / $totalSeats) * 100));
    return $schedule;
}, $schedules);

$todayDate = date('Y-m-d');
$activeUpcomingCount = count(array_filter($schedules, static fn($schedule) => ($schedule['effective_status'] ?? 'scheduled') === 'scheduled' && ($schedule['departure_date'] ?? '') >= $todayDate));
$liveTripsCount = count(array_filter($schedules, static fn($schedule) => in_array(($schedule['effective_trip_status'] ?? 'scheduled'), ['boarding', 'departed'], true)));
$cancelledCount = count(array_filter($schedules, static fn($schedule) => ($schedule['effective_status'] ?? 'scheduled') === 'cancelled'));
$autoAssignedCount = count(array_filter($schedules, static fn($schedule) => (int) ($schedule['is_auto_assigned'] ?? 0) === 1));
$boardingCount = count(array_filter($schedules, static fn($schedule) => ($schedule['effective_trip_status'] ?? 'scheduled') === 'boarding'));
$lowSeatTripsCount = count(array_filter($schedules, static fn($schedule) => (int) ($schedule['available_seats'] ?? 0) <= 5 && ($schedule['effective_status'] ?? 'scheduled') !== 'cancelled'));
$nextSchedules = array_values(
    array_filter(
        $schedules,
        static fn($schedule) => (int) ($schedule['departure_timestamp'] ?? 0) >= (time() - 3600)
            && ($schedule['effective_status'] ?? 'scheduled') !== 'cancelled'
    )
);

// Keep the dispatch preview focused on the next departure even though the main table is newest first.
usort($nextSchedules, static fn(array $left, array $right): int =>
    (int) ($left['departure_timestamp'] ?? 0) <=> (int) ($right['departure_timestamp'] ?? 0)
);
$nextSchedules = array_slice($nextSchedules, 0, 4);
$scheduleChipClass = static function (string $status): string {
    return match ($status) {
        'completed' => 'soft',
        'cancelled' => 'danger',
        default => 'success',
    };
};
$tripChipClass = static function (string $tripStatus): string {
    return match ($tripStatus) {
        'boarding' => 'warning',
        'departed' => 'soft',
        'arrived' => 'success',
        'cancelled' => 'danger',
        default => 'soft',
    };
};
$selectedEditScheduleStatus = (($editSchedule['status'] ?? 'scheduled') === 'cancelled') ? 'cancelled' : 'scheduled';
$scheduleDateMin = date('Y-m-d');
$scheduleDateMax = max_advance_booking_date();
$dispatchSummary = $nextSchedules === []
    ? 'No upcoming departures are currently available. Create a schedule to populate the live dispatch board.'
    : 'Next departure: ' . $nextSchedules[0]['origin_name'] . ' to ' . $nextSchedules[0]['destination_name'] . ' on ' . date('M j, g:i A', (int) $nextSchedules[0]['departure_timestamp']) . '.';
$schedulePageActions = is_admin()
    ? [
        ['label' => 'Manage Buses', 'href' => 'manage-buses.php', 'icon' => 'fa-bus', 'class' => 'btn btn-outline-secondary'],
        ['label' => 'Seat Overview', 'href' => 'manage-seats.php', 'icon' => 'fa-chair', 'class' => 'btn btn-outline-secondary'],
    ]
    : [
        ['label' => 'Seat Overview', 'href' => 'manage-seats.php', 'icon' => 'fa-chair', 'class' => 'btn btn-outline-secondary'],
        ['label' => 'Booking Board', 'href' => 'manage-bookings.php', 'icon' => 'fa-ticket', 'class' => 'btn btn-outline-secondary'],
    ];

admin_render_header('Schedule Management', 'schedules');
admin_page_header(
    'Schedule Management',
    'Create a one-time trip or keep a daily route automatically available throughout the booking window.',
    $schedulePageActions
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-toolbar-card">
    <div class="admin-toolbar-grid">
        <div class="admin-toolbar-copy">
            <span class="admin-toolbar-eyebrow">Dispatch Desk</span>
            <h2>Build departures and watch live trip flow</h2>
            <p><?php echo e($dispatchSummary); ?> This page should feel like the operations heart of the system, not just a plain CRUD table.</p>
        </div>
        <div class="admin-toolbar-actions">
            <a class="btn btn-outline-light" href="manage-seats.php">
                <i class="fa-solid fa-chair me-1"></i>Seat Status
            </a>
            <?php if (is_admin()): ?>
                <a class="btn btn-outline-light" href="manage-buses.php">
                    <i class="fa-solid fa-bus me-1"></i>Fleet
                </a>
            <?php else: ?>
                <a class="btn btn-outline-light" href="manage-bookings.php">
                    <i class="fa-solid fa-ticket me-1"></i>Booking Board
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="admin-split-grid">
    <div class="admin-card">
        <div class="admin-card-header">
            <div>
                <h2 id="schedule-form"><?php echo $editSchedule ? 'Edit Schedule' : 'Create Schedule'; ?></h2>
                <div class="admin-list-meta">Choose an existing route, assign a specific bus, and set timing and fare for a schedule that appears on the user dashboard.</div>
            </div>
            <span class="chip soft"><?php echo $editSchedule ? 'Editing existing trip' : 'New dispatch record'; ?></span>
        </div>
        <div class="admin-card-body">
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="schedule_id" value="<?php echo (int) ($editSchedule['schedule_id'] ?? 0); ?>">
                <div class="col-12">
                    <label class="form-label" for="route_id">Route</label>
                    <select class="form-select" id="route_id" name="route_id" required>
                        <option value="">Select a manually configured route</option>
                        <?php foreach ($routes as $route): ?>
                            <option value="<?php echo (int) $route['route_id']; ?>" <?php echo ((int) ($editSchedule['route_id'] ?? 0) === (int) $route['route_id']) ? 'selected' : ''; ?>>
                                <?php echo e($route['origin_name'] . ' (' . $route['origin_location'] . ') to ' . $route['destination_name'] . ' (' . $route['destination_location'] . ')'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label" for="bus_id">Assign Specific Bus</label>
                    <select class="form-select" id="bus_id" name="bus_id" required>
                        <option value="">Select a bus to assign</option>
                        <?php foreach ($buses as $bus): ?>
                            <option value="<?php echo (int) $bus['bus_id']; ?>" <?php echo ((int) ($editSchedule['bus_id'] ?? 0) === (int) $bus['bus_id']) ? 'selected' : ''; ?>>
                                <?php echo e(($bus['bus_name'] ?: $bus['bus_code']) . ' - ' . $bus['bus_type'] . ' - ' . $bus['total_seats'] . ' seats'); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-12">
                    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <label class="form-label mb-0" for="operator_id">Assign Bus Operator <span class="text-muted fw-normal">(Driver)</span></label>
                        <?php if (is_admin()): ?>
                            <a class="small fw-semibold" href="manage-operators.php"><i class="fa-solid fa-plus me-1"></i>Manage operators</a>
                        <?php endif; ?>
                    </div>
                    <select class="form-select mt-2" id="operator_id" name="operator_id">
                        <option value="0">Assign later — passengers will see Operator assignment pending</option>
                        <?php foreach ($operators as $operator): ?>
                            <option value="<?php echo (int) $operator['operator_id']; ?>" <?php echo ((int) ($editSchedule['operator_id'] ?? 0) === (int) $operator['operator_id']) ? 'selected' : ''; ?> <?php echo ($operator['status'] ?? '') === 'inactive' ? 'disabled' : ''; ?>>
                                <?php echo e($operator['full_name'] . (($operator['status'] ?? '') === 'inactive' ? ' (inactive)' : '')); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Only active operators can be newly assigned. The system checks for driver time conflicts before saving.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="departure_date">Departure Date</label>
                    <input class="form-control" type="date" id="departure_date" name="departure_date" min="<?php echo e($scheduleDateMin); ?>" max="<?php echo e($scheduleDateMax); ?>" value="<?php echo e($editSchedule['departure_date'] ?? $scheduleDateMin); ?>" required>
                    <div class="form-text">Available dates: today through <?php echo e(date('M j, Y', strtotime($scheduleDateMax))); ?>.</div>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="departure_time">Departure Time</label>
                    <input class="form-control" type="time" id="departure_time" name="departure_time" value="<?php echo e($editSchedule['departure_time'] ?? ''); ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label" for="arrival_time">Arrival Time</label>
                    <input class="form-control" type="time" id="arrival_time" name="arrival_time" value="<?php echo e($editSchedule['arrival_time'] ?? ''); ?>" required>
                    <div class="form-text">An arrival time earlier than departure is treated as arrival on the next day.</div>
                </div>
                <div class="col-12">
                    <div class="alert alert-secondary rounded-4">
                        Schedule fare is now determined automatically from route fares. If the route has no fare yet, the schedule will still save but the fare will display as zero until pricing is configured.
                    </div>
                </div>
                <?php if (!$editSchedule): ?>
                    <div class="col-12">
                        <div class="border rounded-4 p-3 bg-light">
                            <div class="form-check mb-1">
                                <input class="form-check-input" type="checkbox" value="1" id="repeat_daily" name="repeat_daily" checked>
                                <label class="form-check-label fw-semibold" for="repeat_daily">Automatically continue this schedule every day</label>
                            </div>
                            <div class="form-text ms-4">The system fills the booking window (today through the next <?php echo (int) MAX_ADVANCE_BOOKING_DAYS; ?> days), then adds the next day automatically. A matching route, date, and departure time is never duplicated.</div>
                        </div>
                    </div>
                <?php elseif ((int) ($editSchedule['recurrence_id'] ?? 0) > 0): ?>
                    <div class="col-12">
                        <div class="alert alert-info rounded-4 mb-0">
                            <i class="fa-solid fa-repeat me-1" aria-hidden="true"></i>
                            This is part of a daily recurring schedule. Changes here apply only to this departure; future daily trips continue using the original recurring plan.
                            <input type="hidden" name="recurrence_id" value="<?php echo (int) $editSchedule['recurrence_id']; ?>">
                            <button class="btn btn-sm <?php echo (int) ($editSchedule['recurrence_is_active'] ?? 0) === 1 ? 'btn-outline-warning' : 'btn-outline-success'; ?> ms-2" type="submit" name="recurrence_action" value="toggle">
                                <i class="fa-solid <?php echo (int) ($editSchedule['recurrence_is_active'] ?? 0) === 1 ? 'fa-pause' : 'fa-play'; ?> me-1" aria-hidden="true"></i>
                                <?php echo (int) ($editSchedule['recurrence_is_active'] ?? 0) === 1 ? 'Pause daily continuation' : 'Resume daily continuation'; ?>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col-md-6">
                    <label class="form-label" for="status">Schedule Status</label>
                    <select class="form-select" id="status" name="status">
                        <?php foreach (['scheduled', 'cancelled'] as $statusOption): ?>
                            <option value="<?php echo e($statusOption); ?>" <?php echo ($selectedEditScheduleStatus === $statusOption) ? 'selected' : ''; ?>>
                                <?php echo e(ucfirst($statusOption)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Trip progress like boarding, departed, and arrived is now calculated automatically from the schedule time.</div>
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editSchedule ? 'Update Schedule' : 'Create Schedule'; ?></button>
                    <?php if ($editSchedule): ?>
                        <a class="btn btn-outline-secondary" href="manage-schedules.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="d-grid gap-4">
        <div class="admin-card">
            <div class="admin-card-header">
                <div>
                    <h2>Dispatch Summary</h2>
                    <div class="admin-list-meta">Track the shape of your schedule board before you start editing individual departures.</div>
                </div>
                <span class="chip soft"><?php echo number_format(count($schedules)); ?> total schedules</span>
            </div>
            <div class="admin-card-body">
                <div class="admin-metric-grid mb-0">
                    <div class="admin-metric-card">
                        <span class="admin-metric-label">Auto Assigned</span>
                        <span class="admin-metric-value"><?php echo number_format($autoAssignedCount); ?></span>
                        <span class="admin-metric-copy"><?php echo number_format(count($schedules) - $autoAssignedCount); ?> were assigned manually.</span>
                    </div>
                    <div class="admin-metric-card">
                        <span class="admin-metric-label">Upcoming Active</span>
                        <span class="admin-metric-value"><?php echo number_format($activeUpcomingCount); ?></span>
                        <span class="admin-metric-copy"><?php echo number_format($boardingCount); ?> are already in the boarding window.</span>
                    </div>
                    <div class="admin-metric-card">
                        <span class="admin-metric-label">Live Trips</span>
                        <span class="admin-metric-value"><?php echo number_format($liveTripsCount); ?></span>
                        <span class="admin-metric-copy"><?php echo number_format($lowSeatTripsCount); ?> trips are close to selling out.</span>
                    </div>
                    <div class="admin-metric-card">
                        <span class="admin-metric-label">Cancelled</span>
                        <span class="admin-metric-value"><?php echo number_format($cancelledCount); ?></span>
                        <span class="admin-metric-copy">Cancelled departures stay visible here until you update or remove them.</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="admin-card">
            <div class="admin-card-header">
                <div>
                    <h2>Upcoming Dispatch Board</h2>
                    <div class="admin-list-meta">A quick visual list of the nearest departures so admins and staff can see trip pressure immediately.</div>
                </div>
                <span class="chip soft"><?php echo number_format(count($nextSchedules)); ?> upcoming</span>
            </div>
            <div class="admin-card-body">
                <?php if ($nextSchedules === []): ?>
                    <div class="admin-empty-state">No upcoming departures are ready to display yet.</div>
                <?php else: ?>
                    <div class="admin-list-stack">
                        <?php foreach ($nextSchedules as $schedule): ?>
                            <a class="admin-list-card" href="manage-schedules.php?action=edit&id=<?php echo (int) $schedule['schedule_id']; ?>">
                                <div class="admin-list-main">
                                    <div class="admin-list-title"><?php echo e($schedule['origin_name']); ?> to <?php echo e($schedule['destination_name']); ?></div>
                                    <div class="admin-list-copy"><?php echo e(($schedule['bus_name'] ?: $schedule['bus_code']) . ' | ' . date('M j, Y g:i A', (int) $schedule['departure_timestamp'])); ?></div>
                                    <div class="admin-list-meta"><i class="fa-solid fa-steering-wheel me-1" aria-hidden="true"></i><?php echo e($schedule['operator_name'] ?: 'Operator assignment pending'); ?></div>
                                    <div class="admin-list-meta"><?php echo number_format(max(0, (int) ($schedule['total_seats'] ?? 0) - (int) ($schedule['available_seats'] ?? 0))); ?> seats taken of <?php echo number_format((int) ($schedule['total_seats'] ?? 0)); ?></div>
                                    <div class="admin-progress"><span style="width: <?php echo (int) ($schedule['load_percent'] ?? 0); ?>%;"></span></div>
                                </div>
                                <div class="admin-list-side">
                                    <span class="chip <?php echo $tripChipClass((string) ($schedule['effective_trip_status'] ?? 'scheduled')); ?>"><?php echo e(ucfirst((string) ($schedule['effective_trip_status'] ?? 'scheduled'))); ?></span>
                                    <small class="text-muted"><?php echo number_format((int) ($schedule['load_percent'] ?? 0)); ?>% load</small>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <div>
            <h2>Dispatch Calendar</h2>
            <div class="admin-list-meta">The full schedule table still handles editing and deletion, but now it reads more like an operations board than a plain CRUD list.</div>
        </div>
        <span class="chip soft"><?php echo number_format(count($schedules)); ?> departures</span>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Code</th>
                        <th>Route</th>
                        <th>Bus / Operator</th>
                        <th>Departure</th>
                        <th>Fare</th>
                        <th>Seats</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($schedules === []): ?>
                        <tr><td colspan="8" class="text-center text-muted py-4">No schedules created yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($schedules as $schedule): ?>
                            <?php
                            $tripStatus = (string) ($schedule['effective_trip_status'] ?? 'scheduled');
                            $scheduleStatus = (string) ($schedule['effective_status'] ?? 'scheduled');
                            ?>
                            <tr>
                                <td><?php echo e($schedule['schedule_code']); ?></td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($schedule['origin_name']); ?> to <?php echo e($schedule['destination_name']); ?></div>
                                    <div class="small text-muted"><?php echo e($schedule['bus_type']); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e($schedule['bus_name'] ?: $schedule['bus_code']); ?></div>
                                    <div class="small text-muted"><?php echo (int) $schedule['is_auto_assigned'] === 1 ? 'Auto assigned' : 'Manual assignment'; ?></div>
                                    <?php if ((int) ($schedule['recurrence_id'] ?? 0) > 0): ?>
                                        <div class="small <?php echo (int) ($schedule['recurrence_is_active'] ?? 0) === 1 ? 'text-primary' : 'text-warning'; ?>"><i class="fa-solid fa-repeat me-1" aria-hidden="true"></i>Daily continuation<?php echo (int) ($schedule['recurrence_is_active'] ?? 0) === 1 ? '' : ' paused'; ?><?php echo (int) ($schedule['is_recurring_generated'] ?? 0) === 1 ? ' • auto-created' : ''; ?></div>
                                    <?php endif; ?>
                                    <div class="small text-muted"><i class="fa-solid fa-steering-wheel me-1" aria-hidden="true"></i><?php echo e($schedule['operator_name'] ?: 'Operator assignment pending'); ?></div>
                                </td>
                                <td>
                                    <div><?php echo date('M j, Y', strtotime($schedule['departure_date'])); ?></div>
                                    <div class="small text-muted"><?php echo date('g:i A', strtotime($schedule['departure_time'])); ?> to <?php echo date('g:i A', strtotime($schedule['arrival_time'])); ?></div>
                                </td>
                                <td>PHP <?php echo number_format((float) $schedule['price'], 2); ?></td>
                                <td>
                                    <div class="fw-semibold"><?php echo number_format((int) $schedule['available_seats']); ?> available</div>
                                    <div class="small text-muted"><?php echo number_format((int) ($schedule['total_seats'] ?? 0)); ?> total seats</div>
                                    <div class="admin-progress"><span style="width: <?php echo (int) ($schedule['load_percent'] ?? 0); ?>%;"></span></div>
                                </td>
                                <td>
                                    <div class="d-grid gap-2">
                                        <div class="d-flex flex-wrap gap-2">
                                            <span class="chip <?php echo $scheduleChipClass($scheduleStatus); ?>">Schedule: <?php echo e(ucfirst($scheduleStatus)); ?></span>
                                            <span class="chip <?php echo $tripChipClass($tripStatus); ?>">Trip: <?php echo e(ucfirst($tripStatus)); ?></span>
                                        </div>
                                        <?php if ($scheduleStatus === 'cancelled'): ?>
                                            <div class="small text-muted">Cancelled schedules stay cancelled until you edit them.</div>
                                        <?php else: ?>
                                            <div class="small text-muted">Trip status changes automatically from the departure and arrival time.</div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="admin-inline-actions">
                                        <a class="btn btn-sm btn-outline-secondary" href="manage-schedules.php?action=edit&id=<?php echo (int) $schedule['schedule_id']; ?>">Edit</a>
                                        <a class="btn btn-sm btn-outline-danger" href="manage-schedules.php?action=delete&id=<?php echo (int) $schedule['schedule_id']; ?>" onclick="return confirm('Delete this schedule?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
