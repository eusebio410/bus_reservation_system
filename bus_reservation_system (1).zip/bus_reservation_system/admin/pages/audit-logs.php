<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$filters = [
    'action_key' => isset_get('action_key'),
    'entity_type' => isset_get('entity_type'),
    'role_key' => isset_get('role_key'),
    'user_id' => (int) isset_get('user_id'),
    'date_from' => isset_get('date_from'),
    'date_to' => isset_get('date_to'),
];

$auditLogs = get_audit_logs($filters, 150);
$actionOptions = table_exists('audit_logs')
    ? db_select_all('SELECT DISTINCT action_key FROM audit_logs ORDER BY action_key ASC')
    : [];
$entityOptions = table_exists('audit_logs')
    ? db_select_all('SELECT DISTINCT entity_type FROM audit_logs ORDER BY entity_type ASC')
    : [];
$roleOptions = [
    ['role_key' => 'admin', 'role_name' => 'Admin'],
    ['role_key' => 'staff', 'role_name' => 'Staff'],
    ['role_key' => 'passenger', 'role_name' => 'Passenger'],
];
$actors = db_select_all(
    "SELECT u.user_id, u.fullname, COALESCE(r.role_name, CASE WHEN u.is_admin = 1 THEN 'Admin' ELSE 'Passenger' END) AS role_name
     FROM users u
     LEFT JOIN roles r ON u.role_id = r.role_id
     ORDER BY u.fullname ASC"
);

$logsToday = count(array_filter($auditLogs, static fn($log) => substr((string) ($log['created_at'] ?? ''), 0, 10) === date('Y-m-d')));
$actorCount = count(array_unique(array_filter(array_map(static fn($log) => (int) ($log['user_id'] ?? 0), $auditLogs))));
$scheduleActions = count(array_filter($auditLogs, static fn($log) => ($log['entity_type'] ?? '') === 'schedule'));
$paymentActions = count(array_filter($auditLogs, static fn($log) => ($log['entity_type'] ?? '') === 'payment'));

$formatActionLabel = static function (string $value): string {
    $value = str_replace(['.', '_', '-'], ' ', strtolower($value));
    return ucwords(trim($value));
};
$formatRoleLabel = static function (string $value): string {
    $value = trim($value);
    return $value === '' ? 'System' : ucfirst($value);
};
$contextPreview = static function (?string $json): string {
    if ($json === null || trim($json) === '') {
        return '';
    }

    $data = json_decode($json, true);
    if (!is_array($data) || $data === []) {
        return '';
    }

    $parts = [];
    $count = 0;
    foreach ($data as $key => $value) {
        if ($count >= 4) {
            break;
        }

        if (is_array($value)) {
            $value = implode(', ', array_map('strval', array_slice($value, 0, 3)));
        } elseif (is_bool($value)) {
            $value = $value ? 'yes' : 'no';
        }

        $parts[] = ucwords(str_replace('_', ' ', (string) $key)) . ': ' . (string) $value;
        $count++;
    }

    return implode("\n", $parts);
};
$roleChipClass = static function (string $roleKey): string {
    return match ($roleKey) {
        'admin' => 'success',
        'staff' => 'warning',
        'passenger' => 'soft',
        default => 'soft',
    };
};

admin_render_header('Audit Logs', 'audit');
admin_page_header(
    'Audit Logs',
    'Track important admin and staff activity so schedule changes, payment decisions, and sign-ins are easy to explain during your capstone demo.'
);
?>

<div class="admin-card mb-4">
    <div class="admin-card-header">
        <h2>Filter Activity</h2>
    </div>
    <div class="admin-card-body">
        <form method="get" class="row g-3">
            <div class="col-md-4">
                <label class="form-label" for="action_key">Action</label>
                <select class="form-select" id="action_key" name="action_key">
                    <option value="">All actions</option>
                    <?php foreach ($actionOptions as $option): ?>
                        <option value="<?php echo e($option['action_key']); ?>" <?php echo ($filters['action_key'] === $option['action_key']) ? 'selected' : ''; ?>>
                            <?php echo e($formatActionLabel((string) $option['action_key'])); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="entity_type">Entity</label>
                <select class="form-select" id="entity_type" name="entity_type">
                    <option value="">All entities</option>
                    <?php foreach ($entityOptions as $option): ?>
                        <option value="<?php echo e($option['entity_type']); ?>" <?php echo ($filters['entity_type'] === $option['entity_type']) ? 'selected' : ''; ?>>
                            <?php echo e(ucfirst((string) $option['entity_type'])); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="role_key">Role</label>
                <select class="form-select" id="role_key" name="role_key">
                    <option value="">All roles</option>
                    <?php foreach ($roleOptions as $role): ?>
                        <option value="<?php echo e($role['role_key']); ?>" <?php echo ($filters['role_key'] === $role['role_key']) ? 'selected' : ''; ?>>
                            <?php echo e($role['role_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="user_id">Actor</label>
                <select class="form-select" id="user_id" name="user_id">
                    <option value="0">All actors</option>
                    <?php foreach ($actors as $actor): ?>
                        <option value="<?php echo (int) $actor['user_id']; ?>" <?php echo ($filters['user_id'] === (int) $actor['user_id']) ? 'selected' : ''; ?>>
                            <?php echo e($actor['fullname'] . ' (' . $actor['role_name'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label" for="date_from">Date From</label>
                <input class="form-control" type="date" id="date_from" name="date_from" value="<?php echo e($filters['date_from']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label" for="date_to">Date To</label>
                <input class="form-control" type="date" id="date_to" name="date_to" value="<?php echo e($filters['date_to']); ?>">
            </div>
            <div class="col-12 d-flex gap-2">
                <button class="btn btn-accent" type="submit">Apply Filters</button>
                <a class="btn btn-outline-secondary" href="audit-logs.php">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-tile">
        <span class="label">Logs Shown</span>
        <span class="value"><?php echo number_format(count($auditLogs)); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Logged Today</span>
        <span class="value"><?php echo number_format($logsToday); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Actors Found</span>
        <span class="value"><?php echo number_format($actorCount); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Schedule Actions</span>
        <span class="value"><?php echo number_format($scheduleActions); ?></span>
    </div>
    <div class="stat-tile">
        <span class="label">Payment Actions</span>
        <span class="value"><?php echo number_format($paymentActions); ?></span>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Recent Activity</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>When</th>
                        <th>Actor</th>
                        <th>Action</th>
                        <th>Target</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($auditLogs === []): ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted py-4">No audit log entries match the current filters yet.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($auditLogs as $log): ?>
                            <?php $preview = $contextPreview($log['context_json'] ?? null); ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo date('M j, Y', strtotime((string) $log['created_at'])); ?></div>
                                    <div class="small text-muted"><?php echo date('g:i:s A', strtotime((string) $log['created_at'])); ?></div>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($log['actor_name'] ?: 'System'); ?></div>
                                    <div class="small text-muted"><?php echo e($log['actor_email'] ?: 'Automatic event'); ?></div>
                                    <div class="mt-2">
                                        <span class="chip <?php echo $roleChipClass((string) ($log['role_key'] ?? '')); ?>">
                                            <?php echo e($formatRoleLabel((string) ($log['role_key'] ?? ''))); ?>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($formatActionLabel((string) $log['action_key'])); ?></div>
                                    <div class="small text-muted"><?php echo e((string) $log['action_key']); ?></div>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e(ucfirst((string) $log['entity_type'])); ?></div>
                                    <div class="small text-muted">ID <?php echo number_format((int) ($log['entity_id'] ?? 0)); ?></div>
                                </td>
                                <td>
                                    <div><?php echo e((string) ($log['description'] ?? '')); ?></div>
                                    <?php if ($preview !== ''): ?>
                                        <div class="small text-muted mt-2" style="white-space: pre-line;"><?php echo e($preview); ?></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
