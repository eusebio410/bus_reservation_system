<?php
require_once '../../includes/config.php';

if (!is_logged_in() || !can_access_admin_panel()) {
    http_response_code(403);
    exit('Access denied.');
}

$paymentId = (int) isset_get('payment_id');
$payment = db_select_one(
    'SELECT payment_id, proof_image FROM payments WHERE payment_id = ? LIMIT 1',
    'i',
    [$paymentId]
);
$proofPath = trim(str_replace('\\', '/', (string) ($payment['proof_image'] ?? '')), '/');
$allowedPrefixes = ['storage/payment-proofs/', 'assets/uploads/payments/'];
$isAllowedPath = false;
foreach ($allowedPrefixes as $prefix) {
    if (strpos($proofPath, $prefix) === 0) {
        $isAllowedPath = true;
        break;
    }
}

$projectRoot = realpath(dirname(__DIR__, 2));
$absolutePath = $projectRoot && $isAllowedPath ? realpath($projectRoot . DIRECTORY_SEPARATOR . $proofPath) : false;
if (!$absolutePath || !$projectRoot || strpos($absolutePath, $projectRoot . DIRECTORY_SEPARATOR) !== 0 || !is_file($absolutePath)) {
    http_response_code(404);
    exit('Payment proof not found.');
}

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = $finfo ? (string) finfo_file($finfo, $absolutePath) : '';
if ($finfo) {
    finfo_close($finfo);
}

$allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
if (!in_array($mimeType, $allowedMimeTypes, true)) {
    http_response_code(404);
    exit('Payment proof is unavailable.');
}

header('Content-Type: ' . $mimeType);
header('Content-Length: ' . (string) filesize($absolutePath));
header('Content-Disposition: inline; filename="payment-proof-' . $paymentId . '.' . pathinfo($absolutePath, PATHINFO_EXTENSION) . '"');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
readfile($absolutePath);
exit();
