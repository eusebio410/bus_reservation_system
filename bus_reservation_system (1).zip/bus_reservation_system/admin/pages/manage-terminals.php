<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel()) {
    redirect('../login.php');
}

if (!is_admin()) {
    redirect('../dashboard.php');
}

$action = isset_get('action');
$terminalId = (int) isset_get('id');
$error = '';
$success = consume_flash('success');

if ($action === 'delete' && $terminalId > 0) {
    $routeCount = db_select_one(
        'SELECT COUNT(*) AS total FROM routes WHERE origin_terminal_id = ? OR destination_terminal_id = ?',
        'ii',
        [$terminalId, $terminalId]
    );

    if ((int) ($routeCount['total'] ?? 0) > 0) {
        $error = 'This terminal is already linked to existing routes. Reassign or remove those routes first.';
    } elseif (db_execute('DELETE FROM terminals WHERE terminal_id = ?', 'i', [$terminalId])) {
        set_flash('success', 'Terminal deleted successfully.');
        redirect('manage-terminals.php');
    } else {
        $error = 'Unable to delete the selected terminal.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editId = (int) ($_POST['terminal_id'] ?? 0);
    $terminalName = isset_post('terminal_name');
    $location = isset_post('location');
    $address = isset_post('address');
    $phoneInput = isset_post('phone');
    $phone = normalize_ph_phone($phoneInput);
    $email = strtolower(isset_post('email'));

    if ($terminalName === '' || $location === '') {
        $error = 'Terminal name and location are required.';
    } elseif ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
        $error = 'Please use a valid Philippine mobile number, such as 09171234567 or +639171234567.';
    } elseif ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        $error = 'Please enter a valid email address.';
    } else {
        $duplicate = db_select_one(
            'SELECT terminal_id FROM terminals WHERE terminal_name = ? AND terminal_id <> ? LIMIT 1',
            'si',
            [$terminalName, $editId]
        );

        if ($duplicate) {
            $error = 'That terminal name is already in use.';
        } else {
            if ($editId > 0) {
                $ok = db_execute(
                    'UPDATE terminals
                     SET terminal_name = ?, location = ?, address = ?, phone = ?, email = ?
                     WHERE terminal_id = ?',
                    'sssssi',
                    [$terminalName, $location, $address, $phone, $email, $editId]
                );
                $message = 'Terminal updated successfully.';
            } else {
                $ok = db_execute(
                    'INSERT INTO terminals (terminal_name, location, address, phone, email)
                     VALUES (?, ?, ?, ?, ?)',
                    'sssss',
                    [$terminalName, $location, $address, $phone, $email]
                );
                $message = 'Terminal added successfully.';
            }

            if ($ok) {
                set_flash('success', $message);
                redirect('manage-terminals.php');
            }

            $error = 'Unable to save the terminal record.';
        }
    }
}

$editTerminal = null;
if ($action === 'edit' && $terminalId > 0) {
    $editTerminal = db_select_one('SELECT * FROM terminals WHERE terminal_id = ? LIMIT 1', 'i', [$terminalId]);
}

$terminals = db_select_all(
    "SELECT t.*,
            COUNT(DISTINCT r.route_id) AS route_count
     FROM terminals t
     LEFT JOIN routes r
        ON r.origin_terminal_id = t.terminal_id
        OR r.destination_terminal_id = t.terminal_id
     GROUP BY t.terminal_id
     ORDER BY t.terminal_name ASC"
);

$withPhoneCount = count(array_filter($terminals, static fn($terminal) => trim((string) ($terminal['phone'] ?? '')) !== ''));
$withEmailCount = count(array_filter($terminals, static fn($terminal) => trim((string) ($terminal['email'] ?? '')) !== ''));
$linkedRouteCount = array_sum(array_map(static fn($terminal) => (int) ($terminal['route_count'] ?? 0), $terminals));

admin_render_header('Terminal Management', 'terminals');
admin_page_header(
    'Terminal Management',
    'Manage terminal contact details and keep the public terminal directory aligned with route operations.',
    [
        ['label' => 'Preview Public Terminals', 'href' => '../../terminals.php', 'icon' => 'fa-arrow-up-right-from-square', 'class' => 'btn-outline-secondary'],
    ]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="admin-grid-2">
    <div class="admin-card">
        <div class="admin-card-header">
            <h2><?php echo $editTerminal ? 'Edit Terminal' : 'Add Terminal'; ?></h2>
        </div>
        <div class="admin-card-body">
            <form method="post" class="row g-3">
                <?php csrf_field(); ?>
                <input type="hidden" name="terminal_id" value="<?php echo (int) ($editTerminal['terminal_id'] ?? 0); ?>">
                <div class="col-md-6">
                    <label class="form-label" for="terminal_name">Terminal Name</label>
                    <input class="form-control" type="text" id="terminal_name" name="terminal_name" value="<?php echo e($editTerminal['terminal_name'] ?? ''); ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="location">Location</label>
                    <input class="form-control" type="text" id="location" name="location" value="<?php echo e($editTerminal['location'] ?? ''); ?>" required>
                </div>
                <div class="col-12">
                    <label class="form-label" for="address">Address</label>
                    <textarea class="form-control" id="address" name="address" rows="3"><?php echo e($editTerminal['address'] ?? ''); ?></textarea>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="phone">Phone</label>
                    <input class="form-control" type="tel" id="phone" name="phone" inputmode="tel" pattern="(?:09\d{9}|\+639\d{9})" maxlength="13" placeholder="09171234567" value="<?php echo e($editTerminal['phone'] ?? ''); ?>">
                    <div class="form-text">Use a Philippine mobile number like <code>09171234567</code> or <code>+639171234567</code>.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label" for="email">Email</label>
                    <input class="form-control" type="email" id="email" name="email" value="<?php echo e($editTerminal['email'] ?? ''); ?>" placeholder="terminal@example.com">
                </div>
                <div class="col-12 d-flex gap-2">
                    <button class="btn btn-accent" type="submit"><?php echo $editTerminal ? 'Update Terminal' : 'Add Terminal'; ?></button>
                    <?php if ($editTerminal): ?>
                        <a class="btn btn-outline-secondary" href="manage-terminals.php">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="admin-card">
        <div class="admin-card-header">
            <h2>Terminal Summary</h2>
        </div>
        <div class="admin-card-body">
            <div class="stats-grid mb-0">
                <div class="stat-tile">
                    <span class="label">Total Terminals</span>
                    <span class="value"><?php echo number_format(count($terminals)); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">With Phone</span>
                    <span class="value"><?php echo number_format($withPhoneCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">With Email</span>
                    <span class="value"><?php echo number_format($withEmailCount); ?></span>
                </div>
                <div class="stat-tile">
                    <span class="label">Route Links</span>
                    <span class="value"><?php echo number_format($linkedRouteCount); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="admin-card mt-4">
    <div class="admin-card-header">
        <h2>Terminal Directory</h2>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Terminal</th>
                        <th>Location</th>
                        <th>Address</th>
                        <th>Contact</th>
                        <th>Routes</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($terminals === []): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No terminals found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($terminals as $terminal): ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($terminal['terminal_name']); ?></div>
                                </td>
                                <td><?php echo e($terminal['location']); ?></td>
                                <td class="text-muted"><?php echo e($terminal['address'] ?: 'No address provided'); ?></td>
                                <td>
                                    <div><?php echo e($terminal['phone'] ?: 'No phone'); ?></div>
                                    <div class="small text-muted"><?php echo e($terminal['email'] ?: 'No email'); ?></div>
                                </td>
                                <td><span class="chip soft"><?php echo number_format((int) ($terminal['route_count'] ?? 0)); ?> linked</span></td>
                                <td class="d-flex gap-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="manage-terminals.php?action=edit&id=<?php echo (int) $terminal['terminal_id']; ?>">Edit</a>
                                    <a class="btn btn-sm btn-outline-danger" href="manage-terminals.php?action=delete&id=<?php echo (int) $terminal['terminal_id']; ?>" onclick="return confirm('Delete this terminal?');">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
