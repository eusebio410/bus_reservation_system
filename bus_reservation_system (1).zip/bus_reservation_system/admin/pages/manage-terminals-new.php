<?php
$base_url = '';
include '../../includes/config.php';

if (!is_admin()) {
    redirect('../login.php');
}

// This retired duplicate used interpolated SQL and GET-based deletes. The maintained
// terminal manager has prepared statements, validation, CSRF protection, and route checks.
redirect('manage-terminals.php');

$action = isset_get('action');
$error = '';
$success = '';

// Handle delete
if ($action == 'delete') {
    $terminal_id = intval(isset_get('id'));
    $delete_query = "DELETE FROM terminals WHERE terminal_id = " . $terminal_id;
    if ($conn->query($delete_query)) {
        $success = "Terminal deleted successfully!";
    } else {
        $error = "Error deleting terminal.";
    }
}

// Handle add/edit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $terminal_name = sanitize($_POST['terminal_name']);
    $location = sanitize($_POST['location']);
    $address = sanitize($_POST['address']);
    $phoneInput = sanitize($_POST['phone']);
    $phone = normalize_ph_phone($phoneInput);
    $email = sanitize($_POST['email']);

    if ($phoneInput !== '' && !is_valid_ph_phone($phone)) {
        $error = 'Please enter a valid Philippine mobile number in the format +639123456789.';
    } elseif ($action == 'edit') {
        $terminal_id = intval(isset_get('id'));
        $update_query = "UPDATE terminals SET terminal_name = '" . $terminal_name . "', location = '" . $location . "', address = '" . $address . "', phone = '" . $phone . "', email = '" . $email . "' WHERE terminal_id = " . $terminal_id;
        if ($conn->query($update_query)) {
            $success = "Terminal updated successfully!";
        } else {
            $error = "Error updating terminal.";
        }
    } else {
        $insert_query = "INSERT INTO terminals (terminal_name, location, address, phone, email) VALUES ('" . $terminal_name . "', '" . $location . "', '" . $address . "', '" . $phone . "', '" . $email . "')";
        if ($conn->query($insert_query)) {
            $success = "Terminal added successfully!";
        } else {
            $error = "Error adding terminal.";
        }
    }
}

// Fetch terminals
$terminals_query = "SELECT * FROM terminals ORDER BY terminal_name";
$terminals_result = $conn->query($terminals_query);

$edit_terminal = null;
if ($action == 'edit') {
    $terminal_id = intval(isset_get('id'));
    $terminal_query = "SELECT * FROM terminals WHERE terminal_id = " . $terminal_id;
    $terminal_result = $conn->query($terminal_query);
    $edit_terminal = $terminal_result->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Terminals - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <style>
        :root {
            --bs-body-bg: #f8f9fa;
            --vl-red: #A72D2D;
            --vl-navy: #1a1a2e;
            --vl-yellow: #ffc107;
        }
        body {
            background-color: #f8f9fa;
            padding-top: 80px;
        }
        .admin-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(135deg, var(--vl-navy) 0%, var(--vl-navy) 100%);
            padding: 30px 0;
            padding-top: 80px;
            overflow-y: auto;
            z-index: 1000;
        }
        .admin-sidebar h3 {
            padding: 0 20px 20px 20px;
            color: var(--vl-yellow);
            font-weight: bold;
            border-bottom: 2px solid var(--vl-red);
            margin-bottom: 20px;
        }
        .admin-sidebar a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
        }
        .admin-sidebar a:hover,
        .admin-sidebar a.active {
            background-color: rgba(167, 45, 45, 0.2);
            color: var(--vl-yellow);
            border-left-color: var(--vl-red);
            padding-left: 25px;
        }
        .admin-sidebar a i {
            margin-right: 10px;
            width: 20px;
        }
        .admin-content {
            margin-left: 250px;
            padding: 30px;
        }
        @media (max-width: 768px) {
            body { padding-top: 120px; }
            .admin-sidebar {
                width: 100%;
                height: auto;
                position: relative;
                padding-top: 20px;
            }
            .admin-content {
                margin-left: 0;
            }
        }
        .page-title h1 {
            color: var(--vl-red);
            font-weight: bold;
            margin-bottom: 30px;
        }
        .card {
            background: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            overflow: hidden;
        }
        .card-header {
            background: linear-gradient(135deg, var(--vl-navy) 0%, var(--vl-red) 100%);
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            border: none;
        }
        .card-header h2 {
            margin: 0;
            font-size: 1.3rem;
            font-weight: bold;
        }
        .form-control:focus {
            border-color: var(--vl-red);
            box-shadow: 0 0 0 0.2rem rgba(167, 45, 45, 0.25);
        }
        .btn-primary-custom {
            background-color: var(--vl-red);
            border: none;
            padding: 10px 25px;
            font-weight: bold;
        }
        .btn-primary-custom:hover {
            background-color: #8a2222;
        }
        .btn-secondary-custom {
            background-color: #6c757d;
            border: none;
            padding: 10px 25px;
            font-weight: bold;
            margin-left: 10px;
        }
        .btn-secondary-custom:hover {
            background-color: #5a6268;
        }
        .alert-custom {
            border-radius: 8px;
            border: none;
            padding: 15px 20px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .alert-success-custom {
            background-color: #d4edda;
            color: #155724;
        }
        .alert-danger-custom {
            background-color: #f8d7da;
            color: #721c24;
        }
        table thead {
            background: linear-gradient(135deg, var(--vl-navy) 0%, var(--vl-red) 100%);
            color: white;
        }
        table thead th {
            padding: 15px;
            font-weight: bold;
            border: none;
        }
        table tbody td {
            padding: 15px;
            vertical-align: middle;
            border-bottom: 1px solid #e9ecef;
        }
        table tbody tr:hover {
            background-color: #f8f9fa;
        }
        .btn-sm {
            padding: 6px 12px;
            font-size: 0.85rem;
            margin-right: 5px;
        }
        .btn-edit {
            background-color: var(--vl-red);
            border: none;
            color: white;
        }
        .btn-edit:hover {
            background-color: #8a2222;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
            border: none;
            color: white;
        }
        .btn-delete:hover {
            background-color: #c82333;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color: var(--vl-navy);">
        <div class="container-fluid px-3">
            <a class="navbar-brand fw-bold" href="../dashboard.php">
                <i class="fas fa-bus" style="color: var(--vl-red);"></i> Victory Liner Admin
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user-circle"></i> Admin
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li>
                                <form method="post" action="../../logout.php?scope=admin">
                                    <?php csrf_field(); ?>
                                    <button class="dropdown-item text-danger" type="submit">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="admin-sidebar">
        <h3><i class="fas fa-cog"></i> Management</h3>
        <a href="../dashboard.php"><i class="fas fa-chart-line"></i> Dashboard</a>
        <a href="manage-buses.php"><i class="fas fa-cube"></i> Buses</a>
        <a href="manage-schedules.php"><i class="fas fa-calendar-alt"></i> Schedules</a>
        <a href="manage-routes.php"><i class="fas fa-road"></i> Routes</a>
        <a href="manage-terminals.php" class="active"><i class="fas fa-location-dot"></i> Terminals</a>
        <a href="manage-fares.php"><i class="fas fa-price-list"></i> Fares</a>
        <a href="manage-bookings.php"><i class="fas fa-ticket-alt"></i> Bookings</a>
        <a href="manage-users.php"><i class="fas fa-users"></i> Users</a>
        <a href="manage-faq.php"><i class="fas fa-question-circle"></i> FAQ</a>
    </div>

    <!-- Main Content -->
    <div class="admin-content">
        <div class="page-title">
            <h1><i class="fas fa-location-dot"></i> Manage Terminals</h1>
        </div>

        <?php if ($error): ?>
            <div class="alert-custom alert-danger-custom">
                <i class="fas fa-exclamation-circle"></i>
                <span><?php echo $error; ?></span>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert-custom alert-success-custom">
                <i class="fas fa-check-circle"></i>
                <span><?php echo $success; ?></span>
            </div>
        <?php endif; ?>

        <!-- Form Card -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-plus-circle"></i>
                <h2><?php echo ($edit_terminal) ? 'Edit Terminal' : 'Add New Terminal'; ?></h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="terminal_name" class="form-label"><i class="fas fa-building"></i> Terminal Name <span style="color: red;">*</span></label>
                            <input type="text" class="form-control" name="terminal_name" id="terminal_name" value="<?php echo $edit_terminal['terminal_name'] ?? ''; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label for="location" class="form-label"><i class="fas fa-map-marker-alt"></i> Location <span style="color: red;">*</span></label>
                            <input type="text" class="form-control" name="location" id="location" value="<?php echo $edit_terminal['location'] ?? ''; ?>" required>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="address" class="form-label"><i class="fas fa-home"></i> Address</label>
                        <textarea class="form-control" name="address" id="address" rows="2"><?php echo $edit_terminal['address'] ?? ''; ?></textarea>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="phone" class="form-label"><i class="fas fa-phone"></i> Phone Number</label>
                            <input type="tel" class="form-control" name="phone" id="phone" inputmode="numeric" placeholder="+639123456789" value="<?php echo $edit_terminal['phone'] ?? ''; ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="email" class="form-label"><i class="fas fa-envelope"></i> Email Address</label>
                            <input type="email" class="form-control" name="email" id="email" value="<?php echo $edit_terminal['email'] ?? ''; ?>">
                        </div>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary-custom"><i class="fas fa-save"></i> <?php echo ($edit_terminal) ? 'Update Terminal' : 'Add Terminal'; ?></button>
                        <?php if ($edit_terminal): ?>
                            <a href="manage-terminals.php" class="btn btn-secondary-custom"><i class="fas fa-times"></i> Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Terminals List Card -->
        <div class="card">
            <div class="card-header">
                <i class="fas fa-list"></i>
                <h2>Terminal List</h2>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><i class="fas fa-building"></i> Name</th>
                                <th><i class="fas fa-map-marker-alt"></i> Location</th>
                                <th><i class="fas fa-home"></i> Address</th>
                                <th><i class="fas fa-phone"></i> Phone</th>
                                <th><i class="fas fa-envelope"></i> Email</th>
                                <th><i class="fas fa-tools"></i> Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($terminal = $terminals_result->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo $terminal['terminal_name']; ?></strong></td>
                                    <td><?php echo $terminal['location']; ?></td>
                                    <td><?php echo $terminal['address']; ?></td>
                                    <td><?php echo $terminal['phone']; ?></td>
                                    <td><?php echo $terminal['email']; ?></td>
                                    <td>
                                        <a href="manage-terminals.php?action=edit&id=<?php echo $terminal['terminal_id']; ?>" class="btn btn-sm btn-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <a href="manage-terminals.php?action=delete&id=<?php echo $terminal['terminal_id']; ?>" class="btn btn-sm btn-delete" onclick="return confirm('Are you sure?')"><i class="fas fa-trash"></i> Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/script.js"></script>
</body>
</html>
