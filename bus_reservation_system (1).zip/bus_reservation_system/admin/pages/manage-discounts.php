<?php
require_once '../../includes/config.php';
require_once '../../includes/admin_layout.php';

if (!can_access_admin_panel() || !admin_page_permitted('discounts')) {
    redirect('../login.php');
}

$requiredDiscountColumns = [
    'id_type',
    'id_proof_path',
    'discount_status',
    'discount_percentage',
    'discount_cash_amount',
    'discount_cash_status',
    'discount_cash_paid_by',
    'discount_cash_paid_at',
];
$discountSchemaReady = true;
foreach ($requiredDiscountColumns as $column) {
    if (!column_exists('passengers', $column)) {
        $discountSchemaReady = false;
        break;
    }
}

if (!$discountSchemaReady) {
    admin_render_header('Discount Reviews', 'discounts');
    admin_page_header('Discount Reviews', 'Discount cash payout schema setup is required.');
    ?>
    <div class="alert alert-danger rounded-4">
        The database is missing discount review columns. From the project folder, run
        <code>C:\xampp\php\php.exe scripts\prepare_system.php</code>, then reload this page.
    </div>
    <?php
    admin_render_footer();
    exit();
}

$allowedStatuses = ['pending', 'approved', 'rejected', 'cash_due', 'cash_paid', 'all'];
$filterStatus = isset_get('status');
if (!in_array($filterStatus, $allowedStatuses, true)) {
    $filterStatus = 'pending';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passengerId = (int) ($_POST['passenger_id'] ?? 0);
    $nextStatus = $filterStatus;
    if (isset_post('action') === 'review_discount') {
        $decision = isset_post('decision');
        $result = review_passenger_discount($passengerId, $decision);
        $nextStatus = $decision === 'approve' ? 'cash_due' : 'rejected';
    } elseif (isset_post('action') === 'mark_cash_paid') {
        $result = complete_passenger_discount_cash($passengerId, (int) $_SESSION['user_id']);
        $nextStatus = 'cash_paid';
    } else {
        $result = ['ok' => false, 'message' => 'Invalid discount action.'];
    }
    set_flash($result['ok'] ? 'success' : 'error', $result['message']);
    redirect('manage-discounts.php?status=' . rawurlencode($nextStatus));
}

$error = consume_flash('error');
$success = consume_flash('success');
$pendingCount = db_select_one('SELECT COUNT(*) AS total FROM passengers WHERE discount_status = "pending"');

$sql = "SELECT p.passenger_id, p.fullname, p.seat_number, p.id_type, p.id_proof_path,
               p.discount_status, p.discount_percentage, p.discount_cash_amount, p.discount_cash_status,
               p.discount_cash_paid_at, p.created_at, cash_payer.fullname AS cash_paid_by_name,
               b.booking_id, b.booking_reference, b.total_amount, b.payment_status, b.payment_method,
               u.fullname AS account_name, s.departure_date, s.departure_time, s.price AS seat_fare,
               EXISTS (SELECT 1 FROM payments pp WHERE pp.booking_id = b.booking_id AND pp.provider = 'paymongo' AND pp.status = 'paid') AS has_paymongo_payment,
               COALESCE((SELECT f.discount_percentage FROM fares f
                         WHERE f.route_id = r.route_id AND f.class_id = bus.class_id
                         ORDER BY f.fare_id DESC LIMIT 1), 0) AS configured_discount_percentage,
               origin.terminal_name AS origin_name, destination.terminal_name AS destination_name
        FROM passengers p
        JOIN bookings b ON p.booking_id = b.booking_id
        JOIN users u ON b.user_id = u.user_id
        JOIN schedules s ON b.schedule_id = s.schedule_id
        JOIN routes r ON s.route_id = r.route_id
        JOIN buses bus ON s.bus_id = bus.bus_id
        JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
        JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
        LEFT JOIN users cash_payer ON p.discount_cash_paid_by = cash_payer.user_id";
$types = '';
$params = [];
if ($filterStatus === 'cash_due') {
    $sql .= ' WHERE p.discount_status = "approved" AND p.discount_cash_status = "due"';
} elseif ($filterStatus === 'cash_paid') {
    $sql .= ' WHERE p.discount_status = "approved" AND p.discount_cash_status = "paid"';
} elseif ($filterStatus !== 'all') {
    $sql .= ' WHERE p.discount_status = ?';
    $types = 's';
    $params[] = $filterStatus;
}
$sql .= ' ORDER BY CASE WHEN p.discount_status = "pending" THEN 0 ELSE 1 END, p.created_at DESC';
$claims = db_select_all($sql, $types, $params);

admin_render_header('Discount Reviews', 'discounts');
admin_page_header(
    'Discount Reviews',
    'Review ID proofs after PayMongo confirms payment, then track the bus operator cash payout.',
    [['label' => 'Booking Board', 'href' => 'manage-bookings.php', 'icon' => 'fa-ticket', 'class' => 'btn btn-outline-secondary']]
);
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger rounded-4"><?php echo e($error); ?></div>
<?php endif; ?>
<?php if ($success !== ''): ?>
    <div class="alert alert-success rounded-4"><?php echo e($success); ?></div>
<?php endif; ?>

<div class="alert alert-warning rounded-4">
    The full fare is paid through PayMongo. After approval, hand the calculated discount to each passenger in cash at departure and record the payout here. This system does not authenticate IDs against government records.
</div>

<div class="admin-metric-grid">
    <div class="admin-metric-card">
        <span class="admin-metric-label">Pending ID Reviews</span>
        <span class="admin-metric-value"><?php echo number_format((int) ($pendingCount['total'] ?? 0)); ?></span>
        <span class="admin-metric-copy">Pending ID review does not block PayMongo checkout.</span>
    </div>
    <div class="admin-metric-card">
        <span class="admin-metric-label">Requests Shown</span>
        <span class="admin-metric-value"><?php echo number_format(count($claims)); ?></span>
        <span class="admin-metric-copy">Filtered by <?php echo e($filterStatus); ?> status.</span>
    </div>
</div>

<div class="admin-card mb-4">
    <div class="admin-card-header"><h2>Filter discount requests</h2></div>
    <div class="admin-card-body">
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label" for="status">Review status</label>
                <select class="form-select" id="status" name="status">
                    <?php foreach ($allowedStatuses as $statusOption): ?>
                        <option value="<?php echo e($statusOption); ?>" <?php echo $filterStatus === $statusOption ? 'selected' : ''; ?>><?php echo e(ucwords(str_replace('_', ' ', $statusOption))); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-auto"><button class="btn btn-accent" type="submit">Apply</button></div>
            <div class="col-auto"><a class="btn btn-outline-secondary" href="manage-discounts.php">Pending queue</a></div>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <div>
            <h2>Passenger discount requests</h2>
            <div class="admin-list-meta">The PayMongo charge stays unchanged. The approved Manage Fares rate creates a separate cash payout for each passenger.</div>
        </div>
        <span class="chip soft"><?php echo number_format(count($claims)); ?> requests</span>
    </div>
    <div class="admin-card-body">
        <div class="table-responsive">
            <table class="table admin-table align-middle mb-0">
                <thead>
                    <tr>
                        <th>Passenger</th>
                        <th>Booking and trip</th>
                        <th>ID proof</th>
                        <th>Manage Fares rate</th>
                        <th>PayMongo / cash</th>
                        <th>Review / payout</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($claims === []): ?>
                        <tr><td colspan="6" class="text-center text-muted py-4">No discount requests match this filter.</td></tr>
                    <?php else: ?>
                        <?php foreach ($claims as $claim): ?>
                            <?php $statusClass = $claim['discount_status'] === 'approved' ? 'success' : ($claim['discount_status'] === 'pending' ? 'warning' : 'danger'); ?>
                            <tr>
                                <td>
                                    <div class="fw-semibold"><?php echo e($claim['fullname']); ?></div>
                                    <div class="small text-muted">Account: <?php echo e($claim['account_name']); ?></div>
                                    <div class="small text-muted">Seat <?php echo e($claim['seat_number']); ?></div>
                                </td>
                                <td>
                                    <a class="fw-semibold" href="booking-view.php?booking_id=<?php echo (int) $claim['booking_id']; ?>"><?php echo e($claim['booking_reference']); ?></a>
                                    <div class="small"><?php echo e($claim['origin_name']); ?> to <?php echo e($claim['destination_name']); ?></div>
                                    <div class="small text-muted"><?php echo e(date('M j, Y', strtotime((string) $claim['departure_date']))); ?> · PHP <?php echo number_format((float) $claim['seat_fare'], 2); ?> per seat</div>
                                </td>
                                <td>
                                    <div class="fw-semibold"><?php echo e($claim['id_type']); ?></div>
                                    <?php if ($claim['id_proof_path'] !== ''): ?>
                                        <a class="btn btn-sm btn-outline-secondary mt-1" href="discount-id-proof.php?passenger_id=<?php echo (int) $claim['passenger_id']; ?>" target="_blank" rel="noopener">
                                            <i class="fa-solid fa-id-card me-1"></i>View proof
                                        </a>
                                    <?php else: ?>
                                        <span class="small text-danger">Proof missing</span>
                                    <?php endif; ?>
                                </td>
                                <?php
                                $shownPercentage = $claim['discount_status'] === 'pending'
                                    ? (float) $claim['configured_discount_percentage']
                                    : (float) $claim['discount_percentage'];
                                $cashAmount = $claim['discount_status'] === 'pending'
                                    ? round((float) $claim['seat_fare'] * $shownPercentage / 100, 2)
                                    : (float) $claim['discount_cash_amount'];
                                ?>
                                <td><?php echo number_format($shownPercentage, 2); ?>%</td>
                                <td>
                                    <div>PayMongo: PHP <?php echo number_format((float) $claim['total_amount'], 2); ?></div>
                                    <div class="small text-muted">Cash discount: PHP <?php echo number_format($cashAmount, 2); ?></div>
                                </td>
                                <td>
                                    <span class="badge text-bg-<?php echo e($statusClass); ?>"><?php echo e(ucfirst((string) $claim['discount_status'])); ?></span>
                                    <?php if ($claim['discount_status'] === 'pending'): ?>
                                        <?php if (!empty($claim['has_paymongo_payment'])): ?>
                                            <div class="d-flex flex-wrap gap-2 mt-2">
                                                <?php foreach (['approve' => 'Approve discount', 'reject' => 'Decline'] as $decision => $label): ?>
                                                    <?php if ($decision === 'approve' && (float) $claim['configured_discount_percentage'] <= 0): ?>
                                                        <?php continue; ?>
                                                    <?php endif; ?>
                                                    <form method="post">
                                                        <?php csrf_field(); ?>
                                                        <input type="hidden" name="action" value="review_discount">
                                                        <input type="hidden" name="passenger_id" value="<?php echo (int) $claim['passenger_id']; ?>">
                                                        <input type="hidden" name="decision" value="<?php echo e($decision); ?>">
                                                        <input type="hidden" name="status" value="<?php echo e($filterStatus); ?>">
                                                        <button class="btn btn-sm <?php echo $decision === 'approve' ? 'btn-success' : 'btn-outline-danger'; ?>" type="submit"><?php echo e($label); ?></button>
                                                    </form>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php else: ?>
                                            <div class="small text-muted mt-2">Waiting for PayMongo payment confirmation.</div>
                                        <?php endif; ?>
                                    <?php elseif ($claim['discount_status'] === 'approved' && $claim['discount_cash_status'] === 'due'): ?>
                                        <div class="small text-success mt-2">Cash due at departure</div>
                                        <form method="post" class="mt-2" onsubmit="return confirm('Confirm that the bus operator handed this cash discount to the passenger?');">
                                            <?php csrf_field(); ?>
                                            <input type="hidden" name="action" value="mark_cash_paid">
                                            <input type="hidden" name="passenger_id" value="<?php echo (int) $claim['passenger_id']; ?>">
                                            <input type="hidden" name="status" value="<?php echo e($filterStatus); ?>">
                                            <button class="btn btn-sm btn-success" type="submit">Mark cash paid</button>
                                        </form>
                                    <?php elseif ($claim['discount_status'] === 'approved' && $claim['discount_cash_status'] === 'paid'): ?>
                                        <div class="small text-success mt-2">Cash paid by <?php echo e($claim['cash_paid_by_name'] ?: 'staff'); ?></div>
                                        <div class="small text-muted"><?php echo e($claim['discount_cash_paid_at'] ? date('M j, Y g:i A', strtotime((string) $claim['discount_cash_paid_at'])) : ''); ?></div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php admin_render_footer(); ?>
