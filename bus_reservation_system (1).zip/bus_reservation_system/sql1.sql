-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: bus_reservation_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `bus_reservation_db`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `bus_reservation_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `bus_reservation_db`;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_posts` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `author_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`post_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `blog_posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `schedule_id` int(11) NOT NULL,
  `booking_reference` varchar(20) NOT NULL,
  `claim_code` varchar(40) DEFAULT NULL,
  `number_of_passengers` int(11) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `payment_method` varchar(40) DEFAULT NULL,
  `payment_status` varchar(30) NOT NULL DEFAULT 'pending',
  `seat_preferences` text DEFAULT NULL,
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_reference` (`booking_reference`),
  UNIQUE KEY `uniq_bookings_claim_code` (`claim_code`),
  KEY `user_id` (`user_id`),
  KEY `schedule_id` (`schedule_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (24,2,8,'GON260403L96DGYAT',NULL,1,1500.00,'payment_review','gcash','pending','[\"S16\"]','2026-04-03 14:51:17','2026-04-03 14:52:01',NULL,NULL,NULL),(25,2,8,'GON2604034USHNNJZ','CTK260403YRK9L9KH',1,1500.00,'pending','cash','pending','[\"S10\"]','2026-04-03 14:55:11','2026-04-03 14:56:02','2026-04-04 14:30:00',NULL,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bus_classes`
--

DROP TABLE IF EXISTS `bus_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bus_classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_name` varchar(50) NOT NULL,
  `capacity` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `amenities` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`class_id`),
  UNIQUE KEY `class_name` (`class_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bus_classes`
--

LOCK TABLES `bus_classes` WRITE;
/*!40000 ALTER TABLE `bus_classes` DISABLE KEYS */;
INSERT INTO `bus_classes` VALUES (1,'Regular AC',48,'Standard air-conditioned provincial coach','Air-conditioned, Reclining Seats','2026-04-02 10:53:53'),(2,'First Class / Deluxe',29,'Deluxe bus used for Gonzaga departures','Air-conditioned, Larger Seats, Charging Ports','2026-04-02 10:53:53'),(3,'Premium - Victory Royal Sleeper',32,'Sleeper configuration for overnight provincial service','Sleeper Seats, Curtains, Charging Ports','2026-04-02 10:53:53');
/*!40000 ALTER TABLE `bus_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buses`
--

DROP TABLE IF EXISTS `buses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buses` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_code` varchar(20) NOT NULL,
  `bus_name` varchar(120) DEFAULT NULL,
  `bus_type` varchar(60) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `registration_number` varchar(20) DEFAULT NULL,
  `model` varchar(100) DEFAULT NULL,
  `year_manufactured` int(11) DEFAULT NULL,
  `total_seats` int(11) DEFAULT NULL,
  `status` enum('active','maintenance','retired') DEFAULT 'active',
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `seat_map_columns` int(11) NOT NULL DEFAULT 4,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`bus_id`),
  UNIQUE KEY `bus_code` (`bus_code`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `buses_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `bus_classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buses`
--

LOCK TABLES `buses` WRITE;
/*!40000 ALTER TABLE `buses` DISABLE KEYS */;
INSERT INTO `buses` VALUES (1,'GON-DELUXE-01','GON-DELUXE-01','First Class / Deluxe',2,'GON-001','Deluxe Coach',2024,29,'active',1,4,'2026-04-03 08:01:10'),(2,'GON-DELUXE-02','GON-DELUXE-02','First Class / Deluxe',2,'GON-002','Deluxe Coach',2024,29,'active',1,4,'2026-04-03 08:01:10'),(3,'GON-DELUXE-03','GON-DELUXE-03','First Class / Deluxe',2,'GON-003','Deluxe Coach',2023,29,'active',1,4,'2026-04-03 08:01:10'),(4,'GON-DELUXE-04','GON-DELUXE-04','First Class / Deluxe',2,'GON-004','Deluxe Coach',2023,29,'active',1,4,'2026-04-03 08:01:10'),(5,'GON-SLEEPER-01','GON-SLEEPER-01','Premium - Victory Royal Sleeper',3,'GON-101','Sleeper Coach',2025,32,'active',1,4,'2026-04-03 08:01:10');
/*!40000 ALTER TABLE `buses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faqs` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) DEFAULT NULL,
  `question` text NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`faq_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faqs`
--

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'Booking','How do I book a ticket?','You can book tickets through our website by selecting your route, date, and preferred bus class. Provide passenger details and proceed to payment.','2026-04-02 10:53:53'),(2,'Booking','Can I cancel my booking?','Yes, you can cancel up to 24 hours before departure for a full refund. Cancellations within 24 hours will have a 25% cancellation fee.','2026-04-02 10:53:53'),(3,'Baggage','What is the baggage allowance?','Passengers are allowed 1 piece of luggage (max 25kg) for free. Additional luggage costs ₱100 per piece.','2026-04-02 10:53:53'),(4,'Baggage','Can I bring oversized baggage?','Oversized baggage can be accommodated for an additional charge. Please contact our office for details.','2026-04-02 10:53:53'),(5,'Travel','What time should I arrive at the terminal?','Please arrive 30 minutes before departure for domestic trips.','2026-04-02 10:53:53'),(6,'Travel','Are meals provided during the journey?','Yes, complimentary snacks and drinks are provided on all services. Full meals are served on longer routes.','2026-04-02 10:53:53'),(7,'Refund','What is the refund policy?','Full refunds are available for cancellations 24 hours before departure. Partial refunds are applicable for cancellations within 24 hours.','2026-04-02 10:53:53'),(8,'Accessibility','Is the bus wheelchair accessible?','Most of our buses have wheelchair accessibility features. Please inform us when booking if you require assistance.','2026-04-02 10:53:53');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fares`
--

DROP TABLE IF EXISTS `fares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fares` (
  `fare_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `base_fare` decimal(10,2) NOT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`fare_id`),
  KEY `route_id` (`route_id`),
  KEY `class_id` (`class_id`),
  CONSTRAINT `fares_ibfk_1` FOREIGN KEY (`route_id`) REFERENCES `routes` (`route_id`),
  CONSTRAINT `fares_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `bus_classes` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fares`
--

LOCK TABLES `fares` WRITE;
/*!40000 ALTER TABLE `fares` DISABLE KEYS */;
INSERT INTO `fares` VALUES (1,1,2,1450.00,0.00,'2026-04-03 08:01:10'),(2,1,3,1850.00,0.00,'2026-04-03 08:01:10'),(3,2,2,1500.00,0.00,'2026-04-03 08:01:10');
/*!40000 ALTER TABLE `fares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `notification_type` varchar(30) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `idx_notifications_user` (`user_id`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (87,2,24,'booking','Seats reserved','Your selected seats are reserved while you complete the booking flow.',1,'2026-04-03 14:51:18'),(88,2,24,'booking','Passenger details saved','Your seats are reserved while your GCash payment is being submitted.',1,'2026-04-03 14:51:41'),(89,2,24,'payment','GCash proof submitted','Your payment proof sent to +639565780262 is pending manual staff verification.',1,'2026-04-03 14:52:01'),(90,2,25,'booking','Seat preference saved','Your seat preference was saved. Final seat assignment will happen after terminal payment is confirmed.',0,'2026-04-03 14:55:11'),(91,2,25,'booking','Passenger details saved','Passenger details were saved. Final seat assignment and ticket issuance will happen after terminal payment is confirmed.',0,'2026-04-03 14:55:37'),(92,2,25,'payment','Terminal payment pending','Your terminal cash ticket is ready. Pay at the terminal before departure on Apr 4, 2026 2:30 PM. Your seat selection stays as a preference until staff confirms payment and issues the final ticket.',0,'2026-04-03 14:56:02');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `passengers`
--

DROP TABLE IF EXISTS `passengers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passengers` (
  `passenger_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` enum('M','F') DEFAULT 'M',
  `id_type` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`passenger_id`),
  KEY `booking_id` (`booking_id`),
  CONSTRAINT `passengers_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passengers`
--

LOCK TABLES `passengers` WRITE;
/*!40000 ALTER TABLE `passengers` DISABLE KEYS */;
INSERT INTO `passengers` VALUES (30,24,'jm mape','jm@gmail.com','+639565780262','S16',23,'M',NULL,NULL,'2026-04-03 14:51:41'),(31,25,'jm mape','jm@gmail.com','+639565780261','S10',22,'M',NULL,NULL,'2026-04-03 14:55:37');
/*!40000 ALTER TABLE `passengers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `payment_reference` varchar(40) NOT NULL,
  `payment_method` varchar(30) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `proof_image` varchar(255) DEFAULT NULL,
  `admin_notes` text DEFAULT NULL,
  `submitted_at` datetime DEFAULT current_timestamp(),
  `verified_at` datetime DEFAULT NULL,
  `verified_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`payment_id`),
  UNIQUE KEY `payment_reference` (`payment_reference`),
  KEY `idx_payments_booking` (`booking_id`),
  CONSTRAINT `fk_payments_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (19,24,'PAY260403RJNHJTEA','gcash',1500.00,'pending','assets/uploads/payments/PAY2604033VMKU45Y.jpg',NULL,'2026-04-03 22:52:01',NULL,NULL,'2026-04-03 14:52:01'),(20,25,'PAY260403U2EUULUZ','cash',1500.00,'pending',NULL,NULL,'2026-04-03 22:56:02',NULL,NULL,'2026-04-03 14:56:02');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr_logs`
--

DROP TABLE IF EXISTS `qr_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qr_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `scan_status` varchar(20) NOT NULL,
  `scan_message` varchar(255) DEFAULT NULL,
  `scan_payload` longtext DEFAULT NULL,
  `scanned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_qr_logs_ticket` (`ticket_id`),
  CONSTRAINT `fk_qr_logs_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`ticket_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr_logs`
--

LOCK TABLES `qr_logs` WRITE;
/*!40000 ALTER TABLE `qr_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `qr_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL AUTO_INCREMENT,
  `role_key` varchar(30) NOT NULL,
  `role_name` varchar(80) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `role_key` (`role_key`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','Administrator','Full control of the platform.','2026-04-03 08:39:46'),(2,'staff','Staff','Operational access for payments, bookings, and QR validation.','2026-04-03 08:39:46'),(3,'passenger','Passenger','Standard passenger account.','2026-04-03 08:39:46');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `routes`
--

DROP TABLE IF EXISTS `routes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `routes` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `origin_terminal_id` int(11) NOT NULL,
  `destination_terminal_id` int(11) NOT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  `travel_time` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`route_id`),
  UNIQUE KEY `uniq_route_pair` (`origin_terminal_id`,`destination_terminal_id`),
  KEY `destination_terminal_id` (`destination_terminal_id`),
  CONSTRAINT `routes_ibfk_1` FOREIGN KEY (`origin_terminal_id`) REFERENCES `terminals` (`terminal_id`),
  CONSTRAINT `routes_ibfk_2` FOREIGN KEY (`destination_terminal_id`) REFERENCES `terminals` (`terminal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `routes`
--

LOCK TABLES `routes` WRITE;
/*!40000 ALTER TABLE `routes` DISABLE KEYS */;
INSERT INTO `routes` VALUES (1,1,2,620.00,720,'2026-04-03 08:01:10'),(2,1,3,635.00,750,'2026-04-03 08:01:10');
/*!40000 ALTER TABLE `routes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schedules`
--

DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `schedule_id` int(11) NOT NULL AUTO_INCREMENT,
  `schedule_code` varchar(30) DEFAULT NULL,
  `bus_id` int(11) NOT NULL,
  `route_id` int(11) NOT NULL,
  `bus_type` varchar(60) DEFAULT NULL,
  `is_auto_assigned` tinyint(1) NOT NULL DEFAULT 0,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `available_seats` int(11) NOT NULL,
  `status` enum('scheduled','cancelled','completed') DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`schedule_id`),
  KEY `bus_id` (`bus_id`),
  KEY `route_id` (`route_id`),
  CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`bus_id`),
  CONSTRAINT `schedules_ibfk_2` FOREIGN KEY (`route_id`) REFERENCES `routes` (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `schedules`
--

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES (1,'SCH-00001',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-03',1450.00,29,'scheduled','2026-04-03 08:01:10'),(2,'SCH-00002',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-03',1450.00,29,'scheduled','2026-04-03 08:01:10'),(3,'SCH-00003',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-03',1500.00,29,'scheduled','2026-04-03 08:01:10'),(4,'SCH-00004',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-03',1450.00,29,'scheduled','2026-04-03 08:01:10'),(5,'SCH-00005',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-03',1850.00,32,'scheduled','2026-04-03 08:01:10'),(6,'SCH-00006',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-04',1450.00,29,'scheduled','2026-04-03 08:01:10'),(7,'SCH-00007',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-04',1450.00,29,'scheduled','2026-04-03 08:01:10'),(8,'SCH-00008',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-04',1500.00,28,'scheduled','2026-04-03 08:01:10'),(9,'SCH-00009',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-04',1450.00,29,'scheduled','2026-04-03 08:01:10'),(10,'SCH-00010',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-04',1850.00,32,'scheduled','2026-04-03 08:01:10'),(11,'SCH-00011',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-05',1450.00,29,'scheduled','2026-04-03 08:01:10'),(12,'SCH-00012',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-05',1450.00,29,'scheduled','2026-04-03 08:01:10'),(13,'SCH-00013',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-05',1500.00,29,'scheduled','2026-04-03 08:01:10'),(14,'SCH-00014',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-05',1450.00,29,'scheduled','2026-04-03 08:01:10'),(15,'SCH-00015',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-05',1850.00,32,'scheduled','2026-04-03 08:01:10'),(16,'SCH-00016',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-06',1450.00,29,'scheduled','2026-04-03 08:01:10'),(17,'SCH-00017',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-06',1450.00,29,'scheduled','2026-04-03 08:01:10'),(18,'SCH-00018',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-06',1500.00,29,'scheduled','2026-04-03 08:01:10'),(19,'SCH-00019',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-06',1450.00,29,'scheduled','2026-04-03 08:01:10'),(20,'SCH-00020',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-06',1850.00,32,'scheduled','2026-04-03 08:01:10'),(21,'SCH-00021',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-07',1450.00,29,'scheduled','2026-04-03 08:01:10'),(22,'SCH-00022',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-07',1450.00,29,'scheduled','2026-04-03 08:01:10'),(23,'SCH-00023',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-07',1500.00,29,'scheduled','2026-04-03 08:01:10'),(24,'SCH-00024',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-07',1450.00,29,'scheduled','2026-04-03 08:01:10'),(25,'SCH-00025',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-07',1850.00,32,'scheduled','2026-04-03 08:01:10'),(26,'SCH-00026',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-08',1450.00,29,'scheduled','2026-04-03 08:01:10'),(27,'SCH-00027',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-08',1450.00,29,'scheduled','2026-04-03 08:01:10'),(28,'SCH-00028',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-08',1500.00,29,'scheduled','2026-04-03 08:01:10'),(29,'SCH-00029',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-08',1450.00,29,'scheduled','2026-04-03 08:01:10'),(30,'SCH-00030',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-08',1850.00,32,'scheduled','2026-04-03 08:01:10'),(31,'SCH-00031',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-09',1450.00,29,'scheduled','2026-04-03 08:01:10'),(32,'SCH-00032',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-09',1450.00,29,'scheduled','2026-04-03 08:01:10'),(33,'SCH-00033',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-09',1500.00,29,'scheduled','2026-04-03 08:01:10'),(34,'SCH-00034',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-09',1450.00,29,'scheduled','2026-04-03 08:01:10'),(35,'SCH-00035',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-09',1850.00,32,'scheduled','2026-04-03 08:01:10'),(36,'SCH-00036',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-10',1450.00,29,'scheduled','2026-04-03 08:01:10'),(37,'SCH-00037',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-10',1450.00,29,'scheduled','2026-04-03 08:01:10'),(38,'SCH-00038',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-10',1500.00,29,'scheduled','2026-04-03 08:01:10'),(39,'SCH-00039',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-10',1450.00,29,'scheduled','2026-04-03 08:01:10'),(40,'SCH-00040',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-10',1850.00,32,'scheduled','2026-04-03 08:01:10'),(41,'SCH-00041',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-11',1450.00,29,'scheduled','2026-04-03 08:01:10'),(42,'SCH-00042',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-11',1450.00,29,'scheduled','2026-04-03 08:01:10'),(43,'SCH-00043',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-11',1500.00,29,'scheduled','2026-04-03 08:01:10'),(44,'SCH-00044',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-11',1450.00,29,'scheduled','2026-04-03 08:01:10'),(45,'SCH-00045',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-11',1850.00,32,'scheduled','2026-04-03 08:01:10'),(46,'SCH-00046',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-12',1450.00,29,'scheduled','2026-04-03 08:01:10'),(47,'SCH-00047',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-12',1450.00,29,'scheduled','2026-04-03 08:01:10'),(48,'SCH-00048',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-12',1500.00,29,'scheduled','2026-04-03 08:01:10'),(49,'SCH-00049',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-12',1450.00,29,'scheduled','2026-04-03 08:01:10'),(50,'SCH-00050',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-12',1850.00,32,'scheduled','2026-04-03 08:01:10'),(51,'SCH-00051',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-13',1450.00,29,'scheduled','2026-04-03 08:01:10'),(52,'SCH-00052',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-13',1450.00,29,'scheduled','2026-04-03 08:01:10'),(53,'SCH-00053',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-13',1500.00,29,'scheduled','2026-04-03 08:01:10'),(54,'SCH-00054',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-13',1450.00,29,'scheduled','2026-04-03 08:01:10'),(55,'SCH-00055',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-13',1850.00,32,'scheduled','2026-04-03 08:01:10'),(56,'SCH-00056',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-14',1450.00,29,'scheduled','2026-04-03 08:01:10'),(57,'SCH-00057',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-14',1450.00,29,'scheduled','2026-04-03 08:01:10'),(58,'SCH-00058',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-14',1500.00,29,'scheduled','2026-04-03 08:01:10'),(59,'SCH-00059',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-14',1450.00,29,'scheduled','2026-04-03 08:01:10'),(60,'SCH-00060',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-14',1850.00,32,'scheduled','2026-04-03 08:01:10'),(61,'SCH-00061',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-15',1450.00,29,'scheduled','2026-04-03 08:01:10'),(62,'SCH-00062',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-15',1450.00,29,'scheduled','2026-04-03 08:01:10'),(63,'SCH-00063',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-15',1500.00,29,'scheduled','2026-04-03 08:01:10'),(64,'SCH-00064',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-15',1450.00,29,'scheduled','2026-04-03 08:01:10'),(65,'SCH-00065',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-15',1850.00,32,'scheduled','2026-04-03 08:01:10'),(66,'SCH-00066',1,1,'First Class / Deluxe',0,'12:30:00','00:30:00','2026-04-16',1450.00,29,'scheduled','2026-04-03 08:01:10'),(67,'SCH-00067',2,1,'First Class / Deluxe',0,'14:00:00','02:00:00','2026-04-16',1450.00,29,'scheduled','2026-04-03 08:01:10'),(68,'SCH-00068',3,2,'First Class / Deluxe',0,'14:30:00','03:00:00','2026-04-16',1500.00,29,'scheduled','2026-04-03 08:01:10'),(69,'SCH-00069',4,1,'First Class / Deluxe',0,'15:00:00','03:00:00','2026-04-16',1450.00,29,'scheduled','2026-04-03 08:01:10'),(70,'SCH-00070',5,1,'Premium - Victory Royal Sleeper',0,'15:30:00','03:30:00','2026-04-16',1850.00,32,'scheduled','2026-04-03 08:01:10');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seats`
--

DROP TABLE IF EXISTS `seats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seats` (
  `seat_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `seat_number` int(11) NOT NULL,
  `seat_label` varchar(20) NOT NULL,
  `seat_row` int(11) NOT NULL,
  `seat_column` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`seat_id`),
  UNIQUE KEY `uniq_bus_seat_number` (`bus_id`,`seat_number`),
  UNIQUE KEY `uniq_bus_seat_label` (`bus_id`,`seat_label`),
  CONSTRAINT `fk_seats_bus` FOREIGN KEY (`bus_id`) REFERENCES `buses` (`bus_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seats`
--

LOCK TABLES `seats` WRITE;
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
INSERT INTO `seats` VALUES (1,1,1,'S01',1,1,1,'2026-04-03 08:39:46'),(2,1,2,'S02',1,2,1,'2026-04-03 08:39:46'),(3,1,3,'S03',1,3,1,'2026-04-03 08:39:46'),(4,1,4,'S04',1,4,1,'2026-04-03 08:39:46'),(5,1,5,'S05',2,1,1,'2026-04-03 08:39:46'),(6,1,6,'S06',2,2,1,'2026-04-03 08:39:46'),(7,1,7,'S07',2,3,1,'2026-04-03 08:39:46'),(8,1,8,'S08',2,4,1,'2026-04-03 08:39:46'),(9,1,9,'S09',3,1,1,'2026-04-03 08:39:46'),(10,1,10,'S10',3,2,1,'2026-04-03 08:39:46'),(11,1,11,'S11',3,3,1,'2026-04-03 08:39:46'),(12,1,12,'S12',3,4,1,'2026-04-03 08:39:46'),(13,1,13,'S13',4,1,1,'2026-04-03 08:39:46'),(14,1,14,'S14',4,2,1,'2026-04-03 08:39:46'),(15,1,15,'S15',4,3,1,'2026-04-03 08:39:47'),(16,1,16,'S16',4,4,1,'2026-04-03 08:39:47'),(17,1,17,'S17',5,1,1,'2026-04-03 08:39:47'),(18,1,18,'S18',5,2,1,'2026-04-03 08:39:47'),(19,1,19,'S19',5,3,1,'2026-04-03 08:39:47'),(20,1,20,'S20',5,4,1,'2026-04-03 08:39:47'),(21,1,21,'S21',6,1,1,'2026-04-03 08:39:47'),(22,1,22,'S22',6,2,1,'2026-04-03 08:39:47'),(23,1,23,'S23',6,3,1,'2026-04-03 08:39:47'),(24,1,24,'S24',6,4,1,'2026-04-03 08:39:47'),(25,1,25,'S25',7,1,1,'2026-04-03 08:39:47'),(26,1,26,'S26',7,2,1,'2026-04-03 08:39:47'),(27,1,27,'S27',7,3,1,'2026-04-03 08:39:47'),(28,1,28,'S28',7,4,1,'2026-04-03 08:39:47'),(29,1,29,'S29',8,1,1,'2026-04-03 08:39:47'),(30,2,1,'S01',1,1,1,'2026-04-03 08:39:47'),(31,2,2,'S02',1,2,1,'2026-04-03 08:39:47'),(32,2,3,'S03',1,3,1,'2026-04-03 08:39:47'),(33,2,4,'S04',1,4,1,'2026-04-03 08:39:47'),(34,2,5,'S05',2,1,1,'2026-04-03 08:39:47'),(35,2,6,'S06',2,2,1,'2026-04-03 08:39:47'),(36,2,7,'S07',2,3,1,'2026-04-03 08:39:47'),(37,2,8,'S08',2,4,1,'2026-04-03 08:39:47'),(38,2,9,'S09',3,1,1,'2026-04-03 08:39:47'),(39,2,10,'S10',3,2,1,'2026-04-03 08:39:47'),(40,2,11,'S11',3,3,1,'2026-04-03 08:39:47'),(41,2,12,'S12',3,4,1,'2026-04-03 08:39:47'),(42,2,13,'S13',4,1,1,'2026-04-03 08:39:47'),(43,2,14,'S14',4,2,1,'2026-04-03 08:39:47'),(44,2,15,'S15',4,3,1,'2026-04-03 08:39:47'),(45,2,16,'S16',4,4,1,'2026-04-03 08:39:47'),(46,2,17,'S17',5,1,1,'2026-04-03 08:39:47'),(47,2,18,'S18',5,2,1,'2026-04-03 08:39:47'),(48,2,19,'S19',5,3,1,'2026-04-03 08:39:47'),(49,2,20,'S20',5,4,1,'2026-04-03 08:39:47'),(50,2,21,'S21',6,1,1,'2026-04-03 08:39:47'),(51,2,22,'S22',6,2,1,'2026-04-03 08:39:47'),(52,2,23,'S23',6,3,1,'2026-04-03 08:39:47'),(53,2,24,'S24',6,4,1,'2026-04-03 08:39:47'),(54,2,25,'S25',7,1,1,'2026-04-03 08:39:47'),(55,2,26,'S26',7,2,1,'2026-04-03 08:39:47'),(56,2,27,'S27',7,3,1,'2026-04-03 08:39:47'),(57,2,28,'S28',7,4,1,'2026-04-03 08:39:47'),(58,2,29,'S29',8,1,1,'2026-04-03 08:39:47'),(59,3,1,'S01',1,1,1,'2026-04-03 08:39:47'),(60,3,2,'S02',1,2,1,'2026-04-03 08:39:47'),(61,3,3,'S03',1,3,1,'2026-04-03 08:39:47'),(62,3,4,'S04',1,4,1,'2026-04-03 08:39:47'),(63,3,5,'S05',2,1,1,'2026-04-03 08:39:47'),(64,3,6,'S06',2,2,1,'2026-04-03 08:39:47'),(65,3,7,'S07',2,3,1,'2026-04-03 08:39:47'),(66,3,8,'S08',2,4,1,'2026-04-03 08:39:47'),(67,3,9,'S09',3,1,1,'2026-04-03 08:39:47'),(68,3,10,'S10',3,2,1,'2026-04-03 08:39:47'),(69,3,11,'S11',3,3,1,'2026-04-03 08:39:47'),(70,3,12,'S12',3,4,1,'2026-04-03 08:39:47'),(71,3,13,'S13',4,1,1,'2026-04-03 08:39:47'),(72,3,14,'S14',4,2,1,'2026-04-03 08:39:47'),(73,3,15,'S15',4,3,1,'2026-04-03 08:39:47'),(74,3,16,'S16',4,4,1,'2026-04-03 08:39:47'),(75,3,17,'S17',5,1,1,'2026-04-03 08:39:47'),(76,3,18,'S18',5,2,1,'2026-04-03 08:39:47'),(77,3,19,'S19',5,3,1,'2026-04-03 08:39:47'),(78,3,20,'S20',5,4,1,'2026-04-03 08:39:47'),(79,3,21,'S21',6,1,1,'2026-04-03 08:39:47'),(80,3,22,'S22',6,2,1,'2026-04-03 08:39:47'),(81,3,23,'S23',6,3,1,'2026-04-03 08:39:47'),(82,3,24,'S24',6,4,1,'2026-04-03 08:39:47'),(83,3,25,'S25',7,1,1,'2026-04-03 08:39:47'),(84,3,26,'S26',7,2,1,'2026-04-03 08:39:47'),(85,3,27,'S27',7,3,1,'2026-04-03 08:39:47'),(86,3,28,'S28',7,4,1,'2026-04-03 08:39:47'),(87,3,29,'S29',8,1,1,'2026-04-03 08:39:47'),(88,4,1,'S01',1,1,1,'2026-04-03 08:39:47'),(89,4,2,'S02',1,2,1,'2026-04-03 08:39:47'),(90,4,3,'S03',1,3,1,'2026-04-03 08:39:47'),(91,4,4,'S04',1,4,1,'2026-04-03 08:39:47'),(92,4,5,'S05',2,1,1,'2026-04-03 08:39:47'),(93,4,6,'S06',2,2,1,'2026-04-03 08:39:47'),(94,4,7,'S07',2,3,1,'2026-04-03 08:39:47'),(95,4,8,'S08',2,4,1,'2026-04-03 08:39:47'),(96,4,9,'S09',3,1,1,'2026-04-03 08:39:47'),(97,4,10,'S10',3,2,1,'2026-04-03 08:39:47'),(98,4,11,'S11',3,3,1,'2026-04-03 08:39:47'),(99,4,12,'S12',3,4,1,'2026-04-03 08:39:47'),(100,4,13,'S13',4,1,1,'2026-04-03 08:39:47'),(101,4,14,'S14',4,2,1,'2026-04-03 08:39:47'),(102,4,15,'S15',4,3,1,'2026-04-03 08:39:47'),(103,4,16,'S16',4,4,1,'2026-04-03 08:39:47'),(104,4,17,'S17',5,1,1,'2026-04-03 08:39:47'),(105,4,18,'S18',5,2,1,'2026-04-03 08:39:47'),(106,4,19,'S19',5,3,1,'2026-04-03 08:39:47'),(107,4,20,'S20',5,4,1,'2026-04-03 08:39:47'),(108,4,21,'S21',6,1,1,'2026-04-03 08:39:47'),(109,4,22,'S22',6,2,1,'2026-04-03 08:39:47'),(110,4,23,'S23',6,3,1,'2026-04-03 08:39:47'),(111,4,24,'S24',6,4,1,'2026-04-03 08:39:47'),(112,4,25,'S25',7,1,1,'2026-04-03 08:39:47'),(113,4,26,'S26',7,2,1,'2026-04-03 08:39:47'),(114,4,27,'S27',7,3,1,'2026-04-03 08:39:47'),(115,4,28,'S28',7,4,1,'2026-04-03 08:39:47'),(116,4,29,'S29',8,1,1,'2026-04-03 08:39:47'),(117,5,1,'S01',1,1,1,'2026-04-03 08:39:47'),(118,5,2,'S02',1,2,1,'2026-04-03 08:39:47'),(119,5,3,'S03',1,3,1,'2026-04-03 08:39:47'),(120,5,4,'S04',1,4,1,'2026-04-03 08:39:47'),(121,5,5,'S05',2,1,1,'2026-04-03 08:39:47'),(122,5,6,'S06',2,2,1,'2026-04-03 08:39:47'),(123,5,7,'S07',2,3,1,'2026-04-03 08:39:47'),(124,5,8,'S08',2,4,1,'2026-04-03 08:39:47'),(125,5,9,'S09',3,1,1,'2026-04-03 08:39:47'),(126,5,10,'S10',3,2,1,'2026-04-03 08:39:47'),(127,5,11,'S11',3,3,1,'2026-04-03 08:39:47'),(128,5,12,'S12',3,4,1,'2026-04-03 08:39:47'),(129,5,13,'S13',4,1,1,'2026-04-03 08:39:47'),(130,5,14,'S14',4,2,1,'2026-04-03 08:39:47'),(131,5,15,'S15',4,3,1,'2026-04-03 08:39:47'),(132,5,16,'S16',4,4,1,'2026-04-03 08:39:47'),(133,5,17,'S17',5,1,1,'2026-04-03 08:39:47'),(134,5,18,'S18',5,2,1,'2026-04-03 08:39:47'),(135,5,19,'S19',5,3,1,'2026-04-03 08:39:47'),(136,5,20,'S20',5,4,1,'2026-04-03 08:39:47'),(137,5,21,'S21',6,1,1,'2026-04-03 08:39:47'),(138,5,22,'S22',6,2,1,'2026-04-03 08:39:47'),(139,5,23,'S23',6,3,1,'2026-04-03 08:39:47'),(140,5,24,'S24',6,4,1,'2026-04-03 08:39:47'),(141,5,25,'S25',7,1,1,'2026-04-03 08:39:47'),(142,5,26,'S26',7,2,1,'2026-04-03 08:39:47'),(143,5,27,'S27',7,3,1,'2026-04-03 08:39:47'),(144,5,28,'S28',7,4,1,'2026-04-03 08:39:47'),(145,5,29,'S29',8,1,1,'2026-04-03 08:39:47'),(146,5,30,'S30',8,2,1,'2026-04-03 08:39:47'),(147,5,31,'S31',8,3,1,'2026-04-03 08:39:47'),(148,5,32,'S32',8,4,1,'2026-04-03 08:39:47');
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `terminals`
--

DROP TABLE IF EXISTS `terminals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `terminals` (
  `terminal_id` int(11) NOT NULL AUTO_INCREMENT,
  `terminal_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`terminal_id`),
  UNIQUE KEY `terminal_name` (`terminal_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `terminals`
--

LOCK TABLES `terminals` WRITE;
/*!40000 ALTER TABLE `terminals` DISABLE KEYS */;
INSERT INTO `terminals` VALUES (1,'Gonzaga Terminal','Gonzaga, Cagayan','Municipal Bus Terminal, Centro, Gonzaga, Cagayan','0912-345-0101','gonzaga.terminal@local.test','2026-04-03 08:01:10'),(2,'Sampaloc Terminal','Sampaloc, Manila','Sampaloc, City of Manila','0912-345-0102','sampaloc.terminal@local.test','2026-04-03 08:01:10'),(3,'Cubao Terminal','Cubao, Quezon City','New York Avenue, Cubao, Quezon City','0912-345-0103','cubao.terminal@local.test','2026-04-03 08:01:10');
/*!40000 ALTER TABLE `terminals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `booking_id` int(11) NOT NULL,
  `passenger_id` int(11) DEFAULT NULL,
  `schedule_id` int(11) NOT NULL,
  `seat_id` int(11) NOT NULL,
  `ticket_code` varchar(40) DEFAULT NULL,
  `qr_payload` longtext DEFAULT NULL,
  `qr_signature` varchar(128) DEFAULT NULL,
  `ticket_status` varchar(20) NOT NULL DEFAULT 'reserved',
  `issued_at` datetime DEFAULT NULL,
  `used_at` datetime DEFAULT NULL,
  `scanned_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ticket_id`),
  UNIQUE KEY `uniq_schedule_seat` (`schedule_id`,`seat_id`),
  UNIQUE KEY `ticket_code` (`ticket_code`),
  KEY `idx_tickets_booking` (`booking_id`),
  KEY `fk_tickets_passenger` (`passenger_id`),
  KEY `fk_tickets_seat` (`seat_id`),
  CONSTRAINT `fk_tickets_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`booking_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tickets_passenger` FOREIGN KEY (`passenger_id`) REFERENCES `passengers` (`passenger_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tickets_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`schedule_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tickets_seat` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (27,24,30,8,74,'TKT260403EV722DZA','eyJ0aWNrZXRfY29kZSI6IlRLVDI2MDQwM0VWNzIyRFpBIiwiYm9va2luZ19yZWZlcmVuY2UiOiJHT04yNjA0MDNMOTZER1lBVCIsInBhc3Nlbmdlcl9uYW1lIjoiUGFzc2VuZ2VyIiwic2VhdCI6IlMxNiIsInJvdXRlIjoiR29uemFnYSBUZXJtaW5hbCB0byBDdWJhbyBUZXJtaW5hbCIsImRlcGFydHVyZV9kYXRlIjoiMjAyNi0wNC0wNCIsImRlcGFydHVyZV90aW1lIjoiMTQ6MzA6MDAifQ==','b10dfff9248efdcdb35b93c994269a87757cf7d2d535e486b8732f2023f9a0d7','issued','2026-04-03 22:51:19',NULL,NULL,'2026-04-03 14:51:17');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `travel_guides`
--

DROP TABLE IF EXISTS `travel_guides`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `travel_guides` (
  `guide_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `author_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`guide_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `travel_guides_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `travel_guides`
--

LOCK TABLES `travel_guides` WRITE;
/*!40000 ALTER TABLE `travel_guides` DISABLE KEYS */;
/*!40000 ALTER TABLE `travel_guides` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_admin` int(11) DEFAULT 0,
  `account_status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login_at` datetime DEFAULT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (2,'jm mape','jm@gmail.com','09565780262','$2y$10$WW54O3O4niPR4lyVBmusxeZgRpzlRr8L6jxiEkk6pMFz9TrjVSPea',3,'masi',0,'active','2026-04-02 11:33:59','2026-04-03 13:22:55','2026-04-03 21:22:55','2026-04-03 21:22:55'),(3,'jm pogi','jm123@gmail.com','199','$2y$10$5K.AEES/zHpWUhd6q5zAh.QfjIZrxceq6Ud7Qr7jDMAm3XAAOHPlG',3,'masi',0,'active','2026-04-03 08:43:11','2026-04-03 15:03:33','2026-04-03 23:03:33','2026-04-03 23:03:33'),(4,'Main Admin','admin@gmail.com','+639171234567','$2y$10$GFBC7F2xVeYU4zNx2nWJ6OfvYSuAkQE8nRaWRnRiPA87.1QHKQh3O',1,NULL,1,'active','2026-04-03 09:23:45','2026-04-03 15:12:08','2026-04-03 23:04:53','2026-04-03 23:04:53'),(6,'Admin User','admin@victoryliner.com','','$2y$10$OrX1lHtB8LME3WtLXxDcG.EX6koVHz5FoJo978ZUE2iKaOy4EIlde',1,NULL,1,'active','2026-04-03 10:35:26','2026-04-03 15:12:08','2026-04-03 18:38:17','2026-04-03 18:38:17'),(8,'Operations Staff','staff@gmail.com','+639170001111','$2y$10$b4HjWM8tbP7GcnFFDcN03.OTKr.dNIgzplN.C2ES2EIdwHUi9URFC',2,NULL,0,'active','2026-04-03 10:42:44','2026-04-03 15:12:08','2026-04-03 23:02:27','2026-04-03 23:02:27');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-04 20:56:27
