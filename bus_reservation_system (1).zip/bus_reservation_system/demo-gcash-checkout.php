<?php
define('BUS_DEMO_GCASH_REQUEST', true);
require_once __DIR__ . '/includes/config.php';

if (!demo_gcash_is_enabled()) {
    http_response_code(404);
    exit('Development QR checkout is disabled.');
}

$token = trim((string) ($_GET['token'] ?? $_POST['token'] ?? ''));
$checkout = get_demo_gcash_checkout($token);
$error = '';
$completed = false;
$bookingId = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $result = complete_demo_gcash_payment($token);
    if ($result['ok']) {
        $completed = true;
        $bookingId = (int) ($result['booking_id'] ?? ($checkout['booking_id'] ?? 0));
        $checkout = get_demo_gcash_checkout($token) ?? $checkout;
    } else {
        $error = (string) ($result['message'] ?? 'Unable to complete the development payment.');
    }
}

if (!$checkout) {
    http_response_code(404);
    exit('This development QR checkout is invalid or has expired.');
}

$departureLabel = '';
if (!empty($checkout['departure_date']) && !empty($checkout['departure_time'])) {
    $departureLabel = date('M j, Y g:i A', strtotime($checkout['departure_date'] . ' ' . $checkout['departure_time']));
}
$checkoutUrl = demo_gcash_checkout_url($token);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Development QR Checkout</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { color-scheme: light; --navy: #101f46; --red: #d92d20; --ink: #172033; --muted: #667085; --line: #e4e7ec; }
        * { box-sizing: border-box; }
        body { background: linear-gradient(145deg, #eef3ff 0%, #f8fafc 52%, #fff4f2 100%); color: var(--ink); font-family: "Segoe UI", sans-serif; margin: 0; min-height: 100vh; }
        .shell { margin: 0 auto; max-width: 960px; padding: 2rem 1rem 4rem; }
        .brand { color: var(--navy); font-size: .78rem; font-weight: 800; letter-spacing: .12em; margin-bottom: 1rem; text-transform: uppercase; }
        .back-home { color: var(--navy); display: inline-flex; font-size: .88rem; font-weight: 700; gap: .45rem; margin-bottom: 1rem; text-decoration: none; }
        .back-home:hover { color: var(--red); }
        .layout { background: #fff; border: 1px solid var(--line); border-radius: 1.4rem; box-shadow: 0 24px 70px rgba(16, 31, 70, .12); display: grid; grid-template-columns: minmax(0, 1fr) 320px; overflow: hidden; }
        .intro { background: var(--navy); color: #fff; padding: clamp(1.5rem, 4vw, 3rem); }
        .intro h1 { font-size: clamp(1.8rem, 4vw, 2.8rem); line-height: 1.06; margin: 0 0 .8rem; }
        .intro p { color: #d8e1ff; line-height: 1.6; margin: 0; max-width: 34rem; }
        .details { display: grid; gap: .8rem; margin-top: 2rem; }
        .detail { border-top: 1px solid rgba(255,255,255,.16); padding-top: .75rem; }
        .detail span { color: #aebcf0; display: block; font-size: .7rem; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }
        .detail strong { display: block; font-size: .95rem; margin-top: .2rem; }
        .checkout { padding: clamp(1.5rem, 4vw, 2.4rem); text-align: center; }
        .badge { color: var(--red); font-size: .72rem; font-weight: 800; letter-spacing: .08em; text-transform: uppercase; }
        .checkout h2 { color: var(--navy); margin: .45rem 0 .3rem; }
        .amount { color: var(--navy); font-size: 1.7rem; font-weight: 800; margin: 1rem 0; }
        #qr { align-items: center; background: #fff; border: 1px solid var(--line); border-radius: 1rem; display: flex; justify-content: center; margin: 0 auto 1rem; min-height: 220px; padding: 1rem; width: 220px; }
        .hint { color: var(--muted); font-size: .86rem; line-height: 1.5; margin: 0 auto 1.2rem; max-width: 18rem; }
        .button { background: linear-gradient(180deg, #ef3e38, var(--red)); border: 0; border-radius: .75rem; box-shadow: 0 10px 18px rgba(217,45,32,.2); color: #fff; cursor: pointer; display: block; font-size: .95rem; font-weight: 800; padding: .85rem 1rem; width: 100%; }
        .button:hover { filter: brightness(1.04); }
        .notice { border-radius: .75rem; font-size: .88rem; line-height: 1.45; margin-bottom: 1rem; padding: .8rem; }
        .notice.error { background: #fef3f2; color: #b42318; }
        .notice.success { background: #ecfdf3; color: #027a48; }
        .success-icon { color: #039855; font-size: 3rem; margin: 1rem 0 .4rem; }
        .fine-print { color: var(--muted); font-size: .75rem; line-height: 1.45; margin-top: 1rem; }
        @media (max-width: 700px) { .layout { grid-template-columns: 1fr; } .intro { padding-bottom: 2rem; } }
    </style>
</head>
<body>
<main class="shell">
    <a class="back-home" href="index.php"><i class="fa-solid fa-arrow-left"></i> Back to homepage</a>
    <div class="brand"><i class="fa-solid fa-bus"></i> Gonzaga Terminal development checkout</div>
    <section class="layout">
        <div class="intro">
            <h1>Scan, complete, and issue.</h1>
            <p>This private development checkout simulates a successful GCash payment. It never contacts a payment provider and never moves money.</p>
            <div class="details">
                <div class="detail"><span>Booking</span><strong><?php echo e((string) $checkout['booking_reference']); ?></strong></div>
                <div class="detail"><span>Route</span><strong><?php echo e((string) $checkout['origin_name'] . ' to ' . (string) $checkout['destination_name']); ?></strong></div>
                <div class="detail"><span>Departure</span><strong><?php echo e($departureLabel); ?></strong></div>
            </div>
        </div>
        <div class="checkout">
            <?php if ($error !== ''): ?><div class="notice error"><?php echo e($error); ?></div><?php endif; ?>
            <?php if ($completed): ?>
                <div class="success-icon"><i class="fa-solid fa-circle-check"></i></div>
                <h2>Ticket issued automatically</h2>
                <div class="notice success">The demo payment is recorded, the booking is confirmed, and the signed passenger ticket QR code is ready on the customer booking.</div>
                <p class="fine-print">Return to the original browser or device to open the e-ticket. Booking ID: <?php echo $bookingId; ?>.</p>
            <?php elseif ((string) ($checkout['status'] ?? '') === 'paid'): ?>
                <div class="success-icon"><i class="fa-solid fa-circle-check"></i></div>
                <h2>Already completed</h2>
                <div class="notice success">This demo payment was already completed and the ticket was issued.</div>
            <?php else: ?>
                <div class="badge">No money charged</div>
                <h2>Scan this QR code</h2>
                <p class="amount">PHP <?php echo number_format((float) $checkout['amount'], 2); ?></p>
                <div id="qr" aria-label="Development checkout QR code"></div>
                <p class="hint">Scan with a phone, open the checkout, then press the button below to simulate a successful payment.</p>
                <form method="post">
                    <input type="hidden" name="token" value="<?php echo e($token); ?>">
                    <button class="button" type="submit"><i class="fa-solid fa-check me-2"></i>Complete Demo Payment</button>
                </form>
                <p class="fine-print">The same completion path confirms the booking and issues the final ticket that staff can scan.</p>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php if (!$completed && (string) ($checkout['status'] ?? '') !== 'paid'): ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<script>new QRCode(document.getElementById('qr'), { text: <?php echo json_encode($checkoutUrl, JSON_UNESCAPED_SLASHES); ?>, width: 190, height: 190, correctLevel: QRCode.CorrectLevel.M });</script>
<?php endif; ?>
</body>
</html>
