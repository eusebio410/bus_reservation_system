<?php
$base_url = '';
$page_title = 'FAQ - Victory Liner';

include 'includes/config.php';

$faqs_query = "SELECT * FROM faqs ORDER BY category ASC, faq_id ASC";
$faqs_result = $conn->query($faqs_query);

$faqs = [];
$total_questions = 0;

if ($faqs_result && $faqs_result->num_rows > 0) {
    while ($faq = $faqs_result->fetch_assoc()) {
        $category = trim((string) ($faq['category'] ?? '')) ?: 'General';

        if (!isset($faqs[$category])) {
            $faqs[$category] = [];
        }

        $faqs[$category][] = $faq;
        $total_questions++;
    }
}

$total_categories = count($faqs);

include 'includes/header.php';
?>

<style>
.page-faq {
    background: #eef1f5;
}

.page-faq .site-main {
    padding: 0;
}

.page-faq footer {
    margin-top: 0 !important;
}

.page-faq .faq-hero {
    background:
        linear-gradient(90deg, rgba(10, 18, 34, 0.88) 0%, rgba(10, 18, 34, 0.74) 30%, rgba(10, 18, 34, 0.44) 100%),
        url('assets/images/bus-terminal-hero-v2.jpg') center center / cover no-repeat;
    min-height: 28rem;
    overflow: hidden;
    position: relative;
}

.page-faq .faq-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.16) 0%, rgba(7, 12, 24, 0.28) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-faq .faq-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 28rem;
    padding: 4.8rem 0 3.5rem;
    position: relative;
    z-index: 1;
}

.page-faq .faq-hero__copy {
    max-width: 56rem;
}

.page-faq .faq-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.8rem, 4.8vw, 4.4rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.2rem;
}

.page-faq .faq-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.06rem, 0.97rem + 0.36vw, 1.34rem);
    line-height: 1.52;
    margin: 0 0 1.7rem;
    max-width: 48rem;
}

.page-faq .faq-hero__stats {
    display: flex;
    flex-wrap: wrap;
    gap: 0.8rem;
}

.page-faq .faq-hero__stats span {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 0.92rem;
    font-weight: 700;
    gap: 0.5rem;
    padding: 0.65rem 0.95rem;
}

.page-faq .faq-section {
    padding: 3.6rem 0 5.2rem;
}

.page-faq .faq-category + .faq-category {
    margin-top: 2rem;
}

.page-faq .faq-category__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.55rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 1rem;
}

.page-faq .faq-stack {
    display: grid;
    gap: 1rem;
}

.page-faq .faq-item {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.2rem;
    box-shadow: 0 16px 28px rgba(15, 23, 42, 0.05);
    overflow: hidden;
}

.page-faq .faq-question {
    align-items: center;
    background: #fff;
    border: none;
    color: #08152f;
    cursor: pointer;
    display: flex;
    font-family: inherit;
    font-size: 1.02rem;
    font-weight: 700;
    gap: 1rem;
    justify-content: space-between;
    padding: 1.2rem 1.3rem;
    text-align: left;
    width: 100%;
}

.page-faq .faq-question span {
    flex: 1;
}

.page-faq .faq-toggle {
    align-items: center;
    background: #f8fafc;
    border-radius: 999px;
    color: #a72d2d;
    display: inline-flex;
    flex: 0 0 auto;
    font-size: 0.88rem;
    height: 2rem;
    justify-content: center;
    transition: transform 0.2s ease, background-color 0.2s ease;
    width: 2rem;
}

.page-faq .faq-question[aria-expanded="true"] .faq-toggle {
    background: #fdeceb;
    transform: rotate(180deg);
}

.page-faq .faq-answer {
    border-top: 1px solid #eaecf0;
    color: #475467;
    display: none;
    line-height: 1.7;
    padding: 1rem 1.3rem 1.25rem;
}

.page-faq .faq-answer.is-open {
    display: block;
}

.page-faq .faq-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-faq .faq-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.6rem;
    justify-content: center;
    margin-bottom: 1.25rem;
    width: 4.6rem;
}

.page-faq .faq-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-faq .faq-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-faq .faq-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-faq .faq-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 767px) {
    .page-faq .faq-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<section class="faq-hero">
    <div class="container faq-hero__inner">
        <div class="faq-hero__copy">
            <h1 class="faq-hero__title">Frequently Asked Questions</h1>
            <p>Find quick answers about booking, refunds, baggage, schedules, and travel policies before your next Victory Liner trip.</p>
            <div class="faq-hero__stats">
                <span><i class="fas fa-circle-question"></i> <?php echo number_format($total_questions); ?> answers available</span>
                <span><i class="fas fa-layer-group"></i> <?php echo number_format($total_categories); ?> help categories</span>
                <span><i class="fas fa-headset"></i> Passenger support reference</span>
            </div>
        </div>
    </div>
</section>

<section class="faq-section">
    <div class="container">
        <?php if (!empty($faqs)): ?>
            <?php foreach ($faqs as $category => $items): ?>
                <section class="faq-category">
                    <h2 class="faq-category__title"><?php echo htmlspecialchars($category); ?></h2>
                    <div class="faq-stack">
                        <?php foreach ($items as $index => $faq): ?>
                            <?php $faq_id = 'faq-' . md5($category . '-' . $index . '-' . $faq['faq_id']); ?>
                            <article class="faq-item">
                                <button class="faq-question" type="button" aria-expanded="false" aria-controls="<?php echo htmlspecialchars($faq_id); ?>">
                                    <span><?php echo htmlspecialchars($faq['question']); ?></span>
                                    <span class="faq-toggle"><i class="fas fa-chevron-down"></i></span>
                                </button>
                                <div class="faq-answer" id="<?php echo htmlspecialchars($faq_id); ?>">
                                    <?php echo nl2br(htmlspecialchars($faq['answer'])); ?>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="faq-empty-state">
                <span class="faq-empty-state__icon"><i class="fas fa-circle-question"></i></span>
                <h2>No FAQs available</h2>
                <p>Help topics have not been added yet. Once FAQs are created in the admin panel, they will appear here by category.</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<a href="booking.php" class="faq-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.faq-question').forEach(function (button) {
        button.addEventListener('click', function () {
            const answer = document.getElementById(button.getAttribute('aria-controls'));
            const isOpen = button.getAttribute('aria-expanded') === 'true';

            button.setAttribute('aria-expanded', isOpen ? 'false' : 'true');

            if (answer) {
                answer.classList.toggle('is-open', !isOpen);
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
