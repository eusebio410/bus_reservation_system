<?php
$base_url = '';

include 'includes/config.php';

$view = isset_get('view');
$view = in_array($view, ['rates', 'bus-fares'], true) ? $view : 'bus-fares';
$page_title = $view === 'rates' ? 'Rates & Services - Gonzaga Terminal' : 'Bus Fares - Gonzaga Terminal';

$format_place_label = static function ($location, $terminal_name) {
    $location = trim((string) $location);

    if ($location !== '') {
        $parts = explode(',', $location);
        $label = trim($parts[0]);
    } else {
        $label = preg_replace('/\s+Terminal$/i', '', (string) $terminal_name);
    }

    $label = preg_replace('/\s+City$/i', '', $label);

    return $label !== '' ? $label : (string) $terminal_name;
};

$normalize_class_name = static function ($class_name) {
    $class_map = [
        'Regular AC' => 'Regular AC',
        'First Class / Deluxe' => 'Deluxe',
        'Premium - Victory Royal Sleeper' => 'Sleeper',
    ];

    $class_name = trim((string) $class_name);

    return $class_map[$class_name] ?? $class_name;
};

$format_duration = static function ($minutes) {
    $minutes = max(0, (int) $minutes);

    if ($minutes === 0) {
        return 'Schedule varies';
    }

    $high = max(1, (int) ceil($minutes / 60));
    $low = max(1, $high - 1);

    if ($low === $high) {
        return $high . ' hr' . ($high === 1 ? '' : 's');
    }

    return $low . '-' . $high . ' hrs';
};

$rates_groups = [];
$detailed_fares_result = null;
$detailed_fares_total = 0;

if ($view === 'rates') {
    $rates_query = "
        SELECT
            r.route_id,
            t1.terminal_name AS origin_terminal_name,
            t1.location AS origin_location,
            t2.terminal_name AS destination_terminal_name,
            t2.location AS destination_location,
            r.distance,
            r.travel_time,
            MIN(f.base_fare) AS starting_fare,
            GROUP_CONCAT(
                DISTINCT bc.class_name
                ORDER BY FIELD(bc.class_name, 'Regular AC', 'First Class / Deluxe', 'Premium - Victory Royal Sleeper'), bc.class_name
                SEPARATOR '|'
            ) AS class_names_raw
        FROM routes r
        JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
        JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
        LEFT JOIN fares f ON f.route_id = r.route_id
        LEFT JOIN bus_classes bc ON f.class_id = bc.class_id
        GROUP BY
            r.route_id,
            t1.terminal_name,
            t1.location,
            t2.terminal_name,
            t2.location,
            r.distance,
            r.travel_time
        ORDER BY t1.terminal_name ASC, t2.terminal_name ASC
    ";

    $rates_result = $conn->query($rates_query);

    if ($rates_result && $rates_result->num_rows > 0) {
        while ($rate = $rates_result->fetch_assoc()) {
            $origin_group = $format_place_label($rate['origin_location'] ?? '', $rate['origin_terminal_name'] ?? '');
            $class_labels = array_values(array_unique(array_filter(array_map($normalize_class_name, explode('|', (string) ($rate['class_names_raw'] ?? ''))))));

            $highlights = $class_labels;

            if (count($highlights) < 2) {
                $highlights[] = 'Direct Route';
            }

            if (count($highlights) < 3 && !empty($rate['distance'])) {
                $highlights[] = number_format((float) $rate['distance'], 0) . ' km';
            }

            $rate['origin_group'] = $origin_group;
            $rate['destination_label'] = $format_place_label($rate['destination_location'] ?? '', $rate['destination_terminal_name'] ?? '');
            $rate['class_labels'] = array_slice($highlights, 0, 3);

            $rates_groups[$origin_group][] = $rate;
        }
    }
} else {
    $detailed_fares_query = "
        SELECT
            f.fare_id,
            r.route_id,
            t1.terminal_name AS origin_name,
            t1.location AS origin_location,
            t2.terminal_name AS destination_name,
            t2.location AS destination_location,
            bc.class_name,
            f.base_fare,
            f.discount_percentage,
            r.travel_time,
            r.distance
        FROM fares f
        JOIN routes r ON f.route_id = r.route_id
        JOIN bus_classes bc ON f.class_id = bc.class_id
        JOIN terminals t1 ON r.origin_terminal_id = t1.terminal_id
        JOIN terminals t2 ON r.destination_terminal_id = t2.terminal_id
        ORDER BY t1.terminal_name ASC, t2.terminal_name ASC, FIELD(bc.class_name, 'Regular AC', 'First Class / Deluxe', 'Premium - Victory Royal Sleeper'), bc.class_name ASC
    ";

    $detailed_fares_result = $conn->query($detailed_fares_query);
    $detailed_fares_total = $detailed_fares_result ? $detailed_fares_result->num_rows : 0;
}

include 'includes/header.php';
?>

<style>
.page-fares {
    background: #eef1f5;
}

.page-fares .site-main {
    padding: 0;
}

.page-fares footer {
    margin-top: 0 !important;
}

.page-fares .rates-hero {
    background:
        linear-gradient(90deg, rgba(12, 19, 34, 0.88) 0%, rgba(12, 19, 34, 0.74) 30%, rgba(12, 19, 34, 0.4) 100%),
        url('assets/images/bus-terminal-hero-v3.jpg') center center / cover no-repeat;
    min-height: 24.5rem;
    overflow: hidden;
    position: relative;
}

.page-fares .rates-hero::before {
    background: linear-gradient(180deg, rgba(7, 12, 24, 0.18) 0%, rgba(7, 12, 24, 0.22) 100%);
    content: '';
    inset: 0;
    position: absolute;
}

.page-fares .rates-hero__inner {
    align-items: flex-start;
    display: flex;
    min-height: 24.5rem;
    padding: 3.4rem 0 3rem;
    position: relative;
    z-index: 1;
}

.page-fares .rates-hero__copy {
    max-width: 52rem;
}

.page-fares .rates-hero__title {
    color: #fff;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.7rem, 4.6vw, 4.2rem);
    font-weight: 800;
    letter-spacing: -0.06em;
    line-height: 0.98;
    margin: 0 0 1.2rem;
    text-shadow: 0 6px 18px rgba(8, 12, 24, 0.32);
}

.page-fares .rates-hero__copy p {
    color: rgba(255, 255, 255, 0.9);
    font-size: clamp(1.05rem, 0.96rem + 0.35vw, 1.35rem);
    line-height: 1.5;
    margin: 0 0 1.8rem;
    max-width: 46rem;
}

.page-fares .rates-hero__notice {
    align-items: center;
    background: rgba(80, 66, 16, 0.84);
    border: 1px solid rgba(248, 201, 72, 0.28);
    border-radius: 1rem;
    box-shadow: 0 14px 30px rgba(8, 12, 24, 0.22);
    color: #fff4c7;
    display: inline-flex;
    font-size: 0.94rem;
    font-weight: 600;
    gap: 0.8rem;
    max-width: 44rem;
    padding: 0.9rem 1.1rem;
}

.page-fares .rates-hero__notice i {
    color: #ffcf3f;
}

.page-fares .rates-section {
    padding: 4.1rem 0 5.2rem;
}

.page-fares .rates-section-heading {
    margin-bottom: 3rem;
    text-align: center;
}

.page-fares .rates-section-heading h2 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: clamp(2.2rem, 2vw + 1rem, 3.3rem);
    font-weight: 800;
    letter-spacing: -0.05em;
    margin: 0 0 0.9rem;
}

.page-fares .rates-section-heading p {
    color: #475467;
    font-size: 1.06rem;
    margin: 0;
}

.page-fares .rates-origin-block + .rates-origin-block {
    margin-top: 2.9rem;
}

.page-fares .rates-origin-heading {
    align-items: center;
    color: #08152f;
    display: inline-flex;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.5rem;
    font-weight: 800;
    gap: 0.9rem;
    letter-spacing: -0.04em;
    margin-bottom: 1.4rem;
}

.page-fares .rates-origin-heading i {
    align-items: center;
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    height: 2.2rem;
    justify-content: center;
    width: 2.2rem;
}

.page-fares .rates-card-grid {
    display: grid;
    gap: 1.25rem;
    grid-template-columns: repeat(3, minmax(0, 1fr));
}

.page-fares .rate-route-card {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.25rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    min-height: 100%;
    overflow: hidden;
}

.page-fares .rate-route-card__body {
    padding: 1.35rem 1.35rem 1rem;
}

.page-fares .rate-route-card__head {
    align-items: flex-start;
    display: flex;
    gap: 0.95rem;
}

.page-fares .rate-route-card__icon {
    align-items: center;
    background: linear-gradient(180deg, #cf2020 0%, #a72d2d 100%);
    border-radius: 0.95rem;
    color: #fff;
    display: inline-flex;
    flex: 0 0 auto;
    font-size: 1.05rem;
    height: 2.9rem;
    justify-content: center;
    width: 2.9rem;
}

.page-fares .rate-route-card__title {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.42rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    line-height: 1.15;
    margin: 0 0 0.45rem;
}

.page-fares .rate-route-card__pill {
    background: #fff5f1;
    border: 1px solid rgba(167, 45, 45, 0.16);
    border-radius: 999px;
    color: #a72d2d;
    display: inline-flex;
    font-size: 0.72rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    margin-bottom: 0.55rem;
    padding: 0.3rem 0.6rem;
    text-transform: uppercase;
}

.page-fares .rate-route-card__subtitle {
    align-items: center;
    color: #475467;
    display: inline-flex;
    font-size: 0.94rem;
    gap: 0.45rem;
    margin: 0;
}

.page-fares .rate-route-card__subtitle i {
    color: #344054;
}

.page-fares .rate-route-card__chips {
    display: flex;
    flex-wrap: wrap;
    gap: 0.55rem;
    margin-top: 1rem;
}

.page-fares .rate-route-card__chip {
    background: #d92d20;
    border-radius: 999px;
    color: #fff;
    display: inline-flex;
    font-size: 0.78rem;
    font-weight: 700;
    padding: 0.38rem 0.78rem;
}

.page-fares .rate-route-card__footer {
    align-items: center;
    border-top: 1px solid #eaecf0;
    display: flex;
    gap: 1rem;
    justify-content: space-between;
    margin-top: auto;
    padding: 0.95rem 1.35rem 1.05rem;
}

.page-fares .rate-route-card__meta {
    align-items: center;
    color: #344054;
    display: inline-flex;
    font-size: 0.94rem;
    gap: 0.45rem;
}

.page-fares .rate-route-card__meta i {
    color: #344054;
}

.page-fares .rate-route-card__cta {
    align-items: center;
    color: #d92d20;
    display: inline-flex;
    font-size: 1.55rem;
    font-weight: 800;
    gap: 0.75rem;
    text-decoration: none;
}

.page-fares .rate-route-card__cta strong {
    font-size: 1.05rem;
}

.page-fares .rate-route-card__cta:hover {
    color: #b42318;
}

.page-fares .rates-detail-shell {
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    overflow: hidden;
}

.page-fares .rates-detail-head {
    align-items: center;
    background: #fff;
    border-bottom: 1px solid #eaecf0;
    display: flex;
    justify-content: space-between;
    padding: 1.4rem 1.5rem;
}

.page-fares .rates-detail-head h2 {
    color: #08152f;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 1.45rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin: 0;
}

.page-fares .rates-detail-head span {
    background: #fdeceb;
    border-radius: 999px;
    color: #d92d20;
    font-size: 0.86rem;
    font-weight: 700;
    padding: 0.42rem 0.8rem;
}

.page-fares .rates-detail-table {
    margin: 0;
}

.page-fares .rates-detail-table thead th {
    background: #f8fafc;
    border-bottom: 1px solid #eaecf0;
    color: #475467;
    font-size: 0.84rem;
    font-weight: 800;
    letter-spacing: 0.04em;
    padding: 1rem 1.2rem;
    text-transform: uppercase;
}

.page-fares .rates-detail-table tbody td {
    border-bottom: 1px solid #f2f4f7;
    padding: 1rem 1.2rem;
    vertical-align: middle;
}

.page-fares .rates-detail-table tbody tr:last-child td {
    border-bottom: none;
}

.page-fares .rates-detail-table h3 {
    color: #08152f;
    font-size: 1rem;
    font-weight: 800;
    margin: 0 0 0.2rem;
}

.page-fares .rates-detail-table p {
    color: #667085;
    font-size: 0.9rem;
    margin: 0;
}

.page-fares .rates-class-pill,
.page-fares .rates-discount-pill {
    border-radius: 999px;
    display: inline-flex;
    font-size: 0.82rem;
    font-weight: 800;
    padding: 0.42rem 0.8rem;
}

.page-fares .rates-class-pill {
    background: #eef4ff;
    color: #175cd3;
}

.page-fares .rates-discount-pill {
    background: #ecfdf3;
    color: #027a48;
}

.page-fares .rates-discount-pill--none {
    background: #f2f4f7;
    color: #667085;
}

.page-fares .rates-price {
    color: #08152f;
    font-size: 1rem;
    font-weight: 800;
}

.page-fares .rates-price--final {
    color: #d92d20;
    font-size: 1.08rem;
}

.page-fares .rates-empty-state {
    align-items: center;
    background: rgba(255, 255, 255, 0.98);
    border: 1px solid rgba(208, 213, 221, 0.9);
    border-radius: 1.4rem;
    box-shadow: 0 18px 34px rgba(15, 23, 42, 0.07);
    display: flex;
    flex-direction: column;
    padding: 3rem 2rem;
    text-align: center;
}

.page-fares .rates-empty-state__icon {
    align-items: center;
    background: linear-gradient(180deg, #fff0ea 0%, #fcded5 100%);
    border-radius: 1.3rem;
    color: #ce2626;
    display: inline-flex;
    font-size: 1.8rem;
    height: 4.5rem;
    justify-content: center;
    margin-bottom: 1.2rem;
    width: 4.5rem;
}

.page-fares .rates-empty-state h2 {
    color: #101828;
    font-family: 'Sora', 'Plus Jakarta Sans', sans-serif;
    font-size: 2rem;
    font-weight: 800;
    letter-spacing: -0.04em;
    margin-bottom: 0.75rem;
}

.page-fares .rates-empty-state p {
    color: #475467;
    margin: 0;
    max-width: 34rem;
}

.page-fares .rates-floating-ticket {
    align-items: center;
    background: linear-gradient(180deg, #10a56d 0%, #0f9966 100%);
    border-radius: 999px;
    bottom: 1.8rem;
    box-shadow: 0 18px 32px rgba(16, 165, 109, 0.34);
    color: #fff;
    display: inline-flex;
    font-size: 1rem;
    font-weight: 800;
    gap: 0.7rem;
    padding: 1rem 1.55rem;
    position: fixed;
    right: 1.8rem;
    text-decoration: none;
    z-index: 1050;
}

.page-fares .rates-floating-ticket:hover {
    color: #fff;
    transform: translateY(-2px);
}

@media (max-width: 1199px) {
    .page-fares .rates-card-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
}

@media (max-width: 991px) {
    .page-fares .rates-hero {
        min-height: auto;
    }

    .page-fares .rates-hero__inner {
        min-height: auto;
        padding: 3rem 0 2.8rem;
    }
}

@media (max-width: 767px) {
    .page-fares .rates-card-grid {
        grid-template-columns: 1fr;
    }

    .page-fares .rates-detail-head {
        align-items: flex-start;
        flex-direction: column;
        gap: 0.9rem;
    }

    .page-fares .rate-route-card__footer {
        align-items: flex-start;
        flex-direction: column;
    }

    .page-fares .rates-floating-ticket {
        bottom: 1rem;
        left: 1rem;
        justify-content: center;
        right: 1rem;
    }
}
</style>

<?php if ($view === 'rates'): ?>
    <section class="rates-hero">
        <div class="container rates-hero__inner">
            <div class="rates-hero__copy">
                <h1 class="rates-hero__title">Rates &amp; Services</h1>
                <p>Explore Gonzaga Terminal fare options across the current route set. Compare starting prices, trip durations, and available bus classes before you book.</p>
                <div class="rates-hero__notice">
                    <i class="fas fa-circle-info"></i>
                    <span>Fares are indicative and subject to change. Senior citizens and PWDs may be eligible for standard discounts.</span>
                </div>
            </div>
        </div>
    </section>

    <section class="rates-section">
        <div class="container">
            <div class="rates-section-heading">
                <h2>Bus Fares</h2>
                <p>Check current fare rates for Gonzaga Terminal routes grouped by departure terminal.</p>
            </div>

            <?php if (!empty($rates_groups)): ?>
                <?php foreach ($rates_groups as $origin_group => $routes): ?>
                    <div class="rates-origin-block">
                        <div class="rates-origin-heading">
                            <i class="fas fa-bus-simple"></i>
                            <span>From <?php echo htmlspecialchars($origin_group); ?></span>
                        </div>

                        <div class="rates-card-grid">
                            <?php foreach ($routes as $route): ?>
                                <?php
                                $starting_fare = $route['starting_fare'] !== null ? (float) $route['starting_fare'] : null;
                                $duration_label = $format_duration($route['travel_time'] ?? 0);
                                ?>
                                <article class="rate-route-card">
                                    <div class="rate-route-card__body">
                                        <div class="rate-route-card__head">
                                            <span class="rate-route-card__icon"><i class="fas fa-bus-simple"></i></span>
                                            <div>
                                                <div class="rate-route-card__pill">Route Pairing</div>
                                                <h3 class="rate-route-card__title"><?php echo htmlspecialchars($route['origin_terminal_name'] ?? $origin_group); ?> → <?php echo htmlspecialchars($route['destination_terminal_name'] ?? $route['destination_label']); ?></h3>
                                                <p class="rate-route-card__subtitle">
                                                    <i class="fas fa-location-dot"></i>
                                                    <span><?php echo htmlspecialchars($route['destination_label']); ?> via <?php echo htmlspecialchars($route['destination_terminal_name'] ?? $route['destination_label']); ?></span>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="rate-route-card__chips">
                                            <?php foreach ($route['class_labels'] as $label): ?>
                                                <span class="rate-route-card__chip"><?php echo htmlspecialchars($label); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>

                                    <div class="rate-route-card__footer">
                                        <span class="rate-route-card__meta">
                                            <i class="fas fa-clock"></i>
                                            <?php echo htmlspecialchars($duration_label); ?>
                                        </span>

                                        <a class="rate-route-card__cta" href="booking.php?route_id=<?php echo (int) $route['route_id']; ?>">
                                            <?php if ($starting_fare !== null): ?>
                                                <strong>&#8369;<?php echo number_format($starting_fare, 0); ?>+</strong>
                                            <?php else: ?>
                                                <strong>See Fare</strong>
                                            <?php endif; ?>
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="rates-empty-state">
                    <span class="rates-empty-state__icon"><i class="fas fa-tag"></i></span>
                    <h2>No fare data available</h2>
                    <p>Route fares have not been added yet. Please check back later or contact the terminal for current pricing details.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php else: ?>
    <section class="rates-hero">
        <div class="container rates-hero__inner">
            <div class="rates-hero__copy">
                <h1 class="rates-hero__title">Bus Fares</h1>
                <p>Review the full fare matrix by route and bus class. Use this view when you want the detailed pricing breakdown for each fare entry.</p>
                <div class="rates-hero__notice">
                    <i class="fas fa-circle-info"></i>
                    <span>Displayed fares are base values from the system. Final paid amounts can vary based on discounts and fare policies.</span>
                </div>
            </div>
        </div>
    </section>

    <section class="rates-section">
        <div class="container">
            <div class="rates-section-heading">
                <h2>Detailed Fare List</h2>
                <p><?php echo number_format((int) $detailed_fares_total); ?> fare entries across routes and bus classes.</p>
            </div>

            <?php if ($detailed_fares_result && $detailed_fares_result->num_rows > 0): ?>
                <div class="rates-detail-shell">
                    <div class="rates-detail-head">
                        <h2>Complete Fare Matrix</h2>
                        <span>Bus Fares View</span>
                    </div>

                    <div class="table-responsive">
                        <table class="table rates-detail-table">
                            <thead>
                                <tr>
                                    <th>Route</th>
                                    <th>Class</th>
                                    <th>Duration</th>
                                    <th>Base Fare</th>
                                    <th>Discount</th>
                                    <th>Final Price</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($fare = $detailed_fares_result->fetch_assoc()): ?>
                                    <?php $final_price = (float) $fare['base_fare'] - ((float) $fare['base_fare'] * ((float) $fare['discount_percentage'] / 100)); ?>
                                    <tr>
                                        <td>
                                            <h3><?php echo htmlspecialchars($fare['origin_name']); ?> to <?php echo htmlspecialchars($fare['destination_name']); ?></h3>
                                            <p><?php echo htmlspecialchars($format_place_label($fare['destination_location'] ?? '', $fare['destination_name'] ?? '')); ?> Route</p>
                                        </td>
                                        <td>
                                            <span class="rates-class-pill"><?php echo htmlspecialchars($normalize_class_name($fare['class_name'] ?? '')); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($format_duration($fare['travel_time'] ?? 0)); ?></td>
                                        <td><span class="rates-price">&#8369;<?php echo number_format((float) $fare['base_fare'], 2); ?></span></td>
                                        <td>
                                            <?php if ((float) $fare['discount_percentage'] > 0): ?>
                                                <span class="rates-discount-pill"><?php echo number_format((float) $fare['discount_percentage'], 0); ?>% Off</span>
                                            <?php else: ?>
                                                <span class="rates-discount-pill rates-discount-pill--none">No Discount</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><span class="rates-price rates-price--final">&#8369;<?php echo number_format($final_price, 2); ?></span></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="rates-empty-state">
                    <span class="rates-empty-state__icon"><i class="fas fa-table"></i></span>
                    <h2>No fare entries found</h2>
                    <p>Add fare records in the admin panel to populate the detailed bus fares list.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>

<a href="booking.php" class="rates-floating-ticket">
    <i class="fas fa-ticket-alt"></i>
    <span>Find Tickets</span>
</a>

<?php include 'includes/footer.php'; ?>
