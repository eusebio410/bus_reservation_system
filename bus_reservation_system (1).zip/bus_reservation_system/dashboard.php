<?php
$page_title = 'Dashboard';
include 'includes/config.php';

if (!is_logged_in()) {
    redirect('login.php');
}

$userId = (int) $_SESSION['user_id'];

$user = db_select_one(
    'SELECT fullname, email, phone, account_status, created_at FROM users WHERE user_id = ? LIMIT 1',
    'i',
    [$userId]
);

if (!$user) {
    logout_user();
    redirect('login.php');
}

$summary = db_select_one(
    'SELECT COUNT(*) AS total_bookings,
            COALESCE(SUM(CASE WHEN status IN (\'pending\', \'payment_review\') THEN 1 ELSE 0 END), 0) AS pending_bookings,
            COALESCE(SUM(CASE WHEN payment_status = \'paid\' THEN 1 ELSE 0 END), 0) AS paid_bookings
     FROM bookings
     WHERE user_id = ?',
    'i',
    [$userId]
);

$upcomingTrips = db_select_all(
    "SELECT b.booking_reference, b.status, b.total_amount, b.number_of_passengers,
            s.departure_date, s.departure_time, s.arrival_time,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.user_id = ?
       AND s.departure_date >= CURDATE()
       AND b.status NOT IN ('cancelled', 'expired')
     ORDER BY s.departure_date ASC, s.departure_time ASC
     LIMIT 3",
    'i',
    [$userId]
);

$recentBookings = db_select_all(
    "SELECT b.booking_reference, b.status, b.total_amount, b.booking_date,
            origin.terminal_name AS origin_name,
            destination.terminal_name AS destination_name
     FROM bookings b
     JOIN schedules s ON b.schedule_id = s.schedule_id
     JOIN routes r ON s.route_id = r.route_id
     JOIN terminals origin ON r.origin_terminal_id = origin.terminal_id
     JOIN terminals destination ON r.destination_terminal_id = destination.terminal_id
     WHERE b.user_id = ?
     ORDER BY b.booking_date DESC
     LIMIT 4",
    'i',
    [$userId]
);

include 'includes/header.php';
?>

<section class="py-5">
    <div class="container">
        <div class="dashboard-shell rounded-4 shadow-sm overflow-hidden">
            <div class="dashboard-hero p-4 p-lg-5">
                <div class="row g-4 align-items-end">
                    <div class="col-lg-8 text-start">
                        <!-- Dashboard label removed per request -->
                        <h1 class="display-6 fw-bold mb-3">Welcome back, <?php echo e($user['fullname'] ?? 'traveler'); ?>.</h1>
                        <p class="mb-0 text-white-50">Manage bookings, review upcoming trips, and continue your journey with a faster, clearer travel dashboard.</p>
                    </div>
                    <div class="col-lg-4">
                        <div class="d-flex justify-content-end mb-3">
                            <a class="btn btn-outline-light me-2" href="profile.php"><i class="fa-solid fa-id-card me-1"></i> View Profile</a>
                            <a class="btn btn-light text-danger" href="booking.php"><i class="fa-solid fa-ticket me-1"></i> Book Now</a>
                        </div>
                        <div class="dashboard-hero-card">
                            <p class="small text-uppercase fw-bold mb-2">Account status</p>
                            <h3 class="fw-bold mb-1"><?php echo e(ucfirst((string) ($user['account_status'] ?? 'active'))); ?></h3>
                            <p class="small mb-0">Member since <?php echo e(date('M d, Y', strtotime((string) ($user['created_at'] ?? 'now')))); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="p-4 p-lg-5">
                <div class="row g-4 mb-4">
                    <div class="col-md-6 col-xl-3">
                        <div class="dashboard-card h-100">
                            <div class="dashboard-card-icon text-primary"><i class="fa-solid fa-ticket"></i></div>
                            <div>
                                <h3 class="fw-bold mb-1"><?php echo e((string) ($summary['total_bookings'] ?? 0)); ?></h3>
                                <p class="mb-0 text-muted">Total bookings</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="dashboard-card h-100">
                            <div class="dashboard-card-icon text-warning"><i class="fa-solid fa-clock"></i></div>
                            <div>
                                <h3 class="fw-bold mb-1"><?php echo e((string) ($summary['pending_bookings'] ?? 0)); ?></h3>
                                <p class="mb-0 text-muted">Pending actions</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="dashboard-card h-100">
                            <div class="dashboard-card-icon text-success"><i class="fa-solid fa-circle-check"></i></div>
                            <div>
                                <h3 class="fw-bold mb-1"><?php echo e((string) ($summary['paid_bookings'] ?? 0)); ?></h3>
                                <p class="mb-0 text-muted">Paid bookings</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="dashboard-card h-100">
                            <div class="dashboard-card-icon text-danger"><i class="fa-solid fa-bus"></i></div>
                            <div>
                                <h3 class="fw-bold mb-1"><?php echo count($upcomingTrips); ?></h3>
                                <p class="mb-0 text-muted">Upcoming trips</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="dashboard-card h-100">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div>
                                    <h2 class="h5 fw-bold mb-1">Upcoming travel</h2>
                                    <p class="text-muted mb-0">Keep an eye on your next departures and reservations.</p>
                                </div>
                                <a class="btn btn-outline-danger rounded-pill btn-sm" href="my-bookings.php">View all</a>
                            </div>

                            <?php if (!empty($upcomingTrips)): ?>
                                <div class="vstack gap-3">
                                    <?php foreach ($upcomingTrips as $trip): ?>
                                        <div class="dashboard-list-item p-3 rounded-4">
                                            <div class="d-flex justify-content-between align-items-start gap-3">
                                                <div>
                                                    <h3 class="h6 fw-bold mb-1"><?php echo e($trip['origin_name'] ?? 'Route'); ?> → <?php echo e($trip['destination_name'] ?? 'Destination'); ?></h3>
                                                    <p class="text-muted mb-1">Booking <?php echo e($trip['booking_reference'] ?? '-'); ?></p>
                                                    <p class="small mb-0"><i class="fa-solid fa-calendar-days me-2"></i><?php echo e(date('M d, Y', strtotime((string) ($trip['departure_date'] ?? '')))); ?> • <?php echo e((string) ($trip['departure_time'] ?? '')); ?></p>
                                                </div>
                                                <span class="badge rounded-pill bg-danger-subtle text-danger fw-semibold"><?php echo e(ucwords(str_replace('_', ' ', (string) ($trip['status'] ?? 'pending')))); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4 text-muted">
                                    <i class="fa-solid fa-route fs-1 d-block mb-3"></i>
                                    <p class="mb-0">No upcoming trips yet. Start by booking your next ride.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="dashboard-card h-100">
                            <h2 class="h5 fw-bold mb-3">Quick actions</h2>
                            <div class="vstack gap-2">
                                <a class="dashboard-action-link" href="booking.php"><i class="fa-solid fa-ticket"></i> Book a new trip</a>
                                <a class="dashboard-action-link" href="my-bookings.php"><i class="fa-solid fa-list-check"></i> Manage bookings</a>
                                <a class="dashboard-action-link" href="profile.php"><i class="fa-solid fa-user-gear"></i> Update profile</a>
                            </div>

                            <div class="mt-4 border-top pt-4">
                                <h3 class="h6 fw-bold mb-2">Recent activity</h3>
                                <?php if (!empty($recentBookings)): ?>
                                    <div class="vstack gap-2">
                                        <?php foreach ($recentBookings as $booking): ?>
                                            <div class="small text-muted">
                                                <strong><?php echo e($booking['booking_reference'] ?? '-'); ?></strong> • <?php echo e($booking['origin_name'] ?? '-'); ?> → <?php echo e($booking['destination_name'] ?? '-'); ?>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p class="small text-muted mb-0">Your recent travel activity will appear here.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
