<?php
$base_url = '';
include 'includes/config.php';

$guide_id = isset_get('id');

if (!$guide_id) {
    redirect('/travel-guides.php');
}

// Fetch travel guide
$guide_query = "SELECT * FROM travel_guides WHERE guide_id = " . intval($guide_id);
$guide_result = $conn->query($guide_query);

if ($guide_result->num_rows == 0) {
    redirect('/travel-guides.php');
}

$guide = $guide_result->fetch_assoc();
$page_title = $guide['title'] . ' - Gonzaga Terminal';
include 'includes/header.php';
?>
        <section style="background-color: #f8f9fa; padding: 40px 20px;">
            <div class="container" style="max-width: 800px;">
                <?php if ($guide['image_url']): ?>
                    <img src="<?php echo $guide['image_url']; ?>" alt="Travel Guide" style="width: 100%; height: 400px; object-fit: cover; border-radius: 8px; margin-bottom: 30px;">
                <?php endif; ?>

                <h1 style="color: #A72D2D; margin-bottom: 10px;"><?php echo $guide['title']; ?></h1>
                <p style="color: #999; margin-bottom: 30px;">Published: <?php echo date('M d, Y', strtotime($guide['created_at'])); ?></p>

                <div style="background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); line-height: 1.8;">
                    <?php echo $guide['content']; ?>
                </div>

                <div style="margin-top: 30px;">
                    <a href="travel-guides.php" class="btn-submit">← Back to Travel Guides</a>
                </div>
            </div>
        </section>
    <?php include 'includes/footer.php'; ?>
